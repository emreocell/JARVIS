# Jarvis

Sesli, Türkçe öncelikli kişisel asistan — **Windows ve macOS**. Python asyncio çekirdeği + React arayüzü,
pywebview ile yerel pencerelerde (Windows: WebView2, macOS: WKWebView).
Tasarım ve yol haritası: [docs/PLAN.md](docs/PLAN.md).

## Kurulum

| | Kurulum | Başlatma |
|---|---|---|
| **Windows 10/11** | `Kur.cmd`'ye çift tıkla | Başlat menüsü / masaüstü "Jarvis", ya da `Jarvis.cmd` |
| **macOS 12+** | `Kur.command`'a çift tıkla (ilk seferde sağ tık → Aç) ya da `bash scripts/install_mac.sh` | Launchpad / `~/Applications/Jarvis.app`, ya da `Jarvis.command` |

Kurulum eksikleri kendisi kurar (Python 3.12, uv, WebView2 / Homebrew paketleri, arayüz), kısayolları
oluşturur ve isterse bilgisayar açılınca başlatır. İlk açılışta **Modeller** sayfasından bir Gemini API
anahtarı eklemek yeterli (ücretsiz katman).

macOS ilk kullanımda şu izinleri sorar: Mikrofon, Erişilebilirlik (uygulamalarda tıklama/yazma),
Ekran Kaydı (ekrana bakma), Otomasyon (Spotify/Müzik/System Events), Giriş İzleme (kısayol tuşları).

## Neler yapabilir

- **Ses**: "Hey Jarvis" + Gemini Live; kesintisiz Türkçe konuşma, yedek ses hattı (Whisper → metin ajanı → TTS).
- **Hız**: Jev (TypeSafe) niyet yönlendirici — basit işler modele gitmeden ~0,3 sn; öğe seçimi (tarayıcı, uygulama).
- **Bilgisayar kontrolü**: uygulamalar, pencereler, dosyalar, medya, tarayıcı (CDP), uygulama içi tıklama/yazma
  (Windows UI Automation / macOS Accessibility). Her işlem **doğrulanır** (eylem → gözlem → doğrulama → kurtarma).
- **Evrensel "bu"**: seçili metin, kopyalanan, Gezgin'de seçili dosya, tarayıcı adresi.
- **Proaktif**: sabah özeti, önemli bildirimler, "sen yokken", pil; oyun/görüşme/toplantıda susar.
- **Bildirim zekası**, **iş günlüğü** ("Bugün ne yaptım?" + git), **ikinci beyin** (Markdown/Obsidian),
  **toplantı modu** (sessiz döküm + kararlar + aksiyonlar), **kişi hafızası**, **kişisel sözlük**.
- **Otonom görevler** (plan → araçlar → rapor, riskli adımda onay), **ekran üstü HUD**, **canlı çeviri** altyazısı.
- **Bağlantılar**: Gmail + Takvim (tarayıcı oturumu, API gerekmez), MCP sunucuları (Windows-MCP, Google API),
  Spotify, WhatsApp, Telegram uzaktan kontrol.

## Yapı

```
core/     Python çekirdeği (uv) — config, sırlar, sağlayıcılar, ses, araçlar, API
  src/jarvis/skills/        araçlar (Windows + mac_* macOS karşılıkları, aynı adlarla)
  src/jarvis/platform/mac.py AppleScript / NSWorkspace / Accessibility / Quartz yardımcıları
  src/jarvis/desktop/       Windows (app.py) ve macOS (mac_app.py) pencere kabukları, HUD
app/      React + TypeScript + Tailwind arayüzü (Vite → app/dist)
scripts/  install.ps1 (Windows), install_mac.sh (macOS)
```

Kullanıcı verisi: Windows `%LOCALAPPDATA%\Jarvis`, macOS `~/Library/Application Support/Jarvis`
(`JARVIS_HOME` ile değiştirilebilir). API anahtarları işletim sisteminin anahtar kasasında
(Windows Credential Manager / macOS Keychain) `Jarvis` adıyla saklanır.

## Geliştirme

Gerekenler: Python 3.12, [uv](https://docs.astral.sh/uv/), Node 22+.

```bash
cd core
uv sync
uv run python -m jarvis        # masaüstü uygulaması
uv run python -m jarvis.app    # yalnızca çekirdek (API)
uv run pytest                  # testler

cd app
npm install
npm run dev                    # http://127.0.0.1:5173 — çekirdeği runtime.json üzerinden bulur
npx vite build                 # app/dist (masaüstü uygulamasının yüklediği)
```

## Çekirdek API

Arayüz çekirdekle loopback WebSocket üzerinden konuşur. İlk çerçeve `{"type":"auth","token":...}`
(token `runtime.json`'da); çekirdek tam bir `snapshot` gönderir, ardından `event` çerçeveleri akar.
İstekler `{"id", "method", "params"}` biçimindedir. Bkz. `core/src/jarvis/api/`.
