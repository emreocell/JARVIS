# JARVIS v3 — Tasarım ve Yol Haritası

> Durum: taslak, tartışmaya açık · Son güncelleme: 2026-09-24
> Kod konumu: `C:\dev\jarvis` (git). Bu klasör (`main/`) plan ve tasarım dokümanları için.

---

## 1. Vizyon ve ilkeler

Windows için sesli, ekranı ve bağlamı anlayan, bilgisayarı gerçekten kontrol edebilen kişisel asistan.

| İlke | Ne demek |
|---|---|
| **Boşta sıfır maliyet** | Komut yokken ağ trafiği yok, API çağrısı yok, CPU < %2. Sadece yerel wake word / kısayol dinler. |
| **Ücretsiz katmanla çalışır** | Tasarım free-tier kotalarına göre yapılır; kota farkındalıklı yönlendirme. |
| **Dinamik** | Sağlayıcı, model, araç, bağlayıcı, wake word, özellik anahtarı — hepsi config/veri, kod değil. |
| **Önce yerel ve deterministik** | Hızlı komut → UIA → OCR → görüntü modeli sırası. LLM en son çare, en ucuz yol önce. |
| **Güvenli varsayılan** | Riskli işlemde onayı sistem ister (model değil). Web içeriği güvenilmez kabul edilir. |
| **Hafif** | UI kapatılabilir; çekirdek tray'de yaşar. Polling yok, olay tabanlı. Ağır modüller ilk kullanımda yüklenir. |

---

## 2. Mimari (özet)

```
 [Yerel, sürekli açık]   Wake word · Kısayol (bas-konuş) · Komut çubuğu · Rutin zamanlayıcı · Telegram
            │
            ▼
 [Ses hattı]  Gemini Live oturumu (wake word ile açılır, sessizlikte kapanır)
            │   alternatif: kademeli mod (STT → LLM → TTS)
            ▼
 [Orkestratör]  1) Hızlı komutlar (LLM'siz)  2) Karar katmanı (Jev / küçük LLM)  3) Ajan döngüsü
            │
            ▼
 [Araç çalıştırıcı]  izin kapısı · onay deposu · zaman aşımı · döngü koruması · injection taraması · denetim logu
            │
            ▼
 [Yetenekler]  Masaüstü (UIA/OCR/vision) · Tarayıcı (CDP) · Uygulama bağlayıcıları · MCP sunucuları

 [Ortak servisler]  Sağlayıcı kaydı + kota sayacı · Hafıza & bağlam (SQLite) · Olay yolu · Ayar şeması · Anahtar kasası
 [Arayüz]  Tauri 2 + React ── yerel WebSocket (kimlik doğrulamalı) ── Python çekirdek
```

**Süreç modeli:** Python çekirdek (tek asyncio event loop, bloklayan işler için worker havuzu) + Tauri uygulaması. Tauri çekirdeği başlatır/izler; UI kapansa da çekirdek tray'de çalışır. Arayüz bağlandığında önce tam durum görüntüsü, sonra değişiklik akışı gelir.

---

## 3. Model ve sağlayıcı stratejisi (free tier)

### 3.1 Kotaların gösterdiği gerçek
AI Studio free tier (hesap başına, 2026-09):

| Model grubu | RPM / TPM / RPD | Kullanım |
|---|---|---|
| **Live API** — `gemini-3.8-live`, `gemini-3.8-live-extended-thinking`, `gemini-3.1-flash-live-preview`, 2.5 Flash Native Audio | **Sınırsız** / 65K–1M / **Sınırsız** | **Ana beyin**: ses, düşünme, araç çağrısı, ekran görüntüsü |
| 3.5 Transcribe Live | Sınırsız / 20K / Sınırsız | Kademeli modda STT, dikte |
| Flash-Lite 3.1 / 3.5 | 15 / 250K / 500 | Arka plan metin işleri (hafıza çıkarma, özet) |
| Gemma 4 26B/31B | 30 / 16K / 14.4K | Kısa, sık metin işleri |
| Flash 3.x | 5 / 250K / 20 | Nadiren, zor metin görevleri |
| Embedding 1/2 | 100 / 30K / 1K | Hafıza vektörleri |
| Robotics ER 2 | 5 / 250K / 20 | Ekranda eleman konumu bulma (yedek) |
| TTS modelleri | 3 / 10K / 10 | Kullanılmaz (Live zaten konuşuyor) |

**Sonuç:** Konuşma, görme ve araç kullanımı Live üzerinden → sınırsız. Metin modelleri sadece arka plan işleri için, kotayı bilen havuzla.

### 3.2 Rol tabanlı yönlendirme
Roller: `voice_brain`, `fast_decider`, `text_worker`, `vision_ground`, `embedding`, `stt`. Her rol için öncelik listesi (arayüzden sürükle-bırak).

```yaml
providers:
  - id: gemini
    type: gemini                 # yerel adaptör (Live, görüntü, embedding)
    keys: [keyring:gemini_1, keyring:gemini_2, keyring:gemini_3]   # 1..N hesap
    quota_profile: gemini_free_2026   # RPM/RPD tablosu önceden yüklü, düzenlenebilir
  - id: groq
    type: openai_compatible
    base_url: https://api.groq.com/openai/v1
    keys: [keyring:groq_1]
  - id: jev
    type: typesafe
    base_url: https://ai-gateway.vercel.sh/typesafe   # Vercel AI Gateway, model: typesafe-ai/jev
    keys: [keyring:vercel_1]
  - id: benim-api
    type: custom                 # istek/cevap eşlemesi veya küçük Python adaptörü
```

- **Kota sayacı:** Her (anahtar, model) çifti için RPM/RPD yerelde sayılır (Gemini RPD Pasifik saati gece yarısı sıfırlanır). Router 429 beklemeden kotası kalan anahtarı seçer; 429 gelirse anahtar soğumaya alınır.
- **Tek adaptör, çok sağlayıcı:** OpenAI uyumlu her şey (Groq, OpenRouter, Cerebras, DeepSeek, Mistral, GitHub Models, NVIDIA NIM, Gemini'nin OpenAI endpoint'i) aynı adaptörle.
- **Circuit breaker + gecikme/başarı istatistiği** gerçek çağrılardan (aktif ping yok).
- **"Test et" butonu** yeni sağlayıcı eklerken.
- NVIDIA = sıradan bir sağlayıcı; hiçbir özellik ona bağlı değil.

### 3.3 Jev'in rolü (gecikme gerçeği)
İstanbul'dan ölçülen medyan ~1,3 sn (p90 > 2 sn) → **konuşma akışında değil**, şuralarda:
- Tarayıcı/masaüstü ajanında "hangi eleman / hangi işlem / görev bitti mi / takıldı mı"
- Hafıza aday sıralaması ve "bu hatırlanmaya değer mi"
- Rutin ve bildirim kararları ("bu bildirim önemli mi, kullanıcıyı rahatsız edeyim mi")
- Arka planda "bu işlem geri alınamaz mı" sınıflandırması
Arayüz: `Decider.choose/score/yes_no` → `JevDecider` ↔ `LLMDecider` (Groq/Gemma, JSON şema). Jev İngilizce odaklı → sorular İngilizce yazılır; Türkçe doğruluğu ölçülür, düşük güvende LLM'e düşer. Kill switch ve "gölge mod" (Jev'i çalıştır ama kararını kullanma, sadece karşılaştır).

---

## 4. Ses hattı

### 4.1 Tetikleme
- **Wake word motoru eklenti tabanlı:**
  - Varsayılan: openWakeWord `hey_jarvis` (model dosyası uygulamayla paketlenir).
  - Özel ifadeler ("naber jarvis", "uyan dostum"): aday Vosk Türkçe (35 MB) kısıtlı gramer modu — **Faz 1'de prototiple doğrulanacak**. Yedek: uygulama içinden openWakeWord özel model eğitimi; Porcupine opsiyonel.
  - Birden fazla ifade aynı anda; ifade başına hassasiyet.
- **Bas-konuş kısayolu**, komut çubuğu, tray tıklaması, Telegram.
- Yerel VAD (Silero) konuşma sonunu belirler.

### 4.2 Live oturumu
- Wake word → oturum açılır (hedef < 1 sn), ses gönderilir. Otomatik VAD kapatılabilir, `activity_start/end` bizim VAD'ımızdan gelir.
- **Takip penceresi:** cevaptan sonra N sn wake word'süz dinler (ayar).
- Sessizlik zaman aşımında oturum kapanır; **session resumption** (2 saat geçerli) + **context window compression** ile bağlam korunur; `GoAway` gelince sessizce yeniden bağlanır.
- 3.x Live modelleri sadece senkron araç çağrısı destekler → uzun işler hemen "başladım" cevabıyla arka plan görevine devredilir, bitince duyurulur.
- Sistem prompt'u kısa; araç rehberliği araç açıklamalarında. Sadece ilgili skill'lerin araçları yüklenir (dinamik araç seti).
- Anahtar havuzu Live için de geçerli (bağlantı hatasında sonraki hesap).

### 4.3 Kademeli mod (alternatif / yedek)
STT (3.5 Transcribe Live / Groq Whisper) → LLM (herhangi bir rol sağlayıcısı) → TTS (Edge TTS, resmi olmayan API). Live erişilemezse otomatik devreye girer.

### 4.4 Yankı ve araya girme — profil tabanlı
| Mod | Davranış | Ne zaman |
|---|---|---|
| Tam çift yönlü | WebRTC AEC + araya girme | Kulaklık, iyi mikrofon |
| Yarı çift yönlü | Jarvis konuşurken mikrofon kapalı | Yankı yapan mikrofon |
| Sadece tuş/wake word ile kes | Sesle kesme kapalı | Gürültülü ortam |

Her modda: **yankı filtresi** (duyulan metin Jarvis'in son söylediğine benziyorsa atılır). Çıkış cihazı kulaklıksa tam, hoparlörse yarı çift yönlü otomatik seçilebilir.

---

## 5. Orkestratör ve araç çalıştırıcı

1. **Hızlı komutlar:** "sesi kıs", "sonraki şarkı", "Spotify'ı aç", "ekranı kilitle"… yerel gramer, LLM yok, anında. Live oturumu açılmadan bile çalışabilir (kısayol + kısa komut).
2. **Karar katmanı:** skill seçimi, eleman seçimi (Jev/küçük LLM).
3. **Ajan döngüsü:** gözle → yap → doğrula; iptal edilebilir arka plan görevi; adımlar ekran görüntüleriyle Görevler sayfasında.

**Araç tanımı** (tip ipuçlarından otomatik şema):
```python
@tool(risk="send", timeout=20, requires=["windows"], category="communication")
async def send_whatsapp(contact: str, message: str) -> ToolResult: ...
```
**Çalıştırıcı zinciri:** hız sınırı → yetenek/izin → taint kontrolü → onay → zaman aşımı → olay → dış içerik için injection taraması.
**Onay deposu** (4 seviye): önemsiz (sorma) · düşük (bir kez sor, hatırla) · orta (hatırlanmadıysa sor) · yüksek (her zaman sor). Kararlar parmak iziyle saklanır ("Ahmet'e mesaj → artık sorma").
**Döngü koruması:** aynı (araç, argüman) 3 kez → dur; A-B-A-B döngü tespiti.
**Gönderim önizlemesi:** "Ahmet'e şunu gönderiyorum: … onaylıyor musun?"

---

## 6. Yetenekler

### 6.1 Uygulama ve dosya
- Uygulama açma: takma ad + registry + Başlat menüsü + **Store uygulamaları (Get-StartApps / AUMID)**; pencerenin gerçekten açıldığını doğrular.
- Dosya/klasör: **Everything (es.exe)** ile anında arama, yoksa Windows Search; "dün indirdiğim PDF'i aç", son dosyalar, taşı/yeniden adlandır/zip, İndirilenler düzenleyici.
- Uygulama kurma/güncelleme: winget (PowerShell modülü üzerinden).

### 6.2 Medya
- **Evrensel medya kontrolü (SMTC):** her oynatıcıda oynat/duraklat/sonraki, "ne çalıyor?" — Premium gerekmez.
- **Spotify iki katman:**
  - Premium: Web API (PKCE, `http://127.0.0.1:PORT/callback`) — tam isabet çalma, sıraya ekleme, cihaz değiştirme, çalma listeleri. Dev-mode kuralları: uygulama sahibinin Premium olması ve uygulama başına 5 kullanıcı → her kullanıcı kendi Spotify geliştirici uygulamasını oluşturur (kurulum sihirbazı adım adım yönlendirir).
  - Premium değil: `spotify:` URI + SMTC/medya tuşu ile oynat + UI otomasyonu yedeği.
- YouTube: API anahtarsız video bulma + autoplay (eski kod), Data API yedeği.

### 6.3 Sistem kontrolü
- Ses: genel + **uygulama bazlı ses**, **çıkış cihazı değiştirme** ("kulaklığa geç") — pycaw.
- Ekran: parlaklık (laptop + harici monitör), gece ışığı.
- Pencereler: yasla/taşı, monitörler arası, **sanal masaüstleri** (pyvda), **çalışma düzenleri** ("kodlama düzeni": VS Code sol, tarayıcı sağ, Spotify küçük).
- Güç: kilitle, uyku, zamanlı kapatma ("30 dk sonra kapat"), yeniden başlat (onaylı).
- Ağ/Bluetooth: Wi-Fi, kulaklık bağla.
- Süreçler: "ne RAM yiyor?", süreç sonlandır (onaylı), başlangıç uygulamaları.
- Bildirimler: **Windows bildirimlerini okuma** ("bana ne geldi?") — paketsiz uygulamada olay dinleme çalışmıyor, 1–2 sn'de bir fark alma ile.
- Odak modu: rahatsız etme, pomodoro, dikkat dağıtan siteleri engelleme.
- Ekran görüntüsü, bölge seçip OCR ile metni kopyalama, ekran kaydı başlat/durdur.

### 6.4 Masaüstü kontrolü (genel)
UIA önce (eski `_uia_collect` genişletilerek; Invoke/Value/Toggle desenleri) → **Windows OCR** (Türkçe OCR paketi kurulum sihirbazında) → görüntü modeli (Live karesi / Robotics ER 2 ile konum bulma, eski koddaki ikinci hassaslaştırma adımı ve ön plan koruması). Yazma: **Unicode SendInput** (Türkçe karakter sorunu biter), uzun metin için pano + geri yükleme.
**Öğretme modu:** tıklamak yerine nereye tıklanacağını ekranda parlatarak gösterir.
**Gösterimle öğretme (ileri faz):** "izle ve kaydet" → kullanıcının yaptığı iş akışını UIA olaylarıyla kaydedip tekrar oynatma.

### 6.5 Tarayıcı
- **Erişim hazır ayarları:** "Tam erişim" (varsayılan tarayıcı + mevcut oturumlar, CDP ile bağlanma) · "Jarvis profili" (ayrı tarayıcı/profil, bir kez giriş) · "Sadece aç" (URL açar, kontrol etmez).
- Hızlı yol: jev-ultrafast tarzı DOM anlık görüntüsü → karar → CDP eylemi → doğrulama. Karar verici: Jev, yoksa küçük LLM.
- **Site tarifleri** (deterministik, hızlı): ChatGPT / Claude.ai / Gemini web'e prompt gönder → yanıt akışının bitmesini bekle → yanıtı oku ve özetle; YouTube; Google; WhatsApp Web.
- Bilinmeyen siteler için ajan; ağır görevler için browser-use yedeği.
- Sayfa metni güvenilmez: injection taraması, model sadece bizim ürettiğimiz eleman ID'lerini seçer.

### 6.6 AI ve kod araçları bağlayıcıları
YAML ile tanımlanır; kullanıcı yeni araç ekleyebilir.
```yaml
connectors:
  - id: claude-code
    kind: cli
    run: claude -p "{prompt}"
    cwd: "{active_project}"
    background: true          # bitince haber ver
  - id: opencode
    kind: cli
    run: opencode run "{prompt}"
  - id: vscode-chat
    kind: window
    launch: code "{active_project}"
    focus: "Visual Studio Code"
    open_chat: ctrl+alt+i
    paste_and_send: true
  - id: chatgpt-web
    kind: browser_recipe
    recipe: chatgpt
```
Türler: `cli` (Claude Code, opencode, Codex, Gemini CLI), `window` (VS Code, Antigravity, Zed, Cursor, ChatGPT masaüstü), `browser_recipe` (ChatGPT/Claude/Gemini web).
**Bağlam paketi:** aktif proje, açık dosya, ekrandaki hata, pano → prompt'a otomatik eklenir. "Bu hatayı Claude Code'a gönder, bitince haber ver."

### 6.7 MCP
- **MCP istemcisi:** herhangi bir MCP sunucusu araç olarak eklenir (Windows-MCP, jev-browser, GitHub, Notion, takvim…); güven seviyesi ve izinler sunucu bazında.
- **MCP sunucusu (ileri faz):** Claude Code / Cursor, Jarvis'in araçlarını kullanabilir.

### 6.8 Seçili metin eylemleri
Her yerde metni seç + kısayol → çevir, özetle, yeniden yaz, açıkla, cevap taslağı, hafızaya kaydet. Seçim alma: UIA TextPattern, olmazsa Ctrl+C + pano geri yükleme.

### 6.9 Kaldırılanlar
Deepfake tespiti, tıbbi/finans QA, creative, embodied, doc_intel, audio_structured, reasoning skill'leri, Steam'e özel tıklayıcı, aktif sağlık ping'leri.

---

## 7. Rutinler, hatırlatıcılar, alarmlar

- **Sesli oluşturma:** "Yarın 8'de alarm kur", "saat 3'te bana annemi aramamı hatırlat", "her pazartesi 9'da haftalık plan".
- **Tetikleyiciler:** zaman (tek sefer / cron), olay (uygulama açıldı/kapandı, pencere değişti, USB/kulaklık takıldı, ağ değişti, batarya düştü, bildirim geldi), ses ifadesi, Telegram.
- **Davranış modu (tetikleyici başına):**
  - `auto` — direkt yap
  - `ask` — önce sor ("VS Code açıldı, çalışma müziğini açayım mı?"), cevap sesle / bildirim butonuyla / Telegram'dan
  - `notify` — sadece bildir
  - Soğuma süresi ("günde bir kez sor"), sessiz saatler, "oyun oynarken sorma".
- Alarm/hatırlatıcı: Windows bildirimi + sesli duyuru (Live kısa oturumu, aynı ses), erteleme ("10 dk ertele"). Bilgisayar kapalıyken kaçanlar açılışta bildirilir.
- Çalışan motor kalıcı (SQLite), yeniden başlatmada kaybolmaz. Adım hatası gerçekten algılanır (`on_error: stop|continue`).

---

## 8. Telefondan kontrol

- **Telegram botu (aiogram 3):** long polling → public IP / port açma gerekmez.
- Yazılı veya **sesli mesaj** (OGG → Gemini) ile komut; sonuç, ekran görüntüsü, dosya geri gönderilir.
- Güvenlik: sadece izinli kullanıcı ID'leri; bilinmeyenler sessizce yok sayılır; riskli işlemler telefonda da onay ister; "uzaktan erişim" anahtarı.
- "Ask" modundaki rutin soruları bilgisayar başında değilsen Telegram'a düşer.
- İleri faz: Tailscale üzerinden PWA (canlı ekran, bas-konuş).

---

## 9. Hafıza ve bağlam

### 9.1 Hafıza v2 (tek SQLite)
- Tablolar: `facts` (içerik, kategori, kaynak, güven, görünürlük, `supersedes`, oluşturma/güncelleme/son kullanım, sabitlenmiş), `episodes` (oturum özetleri), `messages`, `events` (yalnız eklenen değişiklik geçmişi).
- Arama: **FTS5 + Türkçe kök ayıklayıcı** + **vektör (sqlite-vec, Gemini Embedding)** hibrit; alakasız sorguları eleyen eşik (sohbet cümleleri hafıza çekmez).
- **Otomatik çıkarma:** oturum bitince arka planda (Flash-Lite/Gemma) kalıcı bilgiler çıkarılır, çakışanlar güncellenir, injection şüphelileri karantinaya.
- Her turda sadece ilgili bilgiler + küçük sabit profil prompt'a girer.
- **Kişilik ve süreklilik:** Çekirdek profil · Kurallar (kullanıcı düzeltmeleri) · Son oturum · Açık konular. "Nerede kalmıştık?" buradan.
- Hafıza sayfası: gör, düzenle, sil, sabitle; "bunu unut".
- Buluta gitmeden önce gizli bilgi temizleme.

### 9.2 Bağlam izleyici
- Ön plan penceresi / uygulama / URL / proje klasörü olay tabanlı kaydedilir (`SetWinEventHook`, polling yok, API yok).
- Projeler: git depoları, son dosyalar → "üstünde çalıştığım şey", "dünkü projeye devam".
- Hariç tutma listesi (banka, şifre yöneticisi, gizli pencere); gizlilik modu kayıtları durdurur.

### 9.3 Ekran yardımı
- "Ekranıma bak" (tek kare Live'a) · bölge seçip sor · **canlı ekran oturumu** (≤1 fps, sen başlatırsın, 2 dk sınırı compression ile uzatılır).

---

## 10. Güvenlik ve gizlilik

- API anahtarları **Windows Kimlik Bilgisi Yöneticisi**'nde (keyring); config'te sadece referans.
- Yerel WebSocket: rastgele port + token; bağlantı kabulünden önce doğrulama.
- Risk seviyeleri araç manifestinde; onay çalıştırıcıda.
- Taint etiketleri (PII, SECRET, EXTERNAL) — gizli veri web aracına gidemez.
- Pano geçmişi şifreli, şifre yöneticisinden gelen kopyalar kaydedilmez.
- Denetim logu, günlük kota/bütçe göstergesi.
- Gizlilik modu: mikrofon, bağlam izleyici, loglar, hafıza yazımı tek anahtarla durur (eski projede mikrofon durmuyordu).

---

## 11. Arayüz (Tauri 2 + React + TypeScript + Tailwind + shadcn/ui + Framer Motion)

**Yüzeyler**
1. **Ses kapsülü:** tetiklenince beliren küçük kapsül; gerçek ses seviyesine tepki veren animasyon, canlı transkript, o anki işlem ("WhatsApp açılıyor…"), onay butonları. Boştayken görünmez.
2. **Komut çubuğu** (Raycast tarzı, global kısayol): komut, arama, son işlemler, hızlı eylemler.
3. **Ana pencere:** Sohbetler · Görevler (canlı, adım adım) · Rutinler · Hafıza · Yetenekler (skill/bağlayıcı/MCP anahtarları ve izinleri) · Sağlayıcılar (ekle/test et, kota panosu, rol öncelikleri) · Ayarlar (ses, cihazlar, yankı profili, wake word ifadeleri, kısayollar, gizlilik) · Geliştirici.
4. Windows yerel bildirimleri (butonlu: "Evet / Hayır / Ertele"), tray menüsü.

**Tasarım:** koyu/açık tema, Mica, vurgu rengi, TR/EN, klavye öncelikli, erişilebilir kontrast; animasyonlar sadece görünürken. Ayarlar ekranı config şemasından otomatik üretilir; değişiklikler yeniden başlatmadan uygulanır. **Profiller:** Laptop hoparlör · Kulaklık · Sessiz · Oyun.

**İlk açılış sihirbazı:** Gemini anahtarları (test ederek) → mikrofon/hoparlör testi + yankı profili → wake word → isteğe bağlı: Spotify, Telegram, Everything, Türkçe OCR paketi, tarayıcı erişim modu.

---

## 12. Teknoloji yığını

| Katman | Seçim |
|---|---|
| Çekirdek | Python 3.12, asyncio, `uv` (lock dosyası), pydantic (ayar şeması) |
| LLM | `google-genai` (Live + embedding), `openai` SDK (uyumlu sağlayıcılar), `typesafe-sdk` (Jev) |
| Ses | sounddevice/PyAudio, openWakeWord, Vosk (deneme), Silero VAD (ONNX), WebRTC APM (AEC) |
| Windows | uiautomation, pywin32/ctypes, winrt-* (SMTC, OCR, bildirimler), pycaw, pyvda, screen-brightness-control |
| Tarayıcı | CDP (browser-harness / Playwright connect_over_cdp) |
| Veri | SQLite (FTS5 + sqlite-vec) |
| Uzak | aiogram 3 |
| MCP | resmi `mcp` Python SDK |
| UI | Tauri 2, React, TypeScript, Tailwind, shadcn/ui, Framer Motion, keyring crate |
| Paketleme | PyInstaller/Nuitka ile çekirdek sidecar + Tauri kurulum paketi |
| Test | pytest, sahte Jarvis API ile skill testleri, kayıtlı ses örnekleriyle ses hattı testleri |

**Depo yapısı (taslak)**
```
jarvis/
  core/            # Python çekirdek
    jarvis/
      app.py  bus.py  config/  secrets/
      voice/       # wake word, VAD, Live oturumu, kademeli mod, AEC
      brain/       # orkestratör, hızlı komutlar, decider, ajan
      tools/       # çalıştırıcı, onay deposu, döngü koruması, taint
      providers/   # kayıt, adaptörler, kota sayacı
      memory/      # SQLite, çıkarma, arama, bağlam izleyici
      skills/      # system, media, spotify, whatsapp, files, windows, browser, desktop...
      connectors/  # AI/kod aracı bağlayıcıları (YAML)
      routines/    # zamanlayıcı, tetikleyiciler
      remote/      # telegram
      mcp/
      api/         # WebSocket sunucusu
    tests/
  app/             # Tauri + React
  docs/
```

---

## 13. Eski projeden taşınacaklar

| Parça | Nasıl |
|---|---|
| WhatsApp arama akışı, Türkçe ek temizleme, bulanık kişi eşleştirme, VCF içe aktarma | Temizlenerek; + sohbet başlığı doğrulama, pano geri yükleme, sabit bekleme yerine koşul bekleme |
| YouTube video bulma/oynatma | Olduğu gibi |
| Spotify URI hilesi | Premium'suz katmanın parçası |
| open_app çözümleyici | + AUMID, pencere doğrulama |
| UIA toplayıcı, `click_on_screen` hassaslaştırma + ön plan koruması, ekran geometrisi (DPI/çoklu monitör) | Yeniden düzenlenerek |
| Görev durum makinesi, gizlilik modu, rota seçimi, pano dinleyici, sistem kontrolü, Türkçe normalize | Temizlenerek |

Tüm kod yeni projede yeniden yazılır/temizlenir; eski dosya başlıkları ve isimler taşınmaz.

**Dış kaynaklardan alınacak fikirler/kodlar (lisansa uygun, kaynak belirtilerek)**
- OpenJarvis (Apache-2.0): onay deposu, ToolSpec kapıları, döngü koruması, taint + injection tarayıcı, hafıza çıkarma akışı, Tauri çekirdek yönetimi + keyring, WebSocket kimlik doğrulama.
- avenoxbeyin (MIT): SQLite hafıza şema fikirleri, Türkçe kök ayıklayıcı, alakasızlık eşiği, Jev istemcisi, süreklilik dosyaları, gizli bilgi temizleyici.
- jev-ultrafast (MIT): DOM anlık görüntüsü + eylem doğrulama.
- sukeesh/Jarvis (MIT): "gereksinim eksik → nedeniyle devre dışı" deseni, dar eklenti arayüzü, sahte API test düzeneği.

---

## 14. Yol haritası

| Faz | Kapsam | Çıkış ölçütü |
|---|---|---|
| **0 — İskelet** | Depo, uv + Tauri kurulum, olay yolu, ayar şeması, anahtar kasası, sağlayıcı kaydı + kota sayacı, WebSocket, loglama | Arayüz çekirdeğe bağlanıyor; sağlayıcı ekle/test et çalışıyor |
| **1 — Ses** | Wake word (+ özel ifade prototipi), bas-konuş, VAD, Live oturumu (resumption/compression), yankı profilleri, ses kapsülü, kademeli yedek | Boşta ağ trafiği 0, CPU < %2; wake word → ilk ses < 1,5 sn; 1 saatlik testte yankıdan sahte komut yok |
| **2 — Temel yetenekler** | Araç çalıştırıcı + onay deposu, hızlı komutlar, uygulama/dosya, sistem kontrolü, SMTC, Spotify (2 katman), YouTube, WhatsApp | Eski projenin tüm çalışan senaryoları + Türkçe yazma |
| **3 — Hafıza ve bağlam** | Hafıza v2, bağlam izleyici, ekran yardımı, hafıza sayfası | "Nerede kalmıştık", "ekranıma bak" güvenilir |
| **4 — Kontrol** | Tarayıcı (erişim modları, tarifler, ajan), masaüstü ajanı, Jev decider, AI/kod bağlayıcıları | ChatGPT'ye prompt verip cevabı okuma; Claude Code'a görev verip bitince haber alma |
| **5 — Rutinler ve uzak** | Tetikleyiciler + ask/auto/notify, alarm/hatırlatıcı, Telegram, seçili metin eylemleri | "VS Code açınca sor" senaryosu; telefondan sesli komut |
| **6 — Arayüz cilası ve ekstralar** | Tüm sayfalar, kota panosu, profiller, MCP istemci/sunucu, çalışma düzenleri, gösterimle öğretme, kurulum paketi | Temiz kurulumla başka bilgisayarda 10 dk'da çalışır |

---

## 15. Açık riskler ve doğrulanacaklar

- **Türkçe özel wake word:** Vosk Türkçe küçük modelin gramer modunu destekleyip desteklemediği → Faz 1 prototipi.
- **Jev Türkçe doğruluğu ve gecikmesi** → gölge modda ölçüm.
- **Live araç çağrısı 3.x'te senkron** → uzun işler görev sistemine; model seçimi (3.8 Live vs 2.5 native audio) ölçümle.
- **Free tier verileri eğitim için kullanılabilir** → gizlilik modu ve hariç tutma listesi; kullanıcı bilgilendirilir.
- **Bildirim dinleme** paketsiz uygulamada sınırlı → yoklama ile; ileride sparse package.
- **pyvda** Windows güncellemelerinde kırılabilir → sürüm sabitleme.
- **Spotify dev-mode** kuralları değişken → Premium'suz katman her zaman çalışır durumda tutulur.
- **CDP ile ana tarayıcıya bağlanma** güvenlik riski → açık onay, varsayılan "Jarvis profili".
