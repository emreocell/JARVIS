@echo off
rem Jarvis kurulumu: eksikleri kurar, kisayollari olusturur.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\install.ps1"
pause
