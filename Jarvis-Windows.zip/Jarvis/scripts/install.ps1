﻿# Jarvis kurulumu: eksik olanları kurar, Jarvis'i hazırlar ve kısayolları oluşturur.
# Çalıştırma: Kur.cmd'ye çift tıkla (ya da: powershell -ExecutionPolicy Bypass -File scripts\install.ps1)
param([switch]$NoLaunch, [ValidateSet('ask', 'yes', 'no')][string]$Autostart = 'ask')
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
[Console]::OutputEncoding = [Text.Encoding]::UTF8
$env:PYTHONIOENCODING = 'utf-8'

$Root = Split-Path -Parent $PSScriptRoot
$Core = Join-Path $Root 'core'
$App = Join-Path $Root 'app'

function Step($text) { Write-Host "`n==> $text" -ForegroundColor Cyan }
function Ok($text) { Write-Host "    ✓ $text" -ForegroundColor Green }
function Warn($text) { Write-Host "    ! $text" -ForegroundColor Yellow }
function Refresh-Path {
    $env:Path = [Environment]::GetEnvironmentVariable('Path', 'Machine') + ';' + [Environment]::GetEnvironmentVariable('Path', 'User')
}
function Have($cmd) { [bool](Get-Command $cmd -ErrorAction SilentlyContinue) }
function Winget-Install($id, $name) {
    if (-not (Have 'winget')) { throw "$name gerekli ama winget bulunamadı. $name'i elle kurup bu betiği tekrar çalıştır." }
    Write-Host "    $name kuruluyor (winget)…"
    winget install -e --id $id --scope user --silent --accept-package-agreements --accept-source-agreements | Out-Null
    Refresh-Path
}

Write-Host "Jarvis kurulumu" -ForegroundColor Magenta
Write-Host "Klasör: $Root"

# ---------------------------------------------------------------- Windows
Step 'Sistem'
$os = [Environment]::OSVersion.Version
if ($os.Major -lt 10) { throw 'Jarvis Windows 10 veya 11 gerektirir.' }
if (-not [Environment]::Is64BitOperatingSystem) { throw 'Jarvis 64 bit Windows gerektirir.' }
$name = if ($os.Build -ge 22000) { 'Windows 11' } else { 'Windows 10' }
Ok "$name (build $($os.Build))"

# ---------------------------------------------------------------- Python 3.12
Step 'Python 3.12'
function Find-Python {
    foreach ($candidate in @('py -3.12', 'python', 'python3')) {
        $parts = $candidate.Split(' ')
        if (-not (Have $parts[0])) { continue }
        try {
            $pyArgs = @($parts | Select-Object -Skip 1) + @('-c', 'import sys; print(sys.version_info[:2] >= (3,12) and sys.version_info[:2] < (3,14)); print(sys.executable)')
            $out = & $parts[0] @pyArgs 2>$null
            if ($out -and $out[0] -eq 'True') { return $out[1] }
        } catch { }
    }
    return $null
}
$Python = Find-Python
if (-not $Python) {
    Winget-Install 'Python.Python.3.12' 'Python 3.12'
    $Python = Find-Python
    if (-not $Python) {
        $local = Join-Path $env:LOCALAPPDATA 'Programs\Python\Python312\python.exe'
        if (Test-Path $local) { $Python = $local } else { throw 'Python 3.12 kurulamadı.' }
    }
}
Ok $Python

# ---------------------------------------------------------------- uv + packages
Step 'Python paketleri (uv)'
& $Python -m pip --version *> $null
if ($LASTEXITCODE -ne 0) { & $Python -m ensurepip --upgrade | Out-Null }
& $Python -m uv --version *> $null
if ($LASTEXITCODE -ne 0) {
    Write-Host '    uv kuruluyor…'
    & $Python -m pip install --user --quiet --disable-pip-version-check uv
}
Push-Location $Core
try {
    & $Python -m uv sync --python $Python
    if ($LASTEXITCODE -ne 0) { throw 'Paketler kurulamadı (uv sync).' }
} finally { Pop-Location }
$VenvPy = Join-Path $Core '.venv\Scripts\python.exe'
Ok 'Bağımlılıklar hazır'

# ---------------------------------------------------------------- WebView2
Step 'Microsoft Edge WebView2 (pencereler için)'
$wv2 = @(
    'HKLM:\SOFTWARE\WOW6432Node\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}',
    'HKLM:\SOFTWARE\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}',
    'HKCU:\SOFTWARE\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}'
) | Where-Object { (Test-Path $_) -and ((Get-ItemProperty $_ -ErrorAction SilentlyContinue).pv) }
if ($wv2) {
    Ok 'Yüklü'
} else {
    $setup = Join-Path $env:TEMP 'MicrosoftEdgeWebview2Setup.exe'
    Invoke-WebRequest 'https://go.microsoft.com/fwlink/p/?LinkId=2124703' -OutFile $setup
    Start-Process $setup -ArgumentList '/silent', '/install' -Wait
    Ok 'Kuruldu'
}

# ---------------------------------------------------------------- UI
Step 'Arayüz'
if (Test-Path (Join-Path $App 'dist\index.html')) {
    Ok 'Hazır (app\dist)'
} else {
    if (-not (Have 'npm')) { Winget-Install 'OpenJS.NodeJS.LTS' 'Node.js' }
    if (-not (Have 'npm')) { throw 'Node.js kurulamadı; arayüz derlenemiyor.' }
    Push-Location $App
    try {
        npm ci --no-audit --no-fund
        npx vite build
        if (-not (Test-Path 'dist\index.html')) { throw 'Arayüz derlenemedi.' }
    } finally { Pop-Location }
    Ok 'Derlendi'
}

# ---------------------------------------------------------------- shortcuts
Step 'Kısayollar'
Push-Location $Core
try {
    & $VenvPy -m jarvis.shortcuts
} finally { Pop-Location }
Ok 'Başlat menüsü ve masaüstüne "Jarvis" eklendi'

$answer = switch ($Autostart) { 'yes' { 'e' } 'no' { 'h' } default { Read-Host "`nJarvis Windows açılınca otomatik başlasın mı? (E/h)" } }
if ($answer -eq '' -or $answer -match '^[eEyY]') {
    & $VenvPy -c "from jarvis import autostart; autostart.sync(True)" | Out-Null
    # record the choice in config too (a fresh PC has none yet: Jarvis would otherwise
    # read "off" on first start and remove the entry again)
    $cfg = Join-Path $env:LOCALAPPDATA 'Jarvis\config.json'
    & $VenvPy -c "import json,os,sys; p=sys.argv[1]; os.makedirs(os.path.dirname(p),exist_ok=True); c=json.load(open(p,encoding='utf-8-sig')) if os.path.exists(p) else {}; c.setdefault('ui',{})['start_with_windows']=True; json.dump(c,open(p,'w',encoding='utf-8'),ensure_ascii=False,indent=2)" $cfg
    Ok 'Otomatik başlatma açık (Ayarlar → Görünüm'"'"'den kapatabilirsin)'
}

Write-Host "`nKurulum tamam." -ForegroundColor Magenta
if (-not $NoLaunch) {
    Write-Host 'Jarvis açılıyor…'
    Start-Process (Join-Path $Core '.venv\Scripts\pythonw.exe') -ArgumentList '-m', 'jarvis' -WorkingDirectory $Core
}
Write-Host 'İlk açılışta Modeller sayfasından bir Gemini API anahtarı eklemen yeterli.'
