import { existsSync, readFileSync } from 'node:fs'
import { homedir } from 'node:os'
import { join } from 'node:path'
import tailwindcss from '@tailwindcss/vite'
import react from '@vitejs/plugin-react'
import { defineConfig, type Plugin } from 'vite'

/**
 * Dev-only: expose the core's runtime.json (port + token) to the browser UI.
 * In the packaged Tauri app a Rust command reads the same file instead.
 */
function jarvisRuntime(): Plugin {
  const home =
    process.env.JARVIS_HOME ??
    join(process.env.LOCALAPPDATA ?? join(homedir(), 'AppData', 'Local'), 'Jarvis')
  return {
    name: 'jarvis-runtime',
    apply: 'serve',
    configureServer(server) {
      server.middlewares.use('/__jarvis/runtime', (_req, res) => {
        const file = join(home, 'runtime.json')
        res.setHeader('Cache-Control', 'no-store')
        if (!existsSync(file)) {
          res.statusCode = 404
          res.end('{}')
          return
        }
        res.setHeader('Content-Type', 'application/json')
        res.end(readFileSync(file, 'utf-8'))
      })
    },
  }
}

export default defineConfig({
  base: './', // the native shell loads dist/index.html from disk
  plugins: [react(), tailwindcss(), jarvisRuntime()],
  server: { port: 5173, strictPort: true, host: '127.0.0.1' },
  clearScreen: false,
})
