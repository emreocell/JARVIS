import clsx from 'clsx'
import { AnimatePresence, motion } from 'framer-motion'
import { Check, ChevronDown, Copy, Mic, Pin, PinOff, Search, StickyNote, Trash2 } from 'lucide-react'
import { useCallback, useEffect, useRef, useState } from 'react'
import { Markdown } from '../components/Markdown'
import { Input, PageHeader } from '../components/ui'
import { client } from '../lib/rpc'
import { useCore, useCoreEvent } from '../lib/useCore'

interface Note { id: number; text: string; created: number; updated: number; pinned: boolean; done: boolean; source: string }

function ago(ts: number) {
  const s = Date.now() / 1000 - ts
  if (s < 60) return 'az önce'
  if (s < 3600) return `${Math.round(s / 60)} dk önce`
  if (s < 86400) return `${Math.round(s / 3600)} sa önce`
  const d = new Date(ts * 1000)
  return d.toLocaleDateString('tr-TR', { day: 'numeric', month: 'short' })
}

function NoteCard({ note, onChange }: { note: Note; onChange: () => void }) {
  const [editing, setEditing] = useState(false)
  const [draft, setDraft] = useState(note.text)
  const [copied, setCopied] = useState(false)
  const update = async (patch: Partial<Note>) => {
    await client.call('notes.update', { id: note.id, ...patch })
    onChange()
  }
  const save = async () => {
    setEditing(false)
    if (draft.trim() && draft !== note.text) await update({ text: draft })
  }
  return (
    <motion.div layout initial={{ opacity: 0, scale: 0.97 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.95 }}
      transition={{ duration: 0.25 }}
      className={clsx('panel group mb-3 break-inside-avoid p-4', note.done && 'opacity-55', note.pinned && 'ring-1 ring-[var(--accent)]/40')}>
      <div className="flex items-start gap-3">
        <button onClick={() => update({ done: !note.done })} aria-label={note.done ? 'Geri al' : 'Tamamlandı'}
          className={clsx('mt-0.5 grid size-5 shrink-0 place-items-center rounded-md ring-1 transition',
            note.done ? 'bg-accent text-white ring-transparent' : 'ring-line hover:ring-[var(--accent)]')}>
          {note.done && <Check className="size-3.5" strokeWidth={3} />}
        </button>
        <div className="min-w-0 flex-1">
          {editing ? (
            <textarea autoFocus value={draft} onChange={(e) => setDraft(e.target.value)} onBlur={save}
              onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); void save() } if (e.key === 'Escape') setEditing(false) }}
              rows={Math.min(8, draft.split('\n').length + 1)}
              className="w-full resize-none bg-transparent text-[14.5px] leading-relaxed outline-none" />
          ) : (
            <div onClick={() => { setDraft(note.text); setEditing(true) }} className={clsx('cursor-text text-[14.5px]', note.done && 'line-through')}>
              <Markdown text={note.text} />
            </div>
          )}
        </div>
      </div>
      <div className="mt-3 flex items-center gap-1 pl-8 text-[11.5px] text-fg-subtle">
        {note.source === 'voice' && <Mic className="size-3" />}
        <span>{ago(note.created)}</span>
        <span className="ml-auto flex gap-0.5 opacity-0 transition group-hover:opacity-100">
          <button onClick={() => update({ pinned: !note.pinned })} className="grid size-7 place-items-center rounded-lg hover:bg-fill-strong hover:text-fg"
            aria-label={note.pinned ? 'Sabitlemeyi kaldır' : 'Sabitle'}>
            {note.pinned ? <PinOff className="size-3.5" /> : <Pin className="size-3.5" />}
          </button>
          <button onClick={() => { void navigator.clipboard.writeText(note.text); setCopied(true); window.setTimeout(() => setCopied(false), 1200) }}
            className="grid size-7 place-items-center rounded-lg hover:bg-fill-strong hover:text-fg" aria-label="Kopyala">
            {copied ? <Check className="size-3.5" /> : <Copy className="size-3.5" />}
          </button>
          <button onClick={async () => { await client.call('notes.delete', { id: note.id }); onChange() }}
            className="grid size-7 place-items-center rounded-lg hover:bg-red-500/10 hover:text-red-600" aria-label="Sil">
            <Trash2 className="size-3.5" />
          </button>
        </span>
        {note.pinned && <Pin className="size-3 text-accent group-hover:hidden" />}
      </div>
    </motion.div>
  )
}

export function NotesPage() {
  const { status } = useCore()
  const [notes, setNotes] = useState<Note[]>([])
  const [query, setQuery] = useState('')
  const [draft, setDraft] = useState('')
  const [showDone, setShowDone] = useState(false)
  const inputRef = useRef<HTMLTextAreaElement>(null)

  const load = useCallback(() => {
    if (status === 'online') client.call<Note[]>('notes.list', { query }).then(setNotes).catch(() => {})
  }, [status, query])
  useEffect(() => {
    const t = window.setTimeout(load, 150)
    return () => window.clearTimeout(t)
  }, [load])
  useCoreEvent('notes.changed', load)

  const add = async () => {
    if (!draft.trim()) return
    await client.call('notes.add', { text: draft })
    setDraft('')
    load()
    inputRef.current?.focus()
  }

  const open = notes.filter((n) => !n.done)
  const done = notes.filter((n) => n.done)

  return (
    <div className="mx-auto max-w-5xl pb-10">
      <PageHeader title="Notlar" subtitle="Aklına geleni yakala. Sesle de olur: “not al: yarın faturayı öde”."
        actions={
          <div className="relative w-64">
            <Search className="pointer-events-none absolute top-2.5 left-3 size-4 text-fg-subtle" />
            <Input className="w-full pl-9" placeholder="Notlarda ara…" value={query} onChange={(e) => setQuery(e.target.value)} />
          </div>
        } />

      <div className="panel mb-6 flex items-start gap-3 p-4">
        <StickyNote className="mt-1 size-5 shrink-0 text-accent" strokeWidth={1.7} />
        <textarea ref={inputRef} value={draft} onChange={(e) => setDraft(e.target.value)} rows={Math.min(6, draft.split('\n').length)}
          onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); void add() } }}
          placeholder="Yeni not… (Enter ile kaydet, Shift+Enter yeni satır)"
          className="min-h-[28px] flex-1 resize-none bg-transparent pt-0.5 text-[15px] leading-relaxed outline-none placeholder:text-fg-subtle" />
        <button onClick={add} disabled={!draft.trim()}
          className="rounded-xl bg-fg px-3.5 py-1.5 text-[13px] text-bg transition disabled:opacity-30">Kaydet</button>
      </div>

      {notes.length === 0 ? (
        <div className="py-16 text-center text-[13.5px] text-fg-muted">
          {query ? 'Eşleşen not yok.' : 'Henüz not yok. İlk notunu yukarıya yaz ya da Jarvis’e söyle.'}
        </div>
      ) : (
        <>
          <div className="columns-1 gap-3 md:columns-2 xl:columns-3">
            <AnimatePresence initial={false}>
              {open.map((n) => <NoteCard key={n.id} note={n} onChange={load} />)}
            </AnimatePresence>
          </div>
          {done.length > 0 && (
            <div className="mt-6">
              <button onClick={() => setShowDone((v) => !v)} className="mb-3 flex items-center gap-1.5 px-1 text-[13px] text-fg-muted hover:text-fg">
                <ChevronDown className={clsx('size-4 transition', !showDone && '-rotate-90')} /> Tamamlananlar · {done.length}
              </button>
              {showDone && (
                <div className="columns-1 gap-3 md:columns-2 xl:columns-3">
                  {done.map((n) => <NoteCard key={n.id} note={n} onChange={load} />)}
                </div>
              )}
            </div>
          )}
        </>
      )}
    </div>
  )
}
