import clsx from 'clsx'
import { motion } from 'framer-motion'
import { Brain, FileCode2, GitCommitHorizontal, Sparkles } from 'lucide-react'
import { useCallback, useEffect, useState } from 'react'
import { Button, PageHeader } from '../components/ui'
import { client } from '../lib/rpc'

interface Block {
  start: string; end: string; minutes: number; project: string | null
  apps: string[]; titles: string[]; files: string[]
  git?: { commits: string[]; files: string[]; files_total: number }
  jarvis: string[]
}
interface Day { day: string; active_minutes: number; projects: Record<string, number>; blocks: Block[] }

const DAYS = [{ id: 'bugün', label: 'Bugün' }, { id: 'dün', label: 'Dün' }]

function hours(min: number) {
  const h = Math.floor(min / 60), m = min % 60
  return h ? `${h} sa ${m ? `${m} dk` : ''}`.trim() : `${m} dk`
}

/** "Bugün ne yaptım?": the day as project blocks, straight from the activity journal. */
export function JournalPage() {
  const [day, setDay] = useState('bugün')
  const [data, setData] = useState<Day | null>(null)
  const [saving, setSaving] = useState(false)
  const [msg, setMsg] = useState<string | null>(null)
  const load = useCallback(() => client.call<Day>('journal.day', { day }).then(setData).catch(() => setData(null)), [day])
  useEffect(() => {
    void load()
    const t = setInterval(load, 60_000)
    return () => clearInterval(t)
  }, [load])

  const toBrain = async () => {
    setSaving(true)
    setMsg(null)
    try {
      const r = await client.call<{ text: string }>('chat.send', {
        text: `${day === 'dün' ? 'Dünkü' : 'Bugünkü'} işlerimi what_did_i_do ile çıkar, zaman bloklarıyla güzel bir Markdown günlük yaz ve save_to_second_brain ile ikinci beynime kaydet.`,
      })
      setMsg(r.text)
    } catch (e) {
      setMsg(String(e))
    } finally {
      setSaving(false)
    }
  }

  const projects = Object.entries(data?.projects ?? {})
  const total = data?.active_minutes ?? 0
  return (
    <div className="mx-auto max-w-4xl pb-10">
      <PageHeader title="Günlük" subtitle="Bilgisayarda ne yaptığın; projeler, dosyalar ve değişiklikler. Veriler yalnızca bu bilgisayarda tutulur."
        actions={
          <div className="flex items-center gap-2">
            <div className="flex rounded-full bg-fill p-1">
              {DAYS.map((d) => (
                <button key={d.id} onClick={() => setDay(d.id)}
                  className={clsx('rounded-full px-3.5 py-1.5 text-[13px] transition', day === d.id ? 'bg-surface text-fg shadow-sm' : 'text-fg-muted hover:text-fg')}>
                  {d.label}
                </button>
              ))}
            </div>
            <Button size="sm" variant="primary" loading={saving} onClick={toBrain} disabled={!data?.blocks.length}>
              <Brain className="size-4" /> İkinci beynime yaz
            </Button>
          </div>
        } />

      {msg && <div className="panel mb-5 p-4 text-[13px] leading-relaxed text-fg-muted">{msg}</div>}

      {total > 0 && (
        <section className="panel mb-6 p-5">
          <div className="flex flex-wrap items-baseline justify-between gap-3">
            <div>
              <div className="text-[12.5px] text-fg-muted">Aktif süre</div>
              <div className="font-display text-[30px] font-light tracking-tight">{hours(total)}</div>
            </div>
            <div className="flex flex-wrap gap-2">
              {projects.slice(0, 5).map(([p, m]) => (
                <span key={p} className="rounded-full bg-accent-soft px-3 py-1 text-[12.5px] text-accent">{p} · {hours(m)}</span>
              ))}
            </div>
          </div>
          {projects.length > 0 && (
            <div className="mt-4 flex h-2 overflow-hidden rounded-full bg-fill">
              {projects.map(([p, m], i) => (
                <div key={p} title={`${p}: ${hours(m)}`} style={{ width: `${(m / total) * 100}%`, opacity: 1 - i * 0.15 }}
                  className="bg-gradient-to-r from-accent to-accent-2" />
              ))}
            </div>
          )}
        </section>
      )}

      {!data?.blocks.length ? (
        <div className="panel p-8 text-center text-[13.5px] leading-relaxed text-fg-muted">
          <Sparkles className="mx-auto mb-3 size-6 text-accent" strokeWidth={1.5} />
          Bu gün için henüz kayıt yok. Jarvis açıkken hangi projede, hangi dosyalarla çalıştığını kendiliğinden not
          alır; akşam "Bugün ne yaptım?" diye sorabilirsin.
        </div>
      ) : (
        <ol className="relative flex flex-col gap-4 before:absolute before:top-2 before:bottom-2 before:left-[54px] before:w-px before:bg-line">
          {data.blocks.map((b, i) => (
            <motion.li key={b.start + i} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.03 }}
              className="relative flex gap-5">
              <div className="w-[44px] shrink-0 pt-4 text-right text-[12px] leading-tight text-fg-subtle tabular-nums">
                {b.start}<br />{b.end}
              </div>
              <span className="absolute top-5 left-[50px] size-2.5 rounded-full bg-accent ring-4 ring-bg" />
              <div className="panel min-w-0 flex-1 p-4">
                <div className="flex flex-wrap items-baseline justify-between gap-2">
                  <h3 className="text-[15px]">{b.project ?? b.apps[0] ?? 'Diğer'}</h3>
                  <span className="text-[12px] text-fg-subtle">{hours(b.minutes)} · {b.apps.join(' + ')}</span>
                </div>
                {b.files.length > 0 && (
                  <div className="mt-2 flex flex-wrap gap-1.5">
                    {b.files.map((f) => (
                      <span key={f} className="inline-flex items-center gap-1 rounded-lg bg-fill px-2 py-0.5 font-mono text-[11.5px]">
                        <FileCode2 className="size-3 text-fg-subtle" />{f}
                      </span>
                    ))}
                  </div>
                )}
                {!b.files.length && b.titles.length > 0 && (
                  <ul className="mt-2 space-y-0.5 text-[12.5px] text-fg-muted">
                    {b.titles.slice(0, 4).map((t) => <li key={t} className="truncate">• {t}</li>)}
                  </ul>
                )}
                {b.git && (b.git.commits.length > 0 || b.git.files_total > 0) && (
                  <div className="mt-2 flex items-start gap-1.5 text-[12.5px] text-fg-muted">
                    <GitCommitHorizontal className="mt-0.5 size-3.5 shrink-0" />
                    <span>
                      {b.git.commits.length > 0 && <>{b.git.commits.length} commit: {b.git.commits.slice(0, 2).join(' · ')}. </>}
                      {b.git.files_total > 0 && <>{b.git.files_total} dosya değişti.</>}
                    </span>
                  </div>
                )}
                {b.jarvis.length > 0 && (
                  <div className="mt-2 text-[12px] text-fg-subtle">Jarvis: {b.jarvis.slice(0, 3).join(' · ')}</div>
                )}
              </div>
            </motion.li>
          ))}
        </ol>
      )}
    </div>
  )
}
