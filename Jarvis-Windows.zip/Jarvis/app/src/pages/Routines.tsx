import clsx from 'clsx'
import { AlarmClock, Bell, Play, Plus, Trash2, Zap } from 'lucide-react'
import { useCallback, useEffect, useState } from 'react'
import { Badge, Button, Card, Input, PageHeader, Select } from '../components/ui'
import { client, RpcError } from '../lib/rpc'
import { Timers } from '../components/Timers'
import { ToolIcon } from '../components/ToolIcon'
import { useToolCatalog, type ToolInfo } from '../lib/tools'
import { useCore, useCoreEvent } from '../lib/useCore'

interface Reminder { id: number; kind: 'reminder' | 'alarm' | 'timer'; text: string; due: number; due_local: string; repeat: string }
interface Rule {
  id: number
  name: string
  trigger: { type: string; app?: string; at?: string; days?: string }
  action: { type: string; tool?: string; args?: Record<string, unknown>; text?: string }
  mode: 'auto' | 'ask' | 'notify'
  enabled: boolean
  cooldown_minutes: number
  quiet_hours: number[]
}

const REPEAT: Record<string, string> = { none: 'Tek sefer', daily: 'Her gün', weekdays: 'Hafta içi', weekly: 'Her hafta' }
const MODE: Record<string, { label: string; hint: string }> = {
  ask: { label: 'Önce sor', hint: 'Yapmadan önce sana sorar' },
  auto: { label: 'Otomatik', hint: 'Sormadan yapar (riskli işlemler yine onay ister)' },
  notify: { label: 'Sadece bildir', hint: 'Hiçbir şey yapmaz, sadece hatırlatır' },
}

function triggerText(t: Rule['trigger']) {
  if (t.type === 'app_opened') return `${t.app} açılınca`
  if (t.type === 'time') return `${t.at} · ${t.days === 'weekdays' ? 'hafta içi' : t.days === 'weekends' ? 'hafta sonu' : 'her gün'}`
  if (t.type === 'startup') return 'Jarvis başlayınca'
  return t.type
}

function actionText(a: Rule['action'], catalog: ToolInfo[]) {
  if (a.type === 'tool') {
    const title = catalog.find((t) => t.name === a.tool)?.title ?? a.tool
    const arg = Object.values(a.args ?? {}).join(', ')
    return arg ? `${title}: ${arg}` : title
  }
  return a.type === 'prompt' ? `Jarvis'e: “${a.text ?? ''}”` : `Söyle: “${a.text ?? ''}”`
}

function relative(due: number) {
  const s = Math.round(due - Date.now() / 1000)
  if (s < 60) return 'birazdan'
  const m = Math.round(s / 60)
  if (m < 60) return `${m} dk sonra`
  const h = Math.floor(m / 60)
  if (h < 24) return `${h} sa ${m % 60 ? `${m % 60} dk ` : ''}sonra`
  const d = Math.round(h / 24)
  return d === 1 ? 'yarın' : `${d} gün sonra`
}

const TEMPLATES: { title: string; hint: string; icon: string; rule: Record<string, unknown> }[] = [
  { title: 'Kod yazarken müzik', hint: 'VS Code açılınca lofi açmayı sorar', icon: 'Music2',
    rule: { name: 'Kod yazarken müzik', trigger: { type: 'app_opened', app: 'Visual Studio Code' },
      action: { type: 'tool', tool: 'play_spotify', args: { query: 'lofi hip hop' } }, mode: 'ask' } },
  { title: 'Günaydın özeti', hint: 'Hafta içi 09:00’da günün özetini söyler', icon: 'Sunrise',
    rule: { name: 'Günaydın özeti', trigger: { type: 'time', at: '09:00', days: 'weekdays' },
      action: { type: 'tool', tool: 'daily_brief', args: {} }, mode: 'auto' } },
  { title: 'Mola hatırlatıcı', hint: 'Her gün 15:00’te kısa bir mola önerir', icon: 'Bell',
    rule: { name: 'Mola zamanı', trigger: { type: 'time', at: '15:00', days: 'daily' },
      action: { type: 'say', text: 'Biraz mola ver, su iç ve gözlerini dinlendir.' }, mode: 'notify' } },
  { title: 'Açılışta hava durumu', hint: 'Jarvis başlayınca havayı söyler', icon: 'CloudSun',
    rule: { name: 'Açılışta hava', trigger: { type: 'startup' },
      action: { type: 'tool', tool: 'get_weather', args: {} }, mode: 'auto' } },
]

function NewReminder({ onDone }: { onDone: () => void }) {
  const [f, setF] = useState({ text: '', at: '', kind: 'reminder', repeat: 'none' })
  const [error, setError] = useState<string | null>(null)
  const submit = async () => {
    setError(null)
    try {
      await client.call('routines.add_reminder', f)
      setF({ ...f, text: '', at: '' })
      onDone()
    } catch (e) {
      setError(e instanceof RpcError ? e.message : String(e))
    }
  }
  return (
    <Card className="p-4">
      <div className="flex flex-wrap gap-2">
        <Select className="w-32" value={f.kind} onChange={(e) => setF({ ...f, kind: e.target.value })}>
          <option value="reminder">Hatırlatıcı</option>
          <option value="alarm">Alarm</option>
        </Select>
        <Input className="min-w-48 flex-1" placeholder={f.kind === 'alarm' ? 'Etiket (ör. Uyan)' : 'Neyi hatırlatayım?'}
          value={f.text} onChange={(e) => setF({ ...f, text: e.target.value })} />
        <Input className="w-40" type="time" value={f.at} onChange={(e) => setF({ ...f, at: e.target.value })} />
        <Select className="w-32" value={f.repeat} onChange={(e) => setF({ ...f, repeat: e.target.value })}>
          {Object.entries(REPEAT).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
        </Select>
        <Button variant="primary" onClick={submit} disabled={!f.text.trim() || !f.at}><Plus className="size-4" /> Kur</Button>
      </div>
      {error && <div className="mt-2 text-xs text-danger">{error}</div>}
    </Card>
  )
}

function NewRule({ tools, onDone }: { tools: ToolInfo[]; onDone: () => void }) {
  const [open, setOpen] = useState(false)
  const [f, setF] = useState({
    name: '', trigger: 'app_opened', app: '', at: '09:00', days: 'daily',
    action: 'tool', tool: 'play_spotify', arg: '', text: '', mode: 'ask',
  })
  const [error, setError] = useState<string | null>(null)

  const submit = async () => {
    setError(null)
    const trigger = f.trigger === 'app_opened' ? { type: 'app_opened', app: f.app }
      : f.trigger === 'time' ? { type: 'time', at: f.at, days: f.days } : { type: 'startup' }
    const firstArg = f.tool.startsWith('play_') ? 'query' : f.tool === 'open_app' ? 'name' : 'query'
    const action = f.action === 'tool' ? { type: 'tool', tool: f.tool, args: f.arg ? { [firstArg]: f.arg } : {} }
      : { type: f.action, text: f.text }
    try {
      await client.call('routines.save_rule', { rule: { name: f.name, trigger, action, mode: f.mode } })
      setOpen(false)
      onDone()
    } catch (e) {
      setError(e instanceof RpcError ? e.message : String(e))
    }
  }

  if (!open) return <Button onClick={() => setOpen(true)}><Zap className="size-4" /> Yeni rutin</Button>
  return (
    <Card className="p-5">
      <div className="grid grid-cols-2 gap-3 text-sm">
        <Input className="col-span-2 w-full" placeholder="Rutinin adı, ör. Kodlarken müzik" value={f.name}
          onChange={(e) => setF({ ...f, name: e.target.value })} />
        <label className="text-xs text-fg-muted">Ne zaman?
          <Select className="mt-1 w-full" value={f.trigger} onChange={(e) => setF({ ...f, trigger: e.target.value })}>
            <option value="app_opened">Bir uygulama açılınca</option>
            <option value="time">Belirli bir saatte</option>
            <option value="startup">Jarvis başlayınca</option>
          </Select>
        </label>
        {f.trigger === 'app_opened' && (
          <label className="text-xs text-fg-muted">Uygulama
            <Input className="mt-1 w-full" placeholder="VS Code" value={f.app} onChange={(e) => setF({ ...f, app: e.target.value })} />
          </label>
        )}
        {f.trigger === 'time' && (
          <div className="flex gap-2">
            <label className="flex-1 text-xs text-fg-muted">Saat
              <Input className="mt-1 w-full" type="time" value={f.at} onChange={(e) => setF({ ...f, at: e.target.value })} />
            </label>
            <label className="flex-1 text-xs text-fg-muted">Günler
              <Select className="mt-1 w-full" value={f.days} onChange={(e) => setF({ ...f, days: e.target.value })}>
                <option value="daily">Her gün</option><option value="weekdays">Hafta içi</option><option value="weekends">Hafta sonu</option>
              </Select>
            </label>
          </div>
        )}
        {f.trigger === 'startup' && <div />}
        <label className="text-xs text-fg-muted">Ne yapsın?
          <Select className="mt-1 w-full" value={f.action} onChange={(e) => setF({ ...f, action: e.target.value })}>
            <option value="tool">Bir işlem çalıştır</option>
            <option value="prompt">Jarvis'e görev ver</option>
            <option value="say">Sadece söyle</option>
          </Select>
        </label>
        {f.action === 'tool' ? (
          <div className="flex gap-2">
            <label className="flex-1 text-xs text-fg-muted">İşlem
              <Select className="mt-1 w-full" value={f.tool} onChange={(e) => setF({ ...f, tool: e.target.value })}>
                {tools.map((t) => <option key={t.name} value={t.name}>{t.title ?? t.name}</option>)}
              </Select>
            </label>
            <label className="flex-1 text-xs text-fg-muted">Değer
              <Input className="mt-1 w-full" placeholder="lofi" value={f.arg} onChange={(e) => setF({ ...f, arg: e.target.value })} />
            </label>
          </div>
        ) : (
          <label className="text-xs text-fg-muted">{f.action === 'prompt' ? 'Görev' : 'Metin'}
            <Input className="mt-1 w-full" placeholder={f.action === 'prompt' ? 'Günün özetini çıkar' : 'Mola ver!'}
              value={f.text} onChange={(e) => setF({ ...f, text: e.target.value })} />
          </label>
        )}
        <div className="col-span-2">
          <div className="mb-1 text-xs text-fg-muted">Davranış</div>
          <div className="flex gap-2">
            {Object.entries(MODE).map(([k, v]) => (
              <button key={k} onClick={() => setF({ ...f, mode: k })}
                className={clsx('flex-1 rounded-xl border px-3 py-2 text-left transition',
                  f.mode === k ? 'border-accent bg-accent-soft' : 'border-line hover:bg-fill-strong')}>
                <div className="text-sm font-medium">{v.label}</div>
                <div className="text-[11px] text-fg-muted">{v.hint}</div>
              </button>
            ))}
          </div>
        </div>
      </div>
      {error && <div className="mt-2 text-xs text-danger">{error}</div>}
      <div className="mt-4 flex justify-end gap-2">
        <Button variant="ghost" onClick={() => setOpen(false)}>Vazgeç</Button>
        <Button variant="primary" onClick={submit} disabled={!f.name.trim()}>Kaydet</Button>
      </div>
    </Card>
  )
}

export function RoutinesPage() {
  const { status } = useCore()
  const catalog = useToolCatalog()
  const [data, setData] = useState<{ reminders: Reminder[]; rules: Rule[] }>({ reminders: [], rules: [] })
  const tools = catalog.filter((t) => t.available)

  const load = useCallback(async () => {
    if (status !== 'online') return
    setData(await client.call('routines.list'))
  }, [status])
  useEffect(() => { void load() }, [load])
  useCoreEvent('routine.changed', useCallback(() => void load(), [load]))

  const reminders = data.reminders.filter((r) => r.kind !== 'timer')
  const unusedTemplates = TEMPLATES.filter((t) => !data.rules.some((r) => r.name === t.rule.name))

  return (
    <div className="mx-auto max-w-4xl pb-10">
      <PageHeader title="Rutinler" subtitle="Zamanlayıcılar, hatırlatıcılar ve “şu olunca şunu yap” kuralları. Sesle de kurabilirsin: “yarın 9'da doktoru aramamı hatırlat”." />

      <Timers />

      <h2 className="mt-8 mb-3 px-1 text-[13px] font-medium text-fg-muted">Hatırlatıcılar ve alarmlar</h2>
      <NewReminder onDone={load} />
      {reminders.length > 0 && (
        <div className="mt-3 grid grid-cols-1 gap-3 md:grid-cols-2">
          {reminders.map((r) => (
            <div key={r.id} className="panel group flex items-center gap-3 p-4">
              <div className={clsx('grid size-10 shrink-0 place-items-center rounded-2xl',
                r.kind === 'alarm' ? 'bg-accent text-white' : 'bg-accent-soft text-accent')}>
                {r.kind === 'alarm' ? <AlarmClock className="size-5" strokeWidth={1.7} /> : <Bell className="size-5" strokeWidth={1.7} />}
              </div>
              <div className="min-w-0 flex-1">
                <div className="truncate text-[14px]">{r.text}</div>
                <div className="mt-0.5 flex items-center gap-2 text-[12px] text-fg-muted">
                  <span className="tabular-nums">{r.due_local.slice(-5)}</span>·<span>{relative(r.due)}</span>
                  {r.repeat !== 'none' && <Badge tone="accent">{REPEAT[r.repeat]}</Badge>}
                </div>
              </div>
              <Button size="sm" variant="danger" aria-label="İptal" className="opacity-0 transition group-hover:opacity-100"
                onClick={async () => { await client.call('routines.cancel', { id: r.id }); void load() }}>
                <Trash2 className="size-3.5" />
              </Button>
            </div>
          ))}
        </div>
      )}

      <div className="mt-10 mb-3 flex items-center justify-between px-1">
        <h2 className="text-[13px] font-medium text-fg-muted">Kurallar</h2>
      </div>
      {data.rules.length > 0 && (
        <div className="mb-3 flex flex-col gap-2">
          {data.rules.map((r) => {
            const tool = r.action.type === 'tool' ? catalog.find((t) => t.name === r.action.tool) : undefined
            return (
              <div key={r.id} className="panel group flex items-center gap-3 p-4">
                <div className="grid size-10 shrink-0 place-items-center rounded-2xl bg-fill-strong text-fg-muted">
                  <ToolIcon name={tool?.icon ?? (r.trigger.type === 'time' ? 'AlarmClock' : 'Workflow')} className="size-5" />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="text-[14px]">{r.name}</div>
                  <div className="mt-0.5 truncate text-[12px] text-fg-muted">
                    {triggerText(r.trigger)} → {actionText(r.action, catalog)}
                  </div>
                </div>
                <Badge tone={r.mode === 'auto' ? 'warn' : r.mode === 'ask' ? 'accent' : 'neutral'}>{MODE[r.mode].label}</Badge>
                <Button size="sm" variant="ghost" aria-label="Şimdi çalıştır" title="Şimdi çalıştır"
                  onClick={() => client.call('routines.run_rule', { id: r.id })}>
                  <Play className="size-3.5" />
                </Button>
                <Button size="sm" variant="danger" aria-label="Sil" className="opacity-0 transition group-hover:opacity-100"
                  onClick={async () => { await client.call('routines.delete_rule', { id: r.id }); void load() }}>
                  <Trash2 className="size-3.5" />
                </Button>
              </div>
            )
          })}
        </div>
      )}
      {unusedTemplates.length > 0 && (
        <div className="mb-4">
          <div className="mb-2 px-1 text-[12px] text-fg-subtle">Hazır rutinler — tek tıkla ekle</div>
          <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
            {unusedTemplates.map((t) => (
              <button key={t.title} onClick={async () => { await client.call('routines.save_rule', { rule: t.rule }); void load() }}
                className="panel card-hover flex items-center gap-3 p-4 text-left">
                <div className="grid size-10 shrink-0 place-items-center rounded-2xl bg-accent-soft text-accent">
                  <ToolIcon name={t.icon} className="size-5" />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="text-[14px]">{t.title}</div>
                  <div className="mt-0.5 text-[12px] text-fg-muted">{t.hint}</div>
                </div>
                <Plus className="size-4 text-fg-subtle" />
              </button>
            ))}
          </div>
        </div>
      )}
      <NewRule tools={tools} onDone={load} />
    </div>
  )
}
