import { Smartphone, X } from 'lucide-react'
import { useCallback, useEffect, useState } from 'react'
import { Badge, Button, Card, Input } from '../components/ui'
import { client, RpcError } from '../lib/rpc'
import { useCoreEvent } from '../lib/useCore'

interface Status {
  enabled: boolean
  running: boolean
  has_token: boolean
  username: string | null
  pair_code: string
  allowed: number[]
  error: string | null
}

/** Telegram phone remote: token, pairing code, paired accounts. */
export function PhoneRemote() {
  const [s, setS] = useState<Status | null>(null)
  const [token, setToken] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [busy, setBusy] = useState(false)

  const load = useCallback(() => client.call<Status>('remote.status').then(setS).catch(() => {}), [])
  useEffect(() => {
    void load()
  }, [load])
  useCoreEvent('remote.paired', useCallback(() => void load(), [load]))
  useCoreEvent('config.changed', useCallback(() => void load(), [load]))

  const save = async () => {
    setBusy(true)
    setError(null)
    try {
      setS(await client.call<Status>('remote.set_token', { token: token.trim() }))
      setToken('')
    } catch (e) {
      setError(e instanceof RpcError ? e.message : String(e))
    } finally {
      setBusy(false)
    }
  }

  if (!s) return null
  return (
    <section>
      <h2 className="mb-3 px-1 text-[13px] text-fg-muted">Telefondan kontrol</h2>
      <Card className="p-5">
        <div className="flex items-start gap-4">
          <div className="grid size-10 shrink-0 place-items-center rounded-2xl bg-fill">
            <Smartphone className="size-[18px] text-fg-muted" strokeWidth={1.6} />
          </div>
          <div className="min-w-0 flex-1">
            <div className="flex flex-wrap items-center gap-2 text-[14px]">
              Telegram botu
              {s.running ? <Badge tone="ok">@{s.username} çalışıyor</Badge>
                : s.has_token ? <Badge tone="warn">kapalı</Badge> : <Badge>kurulmadı</Badge>}
            </div>
            <p className="mt-1 text-[12.5px] leading-relaxed text-fg-muted">
              Dışarıdayken Jarvis'e yazılı ya da sesli mesajla komut ver; “önce sor” rutinleri ve onaylar telefonuna
              Evet/Hayır butonlarıyla gelir. Port açmak gerekmez.
            </p>

            {!s.running && (
              <div className="mt-4">
                <ol className="mb-3 list-decimal space-y-1 pl-5 text-[12.5px] text-fg-muted">
                  <li>Telegram'da <span className="text-fg">@BotFather</span>'a <span className="font-mono text-fg">/newbot</span> yaz, bir ad ver.</li>
                  <li>Verdiği token'ı buraya yapıştır. (Windows Kimlik Bilgisi Yöneticisi'nde saklanır.)</li>
                </ol>
                <div className="flex gap-2">
                  <Input className="flex-1" type="password" placeholder="123456789:AA…" value={token}
                    onChange={(e) => setToken(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && token && save()} />
                  <Button variant="primary" onClick={save} loading={busy} disabled={!token.trim()}>Bağla</Button>
                </div>
              </div>
            )}

            {s.running && (
              <div className="mt-4 rounded-2xl bg-fill p-4">
                <div className="text-[12.5px] text-fg-muted">Telefonundan <span className="text-fg">@{s.username}</span> botuna şunu gönder:</div>
                <div className="mt-2 font-mono text-[22px] tracking-[0.2em]">/start {s.pair_code}</div>
                <div className="mt-1 text-[11.5px] text-fg-subtle">Kod tek kullanımlık; eşleşince yenilenir. Başka hiç kimseye cevap verilmez.</div>
              </div>
            )}

            {s.allowed.length > 0 && (
              <div className="mt-4 flex flex-wrap gap-2">
                {s.allowed.map((id) => (
                  <span key={id} className="inline-flex items-center gap-1.5 rounded-full bg-fill py-1 pr-1 pl-3 text-[12px]">
                    Eşleşmiş hesap · {id}
                    <button aria-label="Eşleşmeyi kaldır" className="grid size-5 place-items-center rounded-full hover:bg-fill-strong"
                      onClick={async () => setS(await client.call<Status>('remote.unpair', { user_id: id }))}>
                      <X className="size-3" />
                    </button>
                  </span>
                ))}
              </div>
            )}
            {(error || s.error) && <div className="mt-3 text-[12.5px] text-red-600 dark:text-red-300">{error || s.error}</div>}
          </div>
        </div>
      </Card>
    </section>
  )
}
