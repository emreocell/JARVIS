import { Music2 } from 'lucide-react'
import { useCallback, useEffect, useState } from 'react'
import { Badge, Button, Card, Input } from '../components/ui'
import { client, RpcError, type CoreEvent } from '../lib/rpc'
import { useCore, useCoreEvent } from '../lib/useCore'

interface Status { client_id: boolean; linked: boolean; product: string | null }

/** Spotify Premium tier: Client ID + OAuth (PKCE). Free accounts keep the desktop-app path. */
export function SpotifyCard() {
  const { snapshot } = useCore()
  const [s, setS] = useState<Status | null>(null)
  const [cid, setCid] = useState('')
  const [busy, setBusy] = useState(false)
  const [msg, setMsg] = useState<string | null>(null)

  const load = useCallback(() => client.call<Status>('spotify.status').then(setS).catch(() => {}), [])
  useEffect(() => {
    void load()
  }, [load])
  useEffect(() => {
    setCid(snapshot?.config.integrations?.spotify_client_id ?? '')
  }, [snapshot?.config.integrations?.spotify_client_id])

  useCoreEvent('spotify.linked', useCallback((e: CoreEvent) => {
    setBusy(false)
    setMsg(e.data.error ? `Bağlanamadı: ${e.data.error}` : e.data.product === 'premium'
      ? 'Bağlandı ✓ Premium özellikler açık.' : 'Bağlandı, ama hesap Premium değil — masaüstü uygulaması yolu kullanılacak.')
    void load()
  }, [load]))

  const connect = async () => {
    setMsg(null)
    try {
      if (cid.trim() !== (snapshot?.config.integrations?.spotify_client_id ?? ''))
        await client.call('config.patch', { patch: { integrations: { spotify_client_id: cid.trim() } } })
      setBusy(true)
      await client.call('spotify.connect')
      setMsg('Tarayıcında Spotify onay sayfası açıldı…')
    } catch (e) {
      setBusy(false)
      setMsg(e instanceof RpcError ? e.message : String(e))
    }
  }

  if (!s) return null
  return (
    <section>
      <h2 className="mb-3 px-1 text-[13px] text-fg-muted">Spotify</h2>
      <Card className="p-5">
        <div className="flex items-start gap-4">
          <div className="grid size-10 shrink-0 place-items-center rounded-2xl bg-fill">
            <Music2 className="size-[18px] text-fg-muted" strokeWidth={1.6} />
          </div>
          <div className="min-w-0 flex-1">
            <div className="flex flex-wrap items-center gap-2 text-[14px]">
              Spotify hesabı
              {s.linked ? <Badge tone="ok">bağlı{s.product ? ` · ${s.product}` : ''}</Badge> : <Badge>bağlı değil</Badge>}
            </div>
            <p className="mt-1 text-[12.5px] leading-relaxed text-fg-muted">
              Bağlamadan da çalışır (masaüstü uygulaması üzerinden). Premium hesabını bağlarsan istediğin şarkı, albüm
              ya da çalma listesi tam isabetle ve istediğin cihazda çalar.
            </p>
            {!s.linked && (
              <>
                <ol className="mt-3 mb-3 list-decimal space-y-1 pl-5 text-[12.5px] text-fg-muted">
                  <li><span className="text-fg">developer.spotify.com/dashboard</span>'da ücretsiz bir uygulama oluştur (Web API seç).</li>
                  <li>Redirect URI olarak <span className="font-mono text-fg">http://127.0.0.1:8765/callback</span> ekle.</li>
                  <li>Client ID'yi buraya yapıştır ve bağlan.</li>
                </ol>
                <div className="flex gap-2">
                  <Input className="flex-1 font-mono" placeholder="Client ID" value={cid} onChange={(e) => setCid(e.target.value)} />
                  <Button variant="primary" onClick={connect} loading={busy} disabled={!cid.trim()}>Bağlan</Button>
                </div>
              </>
            )}
            {s.linked && (
              <Button className="mt-3" size="sm" variant="ghost"
                onClick={async () => { await client.call('spotify.unlink'); void load() }}>Bağlantıyı kaldır</Button>
            )}
            {msg && <div className="mt-3 text-[12.5px] text-fg-muted">{msg}</div>}
          </div>
        </div>
      </Card>
    </section>
  )
}
