import clsx from 'clsx'
import { Markdown } from '../components/Markdown'
import { AnimatePresence, motion } from 'framer-motion'
import {
  AppWindow, ArrowUpRight, Calculator, CornerDownLeft, FileText, Globe, History, LayoutGrid, Sparkles, StickyNote, Zap,
  type LucideIcon,
} from 'lucide-react'
import { useCallback, useEffect, useLayoutEffect, useRef, useState } from 'react'
import { LiquidOrb, type OrbState } from '../components/LiquidOrb'
import { client, RpcError, type CoreEvent } from '../lib/rpc'
import { useApplyTheme } from '../lib/theme'
import { useCore, useCoreEvent } from '../lib/useCore'

type Api = { command_hide(): void; command_resize(h: number): void; open_main(): void }
const api = (): Api | undefined => (window as unknown as { pywebview?: { api: Api } }).pywebview?.api

const ACTIONS = ['Özetle', 'Türkçeye çevir', 'İngilizceye çevir', 'Açıkla', 'Daha iyi yeniden yaz', 'Cevap taslağı yaz']
const HISTORY_KEY = 'jarvis.command.history'
const CLIP_KEY = 'jarvis.command.clipseq'
const BAR_H = 64

// shown when the bar opens empty: discoverable one-keystroke actions
const QUICK: Result[] = [
  { id: 'fast:günün özeti', kind: 'action', title: 'Günün özeti', subtitle: 'Hava, hatırlatıcılar, gündem' },
  { id: 'fast:odak modunu başlat', kind: 'action', title: 'Odak modu', subtitle: '25 dk zamanlayıcı + odak müziği' },
  { id: 'fast:hava nasıl', kind: 'action', title: 'Hava durumu', subtitle: 'Şimdi ve yarın' },
  { id: 'fast:ekran görüntüsü al', kind: 'action', title: 'Ekran görüntüsü al', subtitle: 'Kaydet ve panoya kopyala' },
  { id: 'fast:masaüstünü göster', kind: 'action', title: 'Masaüstünü göster', subtitle: 'Tüm pencereleri küçült' },
  { id: 'page:notes', kind: 'page', title: 'Notlarım', subtitle: 'Notlar sayfasını aç' },
]

interface Reply { text: string; model: string; steps: string[] }
interface Result { id: string; kind: 'app' | 'file' | 'page' | 'calc' | 'action' | 'ask' | 'web' | 'note' | 'recent'; title: string; subtitle: string; icon?: string | null }

const ICONS: Record<Result['kind'], LucideIcon> = {
  app: AppWindow, file: FileText, page: LayoutGrid, calc: Calculator, action: Zap, ask: Sparkles, web: Globe,
  note: StickyNote, recent: History,
}

/**
 * Alt+Space command bar (Raycast-like): instant local results while typing
 * (apps, recent files, pages, calculator, fast commands), Enter runs the
 * highlighted one; anything else goes to Jarvis. The native window grows to
 * fit the content.
 */
export function CommandBar() {
  useApplyTheme()
  const { snapshot, status } = useCore()
  const [input, setInput] = useState('')
  const [selection, setSelection] = useState<{ text: string; at: number; clipboard?: boolean } | null>(null)
  const [appActions, setAppActions] = useState<{ app: string; actions: string[] } | null>(null)
  const [reply, setReply] = useState<Reply | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [busy, setBusy] = useState(false)
  const [results, setResults] = useState<Result[]>([])
  const [active, setActive] = useState(0)
  const inputRef = useRef<HTMLInputElement>(null)
  const panelRef = useRef<HTMLDivElement>(null)
  const histIdx = useRef(-1)
  const shownAt = useRef(0)
  const hadFocus = useRef(false)
  const query = useRef('')

  useEffect(() => {
    client.start()
    return () => client.stop()
  }, [])

  // shell calls this every time before the window is shown
  useEffect(() => {
    const w = window as unknown as { __jarvisCommandShow?: () => void }
    w.__jarvisCommandShow = () => {
      shownAt.current = Date.now()
      hadFocus.current = false
      setInput('')
      setResults([])
      setActive(0)
      setReply(null)
      setError(null)
      histIdx.current = -1
      // keep a selection captured just before the hotkey opened us
      setSelection((s) => (s && !s.clipboard && Date.now() - s.at < 3000 ? s : null))
      requestAnimationFrame(() => inputRef.current?.focus())
      // mini commands for the app that was in front
      setAppActions(null)
      window.setTimeout(() => {
        client.call<{ app: string; actions: string[] }>('context.actions').then(setAppActions).catch(() => {})
      }, 120)
      // something new on the clipboard since we last looked? offer the same actions for it (once)
      client.call<{ seq: number; text: string | null }>('clipboard.peek').then((r) => {
        if (!r.text || String(r.seq) === localStorage.getItem(CLIP_KEY)) return
        localStorage.setItem(CLIP_KEY, String(r.seq))
        setSelection((s) => s ?? { text: r.text!, at: Date.now(), clipboard: true })
      }).catch(() => {})
    }
    inputRef.current?.focus()
    return () => { delete w.__jarvisCommandShow }
  }, [])

  useCoreEvent('selection.captured', useCallback((e: CoreEvent) => {
    const text = String(e.data.text || '').trim()
    setSelection(text ? { text, at: Date.now() } : null)
  }, []))

  // hide on Esc / when focus really leaves the window
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && api()?.command_hide()
    const onFocus = () => { hadFocus.current = true }
    const onVisible = () => {
      if (document.visibilityState === 'visible') { shownAt.current = Date.now(); hadFocus.current = false }
    }
    const onBlur = () => {
      if (hadFocus.current && Date.now() - shownAt.current > 500) api()?.command_hide()
    }
    window.addEventListener('keydown', onKey)
    window.addEventListener('focus', onFocus)
    window.addEventListener('blur', onBlur)
    document.addEventListener('visibilitychange', onVisible)
    return () => {
      window.removeEventListener('keydown', onKey)
      window.removeEventListener('focus', onFocus)
      window.removeEventListener('blur', onBlur)
      document.removeEventListener('visibilitychange', onVisible)
    }
  }, [])

  // native window follows the content height
  useLayoutEffect(() => {
    const el = panelRef.current
    if (!el) return
    const ro = new ResizeObserver(() => api()?.command_resize(Math.ceil(el.getBoundingClientRect().height)))
    ro.observe(el)
    return () => ro.disconnect()
  }, [])

  // live results while typing (local only, ~ms)
  useEffect(() => {
    query.current = input
    if (!input.trim() || selection || status !== 'online') {
      setResults([])
      return
    }
    const t = window.setTimeout(() => {
      client.call<Result[]>('launcher.search', { q: input }).then((r) => {
        if (query.current === input) {
          setResults(r)
          setActive(0)
        }
      }).catch(() => {})
    }, 40)
    return () => window.clearTimeout(t)
  }, [input, selection, status])

  const remember = (typed: string) => {
    const hist: string[] = JSON.parse(localStorage.getItem(HISTORY_KEY) || '[]')
    localStorage.setItem(HISTORY_KEY, JSON.stringify([typed, ...hist.filter((h) => h !== typed)].slice(0, 30)))
  }

  const send = async (override?: string) => {
    const typed = (override ?? input).trim()
    if ((!typed && !selection) || busy) return
    const text = selection ? `${typed || 'Bu metinle ilgili yardımcı ol'}:\n"""\n${selection.text}\n"""` : typed
    if (typed && !override) remember(typed)
    setBusy(true)
    setError(null)
    setReply(null)
    setResults([])
    try {
      setReply(await client.call<Reply>('chat.send', { text }))
      setSelection(null)
      setInput('')
    } catch (e) {
      setError(e instanceof RpcError ? e.message : String(e))
    } finally {
      setBusy(false)
    }
  }

  const run = async (r: Result) => {
    if (r.kind === 'ask') return send()
    if (r.kind === 'recent') return send(r.title)
    remember(input.trim())
    setBusy(true)
    setError(null)
    try {
      const out = await client.call<{ done: boolean; text?: string; model?: string }>('launcher.run', { id: r.id })
      if (out.done) {
        api()?.command_hide()
      } else {
        setResults([])
        setInput('')
        setReply({ text: out.text ?? 'Tamam.', model: out.model ?? 'fast', steps: [] })
      }
    } catch (e) {
      setError(e instanceof RpcError ? e.message : String(e))
    } finally {
      setBusy(false)
    }
  }

  const recall = (dir: 1 | -1) => {
    const hist: string[] = JSON.parse(localStorage.getItem(HISTORY_KEY) || '[]')
    const next = Math.max(-1, Math.min(hist.length - 1, histIdx.current + dir))
    histIdx.current = next
    setInput(next < 0 ? '' : hist[next])
  }

  const onKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      e.preventDefault()
      if (list.length) void run(list[Math.min(active, list.length - 1)])
      else void send()
    } else if (e.key === 'ArrowDown') {
      e.preventDefault()
      if (list.length) setActive((a) => (a + 1) % list.length)
      else recall(-1)
    } else if (e.key === 'ArrowUp') {
      e.preventDefault()
      if (list.length && input.trim()) setActive((a) => (a - 1 + list.length) % list.length)
      else if (list.length && active > 0) setActive((a) => a - 1)
      else recall(1)
    } else if (e.key === 'Tab' && list.length) {
      e.preventDefault()
      setActive((a) => (a + (e.shiftKey ? -1 : 1) + list.length) % list.length)
    }
  }

  const recents: Result[] = (JSON.parse(localStorage.getItem(HISTORY_KEY) || '[]') as string[]).slice(0, 3)
    .map((h) => ({ id: `recent:${h}`, kind: 'recent' as const, title: h, subtitle: 'Son kullanılan' }))
  const showSuggestions = !input.trim() && !selection && !reply && !busy && status === 'online'
  const list = input.trim() ? results : showSuggestions ? [...recents, ...QUICK] : []

  const voice = (snapshot?.state.voice ?? 'idle') as OrbState
  const orbState: OrbState = busy ? 'thinking' : voice

  return (
    <div ref={panelRef} className="flex flex-col">
      <div className="flex items-center gap-3 px-4" style={{ height: BAR_H }}>
        <LiquidOrb state={orbState} size={30} />
        <input
          ref={inputRef}
          value={input}
          onChange={(e) => {
            setInput(e.target.value)
            histIdx.current = -1
            if (selection?.clipboard && e.target.value.trim()) setSelection(null) // typing = a new intent
          }}
          onKeyDown={onKeyDown}
          placeholder={selection ? (selection.clipboard ? 'Kopyaladığın metinle ne yapayım? (ya da başka bir şey yaz)' : 'Seçili metinle ne yapayım?') : 'Uygulama, dosya, hesap ya da Jarvis\'e bir şey…'}
          disabled={status !== 'online'}
          className="min-w-0 flex-1 bg-transparent text-[17px] font-light text-fg !outline-none placeholder:text-fg-subtle"
          spellCheck={false}
        />
        {busy ? (
          <span className="text-[12px] text-fg-subtle">düşünüyor…</span>
        ) : (
          <kbd className="flex items-center gap-1 rounded-lg bg-fill px-2 py-1 text-[11px] text-fg-subtle">
            <CornerDownLeft className="size-3" />
          </kbd>
        )}
      </div>

      {list.length > 0 && !reply && (
        <ul className="border-t border-line px-2 py-2" role="listbox">
          {!input.trim() && <li className="px-3 pt-1 pb-1.5 text-[11px] text-fg-subtle">Öneriler</li>}
          {list.map((r, i) => {
            const Icon = ICONS[r.kind]
            const on = i === active
            return (
              <li key={r.id} role="option" aria-selected={on}>
                <button onMouseEnter={() => setActive(i)} onClick={() => void run(r)}
                  className={clsx('relative flex w-full items-center gap-3 rounded-xl px-3 py-2 text-left transition-colors',
                    on ? 'text-fg' : 'text-fg-muted')}>
                  {on && <motion.span layoutId="cmd-active" className="absolute inset-0 rounded-xl bg-accent-soft"
                    transition={{ type: 'spring', stiffness: 520, damping: 38 }} />}
                  {r.icon ? (
                    <img src={r.icon} alt="" className="relative size-7 shrink-0 rounded-lg object-contain" />
                  ) : (
                    <span className={clsx('relative grid size-7 shrink-0 place-items-center rounded-lg',
                      r.kind === 'action' || r.kind === 'calc' ? 'bg-accent text-white' : 'bg-fill')}>
                      <Icon className="size-[15px]" strokeWidth={1.8} />
                    </span>
                  )}
                  <span className="relative min-w-0 flex-1 truncate text-[14px]">{r.title}</span>
                  <span className="relative shrink-0 text-[11.5px] text-fg-subtle">{r.subtitle}</span>
                  {on && <CornerDownLeft className="relative size-3.5 shrink-0 text-fg-subtle" />}
                </button>
              </li>
            )
          })}
        </ul>
      )}

      <AnimatePresence initial={false}>
        {selection && !reply && (
          <motion.div key="sel" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="border-t border-line px-4 pt-3 pb-4">
            <div className="mb-1 flex items-center justify-between text-[11px] text-fg-subtle">
              <span>{selection.clipboard ? 'Kopyaladığın metin' : 'Seçili metin'}</span>
              <button onClick={() => setSelection(null)} className="hover:text-fg">kapat</button>
            </div>
            <p className="line-clamp-2 text-[12.5px] leading-relaxed text-fg-muted">“{selection.text}”</p>
            <div className="mt-2.5 flex flex-wrap gap-1.5">
              {ACTIONS.map((a) => (
                <button key={a} onClick={() => void send(a)} disabled={busy}
                  className="rounded-full bg-fill px-3 py-1.5 text-[12.5px] text-fg ring-1 ring-line ring-inset transition hover:bg-fill-strong">
                  {a}
                </button>
              ))}
            </div>
          </motion.div>
        )}

        {!selection && !reply && !error && !input.trim() && appActions && appActions.actions.length > 0 && (
          <motion.div key="app" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="border-t border-line px-4 pt-3 pb-4">
            <div className="mb-2 text-[11px] text-fg-subtle">{appActions.app} için</div>
            <div className="flex flex-wrap gap-1.5">
              {appActions.actions.map((a) => (
                <button key={a} onClick={() => void send(a)} disabled={busy}
                  className="rounded-full bg-fill px-3 py-1.5 text-[12.5px] text-fg ring-1 ring-line ring-inset transition hover:bg-fill-strong">
                  {a}
                </button>
              ))}
            </div>
          </motion.div>
        )}

        {(reply || error) && (
          <motion.div key="reply" initial={{ opacity: 0, y: -4 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}
            className="border-t border-line px-5 pt-3.5 pb-4">
            {error ? (
              <p className="text-[13.5px] text-amber-700 dark:text-amber-200">{error}</p>
            ) : (
              <div className="max-h-[320px] overflow-y-auto text-[14.5px] leading-relaxed font-light whitespace-pre-wrap text-fg">
                <Markdown text={reply!.text} />
              </div>
            )}
            <div className="mt-3 flex items-center gap-3 text-[11px] text-fg-subtle">
              {reply?.model === 'fast' ? (
                <span className="flex items-center gap-1 text-accent"><Zap className="size-3" /> anında · modele gitmedi</span>
              ) : reply ? (
                <span>{reply.model}{reply.steps.length ? ` · ${reply.steps.join(', ')}` : ''}</span>
              ) : null}
              <button onClick={() => api()?.open_main()}
                className="ml-auto flex items-center gap-1 transition-colors hover:text-fg">
                Ana pencerede aç <ArrowUpRight className="size-3" />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}
