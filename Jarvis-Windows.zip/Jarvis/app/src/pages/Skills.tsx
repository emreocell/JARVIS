import clsx from 'clsx'
import { motion } from 'framer-motion'
import { Search } from 'lucide-react'
import { useMemo, useState } from 'react'
import { Badge, Input, PageHeader } from '../components/ui'
import { ToolIcon } from '../components/ToolIcon'
import { norm } from '../lib/text'
import { RISK_LABEL, useToolCatalog, type ToolInfo } from '../lib/tools'

const ORDER = ['info', 'media', 'apps', 'communication', 'browser', 'ai-tools', 'routines', 'memory', 'screen',
  'desktop', 'system', 'files']

/** What Jarvis can do, in plain language: grouped cards with an example of how to ask. */
export function SkillsPage() {
  const tools = useToolCatalog()
  const [query, setQuery] = useState('')

  const groups = useMemo(() => {
    const q = norm(query)
    const match = (t: ToolInfo) => !q || norm(`${t.title} ${t.say} ${t.description} ${t.category_title}`).includes(q)
    const map = new Map<string, ToolInfo[]>()
    for (const t of tools.filter((t) => t.available && match(t))) {
      const k = t.category ?? 'other'
      map.set(k, [...(map.get(k) ?? []), t])
    }
    return [...map.entries()].sort(([a], [b]) => (ORDER.indexOf(a) + 99) % 99 - (ORDER.indexOf(b) + 99) % 99)
  }, [tools, query])
  const unavailable = tools.filter((t) => !t.available)
  const count = tools.filter((t) => t.available).length

  return (
    <div className="mx-auto max-w-5xl pb-10">
      <PageHeader title="Yetenekler"
        subtitle={`Jarvis'in yapabildiği ${count} şey. Riskli olanlar çalışmadan önce sana sorar.`}
        actions={
          <div className="relative w-64">
            <Search className="pointer-events-none absolute top-2.5 left-3 size-4 text-fg-subtle" />
            <Input className="w-full pl-9" placeholder="Yetenek ara…" value={query} onChange={(e) => setQuery(e.target.value)} />
          </div>
        } />

      <div className="flex flex-col gap-8">
        {groups.map(([cat, list], gi) => (
          <motion.section key={cat} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}
            transition={{ delay: Math.min(gi * 0.04, 0.3) }}>
            <h2 className="mb-3 flex items-center gap-2 px-1 text-[13px] font-medium text-fg-muted">
              <ToolIcon name={list[0].category_icon} className="size-4 text-accent" />
              {list[0].category_title ?? cat}
              <span className="text-fg-subtle">· {list.length}</span>
            </h2>
            <div className="grid grid-cols-1 gap-3 md:grid-cols-2 xl:grid-cols-3">
              {list.map((t) => {
                const risk = RISK_LABEL[t.risk ?? '']
                return (
                  <div key={t.name} className="panel card-hover flex flex-col gap-3 p-4" title={t.description}>
                    <div className="flex items-start gap-3">
                      <div className="grid size-10 shrink-0 place-items-center rounded-2xl bg-accent-soft text-accent">
                        <ToolIcon name={t.icon} className="size-5" />
                      </div>
                      <div className="min-w-0 flex-1">
                        <div className="text-[14.5px] leading-snug">{t.title}</div>
                        <p className="mt-0.5 line-clamp-2 text-[12px] leading-relaxed text-fg-subtle">{t.description}</p>
                      </div>
                    </div>
                    <div className="mt-auto flex items-center gap-2">
                      {t.say ? (
                        <span className="min-w-0 flex-1 truncate text-[12.5px] text-fg-muted italic">“{t.say}”</span>
                      ) : <span className="flex-1" />}
                      {risk && <Badge tone={risk.tone}>{risk.label}</Badge>}
                    </div>
                  </div>
                )
              })}
            </div>
          </motion.section>
        ))}
        {groups.length === 0 && tools.length > 0 && (
          <p className="py-16 text-center text-sm text-fg-muted">“{query}” ile eşleşen bir yetenek yok.</p>
        )}

        {unavailable.length > 0 && (
          <section>
            <h2 className="mb-3 px-1 text-[13px] font-medium text-fg-muted">Bu bilgisayarda kullanılamayanlar</h2>
            <div className="panel divide-y divide-line">
              {unavailable.map((t) => (
                <div key={t.name} className={clsx('flex items-center gap-3 px-5 py-3 text-sm')}>
                  <span className="text-fg-muted">{t.title ?? t.name}</span>
                  <span className="text-xs text-fg-subtle">{t.reason}</span>
                </div>
              ))}
            </div>
          </section>
        )}
      </div>
    </div>
  )
}
