import clsx from 'clsx'
import { Markdown } from '../components/Markdown'
import { AnimatePresence, motion } from 'framer-motion'
import {
  ArrowUp, Bell, Brain, ChevronRight, Code2, Eye, Mic, Music2, Sparkles, Sun, type LucideIcon,
} from 'lucide-react'
import { useCallback, useEffect, useRef, useState } from 'react'
import { VoiceBeam } from 'voice-glow'
import { LiquidOrb, type OrbState } from '../components/LiquidOrb'
import { NowPlaying } from '../components/NowPlaying'
import { Timers } from '../components/Timers'
import { WeatherCard } from '../components/WeatherCard'
import { BriefCard } from '../components/BriefCard'
import { MeetingCard } from '../components/MeetingCard'
import { requestHistorySession } from './History'
import type { PageId } from '../components/Sidebar'
import { Waveform } from '../components/Waveform'
import { client, RpcError, type CoreEvent } from '../lib/rpc'
import { useCore, useCoreEvent } from '../lib/useCore'
import { currentLevel } from '../lib/voiceLevel'
import { useWeather, weatherIcon } from '../lib/weather'

interface Line { id: number; role: 'user' | 'assistant'; text: string; live?: boolean }
interface Summary {
  greeting: string
  user_name: string
  episodes: { id: string; ended: number; summary: string }[]
  reminders: { id: number; kind: string; text: string; due_local: string }[]
  projects: string[]
  now_playing: { title: string; artist: string; playing: boolean } | null
  memory_count: number
  recent_facts: string[]
}
interface Suggestion { icon: LucideIcon; title: string; hint: string; prompt: string }

const STATUS: Record<OrbState, string> = {
  idle: 'Seni dinlemek için “Hey Jarvis” de',
  listening: 'Dinliyorum…',
  thinking: 'Düşünüyorum…',
  speaking: 'Konuşuyor',
  muted: 'Sesli asistan kapalı',
  error: 'Bir şeyler ters gitti',
}
const ease = [0.22, 1, 0.36, 1] as const

function ago(ts: number) {
  const m = Math.round((Date.now() / 1000 - ts) / 60)
  if (m < 60) return `${Math.max(1, m)} dk önce`
  const h = Math.round(m / 60)
  if (h < 24) return `${h} sa önce`
  const d = Math.round(h / 24)
  return d === 1 ? 'Dün' : `${d} gün önce`
}

function suggestions(s: Summary | null): Suggestion[] {
  const out: Suggestion[] = []
  if (s?.reminders[0]) {
    const r = s.reminders[0]
    out.push({ icon: Bell, title: 'Sıradaki hatırlatıcı', hint: `${r.text} · ${r.due_local.slice(-5)}`,
      prompt: 'Yaklaşan hatırlatıcılarımı ve alarmlarımı oku.' })
  }
  if (s?.projects[0]) {
    out.push({ icon: Code2, title: `${s.projects[0]} projesine dön`, hint: 'Nerede kaldığını hatırlatayım',
      prompt: `Şu an ${s.projects[0]} projesi üzerinde çalışıyorum. Nerede kalmıştık, bağlamı özetle.` })
  }
  if (s?.now_playing?.title) {
    out.push({ icon: Music2, title: s.now_playing.playing ? 'Şu an çalıyor' : 'Duraklatıldı',
      hint: `${s.now_playing.title}${s.now_playing.artist ? ' · ' + s.now_playing.artist : ''}`,
      prompt: s.now_playing.playing ? 'Sonraki şarkıya geç.' : 'Müziği devam ettir.' })
  }
  const defaults: Suggestion[] = [
    { icon: Sun, title: 'Güne başlayalım', hint: 'Hatırlatıcılar ve günün özeti', prompt: 'günün özeti' },
    { icon: Eye, title: 'Ekranıma bak', hint: 'Gördüğün şeyde yardım et', prompt: 'Ekranıma bak ve ne yaptığımı anlayıp yardım et.' },
    { icon: Music2, title: 'Odak müziği', hint: "Spotify'da sakin bir liste", prompt: "Spotify'da odaklanmak için sakin bir çalma listesi aç." },
    { icon: Sparkles, title: 'Bir rutin kur', hint: '“VS Code açılınca sor” gibi', prompt: 'Bana faydalı olabilecek bir rutin öner ve kurmama yardım et.' },
  ]
  for (const d of defaults) if (out.length < 4 && !out.some((o) => o.icon === d.icon)) out.push(d)
  return out.slice(0, 4)
}

/** The presence screen: greeting, the orb, context-aware suggestions and a quiet side panel. */
export function HomePage({ onNavigate }: { onNavigate?: (p: PageId) => void }) {
  const { snapshot, status } = useCore()
  const [lines, setLines] = useState<Line[]>([])
  const [input, setInput] = useState('')
  const [busy, setBusy] = useState(false)
  const [note, setNote] = useState<string | null>(null)
  const [selection, setSelection] = useState<string | null>(null)
  const [summary, setSummary] = useState<Summary | null>(null)
  const nextId = useRef(1)
  const inputRef = useRef<HTMLTextAreaElement>(null)

  const voiceOn = Boolean(snapshot?.config.voice.enabled) && snapshot?.state.voice !== 'muted'
  const state: OrbState = busy ? 'thinking' : ((snapshot?.state.voice ?? 'idle') as OrbState)
  const online = status === 'online'
  const conversing = lines.length > 0
  const name = summary?.user_name || snapshot?.config.assistant?.user_name || ''

  const loadSummary = useCallback(() => {
    if (online) client.call<Summary>('home.summary').then(setSummary).catch(() => {})
  }, [online])
  useEffect(() => {
    loadSummary()
    const t = window.setInterval(loadSummary, 60_000)
    return () => window.clearInterval(t)
  }, [loadSummary])

  const upsert = useCallback((role: 'user' | 'assistant', text: string) => {
    setLines((ls) => {
      const last = ls[ls.length - 1]
      if (last?.live && last.role === role) return [...ls.slice(0, -1), { ...last, text }]
      return [...ls.map((l) => ({ ...l, live: false })), { id: nextId.current++, role, text, live: true }].slice(-8)
    })
  }, [])

  useCoreEvent('voice.transcript', useCallback((e: CoreEvent) => upsert(e.data.role as 'user' | 'assistant', String(e.data.text)), [upsert]))
  useCoreEvent('voice.turn_complete', useCallback(() => {
    setLines((ls) => ls.map((l) => ({ ...l, live: false })))
    loadSummary()
  }, [loadSummary]))
  useCoreEvent('voice.error', useCallback((e: CoreEvent) => setNote(String(e.data.message)), []))
  useCoreEvent('routine.changed', useCallback(() => loadSummary(), [loadSummary]))
  useCoreEvent('hotkey.command_bar', useCallback(() => { window.setTimeout(() => inputRef.current?.focus(), 80) }, []))
  useCoreEvent('selection.captured', useCallback((e: CoreEvent) => {
    const text = String(e.data.text || '')
    if (text) setSelection(text)
    else setNote('Seçili metin bulunamadı — önce bir metni seç.')
  }, []))

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === '/' && document.activeElement !== inputRef.current) {
        e.preventDefault()
        inputRef.current?.focus()
      }
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [])

  const send = async (override?: string) => {
    const typed = (override ?? input).trim()
    if ((!typed && !selection) || busy) return
    const text = selection ? `${typed || 'Bu metinle ilgili yardımcı ol'}:\n"""\n${selection}\n"""` : typed
    setSelection(null)
    setInput('')
    setNote(null)
    if (voiceOn) {
      client.call('voice.say', { text }).catch((e) => setNote(e instanceof RpcError ? e.message : String(e)))
      return
    }
    upsert('user', typed || 'Seçili metin')
    setBusy(true)
    try {
      const r = await client.call<{ text: string }>('chat.send', { text })
      upsert('assistant', r.text || '✓')
    } catch (e) {
      setNote(e instanceof RpcError ? e.message : String(e))
    } finally {
      setBusy(false)
      setLines((ls) => ls.map((l) => ({ ...l, live: false })))
    }
  }

  const ptt = (pressed: boolean) =>
    client.call('voice.ptt', { pressed }).catch((e) => setNote(e instanceof RpcError ? e.message : String(e)))

  const visible = lines.slice(-4)
  const sugg = suggestions(summary)
  const audible = state === 'listening' || state === 'speaking'

  return (
    <div className="flex h-full gap-6">
      {/* ---------------- centre stage ---------------- */}
      <div className="relative mx-auto flex h-full max-w-[860px] min-w-0 flex-1 flex-col items-center">
        <AnimatePresence initial={false}>
          {!conversing && (
            <motion.div
              key="hero"
              initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -12, filter: 'blur(8px)' }}
              transition={{ duration: 0.6, ease }}
              className="mt-[5vh] text-center"
            >
              <h1 className="font-display text-[clamp(30px,4.2vw,50px)] leading-tight font-light tracking-tight">
                {summary?.greeting ?? 'Merhaba'}{name && <>, <span className="text-aurora font-normal">{name}</span></>}
              </h1>
              <p className="mt-2 text-[16px] font-light text-fg-muted">Bugün sana nasıl yardım edebilirim?</p>
              <WeatherLine />
            </motion.div>
          )}
        </AnimatePresence>

        <motion.div
          className="relative flex flex-col items-center"
          animate={{ scale: conversing ? 0.62 : 1, marginTop: conversing ? '-2vh' : '1vh' }}
          transition={{ duration: 0.9, ease }}
        >
          <LiquidOrb state={state} levelSource={currentLevel} size="min(38vh, 360px)" />
          <div className="glass -mt-3 flex h-10 items-center gap-3 rounded-full px-4">
            <span className={clsx('size-1.5 rounded-full transition-colors',
              audible ? 'bg-accent shadow-[0_0_10px_var(--accent)]' : state === 'error' ? 'bg-red-500' : 'bg-fg-subtle')} />
            <AnimatePresence mode="wait">
              <motion.span key={online ? state : 'offline'} initial={{ opacity: 0, y: 4 }} animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -4 }} transition={{ duration: 0.25 }} className="text-[13.5px] text-fg-muted">
                {online ? STATUS[state] : 'Çekirdek başlatılıyor…'}
              </motion.span>
            </AnimatePresence>
            {audible && <Waveform level={currentLevel} active className="h-5 w-24" />}
          </div>
        </motion.div>

        {/* conversation or suggestions */}
        <div className="flex w-full flex-1 flex-col justify-end overflow-hidden pt-6 pb-5">
          {conversing ? (
            <div className="flex flex-col gap-4">
              <AnimatePresence initial={false}>
                {visible.map((l, i) => {
                  const age = visible.length - 1 - i
                  return (
                    <motion.div key={l.id} layout
                      initial={{ opacity: 0, y: 14, filter: 'blur(8px)' }}
                      animate={{ opacity: Math.max(0.2, 1 - age * 0.27), y: 0, filter: 'blur(0px)' }}
                      exit={{ opacity: 0, y: -10 }} transition={{ duration: 0.5, ease }}
                      className={clsx('max-w-[86%] leading-relaxed whitespace-pre-wrap',
                        l.role === 'user'
                          ? 'self-end rounded-3xl rounded-br-lg bg-fill px-4 py-2.5 text-[15px] text-fg'
                          : 'self-start text-[17px] font-light text-fg')}>
                      {l.role === 'assistant' && !l.live ? <Markdown text={l.text} /> : l.text}
                      {l.live && <span className="ml-1.5 inline-block size-1.5 animate-pulse rounded-full bg-accent align-middle" />}
                    </motion.div>
                  )
                })}
              </AnimatePresence>
              <button onClick={() => setLines([])} className="self-center text-[12px] text-fg-subtle hover:text-fg">
                Yeni konuşma
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-4">
              {sugg.map((s, i) => (
                <motion.button key={s.title}
                  initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: 0.15 + i * 0.06, ease }}
                  onClick={() => void send(s.prompt)}
                  className="panel card-hover group flex items-start gap-3 p-4 text-left">
                  <span className="grid size-9 shrink-0 place-items-center rounded-2xl bg-accent-soft text-accent">
                    <s.icon className="size-[17px]" strokeWidth={1.7} />
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block text-[14px] leading-snug">{s.title}</span>
                    <span className="mt-0.5 line-clamp-2 block text-[12.5px] leading-snug text-fg-muted">{s.hint}</span>
                  </span>
                </motion.button>
              ))}
            </div>
          )}
        </div>

        {note && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}
            className="mb-3 max-w-xl text-center text-xs text-red-600 dark:text-red-300" onClick={() => setNote(null)}>
            {note}
          </motion.div>
        )}

        <AnimatePresence>
          {selection && (
            <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 8 }}
              transition={{ duration: 0.35, ease }} className="glass mb-3 w-full rounded-3xl p-3">
              <div className="flex items-start gap-3 px-1">
                <div className="line-clamp-2 flex-1 text-[13px] leading-relaxed text-fg-muted">“{selection}”</div>
                <button onClick={() => setSelection(null)} className="text-[12px] text-fg-subtle hover:text-fg">kaldır</button>
              </div>
              <div className="mt-2.5 flex flex-wrap gap-1.5">
                {['Özetle', 'Türkçeye çevir', 'İngilizceye çevir', 'Açıkla', 'Daha iyi yeniden yaz', 'Cevap taslağı yaz'].map((a) => (
                  <button key={a} onClick={() => void send(a)}
                    className="rounded-full bg-fill px-3 py-1.5 text-[12.5px] text-fg ring-1 ring-line ring-inset transition hover:bg-fill-strong">
                    {a}
                  </button>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* composer */}
        <div className="w-full pb-7">
          <VoiceBeam type="pill" level={currentLevel} processing={state === 'thinking'} colorVariant="colorful" idle={0.12}
            paused={!audible && state !== 'thinking' && !busy}>
            <div className="glass flex items-center gap-1.5 rounded-full py-2 pr-2 pl-2.5">
              <button aria-label="Basılı tut ve konuş" title="Basılı tut ve konuş" disabled={!voiceOn || !online}
                onPointerDown={(e) => { e.currentTarget.setPointerCapture(e.pointerId); void ptt(true) }}
                onPointerUp={() => void ptt(false)} onPointerCancel={() => void ptt(false)}
                className={clsx('grid size-11 shrink-0 touch-none place-items-center rounded-full transition-all disabled:opacity-35',
                  state === 'listening' ? 'bg-accent text-white shadow-[0_6px_20px_-6px_var(--accent)]' : 'bg-accent-soft text-accent hover:scale-[1.04]')}>
                <Mic className="size-[19px]" strokeWidth={1.8} />
              </button>
              <textarea ref={inputRef} rows={1} value={input}
                placeholder={voiceOn ? 'Bir şey söyle ya da yaz…' : 'Jarvis’e yaz…'}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); void send() } }}
                className="max-h-32 min-h-10 flex-1 resize-none bg-transparent px-2 py-2.5 text-[15px] outline-none placeholder:text-fg-subtle" />
              <button onClick={() => void send()} aria-label="Gönder" disabled={(!input.trim() && !selection) || busy || !online}
                className="grid size-11 shrink-0 place-items-center rounded-full bg-gradient-to-br from-accent to-accent-2 text-white shadow-[0_8px_22px_-8px_var(--accent)] transition hover:scale-[1.05] disabled:scale-100 disabled:from-fill-strong disabled:to-fill-strong disabled:text-fg-subtle disabled:shadow-none">
                <ArrowUp className="size-[19px]" strokeWidth={2} />
              </button>
            </div>
          </VoiceBeam>
        </div>
      </div>

      {/* ---------------- side panel ---------------- */}
      <aside className="hidden w-[300px] shrink-0 flex-col gap-4 overflow-y-auto py-2 pb-7 xl:flex [&>*]:shrink-0">
        <Timers compact />
        <WeatherCard />
        <BriefCard />
        <MeetingCard />
        <NowPlaying />
        <section className="panel p-4">
          <div className="mb-3 flex items-center justify-between px-1">
            <h2 className="text-[14px]">Son konuşmalar</h2>
            <button onClick={() => onNavigate?.('history')}
              className="text-[12px] text-fg-subtle transition-colors hover:text-accent">Tümü</button>
          </div>
          {summary?.episodes.length ? (
            <ul className="flex flex-col gap-1">
              {summary.episodes.slice(0, 4).map((e) => (
                <li key={e.id}>
                  <button onClick={() => { requestHistorySession(e.id); onNavigate?.('history') }}
                    className="flex w-full items-baseline justify-between gap-2 rounded-2xl px-2 py-2 text-left transition hover:bg-fill">
                    <span className="line-clamp-2 text-[13px] leading-snug">{e.summary}</span>
                    <span className="shrink-0 text-[11px] text-fg-subtle">{ago(e.ended)}</span>
                  </button>
                </li>
              ))}
            </ul>
          ) : (
            <p className="px-1 text-[12.5px] leading-relaxed text-fg-muted">Konuştukça burada kısa özetler birikir.</p>
          )}
        </section>

        {summary?.reminders.length ? (
          <section className="panel p-4">
            <h2 className="mb-2 px-1 text-[14px]">Yaklaşanlar</h2>
            <ul className="flex flex-col gap-1">
              {summary.reminders.map((r) => (
                <li key={r.id} className="flex items-center gap-3 rounded-2xl px-2 py-2">
                  <Bell className="size-4 shrink-0 text-accent" strokeWidth={1.7} />
                  <span className="min-w-0 flex-1 truncate text-[13px]">{r.text}</span>
                  <span className="text-[11.5px] text-fg-subtle tabular-nums">{r.due_local.slice(-5)}</span>
                </li>
              ))}
            </ul>
          </section>
        ) : null}

        <button onClick={() => onNavigate?.('memory')} className="panel card-hover p-4 text-left">
          <div className="flex items-center gap-3">
            <span className="grid size-9 place-items-center rounded-2xl bg-accent-soft text-accent">
              <Brain className="size-[17px]" strokeWidth={1.7} />
            </span>
            <span className="flex-1">
              <span className="block text-[14px]">Seni tanıyorum</span>
              <span className="block text-[12.5px] text-fg-muted">
                {summary?.memory_count ? `${summary.memory_count} şey hatırlıyorum` : 'Konuştukça öğreneceğim'}
              </span>
            </span>
            <ChevronRight className="size-4 text-fg-subtle" />
          </div>
          {summary?.recent_facts.length ? (
            <ul className="mt-3 flex flex-col gap-1.5 border-t border-line pt-3">
              {summary.recent_facts.map((f) => (
                <li key={f} className="line-clamp-1 text-[12.5px] text-fg-muted">· {f}</li>
              ))}
            </ul>
          ) : null}
        </button>
      </aside>
    </div>
  )
}

/** "Ladik · 11° kapalı" under the greeting (hidden on wide screens where the card shows). */
function WeatherLine() {
  const { weather: w } = useWeather()
  if (!w) return null
  const Icon = weatherIcon(w.now.code, w.now.is_day)
  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}
      className="mt-3 inline-flex items-center gap-2 rounded-full bg-fill px-3 py-1 text-[12.5px] text-fg-muted xl:hidden">
      <Icon className="size-3.5 text-accent" strokeWidth={1.8} />
      {w.place} · {w.now.temp}° {w.now.summary}
    </motion.div>
  )
}
