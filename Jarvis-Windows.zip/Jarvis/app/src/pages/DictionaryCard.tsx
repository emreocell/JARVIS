import { BookOpen, Plus, X } from 'lucide-react'
import { useState } from 'react'
import { Button, Card, Input } from '../components/ui'
import { client } from '../lib/rpc'

export interface DictEntry { term: string; sounds_like: string[]; note: string }

/** Personal dictionary: names Jarvis must always hear and write correctly. */
export function DictionaryCard({ entries }: { entries: DictEntry[] }) {
  const [term, setTerm] = useState('')
  const [heard, setHeard] = useState('')
  const [note, setNote] = useState('')

  const save = (next: DictEntry[]) => client.call('config.patch', { patch: { assistant: { dictionary: next } } })
  const add = async () => {
    const t = term.trim()
    if (!t) return
    const sounds = heard.split(',').map((s) => s.trim()).filter(Boolean)
    await save([...entries.filter((e) => e.term.toLowerCase() !== t.toLowerCase()),
      { term: t, sounds_like: sounds, note: note.trim() }])
    setTerm(''); setHeard(''); setNote('')
  }

  return (
    <section>
      <h2 className="mb-3 px-1 text-[13px] text-fg-muted">Kişisel sözlük</h2>
      <Card className="p-5">
        <div className="flex items-start gap-4">
          <div className="grid size-10 shrink-0 place-items-center rounded-2xl bg-fill">
            <BookOpen className="size-[18px] text-fg-muted" strokeWidth={1.6} />
          </div>
          <div className="min-w-0 flex-1">
            <p className="text-[12.5px] leading-relaxed text-fg-muted">
              Proje, şirket ve kişi adları gibi Jarvis'in asla yanlış anlamaması gereken kelimeler. Konuşma tanıma ve
              yapay zekâ bunları hep doğru yazar; "nasıl duyulabilir" kısmına yazdıklarını otomatik düzeltir.
              Sesle de ekleyebilirsin: "Webioo'yu öğren, web yo diye anlıyorsun".
            </p>
            {entries.length > 0 && (
              <ul className="mt-3 flex flex-wrap gap-2">
                {entries.map((e) => (
                  <li key={e.term} className="flex items-center gap-2 rounded-full bg-fill py-1 pr-1.5 pl-3 text-[12.5px]">
                    <span>{e.term}</span>
                    {e.sounds_like.length > 0 && <span className="text-fg-subtle">← {e.sounds_like.join(', ')}</span>}
                    <button aria-label={`${e.term} sil`} onClick={() => save(entries.filter((x) => x.term !== e.term))}
                      className="grid size-5 place-items-center rounded-full text-fg-subtle transition hover:bg-fill-strong hover:text-fg">
                      <X className="size-3" />
                    </button>
                  </li>
                ))}
              </ul>
            )}
            <div className="mt-3 grid gap-2 sm:grid-cols-[1fr_1.4fr_1fr_auto]">
              <Input placeholder="Doğru yazılış" value={term} onChange={(e) => setTerm(e.target.value)} />
              <Input placeholder="Nasıl duyulabilir (virgülle)" value={heard} onChange={(e) => setHeard(e.target.value)} />
              <Input placeholder="Not (isteğe bağlı)" value={note} onChange={(e) => setNote(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && add()} />
              <Button variant="primary" onClick={add} disabled={!term.trim()}><Plus className="size-4" />Ekle</Button>
            </div>
          </div>
        </div>
      </Card>
    </section>
  )
}
