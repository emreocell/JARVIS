import { CheckCircle2, KeyRound, Plus, Trash2, XCircle, Zap } from 'lucide-react'
import { useEffect, useState } from 'react'
import { Badge, Button, Card, Input, PageHeader, Toggle } from '../components/ui'
import { client, RpcError } from '../lib/rpc'
import type { AppConfig, ProviderConfig, QuotaRow, SecretInfo } from '../lib/types'
import { useCore } from '../lib/useCore'

const TYPE_LABEL: Record<ProviderConfig['type'], string> = {
  gemini: 'Gemini',
  openai_compatible: 'OpenAI uyumlu',
  typesafe: 'Karar modeli',
}

const ROLE_LABEL: Record<string, string> = {
  voice_brain: 'Ses beyni',
  text_worker: 'Metin işleri',
  fast_decider: 'Hızlı karar',
  vision_ground: 'Ekranda konum bulma',
  embedding: 'Hafıza vektörleri',
  stt: 'Konuşmayı yazıya çevirme',
}

type TestResult = { key?: string; ok: boolean; error?: string; models?: string[]; latency_ms?: number }

function patchProviders(config: AppConfig, fn: (list: ProviderConfig[]) => ProviderConfig[]) {
  return client.call('config.patch', { patch: { providers: fn(structuredClone(config.providers)) } })
}

function QuotaBar({ used, limit }: { used: number; limit: number | null }) {
  if (limit === null) return <span className="text-fg-subtle">sınırsız</span>
  const pct = limit === 0 ? 100 : Math.min(100, (used / limit) * 100)
  return (
    <div className="flex items-center gap-2">
      <div className="h-1.5 w-20 overflow-hidden rounded-full bg-fill-strong">
        <div
          className={pct > 85 ? 'h-full bg-danger' : pct > 60 ? 'h-full bg-warn' : 'h-full bg-accent'}
          style={{ width: `${pct}%` }}
        />
      </div>
      <span className="tabular-nums">
        {used}/{limit}
      </span>
    </div>
  )
}

type DeciderStats = { compared: number; agreement: number | null; jev_latency_ms: number; llm_latency_ms: number }

function ProviderCard({
  provider,
  config,
  secrets,
  quota,
  decider,
}: {
  provider: ProviderConfig
  config: AppConfig
  secrets: SecretInfo[]
  quota: QuotaRow[]
  decider?: DeciderStats
}) {
  const [key, setKey] = useState('')
  const [busy, setBusy] = useState(false)
  const [results, setResults] = useState<TestResult[] | null>(null)
  const [error, setError] = useState<string | null>(null)

  const keyInfos = provider.keys.map((ref) => secrets.find((s) => s.ref === ref) ?? { ref, name: ref, masked: '—' })

  const addKey = async () => {
    setError(null)
    const existing = new Set(secrets.map((s) => s.name))
    let n = provider.keys.length + 1
    while (existing.has(`${provider.id}_${n}`)) n++
    try {
      await client.call('secrets.set', { name: `${provider.id}_${n}`, value: key, provider: provider.id })
      setKey('')
    } catch (e) {
      setError(e instanceof RpcError ? e.message : String(e))
    }
  }

  const test = async () => {
    setBusy(true)
    setResults(null)
    try {
      setResults(await client.call<TestResult[]>('providers.test', { provider: provider.id }))
    } catch (e) {
      setResults([{ ok: false, error: e instanceof Error ? e.message : String(e) }])
    } finally {
      setBusy(false)
    }
  }

  return (
    <Card>
      <div className="flex items-center gap-3 px-5 py-4">
        <div className="flex-1">
          <div className="flex items-center gap-2">
            <span className="font-medium">{provider.label || provider.id}</span>
            <Badge>{TYPE_LABEL[provider.type]}</Badge>
            {provider.quota_profile && <Badge tone="accent">{provider.quota_profile}</Badge>}
          </div>
          {provider.base_url && <div className="mt-0.5 font-mono text-xs text-fg-subtle">{provider.base_url}</div>}
          {provider.type === 'typesafe' && decider && decider.compared > 0 && (
            <div className="mt-1.5 text-[12px] text-fg-muted">
              Gölge mod: LLM ile uyuşma %{Math.round((decider.agreement ?? 0) * 100)} · {decider.compared} karşılaştırma ·
              Jev {decider.jev_latency_ms} ms / LLM {decider.llm_latency_ms} ms
            </div>
          )}
        </div>
        <Button size="sm" onClick={test} loading={busy} disabled={!provider.enabled || provider.keys.length === 0}>
          <Zap className="size-3.5" /> Test et
        </Button>
        <Toggle
          label="Açık"
          checked={provider.enabled}
          onChange={(v) => patchProviders(config, (l) => l.map((p) => (p.id === provider.id ? { ...p, enabled: v } : p)))}
        />
      </div>

      <div className="border-t border-line px-5 py-3">
        <ul className="flex flex-col gap-1.5">
          {keyInfos.map((k) => {
            const r = results?.find((x) => x.key === k.name)
            return (
              <li key={k.ref} className="flex items-center gap-2 text-sm">
                <KeyRound className="size-3.5 text-fg-subtle" />
                <span className="font-mono text-xs">{k.masked}</span>
                <span className="text-xs text-fg-subtle">{k.name}</span>
                {r &&
                  (r.ok ? (
                    <span className="flex items-center gap-1 text-xs text-ok">
                      <CheckCircle2 className="size-3.5" />
                      {r.models ? `${r.models.length} model` : `${r.latency_ms} ms`}
                    </span>
                  ) : (
                    <span className="flex items-center gap-1 truncate text-xs text-danger" title={r.error}>
                      <XCircle className="size-3.5" /> {r.error}
                    </span>
                  ))}
                <Button
                  variant="ghost"
                  size="sm"
                  className="ml-auto"
                  aria-label="Anahtarı sil"
                  onClick={() => client.call('secrets.delete', { name: k.name })}
                >
                  <Trash2 className="size-3.5" />
                </Button>
              </li>
            )
          })}
        </ul>
        {results?.some((r) => !r.key) && <div className="text-xs text-danger">{results[0].error}</div>}
        <div className="mt-2 flex gap-2">
          <Input
            className="flex-1"
            type="password"
            autoComplete="off"
            placeholder={provider.keys.length ? 'Havuza anahtar ekle' : 'API anahtarı'}
            value={key}
            onChange={(e) => setKey(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && key.trim() && addKey()}
          />
          <Button onClick={addKey} disabled={!key.trim()}>
            <Plus className="size-4" /> Ekle
          </Button>
        </div>
        {error && <div className="mt-2 text-xs text-danger">{error}</div>}
        <p className="mt-2 text-[11px] text-fg-subtle">Anahtarlar Windows Kimlik Bilgisi Yöneticisi'nde saklanır.</p>
      </div>

      {quota.length > 0 && <QuotaTable quota={quota} />}
    </Card>
  )
}

/** One row per model: usage summed over the key pool (what actually limits
 *  Jarvis), per-key detail in the tooltip. */
function QuotaTable({ quota }: { quota: QuotaRow[] }) {
  const sum = (a: number | null, b: number | null) => (a == null || b == null ? null : a + b)
  const models = new Map<string, QuotaRow & { keys: QuotaRow[] }>()
  for (const q of quota) {
    const m = models.get(q.model)
    if (!m) models.set(q.model, { ...q, keys: [q] })
    else {
      m.keys.push(q)
      m.rpm_used += q.rpm_used
      m.rpd_used += q.rpd_used
      m.rpm_limit = sum(m.rpm_limit, q.rpm_limit)
      m.rpd_limit = sum(m.rpd_limit, q.rpd_limit)
      m.cooldown_s = Math.min(m.cooldown_s, q.cooldown_s) // pool is blocked only if every key is
    }
  }
  const rows = [...models.values()]
  return (
    <div className="overflow-x-auto border-t border-line px-5 py-3">
      <table className="w-full text-xs">
        <thead className="text-left text-fg-subtle">
          <tr>
            <th className="pb-2 font-medium">Model</th>
            <th className="pb-2 font-medium">Anahtar</th>
            <th className="pb-2 font-medium">Dakikalık</th>
            <th className="pb-2 font-medium">Günlük</th>
          </tr>
        </thead>
        <tbody className="text-fg-muted">
          {rows.map((q) => (
            <tr key={q.model} title={q.keys.map((k) => `${k.key}: ${k.rpd_used}/${k.rpd_limit ?? '∞'} bugün`).join('\n')}>
              <td className="py-1 font-mono">{q.model}</td>
              <td className="py-1">{q.keys.length > 1 ? `${q.keys.length} anahtar` : q.key}</td>
              <td className="py-1">
                <QuotaBar used={q.rpm_used} limit={q.rpm_limit} />
              </td>
              <td className="py-1">
                <QuotaBar used={q.rpd_used} limit={q.rpd_limit} />
                {q.cooldown_s > 0 && <Badge tone="warn">{Math.ceil(q.cooldown_s)} sn bekliyor</Badge>}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}

function AddProvider({ config }: { config: AppConfig }) {
  const [open, setOpen] = useState(false)
  const [form, setForm] = useState({ id: '', label: '', base_url: '', model: '' })
  const [error, setError] = useState<string | null>(null)

  const submit = async () => {
    setError(null)
    try {
      await patchProviders(config, (l) => [
        ...l,
        {
          id: form.id.trim().toLowerCase(),
          type: 'openai_compatible',
          label: form.label.trim(),
          base_url: form.base_url.trim(),
          keys: [],
          models: form.model.trim() ? [{ id: form.model.trim(), caps: ['text'] }] : [],
          quota_profile: null,
          headers: {},
          enabled: true,
        },
      ])
      setOpen(false)
      setForm({ id: '', label: '', base_url: '', model: '' })
    } catch (e) {
      setError(e instanceof RpcError ? 'Geçersiz bilgi: kimlik küçük harf/rakam/tire olmalı ve adres gerekli.' : String(e))
    }
  }

  if (!open)
    return (
      <Button onClick={() => setOpen(true)}>
        <Plus className="size-4" /> Sağlayıcı ekle
      </Button>
    )

  return (
    <Card className="p-5">
      <div className="mb-3 text-sm font-medium">OpenAI uyumlu sağlayıcı</div>
      <div className="grid grid-cols-2 gap-3">
        <Input className="w-full" placeholder="kimlik (örn. cerebras)" value={form.id} onChange={(e) => setForm({ ...form, id: e.target.value })} />
        <Input className="w-full" placeholder="görünen ad" value={form.label} onChange={(e) => setForm({ ...form, label: e.target.value })} />
        <Input
          className="col-span-2 w-full"
          placeholder="https://api.ornek.com/v1"
          value={form.base_url}
          onChange={(e) => setForm({ ...form, base_url: e.target.value })}
        />
        <Input
          className="col-span-2 w-full"
          placeholder="model (örn. llama-3.3-70b)"
          value={form.model}
          onChange={(e) => setForm({ ...form, model: e.target.value })}
        />
      </div>
      {error && <div className="mt-2 text-xs text-danger">{error}</div>}
      <div className="mt-4 flex justify-end gap-2">
        <Button variant="ghost" onClick={() => setOpen(false)}>
          Vazgeç
        </Button>
        <Button variant="primary" onClick={submit} disabled={!form.id || !form.base_url}>
          Kaydet
        </Button>
      </div>
    </Card>
  )
}

function LegacyImport() {
  const [status, setStatus] = useState<{ found: boolean; providers?: string[]; count?: number } | null>(null)
  const [busy, setBusy] = useState(false)
  const [done, setDone] = useState<string | null>(null)

  useEffect(() => {
    client.call<typeof status>('migrate.legacy_status').then(setStatus).catch(() => setStatus(null))
  }, [])

  if (!status?.found || done) {
    return done ? <div className="mb-4 rounded-xl bg-ok/10 px-4 py-3 text-sm text-ok">{done}</div> : null
  }
  const run = async () => {
    setBusy(true)
    try {
      const r = await client.call<{ imported: string[] }>('migrate.import_legacy_keys')
      setDone(r.imported.length ? `${r.imported.length} anahtar içe aktarıldı.` : 'Tüm anahtarlar zaten ekli.')
    } catch (e) {
      setDone(e instanceof Error ? e.message : String(e))
    } finally {
      setBusy(false)
    }
  }
  return (
    <Card className="mb-4 flex items-center gap-4 border-accent/30 bg-accent-soft px-5 py-4">
      <div className="flex-1 text-sm">
        <div className="font-medium">Eski Jarvis bulundu</div>
        <div className="mt-0.5 text-xs text-fg-muted">
          {status.count} API anahtarı ({status.providers?.join(', ')}) güvenli kasaya aktarılabilir.
        </div>
      </div>
      <Button variant="primary" onClick={run} loading={busy}>
        İçe aktar
      </Button>
    </Card>
  )
}

export function ProvidersPage() {
  const { snapshot } = useCore()
  if (!snapshot) return <div className="text-sm text-fg-muted">Yükleniyor…</div>
  const { config, secrets, providers } = snapshot

  return (
    <div className="mx-auto max-w-4xl">
      <PageHeader
        title="Sağlayıcılar"
        subtitle="Birden fazla anahtar bir havuz olarak kullanılır; kotası dolan anahtar otomatik atlanır."
        actions={<AddProvider config={config} />}
      />
      <LegacyImport />
      <div className="flex flex-col gap-4">
        {config.providers.map((p) => (
          <ProviderCard
            key={p.id}
            provider={p}
            config={config}
            secrets={secrets}
            quota={providers.quota.filter((q) => q.provider === p.id)}
            decider={(snapshot as unknown as { decider?: DeciderStats }).decider}
          />
        ))}
      </div>

      <h2 className="mt-10 mb-3 px-1 text-[13px] text-fg-muted">Roller</h2>
      <Card className="divide-y divide-line">
        {Object.entries(config.routes).map(([role, targets]) => (
          <div key={role} className="flex items-center gap-4 px-5 py-3">
            <div className="w-48 text-sm">{ROLE_LABEL[role] ?? role}</div>
            <div className="flex flex-wrap gap-1.5">
              {targets.map((t, i) => (
                <Badge key={i} tone={i === 0 ? 'accent' : 'neutral'}>
                  {i + 1}. {t.provider} / {t.model}
                </Badge>
              ))}
            </div>
          </div>
        ))}
      </Card>
    </div>
  )
}
