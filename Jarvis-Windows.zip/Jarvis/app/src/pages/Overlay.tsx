import { AnimatePresence, motion } from 'framer-motion'
import { useCallback, useEffect, useState } from 'react'
import { LiquidOrb, type OrbState } from '../components/LiquidOrb'
import { client, type CoreEvent } from '../lib/rpc'
import { useApplyTheme } from '../lib/theme'
import { useCore, useCoreEvent } from '../lib/useCore'
import { currentLevel } from '../lib/voiceLevel'

const LABEL: Record<string, string> = {
  listening: 'Dinliyorum…', thinking: 'Düşünüyorum…', speaking: '', idle: '', muted: '', error: 'Bir sorun var',
}

/**
 * The floating presence: a small always-on-top pill (bottom-centre) that
 * appears on wake. Orb on the left, the live transcript flowing beside it.
 */
export function Overlay() {
  const { snapshot } = useCore()
  useApplyTheme()
  const [line, setLine] = useState<{ role: string; text: string } | null>(null)
  const state = (snapshot?.state.voice ?? 'idle') as OrbState

  useEffect(() => {
    client.start()
    return () => client.stop()
  }, [])

  useCoreEvent('voice.transcript', useCallback((e: CoreEvent) => {
    setLine({ role: String(e.data.role), text: String(e.data.text) })
  }, []))
  useCoreEvent('voice.wake', useCallback(() => setLine(null), []))

  const text = line?.text || LABEL[state] || ''
  return (
    <div className="pywebview-drag-region flex h-full items-center gap-3 pr-6 pl-3 select-none">
      <LiquidOrb state={state} levelSource={currentLevel} size={64} className="shrink-0" />
      <AnimatePresence mode="wait">
        <motion.div
          key={(line?.role ?? '') + state}
          initial={{ opacity: 0, y: 6, filter: 'blur(4px)' }}
          animate={{ opacity: 1, y: 0, filter: 'blur(0px)' }}
          exit={{ opacity: 0, y: -6, filter: 'blur(4px)' }}
          transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }}
          className={`min-w-0 flex-1 text-[14px] leading-snug ${line?.role === 'user' ? 'text-fg-muted' : 'text-fg'}`}
        >
          <span className="line-clamp-2">{text}</span>
        </motion.div>
      </AnimatePresence>
    </div>
  )
}
