import { useEffect, useState } from 'react'
import { LiquidOrb, type OrbState } from '../components/LiquidOrb'

const STATES: OrbState[] = ['idle', 'listening', 'thinking', 'speaking', 'muted', 'error']

/** Dev-only: tune the orb (#orb-lab). Simulates speech-like audio levels. */
export function OrbLab() {
  const [state, setState] = useState<OrbState>('speaking')
  const [level, setLevel] = useState(0)
  const [simulate, setSimulate] = useState(true)

  useEffect(() => {
    if (!simulate) return
    let raf = 0
    const tick = (t: number) => {
      // syllable-like envelope: bursts with pauses
      const s = t / 1000
      const env = Math.max(0, Math.sin(s * 5.3) * 0.6 + Math.sin(s * 2.1) * 0.5 + Math.sin(s * 11.7) * 0.2)
      setLevel(state === 'listening' || state === 'speaking' ? Math.min(1, env) : 0)
      raf = requestAnimationFrame(tick)
    }
    raf = requestAnimationFrame(tick)
    return () => cancelAnimationFrame(raf)
  }, [simulate, state])

  return (
    <div className="grid h-full place-items-center bg-bg">
      <div className="flex flex-col items-center gap-8">
        <LiquidOrb state={state} level={level} size={360} />
        <div className="flex flex-wrap justify-center gap-2">
          {STATES.map((s) => (
            <button key={s} onClick={() => setState(s)}
              className={`rounded-full px-4 py-1.5 text-sm ${s === state ? 'bg-fill-strong text-fg' : 'text-fg-muted hover:bg-fill-strong'}`}>
              {s}
            </button>
          ))}
        </div>
        <label className="flex items-center gap-3 text-sm text-fg-muted">
          <input type="checkbox" checked={simulate} onChange={(e) => setSimulate(e.target.checked)} /> ses simülasyonu
          <input type="range" min={0} max={1} step={0.01} value={level} disabled={simulate}
            onChange={(e) => setLevel(Number(e.target.value))} />
          <span className="w-10 tabular-nums">{level.toFixed(2)}</span>
        </label>
      </div>
    </div>
  )
}
