import clsx from 'clsx'
import { AnimatePresence, motion } from 'framer-motion'
import { Check, Loader2, MousePointerClick, Navigation, Keyboard, ScrollText, X } from 'lucide-react'
import { useEffect, useState } from 'react'
import { PageHeader } from '../components/ui'
import { ToolIcon } from '../components/ToolIcon'
import { useActivities, type Activity } from '../lib/activity'
import { useToolCatalog } from '../lib/tools'
import { MissionsSection } from './Missions'

const ease = [0.22, 1, 0.36, 1] as const

function ago(ts: number) {
  const s = Math.round((Date.now() - ts) / 1000)
  if (s < 60) return 'az önce'
  const m = Math.round(s / 60)
  return m < 60 ? `${m} dk önce` : `${Math.round(m / 60)} sa önce`
}

function duration(ms?: number) {
  if (ms === undefined) return ''
  return ms < 1000 ? `${ms} ms` : `${(ms / 1000).toFixed(ms < 10_000 ? 1 : 0)} sn`
}

const STEP_ICON: Record<string, typeof Navigation> = {
  click: MousePointerClick, type: Keyboard, navigate: Navigation, scroll: ScrollText, press: Keyboard,
}

/** Live timeline of what Jarvis is doing: running work first (with browser steps), then history. */
export function TasksPage() {
  const activities = useActivities()
  const catalog = useToolCatalog()
  const [, tick] = useState(0)
  useEffect(() => {
    const t = window.setInterval(() => tick((n) => n + 1), 15_000) // keep "x dk önce" fresh
    return () => window.clearInterval(t)
  }, [])
  const info = (a: Activity) => catalog.find((t) => t.name === a.tool)
  const running = activities.filter((a) => a.status === 'running')
  const done = activities.filter((a) => a.status !== 'running')

  return (
    <div className="mx-auto max-w-3xl pb-10">
      <PageHeader title="Görevler" subtitle="Otonom görevler ve Jarvis'in şu an yaptıkları." />
      <MissionsSection />

      {activities.length === 0 && (
        <div className="panel flex flex-col items-center px-8 py-16 text-center">
          <div className="grid size-14 place-items-center rounded-2xl bg-accent-soft text-accent">
            <ToolIcon name="Workflow" className="size-6" />
          </div>
          <p className="mt-4 text-[15px]">Henüz bir görev yok</p>
          <p className="mt-1 max-w-sm text-[13px] leading-relaxed text-fg-muted">
            Uzun işleri arka planda yaparım ve bitince haber veririm. Örneğin:
          </p>
          <div className="mt-4 flex flex-wrap justify-center gap-2">
            {["“ChatGPT'ye bu hatayı sor”", '“Hepsiburada’da SSD fiyatlarına bak”', '“Notlarım’a özet yaz”'].map((x) => (
              <span key={x} className="rounded-full bg-fill px-3 py-1.5 text-[12.5px] text-fg-muted ring-1 ring-line ring-inset">{x}</span>
            ))}
          </div>
        </div>
      )}

      <AnimatePresence initial={false}>
        {running.map((a) => {
          const t = info(a)
          return (
            <motion.section key={a.id} layout initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.98 }} transition={{ duration: 0.4, ease }}
              className="panel relative mb-4 overflow-hidden p-5">
              <div className="pointer-events-none absolute inset-x-0 top-0 h-[2px] overflow-hidden">
                <motion.div className="h-full w-1/3 bg-gradient-to-r from-transparent via-accent to-transparent"
                  animate={{ x: ['-100%', '300%'] }} transition={{ duration: 1.6, repeat: Infinity, ease: 'easeInOut' }} />
              </div>
              <div className="flex items-center gap-3">
                <div className="grid size-10 place-items-center rounded-2xl bg-accent text-white shadow-[0_8px_24px_-10px_var(--accent)]">
                  <ToolIcon name={t?.icon} className="size-5" />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="text-[15px]">{a.title ?? t?.title ?? a.tool}</div>
                  <div className="flex items-center gap-1.5 text-[12px] text-fg-muted">
                    <Loader2 className="size-3 animate-spin" /> çalışıyor · {ago(a.started)}
                  </div>
                </div>
              </div>
              {a.steps && a.steps.length > 0 && (
                <ol className="mt-4 flex flex-col gap-2 border-l border-line pl-4">
                  {a.steps.map((s, i) => {
                    const Icon = STEP_ICON[s.action] ?? Check
                    return (
                      <motion.li key={i} initial={{ opacity: 0, x: -6 }} animate={{ opacity: 1, x: 0 }}
                        className="flex items-start gap-2 text-[12.5px] text-fg-muted">
                        <Icon className="mt-0.5 size-3.5 shrink-0 text-accent" />
                        <span className="leading-relaxed">{s.thought || s.action}</span>
                      </motion.li>
                    )
                  })}
                </ol>
              )}
            </motion.section>
          )
        })}
      </AnimatePresence>

      {done.length > 0 && (
        <section className="panel p-2">
          <AnimatePresence initial={false}>
            {done.map((a) => {
              const t = info(a)
              const failed = a.status === 'error'
              return (
                <motion.div key={a.id + a.started} layout initial={{ opacity: 0 }} animate={{ opacity: 1 }}
                  className="group flex items-start gap-3 rounded-2xl px-3 py-3 transition-colors hover:bg-fill">
                  <div className={clsx('relative grid size-9 shrink-0 place-items-center rounded-xl',
                    failed ? 'bg-red-500/10 text-red-600 dark:text-red-300' : 'bg-fill-strong text-fg-muted')}>
                    <ToolIcon name={t?.icon} className="size-[17px]" />
                    <span className={clsx('absolute -right-1 -bottom-1 grid size-4 place-items-center rounded-full ring-2 ring-[var(--surface)]',
                      failed ? 'bg-red-500 text-white' : 'bg-emerald-500 text-white')}>
                      {failed ? <X className="size-2.5" strokeWidth={3} /> : <Check className="size-2.5" strokeWidth={3} />}
                    </span>
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-baseline gap-2">
                      <span className="text-[14px]">{a.title ?? t?.title ?? a.tool}</span>
                      {a.background && <span className="text-[11px] text-fg-subtle">arka planda</span>}
                    </div>
                    {a.result && (
                      <p className={clsx('mt-0.5 line-clamp-2 text-[12.5px] leading-relaxed',
                        failed ? 'text-red-600 dark:text-red-300' : 'text-fg-muted')} title={a.result}>
                        {a.result.replace(/^\{?'?output'?:?\s*/, '')}
                      </p>
                    )}
                  </div>
                  <div className="shrink-0 pt-0.5 text-right text-[11px] leading-5 text-fg-subtle tabular-nums">
                    <div>{ago(a.started)}</div>
                    <div className="opacity-0 transition-opacity group-hover:opacity-100">{duration(a.ms)}</div>
                  </div>
                </motion.div>
              )
            })}
          </AnimatePresence>
        </section>
      )}
    </div>
  )
}
