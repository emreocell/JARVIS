import clsx from 'clsx'
import { AnimatePresence, motion } from 'framer-motion'
import {
  AudioLines, Check, Mic, Monitor, Moon, Palette, Plug, Radio, Shield, Sparkles, Sun, UserRound, Volume2, Loader2,
  type LucideIcon,
} from 'lucide-react'
import { useEffect, useState } from 'react'
import { Button, Card, Input, PageHeader, Row, Select, Toggle } from '../components/ui'
import { client, RpcError } from '../lib/rpc'
import type { AppConfig, JsonSchema } from '../lib/types'
import { ACCENTS } from '../lib/theme'
import { useCore } from '../lib/useCore'
import { PhoneRemote } from './PhoneRemote'
import { SpotifyCard } from './SpotifyCard'
import { GoogleWebCard, McpCard } from './McpCard'
import { DictionaryCard, type DictEntry } from './DictionaryCard'
import { WakeWords } from './WakeWords'
import { VoiceDiagnostics } from '../components/VoiceDiagnostics'

/** Human labels for enum values; unknown values fall back to the raw value. */
const ENUM_LABELS: Record<string, string> = {
  live: 'Gemini Live (en doğal)',
  cascade: 'Kademeli (yazıya çevir → cevapla → seslendir)',
  full_duplex: 'Tam çift yönlü',
  half_duplex: 'Yarı çift yönlü',
  key_only: 'Sadece tuşla kes',
  auto: 'Otomatik',
  full: 'Tam erişim (tarayıcım ve oturumlarım)',
  jarvis_profile: 'Jarvis profili (ayrı tarayıcı)',
  open_only: 'Sadece aç',
  edge: 'Edge sinirsel sesler (ücretsiz)',
  gemini: 'Gemini TTS (kotalı)',
  dark: 'Koyu',
  light: 'Açık',
  system: 'Sistem',
  tr: 'Türkçe',
  en: 'English',
}

const LIVE_VOICES: [string, string][] = [
  ['Charon', 'Bilgilendirici, derin'], ['Puck', 'Neşeli'], ['Kore', 'Kararlı'], ['Fenrir', 'Heyecanlı'],
  ['Aoede', 'Ferah'], ['Leda', 'Genç'], ['Orus', 'Sakin'], ['Zephyr', 'Parlak'],
]
const EDGE_VOICES: [string, string][] = [
  ['tr-TR-AhmetNeural', 'Ahmet · erkek'], ['tr-TR-EmelNeural', 'Emel · kadın'],
  ['en-US-AndrewMultilingualNeural', 'Andrew · çok dilli'], ['en-US-AvaMultilingualNeural', 'Ava · çok dilli'],
]

type SectionId = 'assistant' | 'voice' | 'voices' | 'wake' | 'features' | 'privacy' | 'integrations' | 'ui'
const NAV: { id: SectionId; title: string; hint: string; icon: LucideIcon }[] = [
  { id: 'assistant', title: 'Asistan', hint: 'Ad, konum, kuralların', icon: UserRound },
  { id: 'voice', title: 'Konuşma', hint: 'Ses hattı, cihazlar', icon: Mic },
  { id: 'voices', title: 'Jarvis’in sesi', hint: 'Ses seç ve dinle', icon: AudioLines },
  { id: 'wake', title: 'Uyandırma', hint: '“Hey Jarvis” ve kısayol', icon: Radio },
  { id: 'features', title: 'Özellikler', hint: 'Aç / kapat', icon: Sparkles },
  { id: 'privacy', title: 'Gizlilik', hint: 'Ne kaydedilir', icon: Shield },
  { id: 'integrations', title: 'Bağlantılar', hint: 'Gmail, Takvim, Windows, Spotify', icon: Plug },
  { id: 'ui', title: 'Görünüm', hint: 'Tema, kısayollar', icon: Palette },
]

function resolve(schema: JsonSchema, root: JsonSchema): JsonSchema {
  const ref = schema.$ref ?? schema.allOf?.[0]?.$ref
  if (!ref) return schema
  const def = root.$defs?.[ref.split('/').pop()!] ?? {}
  return { ...def, ...schema, $ref: undefined, allOf: undefined }
}

function Field({ name, schema, value, onCommit }: {
  name: string
  schema: JsonSchema
  value: unknown
  onCommit: (v: unknown) => void
}) {
  const [draft, setDraft] = useState(String(value ?? ''))
  useEffect(() => { setDraft(String(value ?? '')) }, [value])

  if (schema.type === 'boolean') return <Toggle label={name} checked={Boolean(value)} onChange={onCommit} />
  if (schema.enum) {
    return (
      <Select className="w-72" value={String(value)} onChange={(e) => onCommit(e.target.value)}>
        {schema.enum.map((v) => <option key={v} value={v}>{ENUM_LABELS[v] ?? v}</option>)}
      </Select>
    )
  }
  if (name === 'user_rules') {
    return (
      <textarea rows={3} value={draft}
        placeholder="örn. Bana 'efendim' diye hitap et. Cevapların kısa olsun."
        onChange={(e) => setDraft(e.target.value)}
        onBlur={() => draft !== String(value ?? '') && onCommit(draft)}
        className="w-80 max-w-full resize-y rounded-xl bg-fill px-3.5 py-2.5 text-[14px] text-fg ring-1 ring-line ring-inset placeholder:text-fg-subtle focus:ring-[var(--accent)]/60 focus:outline-none" />
    )
  }
  const numeric = schema.type === 'number' || schema.type === 'integer'
  return (
    <Input className="w-64" type={numeric ? 'number' : 'text'} min={schema.minimum} max={schema.maximum} value={draft}
      placeholder={name === 'location' ? 'otomatik' : undefined}
      onChange={(e) => setDraft(e.target.value)}
      onBlur={() => { if (draft !== String(value ?? '')) onCommit(numeric ? Number(draft) : draft) }}
      onKeyDown={(e) => e.key === 'Enter' && (e.target as HTMLInputElement).blur()} />
  )
}

/** Voice list + "Dinle" preview (plays a greeting through the speaker). */
function VoicePicker({ engine, value, options, onCommit }: {
  engine: 'edge' | 'gemini'
  value: string
  options: [string, string][]
  onCommit: (v: string) => void
}) {
  const [playing, setPlaying] = useState(false)
  const [note, setNote] = useState<string | null>(null)
  const listed = options.some(([id]) => id === value) ? options : [[value, value] as [string, string], ...options]
  const preview = async () => {
    setPlaying(true)
    setNote(null)
    try {
      const r = await client.call<{ seconds: number }>('voice.preview', { engine, voice: value })
      window.setTimeout(() => setPlaying(false), Math.max(800, r.seconds * 1000))
    } catch (e) {
      setNote(e instanceof RpcError ? e.message : String(e))
      setPlaying(false)
    }
  }
  return (
    <div className="flex flex-col items-end gap-1">
      <div className="flex items-center gap-2">
        <Select className="w-60" value={value} onChange={(e) => onCommit(e.target.value)}>
          {listed.map(([id, label]) => <option key={id} value={id}>{label.includes('·') || id === label ? label : `${id} · ${label}`}</option>)}
        </Select>
        <Button size="sm" variant="secondary" onClick={preview} disabled={playing} aria-label="Dinle">
          {playing ? <Loader2 className="size-3.5 animate-spin" /> : <Volume2 className="size-3.5" />} Dinle
        </Button>
      </div>
      {note && <span className="max-w-72 text-right text-[11.5px] text-amber-700 dark:text-amber-200">{note}</span>}
    </div>
  )
}

function DevicePicker({ kind, value, onCommit }: { kind: 'inputs' | 'outputs'; value: string | null; onCommit: (v: string | null) => void }) {
  const [devices, setDevices] = useState<string[]>([])
  useEffect(() => {
    client.call<{ inputs: string[]; outputs: string[] }>('voice.devices').then((d) => setDevices(d[kind])).catch(() => {})
  }, [kind])
  return (
    <Select className="w-72" value={value ?? ''} onChange={(e) => onCommit(e.target.value || null)}>
      <option value="">Windows varsayılanı</option>
      {devices.map((d) => <option key={d} value={d}>{d}</option>)}
    </Select>
  )
}

function AccentPicker({ value, onCommit }: { value: string; onCommit: (v: string) => void }) {
  const current = ACCENTS.find((a) => a.id === value) ?? ACCENTS[0]
  return (
    <div className="flex items-center gap-2">
      {ACCENTS.map((a) => (
        <button key={a.id} onClick={() => onCommit(a.id)} title={a.name} aria-label={a.name}
          className={clsx('grid size-8 place-items-center rounded-full transition hover:scale-110',
            current.id === a.id && 'ring-2 ring-offset-2 ring-offset-[var(--surface)]')}
          style={{ background: `linear-gradient(135deg, ${a.a}, ${a.b})`, ['--tw-ring-color' as string]: a.a }}>
          {current.id === a.id && <Check className="size-3.5 text-white" strokeWidth={3} />}
        </button>
      ))}
    </div>
  )
}

function ThemePicker({ value, onCommit }: { value: string; onCommit: (v: string) => void }) {
  const themes: { id: string; label: string; icon: LucideIcon; bg: string; card: string }[] = [
    { id: 'light', label: 'Açık', icon: Sun, bg: 'linear-gradient(135deg,#f7f7fc,#e9e6ff)', card: '#ffffff' },
    { id: 'dark', label: 'Koyu', icon: Moon, bg: 'linear-gradient(135deg,#0b0d1c,#1d1840)', card: '#1a1c2e' },
    { id: 'system', label: 'Sistem', icon: Monitor, bg: 'linear-gradient(135deg,#f7f7fc 50%,#0b0d1c 50%)', card: '#8f8fa8' },
  ]
  return (
    <div className="grid grid-cols-3 gap-3 p-5">
      {themes.map((t) => {
        const on = value === t.id
        return (
          <button key={t.id} onClick={() => onCommit(t.id)}
            className={clsx('group rounded-2xl p-2 text-left ring-1 transition', on ? 'ring-2 ring-[var(--accent)]' : 'ring-line hover:ring-fg-subtle')}>
            <div className="relative h-24 overflow-hidden rounded-xl" style={{ background: t.bg }}>
              <div className="absolute top-3 left-3 h-16 w-5 rounded-lg opacity-80" style={{ background: t.card }} />
              <div className="absolute top-3 right-3 left-11 h-6 rounded-lg opacity-80" style={{ background: t.card }} />
              <div className="absolute right-3 bottom-3 left-11 h-7 rounded-lg opacity-60" style={{ background: t.card }} />
              <div className="absolute top-9 left-[46%] size-8 rounded-full bg-gradient-to-br from-[#8f6bff] to-[#46e0e6] opacity-90 blur-[1px]" />
            </div>
            <div className="mt-2 flex items-center gap-1.5 px-1 text-[13px]">
              <t.icon className="size-3.5 text-fg-muted" /> {t.label}
              {on && <Check className="ml-auto size-3.5 text-accent" />}
            </div>
          </button>
        )
      })}
    </div>
  )
}

export function SettingsPage() {
  const { snapshot } = useCore()
  const [schema, setSchema] = useState<JsonSchema | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [active, setActive] = useState<SectionId>('assistant')

  useEffect(() => {
    if (!snapshot) return
    client.call<{ schema: JsonSchema }>('config.get').then((r) => setSchema(r.schema))
  }, [snapshot === null]) // eslint-disable-line react-hooks/exhaustive-deps

  if (!snapshot || !schema) return <div className="text-sm text-fg-muted">Yükleniyor…</div>
  const config = snapshot.config

  const commit = async (section: string, field: string, value: unknown) => {
    setError(null)
    try {
      await client.call('config.patch', { patch: { [section]: { [field]: value } } })
    } catch (e) {
      setError(e instanceof RpcError ? `${field}: ${e.message}` : String(e))
    }
  }

  // hotkey fields whose registration failed (another app owns the combination)
  const HOTKEY_NAMES: Record<string, string> = { push_to_talk_hotkey: 'wake', command_bar_hotkey: 'command_bar', selection_hotkey: 'selection' }
  const hotkeyFailed = snapshot.hotkeys_failed ?? {}

  /** Schema-driven rows for a config section (optionally only / except some fields). */
  const rows = (key: keyof AppConfig, opts: { only?: string[]; except?: string[] } = {}) => {
    const section = resolve(schema.properties![key as string], schema)
    const values = config[key] as unknown as Record<string, unknown>
    const entries = Object.entries(section.properties ?? {})
      .filter(([n]) => (!opts.only || opts.only.includes(n)) && !(opts.except ?? []).includes(n))
      .sort(([a], [b]) => (opts.only ? opts.only.indexOf(a) - opts.only.indexOf(b) : 0))
    return entries.map(([name, raw]) => {
      const prop = resolve(raw, schema)
      if (prop.type === 'array' || prop.type === 'object') return null
      const failed = HOTKEY_NAMES[name] ? hotkeyFailed[HOTKEY_NAMES[name]] : undefined
      return (
        <Row key={name} title={prop.title ?? name}
          description={failed ? `⚠ Çalışmıyor: ${failed}. Başka bir tuş birleşimi dene (ör. ctrl+shift+space).` : prop.description}>
          <Field name={name} schema={prop} value={values[name]} onCommit={(v) => commit(key, name, v)} />
        </Row>
      )
    })
  }

  const v = config.voice as AppConfig['voice'] & { tts_voice: string; tts_engine: 'edge' | 'gemini' }
  const content: Record<SectionId, React.ReactNode> = {
    assistant: (
      <div className="flex flex-col gap-6">
        <Card className="divide-y divide-line">{rows('assistant')}</Card>
        <DictionaryCard entries={((config.assistant as { dictionary?: DictEntry[] }).dictionary) ?? []} />
      </div>
    ),
    voice: (
      <div className="flex flex-col gap-4">
        <Card className="divide-y divide-line">
          {rows('voice', { only: ['enabled', 'mode', 'cascade_fallback', 'echo_profile', 'echo_text_filter',
            'follow_up_seconds', 'session_idle_seconds', 'language'] })}
        </Card>
        <Card className="divide-y divide-line">
          <Row title="Mikrofon" description="Jarvis'in dinlediği cihaz.">
            <DevicePicker kind="inputs" value={config.voice.input_device} onCommit={(d) => commit('voice', 'input_device', d)} />
          </Row>
          <Row title="Hoparlör" description="Kulaklık seçersen konuşurken sözünü kesebilirsin.">
            <DevicePicker kind="outputs" value={config.voice.output_device} onCommit={(d) => commit('voice', 'output_device', d)} />
          </Row>
        </Card>
        <VoiceDiagnostics />
      </div>
    ),
    voices: (
      <Card className="divide-y divide-line">
        <Row title="Live sesi" description="Gemini Live ile konuşurken kullanılan ses.">
          <VoicePicker engine="gemini" value={config.voice.voice_name} options={LIVE_VOICES}
            onCommit={(x) => commit('voice', 'voice_name', x)} />
        </Row>
        <Row title="Kademeli hat sesi" description="Live yerine kademeli hat çalışırken (veya yedek olarak) konuşan ses.">
          <VoicePicker engine="edge" value={v.tts_voice} options={EDGE_VOICES} onCommit={(x) => commit('voice', 'tts_voice', x)} />
        </Row>
        {rows('voice', { only: ['tts_engine', 'live_model'] })}
      </Card>
    ),
    wake: (
      <div className="flex flex-col gap-4">
        <WakeWords words={config.voice.wake_words} />
        <Card className="divide-y divide-line">{rows('voice', { only: ['push_to_talk_hotkey'] })}</Card>
      </div>
    ),
    features: <Card className="divide-y divide-line">{rows('features')}</Card>,
    privacy: <Card className="divide-y divide-line">{rows('privacy', { except: ['excluded_apps'] })}</Card>,
    integrations: <div className="flex flex-col gap-6"><GoogleWebCard /><McpCard /><SpotifyCard /><PhoneRemote /></div>,
    ui: (
      <div className="flex flex-col gap-4">
        <Card><ThemePicker value={config.ui.theme} onCommit={(t) => commit('ui', 'theme', t)} /></Card>
        <Card className="divide-y divide-line">
          <Row title="Vurgu rengi" description="Orb, düğmeler ve seçimler bu renge bürünür.">
            <AccentPicker value={(config.ui as { accent?: string }).accent ?? ''} onCommit={(a) => commit('ui', 'accent', a)} />
          </Row>
          {rows('ui', { except: ['theme', 'accent', 'language'] })}
        </Card>
      </div>
    ),
  }
  const current = NAV.find((n) => n.id === active)!

  return (
    <div className="mx-auto max-w-5xl pb-10">
      <PageHeader title="Ayarlar" subtitle="Değişiklikler anında uygulanır, yeniden başlatma gerekmez." />
      {error && <div className="mb-4 rounded-2xl bg-red-400/10 px-4 py-2.5 text-sm text-red-600 dark:text-red-300">{error}</div>}
      <div className="flex items-start gap-6">
        <nav className="panel sticky top-2 w-60 shrink-0 p-2">
          {NAV.map((n) => {
            const on = n.id === active
            return (
              <button key={n.id} onClick={() => setActive(n.id)}
                className={clsx('relative flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-left transition-colors',
                  on ? 'text-fg' : 'text-fg-muted hover:text-fg')}>
                {on && <motion.span layoutId="settings-active" className="absolute inset-0 rounded-xl bg-accent-soft"
                  transition={{ type: 'spring', stiffness: 460, damping: 36 }} />}
                <n.icon className={clsx('relative size-[18px] shrink-0', on && 'text-accent')} strokeWidth={1.7} />
                <span className="relative min-w-0">
                  <span className="block text-[13.5px]">{n.title}</span>
                  <span className="block truncate text-[11.5px] text-fg-subtle">{n.hint}</span>
                </span>
              </button>
            )
          })}
        </nav>
        <div className="min-w-0 flex-1">
          <AnimatePresence mode="wait">
            <motion.div key={active} initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -4 }}
              transition={{ duration: 0.22 }}>
              <h2 className="mb-3 px-1 text-[13px] font-medium text-fg-muted">{current.title}</h2>
              {content[active]}
            </motion.div>
          </AnimatePresence>
        </div>
      </div>
    </div>
  )
}
