import clsx from 'clsx'
import { Markdown } from '../components/Markdown'
import { AnimatePresence, motion } from 'framer-motion'
import { MessagesSquare, Search, Trash2 } from 'lucide-react'
import { useCallback, useEffect, useMemo, useState } from 'react'
import { Button, Input } from '../components/ui'
import { client } from '../lib/rpc'
import { useCore, useCoreEvent } from '../lib/useCore'

interface SessionRow {
  session: string
  started: number
  ended: number
  turns: number
  opening: string | null
  summary: string | null
  current: boolean
}

interface SessionDetail {
  session: string
  messages: { ts: number; role: 'user' | 'assistant'; text: string }[]
  summary: string | null
  current: boolean
}

/** Session to open when the page mounts (set by other pages before navigating). */
let requested: string | null = null
export function requestHistorySession(session: string) {
  requested = session
}

const titleOf = (s: SessionRow) => s.summary || s.opening || 'Adsız sohbet'

function dayGroup(ts: number): string {
  const d = new Date(ts * 1000)
  const today = new Date()
  today.setHours(0, 0, 0, 0)
  const diff = Math.floor((today.getTime() - new Date(d).setHours(0, 0, 0, 0)) / 86_400_000)
  if (diff <= 0) return 'Bugün'
  if (diff === 1) return 'Dün'
  if (diff < 7) return 'Bu hafta'
  if (diff < 31) return 'Bu ay'
  return d.toLocaleDateString('tr-TR', { month: 'long', year: 'numeric' })
}

const clock = (ts: number) => new Date(ts * 1000).toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' })

export function HistoryPage() {
  const { status } = useCore()
  const [rows, setRows] = useState<SessionRow[]>([])
  const [query, setQuery] = useState('')
  const [selected, setSelected] = useState<string | null>(() => {
    const s = requested
    requested = null
    return s
  })
  const [detail, setDetail] = useState<SessionDetail | null>(null)
  const [confirmDelete, setConfirmDelete] = useState(false)

  const load = useCallback(async () => {
    if (status !== 'online') return
    const r = await client.call<SessionRow[]>('history.sessions', { limit: 100, query: query.trim() || undefined })
    setRows(r)
    setSelected((cur) => (cur && r.some((x) => x.session === cur) ? cur : r[0]?.session ?? null))
  }, [status, query])

  useEffect(() => {
    const t = window.setTimeout(() => void load(), 200)
    return () => window.clearTimeout(t)
  }, [load])

  useEffect(() => {
    setConfirmDelete(false)
    if (!selected || status !== 'online') return setDetail(null)
    let live = true
    void client.call<SessionDetail>('history.session', { session: selected }).then((d) => live && setDetail(d))
    return () => { live = false }
  }, [selected, status])

  // new turns land in the current session; summaries arrive with memory extraction
  const refresh = useCallback(() => {
    void load()
    if (selected) void client.call<SessionDetail>('history.session', { session: selected }).then(setDetail)
  }, [load, selected])
  useCoreEvent('voice.turn_complete', refresh)
  useCoreEvent('memory.changed', refresh)

  const groups = useMemo(() => {
    const out: { label: string; items: SessionRow[] }[] = []
    for (const r of rows) {
      const label = dayGroup(r.ended)
      if (out.at(-1)?.label !== label) out.push({ label, items: [] })
      out.at(-1)!.items.push(r)
    }
    return out
  }, [rows])

  const remove = async () => {
    if (!detail) return
    if (!confirmDelete) return setConfirmDelete(true)
    await client.call('history.delete', { session: detail.session })
    setSelected(null)
    void load()
  }

  const current = rows.find((r) => r.session === selected)

  return (
    <div className="flex h-full min-h-0 gap-4 pb-4">
      {/* ------------- list ------------- */}
      <aside className="panel flex w-[320px] shrink-0 flex-col overflow-hidden">
        <div className="px-5 pt-5 pb-3">
          <h1 className="text-[22px] font-light tracking-tight">Sohbetler</h1>
          <div className="relative mt-3">
            <Search className="pointer-events-none absolute top-2.5 left-3 size-4 text-fg-subtle" />
            <Input className="w-full pl-9" placeholder="Sohbetlerde ara…" value={query}
              onChange={(e) => setQuery(e.target.value)} />
          </div>
        </div>
        <div className="min-h-0 flex-1 overflow-y-auto px-3 pb-4">
          {groups.length === 0 && (
            <p className="px-3 py-10 text-center text-[13px] leading-relaxed text-fg-muted">
              {query ? 'Eşleşen sohbet yok.' : 'Henüz sohbet yok. Sesle ya da yazarak konuştuğunda burada birikir.'}
            </p>
          )}
          {groups.map((g) => (
            <section key={g.label} className="mb-2">
              <h2 className="px-3 pt-3 pb-1.5 text-[11.5px] font-medium tracking-wide text-fg-subtle">{g.label}</h2>
              <ul className="flex flex-col gap-0.5">
                {g.items.map((r) => {
                  const active = r.session === selected
                  return (
                    <li key={r.session}>
                      <button onClick={() => setSelected(r.session)}
                        className={clsx('relative w-full rounded-2xl px-3 py-2.5 text-left transition-colors',
                          active ? 'text-fg' : 'text-fg-muted hover:bg-fill hover:text-fg')}>
                        {active && (
                          <motion.span layoutId="history-active" className="absolute inset-0 rounded-2xl bg-accent-soft"
                            transition={{ type: 'spring', stiffness: 420, damping: 34 }} />
                        )}
                        <span className="relative line-clamp-2 text-[13.5px] leading-snug">{titleOf(r)}</span>
                        <span className="relative mt-1 flex items-center gap-1.5 text-[11px] text-fg-subtle">
                          {r.current && <span className="size-1.5 rounded-full bg-accent" />}
                          {r.current ? 'Şu anki sohbet' : clock(r.ended)} · {r.turns} mesaj
                        </span>
                      </button>
                    </li>
                  )
                })}
              </ul>
            </section>
          ))}
        </div>
      </aside>

      {/* ------------- transcript ------------- */}
      <section className="panel relative flex min-w-0 flex-1 flex-col overflow-hidden">
        {detail && current ? (
          <>
            <header className="flex items-start gap-4 border-b border-line px-7 pt-6 pb-4">
              <div className="min-w-0 flex-1">
                <div className="text-[12px] text-fg-subtle">
                  {new Date(current.started * 1000).toLocaleDateString('tr-TR', { weekday: 'long', day: 'numeric', month: 'long' })}
                  {' · '}{clock(current.started)}–{clock(current.ended)}
                </div>
                <h2 className="mt-1 text-[19px] leading-snug font-light">{titleOf(current)}</h2>
                {detail.summary && current.opening && detail.summary !== current.opening && (
                  <p className="mt-1.5 line-clamp-2 text-[12.5px] text-fg-muted">İlk mesaj: “{current.opening}”</p>
                )}
              </div>
              <Button size="sm" variant={confirmDelete ? 'danger' : 'ghost'} onClick={remove}
                className={confirmDelete ? 'bg-red-500/10 text-red-600 dark:text-red-300' : undefined}
                onBlur={() => setConfirmDelete(false)} aria-label="Sohbeti sil">
                <Trash2 className="size-3.5" />{confirmDelete && ' Emin misin?'}
              </Button>
            </header>
            <div className="min-h-0 flex-1 overflow-y-auto px-7 py-6">
              <AnimatePresence mode="popLayout" initial={false}>
                <motion.div key={detail.session} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0 }} transition={{ duration: 0.25 }}
                  className="mx-auto flex max-w-2xl flex-col gap-3">
                  {detail.messages.map((m, i) => (
                    <div key={i} className={clsx('max-w-[85%] whitespace-pre-wrap',
                      m.role === 'user'
                        ? 'self-end rounded-3xl rounded-br-lg bg-fill px-4 py-2.5 text-[14.5px]'
                        : 'self-start py-1 text-[15.5px] leading-relaxed font-light')}>
                      {m.role === 'assistant' ? <Markdown text={m.text} /> : m.text}
                    </div>
                  ))}
                </motion.div>
              </AnimatePresence>
            </div>
          </>
        ) : (
          <div className="m-auto flex flex-col items-center gap-3 text-fg-muted">
            <MessagesSquare className="size-8 text-fg-subtle" strokeWidth={1.4} />
            <span className="text-[13px]">Bir sohbet seç</span>
          </div>
        )}
      </section>
    </div>
  )
}
