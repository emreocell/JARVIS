import { CalendarDays, Mail, MonitorSmartphone } from 'lucide-react'
import { useCallback, useEffect, useState } from 'react'
import { Badge, Button, Card, Input, Toggle } from '../components/ui'
import { client, RpcError } from '../lib/rpc'
import { useCoreEvent } from '../lib/useCore'

interface Field { key: string; label: string; secret: boolean; set: boolean }
interface Preset { id: string; name: string; description: string; fields: Field[] }
interface Server {
  id: string; name: string; preset: string; enabled: boolean; state: string; error: string
  tool_count: number; email?: string
}
interface Status { presets: Preset[]; servers: Server[] }

const ICONS: Record<string, typeof Mail> = { google: Mail, windows: MonitorSmartphone }

function stateBadge(s: Server | undefined) {
  if (!s) return <Badge>kapalı</Badge>
  if (!s.enabled) return <Badge>duraklatıldı</Badge>
  if (s.state === 'ready') return <Badge tone="ok">çalışıyor · {s.tool_count} araç</Badge>
  if (s.state === 'starting') return <Badge tone="accent">başlatılıyor…</Badge>
  if (s.state === 'error') return <Badge tone="danger">hata</Badge>
  return <Badge tone="ok">hazır{s.tool_count ? ` · ${s.tool_count} araç` : ''}</Badge>
}

/** MCP servers from presets: Windows-MCP, Gmail + Google Calendar. */
export function McpCard() {
  const [st, setSt] = useState<Status | null>(null)
  const load = useCallback(() => client.call<Status>('mcp.status').then(setSt).catch(() => {}), [])
  useEffect(() => {
    void load()
  }, [load])
  useCoreEvent('mcp.status', useCallback(() => void load(), [load]))

  if (!st) return null
  return (
    <section>
      <h2 className="mb-3 px-1 text-[13px] text-fg-muted">Akıllı bağlantılar (MCP)</h2>
      <div className="flex flex-col gap-3">
        {st.presets.map((p) => (
          <PresetRow key={p.id} preset={p} server={st.servers.find((s) => s.id === p.id)} reload={load} />
        ))}
      </div>
      <p className="mt-2 px-1 text-[12px] leading-relaxed text-fg-subtle">
        Bağlantılar yalnızca kullanıldığında çalışır, 10 dakika boşta kalınca kapanır. Mail göndermek, etkinlik eklemek
        gibi işler her zaman onayını ister.
      </p>
    </section>
  )
}

function PresetRow({ preset, server, reload }: { preset: Preset; server?: Server; reload: () => void }) {
  const Icon = ICONS[preset.id] ?? MonitorSmartphone
  const [values, setValues] = useState<Record<string, string>>({})
  const [busy, setBusy] = useState<string | null>(null)
  const [msg, setMsg] = useState<string | null>(null)
  const [editing, setEditing] = useState(false)
  const needsFields = preset.fields.length > 0
  const showForm = needsFields && editing

  const run = async (what: string, fn: () => Promise<unknown>) => {
    setBusy(what)
    setMsg(null)
    try {
      await fn()
    } catch (e) {
      setMsg(e instanceof RpcError ? e.message : String(e))
    } finally {
      setBusy(null)
      reload()
    }
  }

  const enable = () => run('enable', async () => {
    await client.call('mcp.enable', { preset: preset.id, fields: values })
    setEditing(false)
    setValues({})
    const r = await client.call<{ ok: boolean; message: string }>('mcp.test', { id: preset.id })
    setMsg(r.message)
  })
  const test = () => run('test', async () => {
    const r = await client.call<{ ok: boolean; message: string }>('mcp.test', { id: preset.id })
    setMsg(r.message)
  })

  return (
    <Card className="p-5">
      <div className="flex items-start gap-4">
        <div className="grid size-10 shrink-0 place-items-center rounded-2xl bg-fill">
          <Icon className="size-[18px] text-fg-muted" strokeWidth={1.6} />
        </div>
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center gap-2 text-[14px]">
            {preset.name}
            {stateBadge(server)}
            {server && (
              <span className="ml-auto">
                <Toggle checked={server.enabled} label={preset.name}
                  onChange={(v) => run('toggle', () => client.call('mcp.set_enabled', { id: preset.id, enabled: v }))} />
              </span>
            )}
          </div>
          <p className="mt-1 text-[12.5px] leading-relaxed text-fg-muted">{preset.description}</p>
          {server?.email && <p className="mt-1 text-[12.5px] text-fg-muted">Hesap: <span className="text-fg">{server.email}</span></p>}
          {server?.state === 'error' && server.error && (
            <p className="mt-2 line-clamp-3 text-[12px] text-red-600 dark:text-red-300">{server.error}</p>
          )}

          {showForm && preset.id === 'google' && (
            <ol className="mt-3 mb-3 list-decimal space-y-1 pl-5 text-[12.5px] text-fg-muted">
              <li><span className="text-fg">console.cloud.google.com</span>'da bir proje aç; <span className="text-fg">Gmail API</span> ve <span className="text-fg">Google Calendar API</span>'yi etkinleştir.</li>
              <li>OAuth izin ekranını "Harici" olarak ayarla ve kendi Gmail adresini test kullanıcısı ekle.</li>
              <li>Kimlik bilgileri → OAuth istemci kimliği → uygulama türü <span className="text-fg">Masaüstü uygulaması</span>.</li>
              <li>Client ID ve Secret'ı buraya yapıştır; ilk testte tarayıcıda Google izni istenecek.</li>
            </ol>
          )}
          {showForm && (
            <div className="mt-3 grid gap-2 sm:grid-cols-2">
              {preset.fields.map((f) => (
                <Input key={f.key} className={f.key === 'email' ? 'sm:col-span-2' : ''}
                  type={f.secret ? 'password' : 'text'}
                  placeholder={f.set ? `${f.label} (kayıtlı)` : f.label}
                  value={values[f.key] ?? ''}
                  onChange={(e) => setValues((v) => ({ ...v, [f.key]: e.target.value }))} />
              ))}
            </div>
          )}

          <div className="mt-3 flex flex-wrap gap-2">
            {!server && needsFields && !editing && (
              <Button size="sm" onClick={() => setEditing(true)}>Kur</Button>
            )}
            {!server && (!needsFields || editing) && (
              <Button variant="primary" size="sm" loading={busy === 'enable'} onClick={enable}
                disabled={preset.fields.some((f) => !f.set && !(values[f.key] ?? '').trim())}>
                Bağla
              </Button>
            )}
            {server && showForm && (
              <Button variant="primary" size="sm" loading={busy === 'enable'} onClick={enable}>Kaydet</Button>
            )}
            {server && (
              <Button size="sm" loading={busy === 'test'} onClick={test} disabled={!server.enabled}>Test et</Button>
            )}
            {server && needsFields && !editing && (
              <Button size="sm" variant="ghost" onClick={() => setEditing(true)}>Bilgileri düzenle</Button>
            )}
            {server && (
              <Button size="sm" variant="ghost" loading={busy === 'remove'}
                onClick={() => run('remove', () => client.call('mcp.remove', { id: preset.id }))}>Kaldır</Button>
            )}
          </div>
          {msg && <div className="mt-3 text-[12.5px] text-fg-muted">{msg}</div>}
        </div>
      </div>
    </Card>
  )
}


interface GoogleStatus { signed_in: boolean | null; account: string; error?: string }

/** Gmail + Calendar through the user's own Google session in the Jarvis browser: no API setup. */
export function GoogleWebCard() {
  const [st, setSt] = useState<GoogleStatus | null>(null)
  const [busy, setBusy] = useState(false)
  const [msg, setMsg] = useState<string | null>(null)
  const load = useCallback(() => client.call<GoogleStatus>('google.status').then(setSt).catch(() => {}), [])
  useEffect(() => {
    void load()
  }, [load])

  const signIn = async () => {
    setBusy(true)
    setMsg(null)
    try {
      const r = await client.call<{ output: string }>('google.sign_in')
      setMsg(r.output)
    } catch (e) {
      setMsg(e instanceof RpcError ? e.message : String(e))
    } finally {
      setBusy(false)
      void load()
    }
  }

  return (
    <section>
      <h2 className="mb-3 px-1 text-[13px] text-fg-muted">Google</h2>
      <Card className="p-5">
        <div className="flex items-start gap-4">
          <div className="grid size-10 shrink-0 place-items-center rounded-2xl bg-fill">
            <CalendarDays className="size-[18px] text-fg-muted" strokeWidth={1.6} />
          </div>
          <div className="min-w-0 flex-1">
            <div className="flex flex-wrap items-center gap-2 text-[14px]">
              Gmail ve Google Takvim
              {st?.signed_in ? <Badge tone="ok">bağlı{st.account ? ` · ${st.account}` : ''}</Badge>
                : st?.signed_in === false ? <Badge>giriş yapılmadı</Badge> : <Badge>tarayıcı kapalı</Badge>}
            </div>
            <p className="mt-1 text-[12.5px] leading-relaxed text-fg-muted">
              API anahtarı, Google Cloud ya da ücret yok. Jarvis'in tarayıcısında Google hesabınla bir kez giriş yap;
              okunmamış mailleri özetler, maillerde arar, taslak hazırlar, onayınla gönderir, takvimine bakar ve
              etkinlik ekler. Kişisel ve Workspace (okul/iş) hesaplarında aynı şekilde çalışır. Şifreni Jarvis
              görmez, girişi Google'ın kendi sayfasında sen yaparsın.
            </p>
            <div className="mt-3 flex flex-wrap gap-2">
              {!st?.signed_in && (
                <Button variant="primary" size="sm" loading={busy} onClick={signIn}>Google ile giriş yap</Button>
              )}
              <Button size="sm" variant="ghost" onClick={() => void load()}>Durumu yenile</Button>
            </div>
            {msg && <div className="mt-3 text-[12.5px] text-fg-muted">{msg}</div>}
          </div>
        </div>
      </Card>
    </section>
  )
}
