import { Plus, Trash2 } from 'lucide-react'
import { useState } from 'react'
import { Badge, Button, Card, Input, Toggle } from '../components/ui'
import { client } from '../lib/rpc'
import { useCore } from '../lib/useCore'
import type { WakeWord } from '../lib/types'

export function WakeWords({ words }: { words: WakeWord[] }) {
  const [phrase, setPhrase] = useState('')
  const snap = useCore().snapshot
  const rejected = snap?.wake_rejected ?? {}
  const approx = snap?.wake_approx ?? {}

  const save = (next: WakeWord[]) => client.call('config.patch', { patch: { voice: { wake_words: next } } })

  const add = async () => {
    const p = phrase.trim().toLocaleLowerCase('tr')
    if (!p || words.some((w) => w.phrase === p)) return
    // Non-default phrases need an open-vocabulary engine.
    await save([...words, { phrase: p, engine: p === 'hey jarvis' ? 'openwakeword' : 'vosk', sensitivity: 0.5, enabled: true }])
    setPhrase('')
  }

  return (
    <Card className="mt-3">
      <div className="px-5 pt-4 pb-2">
        <div className="text-sm font-medium">Uyandırma ifadeleri</div>
        <div className="mt-0.5 text-xs text-fg-muted">
          Birden fazla ifade aynı anda dinlenir. Tamamen yerelde çalışır, internete bir şey gönderilmez.
          Özel ifadeler Türkçe konuşma modeliyle tanınır; “jarvis” gibi yabancı kelimeler okunuşlarına göre
          yaklaşık dinlenir. En iyi sonuç için en az iki kelimelik ifadeler kullanın.
        </div>
      </div>
      <ul className="divide-y divide-line">
        {words.map((w, i) => (
          <li key={w.phrase} className="flex items-center gap-3 px-5 py-3">
            <div className="min-w-0 flex-1">
              <div className="text-sm">“{w.phrase}”</div>
              {w.enabled && rejected[w.phrase] && (
                <div className="mt-0.5 text-xs text-amber-700 dark:text-amber-200">{rejected[w.phrase]}</div>
              )}
              {w.enabled && approx[w.phrase] && (
                <div className="mt-0.5 text-xs text-fg-subtle" title="Türkçe modelin bildiği kelimelerle yaklaşık dinleniyor">
                  Okunuşuyla dinleniyor: “{approx[w.phrase]}”
                </div>
              )}
            </div>
            {w.enabled && rejected[w.phrase]
              ? <Badge tone="warn">dinlenmiyor</Badge>
              : <Badge tone={w.engine === 'openwakeword' ? 'accent' : 'neutral'}>{w.engine === 'openwakeword' ? 'yerleşik model' : 'özel ifade'}</Badge>}
            <input
              type="range"
              min={0.05}
              max={0.95}
              step={0.05}
              value={w.sensitivity}
              aria-label="Hassasiyet"
              className="w-24 accent-[var(--accent)]"
              onChange={(e) => save(words.map((x, j) => (j === i ? { ...x, sensitivity: Number(e.target.value) } : x)))}
            />
            <Toggle
              label="Açık"
              checked={w.enabled}
              onChange={(v) => save(words.map((x, j) => (j === i ? { ...x, enabled: v } : x)))}
            />
            <Button
              variant="ghost"
              size="sm"
              aria-label="Sil"
              disabled={words.length === 1}
              onClick={() => save(words.filter((_, j) => j !== i))}
            >
              <Trash2 className="size-4" />
            </Button>
          </li>
        ))}
      </ul>
      <div className="flex gap-2 border-t border-line px-5 py-3">
        <Input
          className="flex-1"
          placeholder="örn. uyan dostum"
          value={phrase}
          onChange={(e) => setPhrase(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && add()}
        />
        <Button onClick={add} disabled={!phrase.trim()}>
          <Plus className="size-4" /> Ekle
        </Button>
      </div>
    </Card>
  )
}
