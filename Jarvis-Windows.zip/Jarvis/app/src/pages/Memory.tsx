import clsx from 'clsx'
import { motion } from 'framer-motion'
import {
  Briefcase, Check, FolderGit2, Heart, Laptop, MapPin, Pencil, Pin, PinOff, Plus, Repeat, Search, Sparkles, Trash2,
  UserRound, Users, X, type LucideIcon,
} from 'lucide-react'
import { useCallback, useEffect, useState } from 'react'
import { Button, Input, PageHeader, Select } from '../components/ui'
import { client } from '../lib/rpc'
import { useCore, useCoreEvent } from '../lib/useCore'

interface Fact {
  id: number
  content: string
  category: string
  source: string
  pinned: boolean
  updated: number
  use_count: number
}
interface MemEvent { ts: number; kind: string; fact_id: number | null; payload: Record<string, string> }

const CATEGORY: Record<string, { label: string; icon: LucideIcon }> = {
  identity: { label: 'Kimlik', icon: UserRound },
  preference: { label: 'Tercihler', icon: Heart },
  relationship: { label: 'Kişiler', icon: Users },
  work: { label: 'İş', icon: Briefcase },
  project: { label: 'Projeler', icon: FolderGit2 },
  habit: { label: 'Alışkanlıklar', icon: Repeat },
  device: { label: 'Cihaz ve uygulamalar', icon: Laptop },
  general: { label: 'Genel', icon: Sparkles },
}
const ORDER = ['identity', 'preference', 'relationship', 'work', 'project', 'habit', 'device', 'general']
const SOURCE: Record<string, string> = { user: 'sen ekledin', auto: 'konuşmadan öğrendim', assistant: 'Jarvis' }
const EVENT: Record<string, string> = { add: 'Öğrendim', update: 'Güncelledim', forget: 'Unuttum', pin: 'Sabitledim', reinforce: 'Doğrulandı' }

function ago(ts: number) {
  const s = Date.now() / 1000 - ts
  if (s < 3600) return `${Math.max(1, Math.round(s / 60))} dk önce`
  if (s < 86400) return `${Math.round(s / 3600)} sa önce`
  const d = Math.round(s / 86400)
  return d === 1 ? 'dün' : `${d} gün önce`
}

function FactCard({ f, onChanged }: { f: Fact; onChanged: () => void }) {
  const [editing, setEditing] = useState(false)
  const [draft, setDraft] = useState(f.content)
  const save = async () => {
    if (draft.trim() && draft !== f.content) await client.call('memory.update', { id: f.id, content: draft })
    setEditing(false)
    onChanged()
  }
  return (
    <div className={clsx('group flex items-start gap-3 rounded-2xl px-3 py-2.5 transition-colors hover:bg-fill', f.pinned && 'bg-accent-soft/50')}>
      <div className="min-w-0 flex-1">
        {editing ? (
          <div className="flex gap-2">
            <Input className="flex-1" value={draft} autoFocus onChange={(e) => setDraft(e.target.value)}
              onKeyDown={(e) => { if (e.key === 'Enter') void save(); if (e.key === 'Escape') setEditing(false) }} />
            <Button size="sm" variant="primary" onClick={save} aria-label="Kaydet"><Check className="size-3.5" /></Button>
            <Button size="sm" variant="ghost" onClick={() => setEditing(false)} aria-label="Vazgeç"><X className="size-3.5" /></Button>
          </div>
        ) : (
          <div className="text-[14px] leading-relaxed">{f.content}</div>
        )}
        <div className="mt-0.5 text-[11.5px] text-fg-subtle">
          {SOURCE[f.source] ?? f.source} · {ago(f.updated)}{f.use_count > 0 && ` · ${f.use_count} kez işe yaradı`}
        </div>
      </div>
      {!editing && (
        <div className={clsx('flex shrink-0 gap-0.5', !f.pinned && 'opacity-0 group-hover:opacity-100 focus-within:opacity-100')}>
          <button onClick={async () => { await client.call('memory.pin', { id: f.id, pinned: !f.pinned }); onChanged() }}
            className="grid size-7 place-items-center rounded-lg text-fg-subtle hover:bg-fill-strong hover:text-fg"
            aria-label={f.pinned ? 'Sabitlemeyi kaldır' : 'Her zaman hatırla'} title={f.pinned ? 'Sabitlemeyi kaldır' : 'Her zaman hatırla'}>
            {f.pinned ? <PinOff className="size-3.5 text-accent" /> : <Pin className="size-3.5" />}
          </button>
          <button onClick={() => { setDraft(f.content); setEditing(true) }} aria-label="Düzenle"
            className="grid size-7 place-items-center rounded-lg text-fg-subtle hover:bg-fill-strong hover:text-fg">
            <Pencil className="size-3.5" />
          </button>
          <button onClick={async () => { await client.call('memory.forget', { id: f.id }); onChanged() }} aria-label="Unut"
            className="grid size-7 place-items-center rounded-lg text-fg-subtle hover:bg-red-500/10 hover:text-red-600">
            <Trash2 className="size-3.5" />
          </button>
        </div>
      )}
    </div>
  )
}

export function MemoryPage() {
  const { status, snapshot } = useCore()
  const [facts, setFacts] = useState<Fact[]>([])
  const [events, setEvents] = useState<MemEvent[]>([])
  const [episode, setEpisode] = useState<{ summary: string; ended: number } | null>(null)
  const [query, setQuery] = useState('')
  const [adding, setAdding] = useState({ content: '', category: 'general' })

  const load = useCallback(async () => {
    if (status !== 'online') return
    const r = await client.call<{ facts: Fact[]; last_episode: { summary: string; ended: number } | null }>(
      'memory.list', { query: query.trim() || undefined })
    setFacts(r.facts)
    setEpisode(r.last_episode)
    setEvents(await client.call<MemEvent[]>('memory.history', { limit: 12 }))
  }, [status, query])

  useEffect(() => {
    const t = window.setTimeout(() => void load(), 200)
    return () => window.clearTimeout(t)
  }, [load])
  useCoreEvent('memory.changed', useCallback(() => void load(), [load]))

  const add = async () => {
    if (!adding.content.trim()) return
    await client.call('memory.add', adding)
    setAdding({ content: '', category: adding.category })
    void load()
  }

  const name = snapshot?.config.assistant?.user_name || ''
  const location = snapshot?.config.assistant?.location || ''
  const groups = ORDER.map((k) => [k, facts.filter((f) => (CATEGORY[f.category] ? f.category : 'general') === k)] as const)
    .filter(([, list]) => list.length > 0)
  const visibleEvents = events.filter((e) => EVENT[e.kind])

  return (
    <div className="mx-auto max-w-6xl pb-10">
      <PageHeader title="Hafıza" subtitle="Jarvis'in senin hakkında bildikleri. Konuşmalardan kendisi öğrenir; istediğini düzelt, sabitle ya da unut."
        actions={
          <div className="relative w-64">
            <Search className="pointer-events-none absolute top-2.5 left-3 size-4 text-fg-subtle" />
            <Input className="w-full pl-9" placeholder="Hafızada ara…" value={query} onChange={(e) => setQuery(e.target.value)} />
          </div>
        } />

      <div className="flex items-start gap-6">
        <div className="min-w-0 flex-1">
          {/* profile */}
          <motion.section initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="panel mb-6 flex items-center gap-5 p-5">
            <div className="grid size-16 shrink-0 place-items-center rounded-full bg-gradient-to-br from-[var(--accent)] to-[var(--accent-2)] text-[24px] font-light text-white shadow-[0_10px_30px_-12px_var(--accent)]">
              {(name || '?').slice(0, 1).toUpperCase()}
            </div>
            <div className="min-w-0 flex-1">
              <div className="text-[20px] font-light">{name ? `Seni tanıyorum, ${name}` : 'Seni tanımaya başladım'}</div>
              <div className="mt-1 flex flex-wrap items-center gap-x-4 gap-y-1 text-[12.5px] text-fg-muted">
                <span>{facts.length} şey biliyorum</span>
                <span>{groups.length} konu</span>
                {location && <span className="flex items-center gap-1"><MapPin className="size-3.5" />{location}</span>}
              </div>
              {episode && (
                <p className="mt-2 line-clamp-2 text-[12.5px] leading-relaxed text-fg-subtle">Son konuşma ({ago(episode.ended)}): {episode.summary}</p>
              )}
            </div>
          </motion.section>

          {/* add */}
          <div className="panel mb-6 flex gap-2 p-3">
            <Input className="flex-1" placeholder="Bana bir şey öğret, ör. “Kahvemi şekersiz içerim.”"
              value={adding.content} onChange={(e) => setAdding({ ...adding, content: e.target.value })}
              onKeyDown={(e) => e.key === 'Enter' && add()} />
            <Select className="w-44" value={adding.category} onChange={(e) => setAdding({ ...adding, category: e.target.value })}>
              {ORDER.map((k) => <option key={k} value={k}>{CATEGORY[k].label}</option>)}
            </Select>
            <Button onClick={add} disabled={!adding.content.trim()}><Plus className="size-4" /> Ekle</Button>
          </div>

          {facts.length === 0 ? (
            <div className="rounded-3xl border border-dashed border-line py-16 text-center text-sm text-fg-muted">
              {query ? 'Eşleşen bilgi yok.' : 'Henüz bir şey öğrenmedim. Benimle konuştukça burası dolacak.'}
            </div>
          ) : (
            <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
              {groups.map(([cat, list]) => {
                const C = CATEGORY[cat]
                return (
                  <section key={cat} className="panel p-3">
                    <h2 className="mb-1 flex items-center gap-2 px-3 pt-1 text-[13px] font-medium text-fg-muted">
                      <C.icon className="size-4 text-accent" strokeWidth={1.7} /> {C.label}
                      <span className="text-fg-subtle">· {list.length}</span>
                    </h2>
                    {list.map((f) => <FactCard key={f.id} f={f} onChanged={load} />)}
                  </section>
                )
              })}
            </div>
          )}
        </div>

        {/* recent learning */}
        {visibleEvents.length > 0 && (
          <aside className="panel sticky top-2 hidden w-72 shrink-0 p-4 xl:block">
            <h2 className="mb-3 text-[13px] font-medium text-fg-muted">Son öğrendiklerim</h2>
            <ol className="relative flex flex-col gap-3 border-l border-line pl-4">
              {visibleEvents.map((e, i) => (
                <li key={i} className="relative">
                  <span className={clsx('absolute top-1.5 -left-[21px] size-2.5 rounded-full ring-4 ring-[var(--surface)]',
                    e.kind === 'forget' ? 'bg-red-400' : e.kind === 'update' ? 'bg-amber-400' : 'bg-[var(--accent)]')} />
                  <div className="text-[11.5px] text-fg-subtle">{EVENT[e.kind]} · {ago(e.ts)}</div>
                  <div className="mt-0.5 line-clamp-3 text-[12.5px] leading-relaxed">
                    {e.payload.content ?? e.payload.new ?? ''}
                  </div>
                </li>
              ))}
            </ol>
          </aside>
        )}
      </div>
    </div>
  )
}
