import clsx from 'clsx'
import { AnimatePresence, motion } from 'framer-motion'
import { Check, Circle, Loader2, Workflow, X } from 'lucide-react'
import { useCallback, useEffect, useState } from 'react'
import { Badge, Button, Input } from '../components/ui'
import { client, type CoreEvent } from '../lib/rpc'
import { useCore, useCoreEvent } from '../lib/useCore'

interface Step { n: number; title: string; status: string; note: string }
interface Mission {
  id: number; goal: string; title: string; status: string; steps: Step[]; log: string[]; report: string
  created: number; updated: number; calls: number
}

const STATUS: Record<string, { label: string; tone: 'accent' | 'ok' | 'warn' | 'danger' | 'neutral' }> = {
  planning: { label: 'planlanıyor', tone: 'accent' },
  running: { label: 'çalışıyor', tone: 'accent' },
  waiting: { label: 'onay bekliyor', tone: 'warn' },
  done: { label: 'bitti', tone: 'ok' },
  failed: { label: 'tamamlanamadı', tone: 'danger' },
  cancelled: { label: 'iptal', tone: 'neutral' },
}

/** Autonomous missions: a plan checklist that fills in live, the log, and the final report. */
export function MissionsSection() {
  const [items, setItems] = useState<Mission[]>([])
  const [goal, setGoal] = useState('')
  const [busy, setBusy] = useState(false)
  const online = !!useCore().snapshot
  const load = useCallback(() => client.call<Mission[]>('mission.list').then(setItems).catch(() => {}), [])
  useEffect(() => {
    if (online) void load()
  }, [load, online])
  useCoreEvent('mission.update', useCallback((e: CoreEvent) => {
    const m = e.data as unknown as Mission
    setItems((xs) => [m, ...xs.filter((x) => x.id !== m.id)].sort((a, b) => b.created - a.created))
  }, []))

  const start = async () => {
    if (!goal.trim()) return
    setBusy(true)
    try {
      await client.call('mission.start', { goal })
      setGoal('')
    } finally {
      setBusy(false)
    }
  }

  return (
    <section className="mb-8">
      <div className="panel p-4">
        <div className="flex items-center gap-3">
          <span className="grid size-9 shrink-0 place-items-center rounded-2xl bg-accent-soft text-accent">
            <Workflow className="size-[18px]" strokeWidth={1.6} />
          </span>
          <Input className="flex-1" placeholder="Otonom görev ver: “Samsun’da hafta sonu için 3 kafe araştır, not çıkar”"
            value={goal} onChange={(e) => setGoal(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && start()} />
          <Button variant="primary" loading={busy} onClick={start} disabled={!goal.trim()}>Başlat</Button>
        </div>
      </div>
      <AnimatePresence initial={false}>
        {items.map((m) => {
          const done = m.steps.filter((s) => s.status === 'done').length
          const live = ['planning', 'running', 'waiting'].includes(m.status)
          const st = STATUS[m.status] ?? STATUS.running
          return (
            <motion.article key={m.id} layout initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }} className="panel mt-3 p-5">
              <div className="flex flex-wrap items-center gap-2">
                <h3 className="text-[15px]">{m.title || m.goal}</h3>
                <Badge tone={st.tone}>{live && <Loader2 className="size-3 animate-spin" />}{st.label}</Badge>
                {live && (
                  <button onClick={() => client.call('mission.cancel', { id: m.id })} aria-label="İptal"
                    className="ml-auto grid size-7 place-items-center rounded-full text-fg-subtle transition hover:bg-fill-strong hover:text-fg">
                    <X className="size-4" />
                  </button>
                )}
              </div>
              {m.steps.length > 0 && (
                <>
                  <div className="mt-3 h-1.5 overflow-hidden rounded-full bg-fill">
                    <motion.div className="h-full rounded-full bg-gradient-to-r from-accent to-accent-2"
                      animate={{ width: `${(done / m.steps.length) * 100}%` }} transition={{ ease: [0.22, 1, 0.36, 1] }} />
                  </div>
                  <ol className="mt-3 space-y-1.5">
                    {m.steps.map((s) => (
                      <li key={s.n} className="flex items-start gap-2 text-[13px]">
                        {s.status === 'done'
                          ? <Check className="mt-0.5 size-4 shrink-0 text-emerald-600 dark:text-emerald-300" />
                          : <Circle className="mt-0.5 size-4 shrink-0 text-fg-subtle" strokeWidth={1.5} />}
                        <span className={clsx(s.status === 'done' && 'text-fg-muted')}>
                          {s.title}{s.note && <span className="text-fg-subtle"> — {s.note}</span>}
                        </span>
                      </li>
                    ))}
                  </ol>
                </>
              )}
              {live && m.log.length > 0 && (
                <div className="mt-3 rounded-2xl bg-fill px-3 py-2 font-mono text-[11.5px] leading-relaxed text-fg-muted">
                  {m.log.slice(-4).map((l, i) => <div key={i} className="truncate">{l}</div>)}
                </div>
              )}
              {m.report && <p className="mt-3 text-[13.5px] leading-relaxed">{m.report}</p>}
            </motion.article>
          )
        })}
      </AnimatePresence>
    </section>
  )
}
