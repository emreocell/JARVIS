import { AnimatePresence, motion } from 'framer-motion'
import { useCallback, useEffect, useState } from 'react'
import { Ambient } from './components/Ambient'
import { Approvals } from './components/Approvals'
import type { OrbState } from './components/LiquidOrb'
import { Sidebar, type PageId } from './components/Sidebar'
import { TitleBar } from './components/TitleBar'
import './lib/activity'
import { client, type CoreEvent } from './lib/rpc'
import { useCore, useCoreEvent } from './lib/useCore'
import { useApplyTheme } from './lib/theme'
import './lib/voiceLevel'
import { HistoryPage } from './pages/History'
import { HomePage } from './pages/Home'
import { JournalPage } from './pages/Journal'
import { MemoryPage } from './pages/Memory'
import { NotesPage } from './pages/Notes'
import { ProvidersPage } from './pages/Providers'
import { RoutinesPage } from './pages/Routines'
import { SettingsPage } from './pages/Settings'
import { SkillsPage } from './pages/Skills'
import { TasksPage } from './pages/Tasks'

const PAGES: Record<PageId, (props: { onNavigate?: (p: PageId) => void }) => React.JSX.Element> = {
  home: HomePage,
  journal: JournalPage,
  history: HistoryPage,
  notes: NotesPage,
  tasks: TasksPage,
  routines: RoutinesPage,
  memory: MemoryPage,
  skills: SkillsPage,
  providers: ProvidersPage,
  settings: SettingsPage,
}

export default function App() {
  const [page, setPage] = useState<PageId>('home')
  const { status, snapshot } = useCore()
  useApplyTheme()

  useEffect(() => {
    client.start()
    return () => client.stop()
  }, [])

  useCoreEvent('ui.navigate', useCallback((e: CoreEvent) => {
    const p = String(e.data.page) as PageId
    if (p in PAGES) setPage(p)
  }, []))

  const orbState = (snapshot?.state.voice ?? 'idle') as OrbState
  const Page = PAGES[page]
  return (
    <div className="flex h-full flex-col">
      <Ambient state={orbState} />
      <TitleBar />
      <div className="flex min-h-0 flex-1">
        <Sidebar page={page} onNavigate={setPage} status={status} />
        <main className="relative min-w-0 flex-1 overflow-y-auto px-5 pt-2 md:px-10">
          {status === 'offline' && page !== 'home' && (
            <div className="mx-auto mb-5 max-w-3xl rounded-2xl border border-amber-500/20 bg-amber-500/8 px-4 py-3 text-sm text-amber-700 dark:text-amber-200">
              Jarvis'in çekirdeği çalışmıyor; yeniden bağlanmaya çalışıyorum…
            </div>
          )}
          <AnimatePresence mode="wait">
            <motion.div
              key={page}
              className="h-full"
              initial={{ opacity: 0, y: 8, filter: 'blur(6px)' }}
              animate={{ opacity: 1, y: 0, filter: 'blur(0px)' }}
              exit={{ opacity: 0, y: -6, filter: 'blur(4px)' }}
              transition={{ duration: 0.28, ease: [0.22, 1, 0.36, 1] }}
            >
              {page === "home" ? <HomePage onNavigate={setPage} /> : <Page />}
            </motion.div>
          </AnimatePresence>
        </main>
      </div>
      <Approvals />
    </div>
  )
}
