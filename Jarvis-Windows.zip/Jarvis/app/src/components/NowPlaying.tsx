import { AnimatePresence, motion } from 'framer-motion'
import { Music2, Pause, Play, SkipBack, SkipForward } from 'lucide-react'
import { useCallback, useEffect, useState } from 'react'
import { client } from '../lib/rpc'
import { useCore } from '../lib/useCore'

interface Track { title: string; artist: string; album: string; app: string; playing: boolean; art: string | null }

/** Mini player for whatever Windows is playing (Spotify, YouTube, any app).
 *  Polls the local media session only while the window is visible. */
export function NowPlaying() {
  const { status } = useCore()
  const [track, setTrack] = useState<Track | null>(null)

  const load = useCallback(() => {
    if (status !== 'online' || document.visibilityState !== 'visible') return
    client.call<Track | null>('media.now_playing').then(setTrack).catch(() => {})
  }, [status])

  useEffect(() => {
    load()
    const t = window.setInterval(load, 4000)
    document.addEventListener('visibilitychange', load)
    return () => {
      window.clearInterval(t)
      document.removeEventListener('visibilitychange', load)
    }
  }, [load])

  const control = (action: string) => {
    if (track && (action === 'play' || action === 'pause')) setTrack({ ...track, playing: action === 'play' })
    void client.call('tools.run', { name: 'media_control', args: { action } }).then(() => window.setTimeout(load, 350))
  }

  return (
    <AnimatePresence>
      {track && (
        <motion.section key="np" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 8 }}
          className="panel relative overflow-hidden p-3">
          {track.art && (
            <img src={track.art} alt="" aria-hidden
              className="pointer-events-none absolute inset-0 size-full scale-125 object-cover opacity-[0.16] blur-2xl" />
          )}
          <div className="relative flex items-center gap-3">
            <div className="grid size-14 shrink-0 place-items-center overflow-hidden rounded-2xl bg-fill shadow-sm">
              {track.art
                ? <img src={track.art} alt="" className="size-full object-cover" />
                : <Music2 className="size-5 text-fg-subtle" strokeWidth={1.5} />}
            </div>
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-1.5 text-[10.5px] tracking-wide text-fg-subtle uppercase">
                {track.playing && <Bars />}
                {track.app}
              </div>
              <div className="truncate text-[13.5px] font-medium">{track.title}</div>
              <div className="truncate text-[12px] text-fg-muted">{track.artist}</div>
            </div>
          </div>
          <div className="relative mt-2.5 flex items-center justify-center gap-2">
            <button onClick={() => control('previous')} aria-label="Önceki"
              className="grid size-8 place-items-center rounded-full text-fg-muted transition hover:bg-fill-strong hover:text-fg">
              <SkipBack className="size-4" fill="currentColor" />
            </button>
            <button onClick={() => control(track.playing ? 'pause' : 'play')} aria-label={track.playing ? 'Duraklat' : 'Oynat'}
              className="grid size-10 place-items-center rounded-full bg-fg text-bg transition hover:scale-105">
              {track.playing ? <Pause className="size-4" fill="currentColor" /> : <Play className="size-4 translate-x-px" fill="currentColor" />}
            </button>
            <button onClick={() => control('next')} aria-label="Sonraki"
              className="grid size-8 place-items-center rounded-full text-fg-muted transition hover:bg-fill-strong hover:text-fg">
              <SkipForward className="size-4" fill="currentColor" />
            </button>
          </div>
        </motion.section>
      )}
    </AnimatePresence>
  )
}

function Bars() {
  return (
    <span className="flex h-2.5 items-end gap-[2px]" aria-hidden>
      {[0, 0.2, 0.4].map((d) => (
        <motion.span key={d} className="w-[2px] rounded-full bg-accent"
          animate={{ height: ['30%', '100%', '45%', '80%', '30%'] }}
          transition={{ duration: 1.1, repeat: Infinity, delay: d, ease: 'easeInOut' }} />
      ))}
    </span>
  )
}
