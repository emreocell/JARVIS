import {
  AlarmClock, AppWindow, BadgeDollarSign, Bell, BellOff, Blocks, BookmarkPlus, BookOpen, Bot, Brain, Clock, CloudSun, Code2,
  Command, Cpu, Disc3, Eraser, Eye, FileSearch, Folder, FolderOpen, Globe, Keyboard, LayoutGrid, Link, ListChecks, Lock,
  MessageCircle, MousePointer2, MousePointerClick, Music2, Newspaper, PanelTop, Pointer, Power, Radar, Repeat, ScanText,
  Settings2, SkipForward, SlidersHorizontal, Sparkles, SunMedium, Sunrise, TextCursorInput, TimerReset, Volume2, Workflow,
  Wrench, XSquare, Tv, Timer, StickyNote, NotebookText, Trash2, CheckSquare, Target, PanelLeft, Columns2, Monitor,
  Camera, Mail, Plug, CalendarDays, type LucideIcon,
} from 'lucide-react'

const ICONS: Record<string, LucideIcon> = {
  AlarmClock, AppWindow, BadgeDollarSign, Bell, BellOff, Blocks, BookmarkPlus, BookOpen, Bot, Brain, Clock, CloudSun, Code2,
  Command, Cpu, Disc3, Eraser, Eye, FileSearch, Folder, FolderOpen, Globe, Keyboard, LayoutGrid, Link, ListChecks, Lock,
  MessageCircle, MousePointer2, MousePointerClick, Music2, Newspaper, PanelTop, Pointer, Power, Radar, Repeat, ScanText,
  Settings2, SkipForward, SlidersHorizontal, Sparkles, SunMedium, Sunrise, TextCursorInput, TimerReset, Volume2, Workflow,
  XSquare, Youtube: Tv, Timer, StickyNote, NotebookText, Trash2, CheckSquare, Target, PanelLeft, Columns2, Monitor, Camera,
  Mail, Plug, CalendarDays,
}

/** Lucide icon by name (names come from the core's tools/titles.py). */
export function ToolIcon({ name, className, strokeWidth = 1.7 }: { name?: string; className?: string; strokeWidth?: number }) {
  const Icon = (name && ICONS[name]) || Wrench
  return <Icon className={className} strokeWidth={strokeWidth} />
}
