import { useThemeMode } from '../lib/theme'
import type { OrbState } from './LiquidOrb'

type Tint = [string, string, string]

const DARK: Record<OrbState, Tint> = {
  idle: ['#4c47d6', '#1f5fd1', '#6b3fc4'],
  listening: ['#2a7dff', '#2fc7d9', '#7a5cff'],
  thinking: ['#8f6bff', '#ff5fa2', '#3aa7ff'],
  speaking: ['#ff4f9a', '#8b5cff', '#ff8f4a'],
  muted: ['#3a3e52', '#2e3244', '#3a3e52'],
  error: ['#ff4d4d', '#ff8a4c', '#d6336c'],
}

// light: soft pastel washes that read as light, not as colour blocks
const LIGHT: Record<OrbState, Tint> = {
  idle: ['#b9c4ff', '#cfe3ff', '#e5d6ff'],
  listening: ['#a9c6ff', '#b8f0f2', '#d3c8ff'],
  thinking: ['#d0c2ff', '#ffc6e1', '#bfe0ff'],
  speaking: ['#ffc2dc', '#d6c4ff', '#ffdcbf'],
  muted: ['#dfe2ea', '#e7e9f0', '#dfe2ea'],
  error: ['#ffc4c4', '#ffd9bf', '#f7c1d6'],
}

/**
 * Soft ambient light behind everything, tinted by Jarvis' state.
 * Pure CSS (blurred radial gradients); colour changes are transitions and
 * the slow drift is a compositor-only transform animation.
 */
export function Ambient({ state }: { state: OrbState }) {
  const light = useThemeMode() === 'light'
  const [a, b, c] = (light ? LIGHT : DARK)[state]
  const active = state !== 'idle' && state !== 'muted'
  const o = light ? [0.75, 0.65, 0.6] : active ? [0.2, 0.16, 0.12] : [0.1, 0.07, 0.05]
  return (
    <div aria-hidden className="pointer-events-none fixed inset-0 -z-10 overflow-hidden bg-bg">
      <div className="ambient-drift absolute inset-[-20%]">
        <div className="absolute top-[4%] left-[26%] size-[48vmax] rounded-full blur-[120px] transition-[background-color,opacity] duration-[1400ms]"
          style={{ backgroundColor: a, opacity: o[0] }} />
        <div className="absolute right-[8%] bottom-[4%] size-[42vmax] rounded-full blur-[130px] transition-[background-color,opacity] duration-[1400ms]"
          style={{ backgroundColor: b, opacity: o[1] }} />
        <div className="absolute bottom-[28%] left-[2%] size-[32vmax] rounded-full blur-[120px] transition-[background-color,opacity] duration-[1400ms]"
          style={{ backgroundColor: c, opacity: o[2] }} />
      </div>
      {light && <div className="absolute inset-0 bg-gradient-to-b from-white/60 via-transparent to-white/40" />}
      <div className={`grain absolute inset-0 mix-blend-overlay ${light ? 'opacity-[0.05]' : 'opacity-[0.035]'}`} />
    </div>
  )
}
