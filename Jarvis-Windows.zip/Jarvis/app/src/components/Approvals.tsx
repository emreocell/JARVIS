import { AnimatePresence, motion } from 'framer-motion'
import { ShieldAlert } from 'lucide-react'
import { useState } from 'react'
import { dismissApproval, useApprovals, type Approval } from '../lib/activity'
import { client } from '../lib/rpc'
import { Button } from './ui'

function ApprovalCard({ a }: { a: Approval }) {
  const [remember, setRemember] = useState(false)
  const [busy, setBusy] = useState(false)
  const destructive = a.risk === 'destructive'

  const resolve = async (allow: boolean) => {
    setBusy(true)
    try {
      await client.call('approvals.resolve', { token: a.token, allow, remember: remember && !destructive })
    } finally {
      dismissApproval(a.token)
    }
  }

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 16, scale: 0.98 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      exit={{ opacity: 0, x: 40 }}
      className="w-96 rounded-2xl border border-line bg-surface p-4 shadow-2xl shadow-black/40"
    >
      <div className="flex gap-3">
        <div className={destructive ? 'text-danger' : 'text-warn'}>
          <ShieldAlert className="size-5" />
        </div>
        <div className="min-w-0 flex-1">
          <div className="text-sm font-medium">Onay gerekiyor</div>
          <div className="mt-1 text-sm text-fg-muted">{a.summary}</div>
          {!destructive && (
            <label className="mt-3 flex items-center gap-2 text-xs text-fg-muted">
              <input type="checkbox" checked={remember} onChange={(e) => setRemember(e.target.checked)}
                className="accent-[var(--accent)]" />
              Bunun için bir daha sorma
            </label>
          )}
          <div className="mt-3 flex justify-end gap-2">
            <Button size="sm" variant="ghost" onClick={() => resolve(false)} disabled={busy}>Reddet</Button>
            <Button size="sm" variant={destructive ? 'danger' : 'primary'} onClick={() => resolve(true)} loading={busy}>
              Onayla
            </Button>
          </div>
        </div>
      </div>
    </motion.div>
  )
}

/** Floating approval cards (bottom-right). Voice confirmation works in parallel. */
export function Approvals() {
  const approvals = useApprovals()
  return (
    <div className="pointer-events-none fixed right-6 bottom-6 z-50 flex flex-col gap-3">
      <AnimatePresence>
        {approvals.map((a) => (
          <div key={a.token} className="pointer-events-auto">
            <ApprovalCard a={a} />
          </div>
        ))}
      </AnimatePresence>
    </div>
  )
}
