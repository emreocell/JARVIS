import { AnimatePresence, motion } from 'framer-motion'
import { Plus, Timer as TimerIcon, X } from 'lucide-react'
import { useCallback, useEffect, useState } from 'react'
import { client } from '../lib/rpc'
import { useCore, useCoreEvent } from '../lib/useCore'

export interface ReminderRow { id: number; kind: string; text: string; due: number; created: number; due_local: string; repeat: string }

/** All pending reminders, refreshed whenever the core says routines changed. */
export function useReminders(): { reminders: ReminderRow[]; reload: () => void } {
  const { status } = useCore()
  const [reminders, setReminders] = useState<ReminderRow[]>([])
  const reload = useCallback(() => {
    if (status === 'online') client.call<{ reminders: ReminderRow[] }>('routines.list').then((r) => setReminders(r.reminders)).catch(() => {})
  }, [status])
  useEffect(() => { reload() }, [reload])
  useCoreEvent('routine.changed', reload)
  useCoreEvent('routine.fired', reload)
  return { reminders, reload }
}

function useNow(active: boolean) {
  const [now, setNow] = useState(Date.now() / 1000)
  useEffect(() => {
    if (!active) return
    const t = window.setInterval(() => setNow(Date.now() / 1000), 250)
    return () => window.clearInterval(t)
  }, [active])
  return now
}

export function clock(seconds: number) {
  const s = Math.max(0, Math.ceil(seconds))
  const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), sec = s % 60
  return h ? `${h}:${String(m).padStart(2, '0')}:${String(sec).padStart(2, '0')}` : `${m}:${String(sec).padStart(2, '0')}`
}

function Ring({ progress, size = 44 }: { progress: number; size?: number }) {
  const r = size / 2 - 3, c = 2 * Math.PI * r
  return (
    <svg width={size} height={size} className="-rotate-90">
      <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="var(--fill-strong)" strokeWidth="3" />
      <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="url(#timer-grad)" strokeWidth="3" strokeLinecap="round"
        strokeDasharray={c} strokeDashoffset={c * (1 - progress)} style={{ transition: 'stroke-dashoffset 0.25s linear' }} />
      <defs>
        <linearGradient id="timer-grad" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="var(--accent)" /><stop offset="100%" stopColor="var(--accent-2)" />
        </linearGradient>
      </defs>
    </svg>
  )
}

const QUICK = [1, 5, 10, 25]

/** Live countdowns. ``compact``: only renders when a timer runs (home side panel). */
export function Timers({ compact = false }: { compact?: boolean }) {
  const { reminders } = useReminders()
  const timers = reminders.filter((r) => r.kind === 'timer').sort((a, b) => a.due - b.due)
  const now = useNow(timers.length > 0)
  const [custom, setCustom] = useState('')

  const start = (minutes: number, label = 'Zamanlayıcı') =>
    client.call('tools.run', { name: 'set_timer', args: { minutes, label } })
  const cancel = (id: number) => client.call('routines.cancel', { id })

  if (compact && timers.length === 0) return null
  return (
    <section className="panel p-4">
      <div className="mb-2 flex items-center justify-between px-1">
        <h2 className="flex items-center gap-2 text-[14px]"><TimerIcon className="size-4 text-accent" /> Zamanlayıcılar</h2>
      </div>
      <ul className="flex flex-col gap-1">
        <AnimatePresence initial={false}>
          {timers.map((t) => {
            const total = Math.max(1, t.due - t.created)
            const left = t.due - now
            return (
              <motion.li key={t.id} layout initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, x: 20 }}
                className="group flex items-center gap-3 rounded-2xl px-2 py-1.5">
                <div className="relative grid place-items-center">
                  <Ring progress={Math.min(1, Math.max(0, 1 - left / total))} />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="text-[22px] leading-none font-extralight tabular-nums">{clock(left)}</div>
                  <div className="mt-1 truncate text-[12px] text-fg-muted">{t.text}</div>
                </div>
                <button onClick={() => cancel(t.id)} aria-label="İptal"
                  className="grid size-8 place-items-center rounded-full text-fg-subtle opacity-0 transition group-hover:opacity-100 hover:bg-fill-strong hover:text-fg">
                  <X className="size-4" />
                </button>
              </motion.li>
            )
          })}
        </AnimatePresence>
      </ul>
      {!compact && (
        <div className="mt-2 flex flex-wrap items-center gap-1.5 px-1">
          {timers.length === 0 && <span className="mr-1 text-[12.5px] text-fg-muted">Hızlı başlat:</span>}
          {QUICK.map((m) => (
            <button key={m} onClick={() => start(m)}
              className="rounded-full bg-fill px-3 py-1.5 text-[12.5px] ring-1 ring-line ring-inset transition hover:bg-fill-strong">
              {m} dk
            </button>
          ))}
          <form className="flex items-center" onSubmit={(e) => { e.preventDefault(); const m = Number(custom); if (m > 0) { void start(m); setCustom('') } }}>
            <input value={custom} onChange={(e) => setCustom(e.target.value.replace(/[^\d.]/g, ''))} placeholder="dk"
              className="w-14 rounded-full bg-fill px-3 py-1.5 text-[12.5px] ring-1 ring-line ring-inset outline-none placeholder:text-fg-subtle" />
            <button type="submit" aria-label="Başlat" className="ml-1 grid size-7 place-items-center rounded-full text-fg-muted hover:bg-fill-strong">
              <Plus className="size-4" />
            </button>
          </form>
        </div>
      )}
    </section>
  )
}
