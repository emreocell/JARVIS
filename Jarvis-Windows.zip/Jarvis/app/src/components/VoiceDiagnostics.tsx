import clsx from 'clsx'
import { Activity, CheckCircle2, Loader2, Mic, Play, Radio } from 'lucide-react'
import { useCallback, useEffect, useRef, useState } from 'react'
import { client, RpcError, type CoreEvent } from '../lib/rpc'
import { useCore, useCoreEvent } from '../lib/useCore'
import { Button, Card } from './ui'

function since(ts: number | null) {
  if (!ts) return ''
  const s = Math.round((Date.now() - ts) / 1000)
  return s < 60 ? `${s} sn önce` : `${Math.round(s / 60)} dk önce`
}

/** Self-service checks: can Jarvis hear you, does the wake word fire, does the whole pipeline answer? */
export function VoiceDiagnostics() {
  const { snapshot } = useCore()
  const voiceOn = snapshot?.state.voice !== 'muted' && Boolean(snapshot?.config.voice.enabled)
  const [metering, setMetering] = useState(false)
  const [level, setLevel] = useState(0)
  const peak = useRef(0)
  const [heard, setHeard] = useState(false)
  const [wakeAt, setWakeAt] = useState<number | null>(null)
  const [wakePhrase, setWakePhrase] = useState('')
  const [test, setTest] = useState<{ running: boolean; user?: string; reply?: string; error?: string }>({ running: false })
  const [, tick] = useState(0)

  useEffect(() => {
    const t = window.setInterval(() => tick((n) => n + 1), 5000)
    return () => window.clearInterval(t)
  }, [])

  useCoreEvent('voice.level', useCallback((e: CoreEvent) => {
    const mic = Number(e.data.mic) || 0
    setLevel(mic)
    peak.current = Math.max(peak.current * 0.9, mic)
    if (mic > 0.06) setHeard(true)
  }, []))
  useCoreEvent('voice.wake', useCallback((e: CoreEvent) => {
    setWakeAt(Date.now())
    setWakePhrase(String(e.data.phrase || ''))
  }, []))
  useCoreEvent('voice.turn_complete', useCallback((e: CoreEvent) => {
    setTest((t) => (t.running ? { running: false, user: String(e.data.user || ''), reply: String(e.data.assistant || '') } : t))
  }, []))

  const startMeter = async () => {
    setHeard(false)
    setMetering(true)
    try {
      await client.call('voice.meter', { seconds: 10 })
      window.setTimeout(() => { setMetering(false); setLevel(0) }, 10_000)
    } catch (e) {
      setMetering(false)
      setTest({ running: false, error: e instanceof RpcError ? e.message : String(e) })
    }
  }
  const runPipeline = async () => {
    setTest({ running: true })
    try {
      await client.call('voice.inject', { text: 'Saat kaç?' })
      window.setTimeout(() => setTest((t) => (t.running ? { running: false, error: 'Cevap gelmedi (20 sn).' } : t)), 20_000)
    } catch (e) {
      setTest({ running: false, error: e instanceof RpcError ? e.message : String(e) })
    }
  }

  const bar = Math.min(1, level * 4)
  return (
    <Card className="divide-y divide-line">
      <div className="flex items-center gap-2 px-5 pt-4 pb-3 text-[14px]">
        <Activity className="size-4 text-accent" /> Tanılama
        {!voiceOn && <span className="ml-auto text-[12px] text-fg-subtle">Sesli asistan kapalı</span>}
      </div>

      <div className="flex flex-wrap items-center gap-4 px-5 py-4">
        <div className="min-w-0 flex-1 basis-60">
          <div className="flex items-center gap-2 text-[14px]"><Mic className="size-4 text-fg-muted" /> Mikrofon</div>
          <div className="mt-2 h-2 overflow-hidden rounded-full bg-fill-strong">
            <div className="h-full rounded-full bg-gradient-to-r from-[var(--accent)] to-[var(--accent-2)] transition-[width] duration-100"
              style={{ width: `${bar * 100}%` }} />
          </div>
          <div className="mt-1.5 text-[12px] text-fg-muted">
            {metering ? (heard ? 'Seni duyuyorum ✓' : 'Bir şeyler söyle…') : heard ? 'Mikrofon çalışıyor ✓' : 'Test ederken konuş; çubuk hareket etmeli.'}
          </div>
        </div>
        <Button size="sm" variant="secondary" onClick={startMeter} disabled={metering || !voiceOn}>
          {metering ? <Loader2 className="size-3.5 animate-spin" /> : <Mic className="size-3.5" />} Mikrofonu test et
        </Button>
      </div>

      <div className="flex items-center gap-4 px-5 py-4">
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2 text-[14px]"><Radio className="size-4 text-fg-muted" /> Uyandırma</div>
          <div className={clsx('mt-1 text-[12.5px]', wakeAt ? 'text-emerald-700 dark:text-emerald-300' : 'text-fg-muted')}>
            {wakeAt ? <>“{wakePhrase}” algılandı · {since(wakeAt)}</> : '“Hey Jarvis” de — algılanınca burada görünür.'}
          </div>
        </div>
        {wakeAt && <CheckCircle2 className="size-5 text-emerald-500" />}
      </div>

      <div className="flex flex-wrap items-center gap-4 px-5 py-4">
        <div className="min-w-0 flex-1 basis-60">
          <div className="flex items-center gap-2 text-[14px]"><Play className="size-4 text-fg-muted" /> Sesli hat testi</div>
          <div className="mt-1 text-[12.5px] leading-relaxed text-fg-muted">
            {test.running && 'Jarvis’e “Hey Jarvis, saat kaç?” söyletiliyor…'}
            {!test.running && test.reply !== undefined && <>Duydu: “{test.user}” → Cevap: “{test.reply}”</>}
            {!test.running && test.error && <span className="text-amber-700 dark:text-amber-200">{test.error}</span>}
            {!test.running && test.reply === undefined && !test.error && 'Uyandırma, konuşmayı anlama ve sesli cevabın hepsini bir arada dener.'}
          </div>
        </div>
        <Button size="sm" variant="secondary" onClick={runPipeline} disabled={test.running || !voiceOn}>
          {test.running ? <Loader2 className="size-3.5 animate-spin" /> : <Play className="size-3.5" />} Sesli hattı dene
        </Button>
      </div>
    </Card>
  )
}
