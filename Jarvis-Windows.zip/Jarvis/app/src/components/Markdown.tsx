import clsx from 'clsx'
import { Check, Copy } from 'lucide-react'
import { Fragment, useState, type ReactNode } from 'react'

/**
 * Minimal, injection-proof Markdown for assistant answers: paragraphs,
 * headings, bullet/numbered lists, **bold**, *italic*, `code`, fenced code
 * blocks and links (shown as text + url). Builds React elements only — no
 * innerHTML — because answers can come from web pages and LLMs.
 */
export function Markdown({ text, className }: { text: string; className?: string }) {
  return <div className={clsx('md flex flex-col gap-2.5', className)}>{blocks(text)}</div>
}

function blocks(src: string): ReactNode[] {
  const out: ReactNode[] = []
  const lines = src.replace(/\r\n/g, '\n').split('\n')
  let i = 0
  let key = 0
  while (i < lines.length) {
    const line = lines[i]
    const fence = line.match(/^\s*```(\w*)\s*$/)
    if (fence) {
      const code: string[] = []
      i++
      while (i < lines.length && !/^\s*```\s*$/.test(lines[i])) code.push(lines[i++])
      i++
      out.push(<CodeBlock key={key++} lang={fence[1]} code={code.join('\n')} />)
      continue
    }
    const heading = line.match(/^\s*(#{1,4})\s+(.*)$/)
    if (heading) {
      out.push(<div key={key++} className={clsx('font-medium', heading[1].length <= 2 ? 'text-[1.08em]' : '')}>{inline(heading[2])}</div>)
      i++
      continue
    }
    if (/^\s*([-*•]|\d+[.)])\s+/.test(line)) {
      const ordered = /^\s*\d+[.)]/.test(line)
      const start = ordered ? parseInt(line.trim(), 10) : undefined
      const items: string[] = []
      const isItem = (l: string | undefined) => l !== undefined && /^\s*([-*•]|\d+[.)])\s+/.test(l)
      while (i < lines.length) {
        if (isItem(lines[i])) {
          items.push(lines[i].replace(/^\s*([-*•]|\d+[.)])\s+/, ''))
          i++
          continue
        }
        // models often leave a blank line between items: keep one list across it
        let j = i
        while (j < lines.length && !lines[j].trim()) j++
        if (j > i && isItem(lines[j])) { i = j; continue }
        break
      }
      const List = ordered ? 'ol' : 'ul'
      out.push(
        <List key={key++} start={start} className={clsx('flex flex-col gap-1 pl-5', ordered ? 'list-decimal' : 'list-disc')}>
          {items.map((it, j) => <li key={j} className="pl-1 marker:text-fg-subtle">{inline(it)}</li>)}
        </List>,
      )
      continue
    }
    if (!line.trim()) {
      i++
      continue
    }
    const para: string[] = []
    while (i < lines.length && lines[i].trim() && !/^\s*(```|#{1,4}\s|[-*•]\s|\d+[.)]\s)/.test(lines[i])) para.push(lines[i++])
    out.push(<p key={key++} className="leading-relaxed">{para.map((p, j) => <Fragment key={j}>{j > 0 && <br />}{inline(p)}</Fragment>)}</p>)
  }
  return out
}

const TOKEN = /(`[^`]+`|\*\*[^*]+\*\*|__[^_]+__|\*[^*\s][^*]*\*|\[[^\]]+\]\((?:https?:\/\/)[^)\s]+\))/g

function inline(text: string): ReactNode[] {
  const parts: ReactNode[] = []
  let last = 0
  let k = 0
  for (const m of text.matchAll(TOKEN)) {
    if (m.index! > last) parts.push(text.slice(last, m.index))
    const t = m[0]
    if (t.startsWith('`')) parts.push(<code key={k++} className="rounded-md bg-fill-strong px-1.5 py-0.5 font-mono text-[0.88em]">{t.slice(1, -1)}</code>)
    else if (t.startsWith('**') || t.startsWith('__')) parts.push(<strong key={k++} className="font-medium">{t.slice(2, -2)}</strong>)
    else if (t.startsWith('[')) {
      const [, label, url] = t.match(/^\[([^\]]+)\]\(([^)]+)\)$/) ?? []
      parts.push(<span key={k++} className="text-accent" title={url}>{label}</span>)
    } else parts.push(<em key={k++}>{t.slice(1, -1)}</em>)
    last = m.index! + t.length
  }
  if (last < text.length) parts.push(text.slice(last))
  return parts
}

function CodeBlock({ code, lang }: { code: string; lang: string }) {
  const [copied, setCopied] = useState(false)
  const copy = () => {
    void navigator.clipboard.writeText(code).then(() => {
      setCopied(true)
      window.setTimeout(() => setCopied(false), 1500)
    })
  }
  return (
    <div className="group relative overflow-hidden rounded-xl bg-fill-strong ring-1 ring-line ring-inset">
      <div className="flex items-center justify-between px-3 pt-2 text-[11px] text-fg-subtle">
        <span>{lang || 'kod'}</span>
        <button onClick={copy} className="flex items-center gap-1 opacity-0 transition group-hover:opacity-100 hover:text-fg" aria-label="Kopyala">
          {copied ? <Check className="size-3" /> : <Copy className="size-3" />} {copied ? 'kopyalandı' : 'kopyala'}
        </button>
      </div>
      <pre className="overflow-x-auto px-3 pt-1 pb-3 font-mono text-[12.5px] leading-relaxed"><code>{code}</code></pre>
    </div>
  )
}
