import clsx from 'clsx'
import { motion } from 'framer-motion'
import { Blocks, Brain, Cable, CalendarClock, House, ListChecks, MessagesSquare, Repeat, Settings, StickyNote, type LucideIcon } from 'lucide-react'
import type { ConnectionStatus } from '../lib/rpc'
import { useCore } from '../lib/useCore'
import { LiquidOrb, type OrbState } from './LiquidOrb'

export type PageId = 'home' | 'journal' | 'history' | 'notes' | 'tasks' | 'routines' | 'memory' | 'skills' | 'providers' | 'settings'

const items: { id: PageId; label: string; icon: LucideIcon }[] = [
  { id: 'home', label: 'Ana Sayfa', icon: House },
  { id: 'journal', label: 'Günlük', icon: CalendarClock },
  { id: 'history', label: 'Sohbetler', icon: MessagesSquare },
  { id: 'notes', label: 'Notlar', icon: StickyNote },
  { id: 'tasks', label: 'Görevler', icon: ListChecks },
  { id: 'routines', label: 'Rutinler', icon: Repeat },
  { id: 'memory', label: 'Hafıza', icon: Brain },
  { id: 'skills', label: 'Yetenekler', icon: Blocks },
  { id: 'providers', label: 'Modeller', icon: Cable },
  { id: 'settings', label: 'Ayarlar', icon: Settings },
]

const statusText: Record<ConnectionStatus, string> = {
  connecting: 'Bağlanıyor',
  online: 'Çevrimiçi',
  offline: 'Çekirdek kapalı',
}

/** Floating glass rail: a live mini-orb on top, labelled icons, a liquid active pill. */
export function Sidebar({ page, onNavigate, status }: {
  page: PageId
  onNavigate: (p: PageId) => void
  status: ConnectionStatus
}) {
  const { snapshot } = useCore()
  const state = (snapshot?.state.voice ?? 'idle') as OrbState
  const name = snapshot?.config.assistant?.user_name
  return (
    <nav className="glass relative z-10 my-2 ml-3 flex w-[76px] shrink-0 flex-col items-center rounded-[28px] py-4">
      <button onClick={() => onNavigate('home')} aria-label="Jarvis" className="mb-4 rounded-full transition hover:scale-105">
        <LiquidOrb state={state} size={46} />
      </button>
      <ul className="flex flex-1 flex-col gap-1.5">
        {items.map(({ id, label, icon: Icon }) => {
          const active = page === id
          return (
            <li key={id}>
              <button
                onClick={() => onNavigate(id)}
                aria-current={active ? 'page' : undefined}
                className={clsx('relative flex w-[62px] flex-col items-center gap-1 rounded-2xl py-2 transition-colors',
                  active ? 'text-accent' : 'text-fg-subtle hover:text-fg')}
              >
                {active && (
                  <motion.span layoutId="rail-active" className="absolute inset-0 rounded-2xl bg-accent-soft"
                    transition={{ type: 'spring', stiffness: 420, damping: 34 }} />
                )}
                <Icon className="relative size-[19px]" strokeWidth={active ? 1.9 : 1.6} />
                <span className="relative text-[10.5px] leading-none">{label}</span>
              </button>
            </li>
          )
        })}
      </ul>
      <div className="flex flex-col items-center gap-2" title={statusText[status]}>
        {name && (
          <span className="grid size-8 place-items-center rounded-full bg-gradient-to-br from-accent to-accent-2 text-[12px] font-medium text-white">
            {name.slice(0, 1).toUpperCase()}
          </span>
        )}
        <span className={clsx('size-1.5 rounded-full',
          status === 'online' && 'bg-emerald-500 shadow-[0_0_8px_#10b981]',
          status === 'connecting' && 'animate-pulse bg-amber-400',
          status === 'offline' && 'bg-red-500')} />
      </div>
    </nav>
  )
}
