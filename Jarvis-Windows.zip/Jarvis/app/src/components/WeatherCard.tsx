import { motion } from 'framer-motion'
import { Droplets, Wind } from 'lucide-react'
import { useWeather, weatherIcon } from '../lib/weather'

/** Side-panel weather: now, the next hours as a soft strip, and three days. */
export function WeatherCard() {
  const { weather: w, error } = useWeather()
  if (!w) {
    return error ? null : (
      <section className="panel h-[168px] animate-pulse p-4">
        <div className="h-4 w-24 rounded bg-fill" />
        <div className="mt-4 h-10 w-20 rounded bg-fill" />
      </section>
    )
  }
  const Icon = weatherIcon(w.now.code, w.now.is_day)
  const hours = w.hours.filter((_, i) => i % 2 === 0).slice(0, 6)
  const temps = w.hours.map((h) => h.temp)
  const lo = Math.min(...temps), hi = Math.max(...temps)
  return (
    <motion.section initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="panel overflow-hidden p-4">
      <div className="flex items-start justify-between gap-3 px-1">
        <div className="min-w-0">
          <div className="truncate text-[12.5px] text-fg-muted">{w.place}</div>
          <div className="mt-1 flex items-baseline gap-1.5">
            <span className="text-[38px] leading-none font-extralight tracking-tight">{w.now.temp}°</span>
            <span className="text-[12.5px] text-fg-subtle">{w.days[0]?.max}° / {w.days[0]?.min}°</span>
          </div>
          <div className="mt-1 text-[13px] first-letter:uppercase">{w.now.summary}</div>
        </div>
        <Icon className="size-11 shrink-0 text-accent" strokeWidth={1.2} />
      </div>

      <div className="mt-3 flex justify-between gap-1 rounded-2xl bg-fill px-2 py-2.5">
        {hours.map((h) => {
          const HIcon = weatherIcon(h.code, Number(h.time.slice(0, 2)) >= 7 && Number(h.time.slice(0, 2)) < 20)
          const lift = hi > lo ? ((h.temp - lo) / (hi - lo)) * 6 : 3
          return (
            <div key={h.time} className="flex flex-1 flex-col items-center gap-1 text-[11px]">
              <span className="text-fg-subtle tabular-nums">{h.time.slice(0, 2)}</span>
              <HIcon className="size-4 text-fg-muted" strokeWidth={1.5} />
              <span className="tabular-nums" style={{ transform: `translateY(${-lift + 3}px)` }}>{h.temp}°</span>
              {h.rain_chance >= 30 && <span className="text-[10px] text-accent">%{h.rain_chance}</span>}
            </div>
          )
        })}
      </div>

      <div className="mt-3 flex items-center gap-4 px-1 text-[11.5px] text-fg-subtle">
        <span className="flex items-center gap-1"><Droplets className="size-3.5" />%{w.now.humidity}</span>
        <span className="flex items-center gap-1"><Wind className="size-3.5" />{w.now.wind_kmh} km/s</span>
        <span className="ml-auto">hissedilen {w.now.feels_like}°</span>
      </div>

      <ul className="mt-2 flex flex-col">
        {w.days.slice(1, 3).map((d) => {
          const DIcon = weatherIcon(d.code)
          return (
            <li key={d.date} className="flex items-center gap-3 px-1 py-1.5 text-[12.5px]">
              <span className="w-16 text-fg-muted">{d.label}</span>
              <DIcon className="size-4 text-fg-muted" strokeWidth={1.5} />
              <span className="min-w-0 flex-1 truncate text-fg-subtle first-letter:uppercase">{d.summary}</span>
              <span className="tabular-nums">{d.max}°</span>
              <span className="w-7 text-right text-fg-subtle tabular-nums">{d.min}°</span>
            </li>
          )
        })}
      </ul>
    </motion.section>
  )
}
