import { AnimatePresence, motion } from 'framer-motion'
import { Mic, Square } from 'lucide-react'
import { useCallback, useEffect, useState } from 'react'
import { client, type CoreEvent } from '../lib/rpc'
import { useCore, useCoreEvent } from '../lib/useCore'

interface Status {
  active: boolean; id?: number; title?: string; start?: number; segments?: number; last?: string
  recent: { id: number; title: string; start: number; decisions: number; actions: number }[]
}

function clock(since: number) {
  const s = Math.max(0, Math.floor(Date.now() / 1000 - since))
  return `${Math.floor(s / 60).toString().padStart(2, '0')}:${(s % 60).toString().padStart(2, '0')}`
}

/** Meeting mode: start/stop, a live line of what was just said, the last meeting's outcome. */
export function MeetingCard() {
  const [st, setSt] = useState<Status | null>(null)
  const [busy, setBusy] = useState(false)
  const [, tick] = useState(0)
  const [result, setResult] = useState<string | null>(null)
  const { snapshot } = useCore()
  const online = !!snapshot
  const load = useCallback(() => client.call<Status>('meeting.status').then(setSt).catch(() => {}), [])
  useEffect(() => {
    if (online) void load()   // (re)load once the core connection is up
  }, [load, online])
  useEffect(() => {
    if (!st?.active) return
    const t = setInterval(() => tick((x) => x + 1), 1000)
    return () => clearInterval(t)
  }, [st?.active])
  useCoreEvent('meeting.state', useCallback(() => void load(), [load]))
  useCoreEvent('meeting.segment', useCallback((e: CoreEvent) =>
    setSt((s) => (s ? { ...s, last: String(e.data.text), segments: (s.segments ?? 0) + 1 } : s)), []))

  const start = async () => {
    setBusy(true); setResult(null)
    try { await client.call('meeting.start', {}) } finally { setBusy(false); void load() }
  }
  const stop = async () => {
    setBusy(true)
    try {
      const r = await client.call<{ output: string; summary?: { decisions: string[]; action_items: unknown[] } }>('meeting.stop')
      setResult(r.summary ? `${r.output} ${r.summary.decisions.length} karar, ${r.summary.action_items.length} aksiyon; ikinci beyne kaydedildi.` : r.output)
    } finally { setBusy(false); void load() }
  }

  const last = st?.recent[0]
  return (
    <motion.section layout className="panel p-4">
      <div className="flex items-center justify-between px-1">
        <h2 className="flex items-center gap-2 text-[14px]">
          <Mic className="size-4 text-accent" strokeWidth={1.6} /> Toplantı modu
        </h2>
        {st?.active ? (
          <button onClick={stop} disabled={busy}
            className="flex items-center gap-1.5 rounded-full bg-red-500/10 px-2.5 py-1 text-[12px] text-red-600 transition hover:bg-red-500/15 disabled:opacity-50 dark:text-red-300">
            <Square className="size-3 fill-current" /> {busy ? 'Özetleniyor…' : 'Bitir'}
          </button>
        ) : (
          <button onClick={start} disabled={busy} className="text-[12px] text-fg-subtle transition-colors hover:text-accent">
            Başlat
          </button>
        )}
      </div>
      <AnimatePresence mode="wait">
        {st?.active ? (
          <motion.div key="on" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="mt-2 px-1">
            <div className="flex items-center gap-2 text-[12.5px]">
              <span className="relative flex size-2"><span className="absolute inline-flex size-full animate-ping rounded-full bg-red-400 opacity-60" />
                <span className="relative inline-flex size-2 rounded-full bg-red-500" /></span>
              <span className="tabular-nums">{clock(st?.start ?? 0)}</span>
              <span className="text-fg-subtle">· sessizce not alıyor · {st?.segments ?? 0} bölüm</span>
            </div>
            {st?.last && <p className="mt-2 line-clamp-2 text-[12.5px] leading-snug text-fg-muted">“{st.last}”</p>}
          </motion.div>
        ) : (
          <motion.p key="off" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="mt-2 px-1 text-[12.5px] leading-relaxed text-fg-muted">
            {result ?? (last ? `Son: ${last.title} · ${last.decisions} karar, ${last.actions} aksiyon`
              : 'Dinler, yazıya döker, kararları ve aksiyonları çıkarır. Bu sırada hiç konuşmaz.')}
          </motion.p>
        )}
      </AnimatePresence>
    </motion.section>
  )
}
