import { motion } from 'framer-motion'
import { CalendarDays, Mail, Sunrise } from 'lucide-react'
import { useCallback, useEffect, useState } from 'react'
import { client, type CoreEvent } from '../lib/rpc'
import { useCore, useCoreEvent } from '../lib/useCore'

interface Brief {
  zaman?: string
  hava?: string | null
  hatırlatıcılar?: { time: string; text: string }[]
  mail?: { unread: number; top: { from: string; subject: string }[] } | null
  takvim_bugün?: string | null
}

/** Side-panel "Günün özeti": what the morning brief said, and a button to hear it again. */
export function BriefCard() {
  const [brief, setBrief] = useState<Brief | null>(null)
  const [busy, setBusy] = useState(false)

  const online = !!useCore().snapshot
  useEffect(() => {
    if (online) client.call<{ data: Brief } | null>('brief.last').then((r) => r && setBrief(r.data)).catch(() => {})
  }, [online])
  useCoreEvent('brief.ready', useCallback((e: CoreEvent) => setBrief(e.data.data as Brief), []))

  const run = async () => {
    setBusy(true)
    try {
      setBrief(await client.call<Brief>('brief.run'))
    } catch {
      /* shown by the voice layer */
    } finally {
      setBusy(false)
    }
  }

  const reminders = brief?.hatırlatıcılar ?? []
  return (
    <motion.section initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="panel p-4">
      <div className="mb-2 flex items-center justify-between px-1">
        <h2 className="flex items-center gap-2 text-[14px]">
          <Sunrise className="size-4 text-accent" strokeWidth={1.6} /> Günün özeti
        </h2>
        <button onClick={run} disabled={busy}
          className="text-[12px] text-fg-subtle transition-colors hover:text-accent disabled:opacity-50">
          {busy ? 'Hazırlanıyor…' : brief ? 'Tekrar dinle' : 'Dinle'}
        </button>
      </div>
      {!brief ? (
        <p className="px-1 text-[12.5px] leading-relaxed text-fg-muted">
          Sabah bilgisayarın başına ilk geldiğinde Jarvis günaydın der ve günü kısaca anlatır.
        </p>
      ) : (
        <ul className="flex flex-col gap-1.5 px-1 text-[12.5px] leading-snug">
          {brief.mail && (
            <li className="flex gap-2">
              <Mail className="mt-0.5 size-3.5 shrink-0 text-fg-subtle" strokeWidth={1.7} />
              <span>
                {brief.mail.unread ? `${brief.mail.unread} okunmamış mail` : 'Okunmamış mail yok'}
                {brief.mail.top[0] && <span className="text-fg-muted"> · {brief.mail.top[0].from}</span>}
              </span>
            </li>
          )}
          {brief.takvim_bugün && (
            <li className="flex gap-2">
              <CalendarDays className="mt-0.5 size-3.5 shrink-0 text-fg-subtle" strokeWidth={1.7} />
              <span className="line-clamp-2 text-fg-muted">{brief.takvim_bugün.split('\n').slice(0, 3).join(' · ')}</span>
            </li>
          )}
          {reminders.slice(0, 3).map((r) => (
            <li key={r.time + r.text} className="flex gap-2">
              <span className="w-9 shrink-0 text-fg-subtle tabular-nums">{r.time}</span>
              <span>{r.text}</span>
            </li>
          ))}
          {!brief.mail && !brief.takvim_bugün && !reminders.length && (
            <li className="text-fg-muted">Bugün için takvimde ya da hatırlatıcılarda bir şey yok.</li>
          )}
        </ul>
      )}
    </motion.section>
  )
}
