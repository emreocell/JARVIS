import { useEffect, useRef } from 'react'

/**
 * Symmetric bar waveform driven by the live audio level (read per frame, no
 * re-renders). Idle bars rest as a faint dotted line; the animation loop only
 * runs while `active`.
 */
export function Waveform({ level, active, bars = 48, className }: {
  level: () => number
  active: boolean
  bars?: number
  className?: string
}) {
  const ref = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = ref.current!
    const ctx = canvas.getContext('2d')!
    const heights = new Float32Array(bars)
    let raf = 0
    const seeds = Array.from({ length: bars }, () => Math.random() * Math.PI * 2)

    const draw = (t: number) => {
      const dpr = Math.min(window.devicePixelRatio || 1, 2)
      const w = canvas.clientWidth, h = canvas.clientHeight
      if (canvas.width !== w * dpr) { canvas.width = w * dpr; canvas.height = h * dpr }
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0)
      ctx.clearRect(0, 0, w, h)
      const lv = active ? Math.min(1, level() * 1.4) : 0
      const styles = getComputedStyle(document.documentElement)
      const a = styles.getPropertyValue('--accent').trim() || '#5b6cff'
      const b = styles.getPropertyValue('--accent-2').trim() || '#9b7bff'
      const grad = ctx.createLinearGradient(0, 0, w, 0)
      grad.addColorStop(0, 'transparent'); grad.addColorStop(0.25, a); grad.addColorStop(0.75, b); grad.addColorStop(1, 'transparent')
      ctx.fillStyle = grad
      const gap = w / bars
      for (let i = 0; i < bars; i++) {
        const center = 1 - Math.abs(i - bars / 2) / (bars / 2)          // taller in the middle
        const wobble = 0.55 + 0.45 * Math.sin(t / 180 + seeds[i] + i * 0.35)
        const target = 2 + lv * h * 0.9 * center ** 1.4 * wobble
        heights[i] += (target - heights[i]) * 0.25
        const bh = Math.max(2, heights[i])
        ctx.beginPath()
        ctx.roundRect(i * gap + gap * 0.3, (h - bh) / 2, Math.max(1.5, gap * 0.4), bh, 2)
        ctx.fill()
      }
      if (active) raf = requestAnimationFrame(draw)
    }
    raf = requestAnimationFrame(draw)
    return () => cancelAnimationFrame(raf)
  }, [active, bars, level])

  return <canvas ref={ref} className={className} aria-hidden />
}
