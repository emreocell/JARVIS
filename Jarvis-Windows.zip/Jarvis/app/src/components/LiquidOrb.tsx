import { useEffect, useRef } from 'react'
import { isSurfaceActive, onSurfaceActive } from '../lib/surface'

export type OrbState = 'idle' | 'listening' | 'thinking' | 'speaking' | 'muted' | 'error'

/**
 * Audio-reactive liquid orb (raw WebGL, no deps).
 *
 * - Silhouette: circle SDF displaced by 3D simplex noise; amplitude follows the
 *   live audio level (mic while listening, speaker while speaking).
 * - Body: domain-warped fbm mixing a 4-colour state palette, flowing over time.
 * - Glass: fresnel rim, specular highlight, inner glow, soft outer halo.
 * - Palette/params ease between states; transparent background (overlay-ready).
 * - Stops rendering when hidden; 30 fps when idle, 60 fps when active.
 */

const VERT = `attribute vec2 p; void main(){ gl_Position = vec4(p, 0.0, 1.0); }`

const FRAG = `
precision highp float;
uniform vec2 uRes;
uniform float uTime, uLevel, uEnergy, uSwirl, uSat, uLight;
uniform vec3 uC0, uC1, uC2, uC3;

// --- simplex noise (Ashima / Stefan Gustavson, MIT)
vec3 mod289(vec3 x){return x-floor(x*(1.0/289.0))*289.0;}
vec4 mod289(vec4 x){return x-floor(x*(1.0/289.0))*289.0;}
vec4 permute(vec4 x){return mod289(((x*34.0)+1.0)*x);}
vec4 taylorInvSqrt(vec4 r){return 1.79284291400159-0.85373472095314*r;}
float snoise(vec3 v){
  const vec2 C=vec2(1.0/6.0,1.0/3.0); const vec4 D=vec4(0.0,0.5,1.0,2.0);
  vec3 i=floor(v+dot(v,C.yyy)); vec3 x0=v-i+dot(i,C.xxx);
  vec3 g=step(x0.yzx,x0.xyz); vec3 l=1.0-g; vec3 i1=min(g.xyz,l.zxy); vec3 i2=max(g.xyz,l.zxy);
  vec3 x1=x0-i1+C.xxx; vec3 x2=x0-i2+C.yyy; vec3 x3=x0-D.yyy;
  i=mod289(i);
  vec4 p=permute(permute(permute(i.z+vec4(0.0,i1.z,i2.z,1.0))+i.y+vec4(0.0,i1.y,i2.y,1.0))+i.x+vec4(0.0,i1.x,i2.x,1.0));
  float n_=0.142857142857; vec3 ns=n_*D.wyz-D.xzx;
  vec4 j=p-49.0*floor(p*ns.z*ns.z); vec4 x_=floor(j*ns.z); vec4 y_=floor(j-7.0*x_);
  vec4 x=x_*ns.x+ns.yyyy; vec4 y=y_*ns.x+ns.yyyy; vec4 h=1.0-abs(x)-abs(y);
  vec4 b0=vec4(x.xy,y.xy); vec4 b1=vec4(x.zw,y.zw);
  vec4 s0=floor(b0)*2.0+1.0; vec4 s1=floor(b1)*2.0+1.0; vec4 sh=-step(h,vec4(0.0));
  vec4 a0=b0.xzyw+s0.xzyw*sh.xxyy; vec4 a1=b1.xzyw+s1.xzyw*sh.zzww;
  vec3 p0=vec3(a0.xy,h.x); vec3 p1=vec3(a0.zw,h.y); vec3 p2=vec3(a1.xy,h.z); vec3 p3=vec3(a1.zw,h.w);
  vec4 norm=taylorInvSqrt(vec4(dot(p0,p0),dot(p1,p1),dot(p2,p2),dot(p3,p3)));
  p0*=norm.x; p1*=norm.y; p2*=norm.z; p3*=norm.w;
  vec4 m=max(0.6-vec4(dot(x0,x0),dot(x1,x1),dot(x2,x2),dot(x3,x3)),0.0); m=m*m;
  return 42.0*dot(m*m,vec4(dot(p0,x0),dot(p1,x1),dot(p2,x2),dot(p3,x3)));
}
float fbm(vec3 p){ float a=0.5, s=0.0; for(int i=0;i<4;i++){ s+=a*snoise(p); p*=2.02; a*=0.5; } return s; }

vec3 palette(float t){
  t = fract(t);
  vec3 c = mix(uC0, uC1, smoothstep(0.0, 0.33, t));
  c = mix(c, uC2, smoothstep(0.33, 0.66, t));
  c = mix(c, uC3, smoothstep(0.66, 1.0, t));
  return c;
}

void main(){
  vec2 uv = (gl_FragCoord.xy - 0.5*uRes) / min(uRes.x, uRes.y);
  float t = uTime;
  float r = length(uv);
  float ang = atan(uv.y, uv.x);

  // silhouette: slow breathing + smooth, low-frequency liquid wobble driven by audio
  float breathe = 0.010 * sin(t * 1.1);
  vec3 dir = vec3(cos(ang), sin(ang), 0.0);
  float wob = snoise(dir * 1.1 + vec3(0.0, 0.0, t * (0.25 + 0.8 * uEnergy))) * (0.010 + 0.075 * uLevel)
            + snoise(dir * 2.3 + vec3(3.0, 1.0, t * (0.45 + 1.0 * uEnergy))) * (0.004 + 0.035 * uLevel);
  float radius = 0.285 + breathe + wob + 0.03 * uLevel;
  float d = r - radius;

  vec2 q = uv / max(radius, 0.001);
  float z = sqrt(max(0.0, 1.0 - dot(q, q)));           // sphere depth (1 = front)
  float sw = uSwirl * t;
  mat2 rot = mat2(cos(sw), -sin(sw), sin(sw), cos(sw));
  // refract: the far side of the glass is seen slightly magnified
  vec2 w = rot * (q * (0.75 + 0.25 * z));

  // dark tinted glass body
  vec3 col = mix(uC0 * 0.10, uC2 * 0.16, 0.5 + 0.5 * q.y) + uC1 * 0.05;
  // light theme: a pearly, luminous body the ribbons tint (instead of glow on black)
  vec3 lcol = mix(vec3(0.985, 0.99, 1.0), mix(uC1, uC2, 0.5) * 0.35 + 0.65, 0.25 + 0.45 * (1.0 - z));

  // luminous ribbons: warped ridged noise, one layer per palette colour
  vec3 ribbons = vec3(0.0);
  for (int i = 0; i < 3; i++) {
    float fi = float(i);
    // large, slow shapes: few elegant ribbons instead of a busy plasma
    vec3 p = vec3(w * (0.55 + 0.18 * fi), t * (0.08 + 0.28 * uEnergy) + fi * 3.3);
    float warp = snoise(p * 0.5 + vec3(fi * 1.9, 0.0, 0.0));
    float n = snoise(p + vec3(warp * 0.7, warp * 0.45, 0.0));
    float band = pow(1.0 - abs(n), 14.0 - 6.0 * uLevel - 3.0 * uEnergy);  // thin filament, fuller when loud
    float veil = pow(1.0 - abs(n), 3.0) * 0.18;                          // soft coloured haze around it
    vec3 c = fi < 0.5 ? uC0 : fi < 1.5 ? uC1 : uC2;
    ribbons += (band + veil) * c;
    // light: soft light volumes (wide veil) with only a hint of filament
    float cloud = smoothstep(0.35, 1.0, 1.0 - abs(n));
    lcol = mix(lcol, mix(c, vec3(1.0), 0.18), clamp(cloud * (0.42 + 0.25 * uLevel) + band * 0.28, 0.0, 0.8));
  }
  ribbons += uC3 * pow(max(0.0, snoise(vec3(w * 0.8, t * 0.2 + 9.0))), 2.0) * 0.25;
  col += ribbons * (0.3 + 0.7 * z) * (1.0 + 1.1 * uLevel);
  // soft volumetric core glow
  col += mix(uC1, uC3, 0.5) * pow(z, 3.0) * (0.10 + 0.35 * uLevel);
  col = mix(vec3(dot(col, vec3(0.299, 0.587, 0.114))), col, uSat);

  // glass lighting
  vec3 nrm = normalize(vec3(q, z + 0.001));
  vec3 L = normalize(vec3(-0.4, 0.6, 0.8));
  float fres = pow(1.0 - z, 3.0);
  float specSharp = pow(max(dot(reflect(-L, nrm), vec3(0.0, 0.0, 1.0)), 0.0), 90.0);
  float specSoft = pow(max(dot(reflect(-L, nrm), vec3(0.0, 0.0, 1.0)), 0.0), 9.0);
  col += fres * mix(uC1, uC2, 0.5 + 0.5 * sin(ang + t * 0.3)) * (0.9 + 0.8 * uLevel);
  col += vec3(1.0) * (specSharp * 0.35 + specSoft * 0.06);

  col = 1.0 - exp(-col * 1.35);                         // filmic tone map: no clipped hotspots
  lcol = mix(lcol, mix(uC0, uC2, 0.5) * 0.9, fres * (0.45 + 0.3 * uLevel));  // deeper rim reads as glass on white
  lcol += vec3(1.0) * (specSharp * 0.6 + specSoft * 0.12) + mix(uC1, uC3, 0.5) * pow(z, 3.0) * 0.12 * uLevel;
  lcol = mix(vec3(dot(lcol, vec3(0.299, 0.587, 0.114))), lcol, uSat);
  col = mix(col, clamp(lcol, 0.0, 1.0), uLight);

  float aa = 1.5 / min(uRes.x, uRes.y);
  float body = 1.0 - smoothstep(-aa, aa, d);

  // halo that always fades out before the canvas edge
  float halo = exp(-max(d, 0.0) * (15.0 - 6.0 * uLevel)) * (0.22 + 0.5 * uLevel) * (1.0 - body);
  halo *= smoothstep(0.5, 0.38, r);
  vec3 haloCol = mix(uC1, uC2, 0.5 + 0.5 * sin(ang * 2.0 + t * 0.4));

  vec3 outc = col * body + haloCol * halo;
  float alpha = clamp(body + halo, 0.0, 1.0);
  gl_FragColor = vec4(outc, alpha); // premultiplied
}
`

type Vec3 = [number, number, number]
interface Look { c: [Vec3, Vec3, Vec3, Vec3]; energy: number; swirl: number; sat: number }

const hex = (h: string): Vec3 => [1, 3, 5].map((i) => parseInt(h.slice(i, i + 2), 16) / 255) as Vec3

const LOOKS: Record<OrbState, Look> = {
  idle:      { c: [hex('#4c3bd6'), hex('#2f7de1'), hex('#8b5cf6'), hex('#22b8cf')], energy: 0.05, swirl: 0.04, sat: 0.7 },
  listening: { c: [hex('#2f9bff'), hex('#46e0e6'), hex('#8f6bff'), hex('#6ff2c2')], energy: 0.35, swirl: 0.10, sat: 1.0 },
  thinking:  { c: [hex('#8f6bff'), hex('#ff5fa2'), hex('#4ab8ff'), hex('#ffc861')], energy: 0.65, swirl: 0.45, sat: 1.0 },
  speaking:  { c: [hex('#ff4f9a'), hex('#9b6bff'), hex('#ff9f5a'), hex('#5f8bff')], energy: 0.45, swirl: 0.14, sat: 1.0 },
  muted:     { c: [hex('#4a4f63'), hex('#5c6275'), hex('#474b60'), hex('#3a3e52')], energy: 0.02, swirl: 0.02, sat: 0.2 },
  error:     { c: [hex('#ff4d4d'), hex('#ff8a4c'), hex('#d6336c'), hex('#ffb347')], energy: 0.3, swirl: 0.08, sat: 1.0 },
}

/** Light theme: a muted orb should read as quiet frosted silver, not a dark ball. */
const LIGHT_LOOKS: Partial<Record<OrbState, Look>> = {
  muted: { c: [hex('#b4b2e0'), hex('#c9d3ec'), hex('#c4b3e6'), hex('#b3d2e2')], energy: 0.02, swirl: 0.02, sat: 0.8 },
}

function compile(gl: WebGLRenderingContext, type: number, src: string) {
  const s = gl.createShader(type)!
  gl.shaderSource(s, src)
  gl.compileShader(s)
  if (!gl.getShaderParameter(s, gl.COMPILE_STATUS) && !gl.isContextLost())
    throw new Error(gl.getShaderInfoLog(s) || 'shader compile failed')
  return s
}

export function LiquidOrb({
  state,
  level = 0,
  levelSource,
  size = 240,
  className,
}: {
  state: OrbState
  level?: number
  /** read every frame (preferred: avoids React re-renders at audio rate) */
  levelSource?: () => number
  size?: number | string
  className?: string
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const target = useRef({ state, level, levelSource })
  target.current = { state, level, levelSource }

  useEffect(() => {
    const canvas = canvasRef.current!
    const gl = canvas.getContext('webgl', { premultipliedAlpha: true, alpha: true, antialias: false })
    if (!gl) return
    const prog = gl.createProgram()!
    gl.attachShader(prog, compile(gl, gl.VERTEX_SHADER, VERT))
    gl.attachShader(prog, compile(gl, gl.FRAGMENT_SHADER, FRAG))
    gl.linkProgram(prog)
    gl.useProgram(prog)
    const buf = gl.createBuffer()
    gl.bindBuffer(gl.ARRAY_BUFFER, buf)
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 3, -1, -1, 3]), gl.STATIC_DRAW)
    const loc = gl.getAttribLocation(prog, 'p')
    gl.enableVertexAttribArray(loc)
    gl.vertexAttribPointer(loc, 2, gl.FLOAT, false, 0, 0)
    gl.enable(gl.BLEND)
    gl.blendFunc(gl.ONE, gl.ONE_MINUS_SRC_ALPHA)
    const u = (n: string) => gl.getUniformLocation(prog, n)
    const uRes = u('uRes'), uTime = u('uTime'), uLevel = u('uLevel'), uEnergy = u('uEnergy')
    const uSwirl = u('uSwirl'), uSat = u('uSat'), uLightLoc = u('uLight'), uC = [u('uC0'), u('uC1'), u('uC2'), u('uC3')]

    // eased render state
    const st0 = target.current.state
    const cur: Look = structuredClone((document.documentElement.dataset.theme !== 'dark' && LIGHT_LOOKS[st0]) || LOOKS[st0])
    let lvl = 0
    let lightMix = document.documentElement.dataset.theme === 'dark' ? 0 : 1
    // user accent (Settings → Görünüm): calm states lean toward it; re-read ~1/s
    let accent: [Vec3, Vec3] | null = null
    let accentReadAt = 0
    const readAccent = () => {
      const st = document.documentElement.style
      const a = st.getPropertyValue('--accent').trim(), b = st.getPropertyValue('--accent-2').trim()
      accent = /^#[0-9a-f]{6}$/i.test(a) && /^#[0-9a-f]{6}$/i.test(b) ? [hex(a), hex(b)] : null
    }
    let raf = 0
    let last = performance.now()
    let time = Math.random() * 100
    let lastFrame = 0

    const resize = () => {
      const dpr = Math.min(window.devicePixelRatio || 1, 1.75)
      const w = Math.round(canvas.clientWidth * dpr), h = Math.round(canvas.clientHeight * dpr)
      if (canvas.width !== w || canvas.height !== h) {
        canvas.width = w
        canvas.height = h
        gl.viewport(0, 0, w, h)
      }
    }
    const ro = new ResizeObserver(resize)
    ro.observe(canvas)
    resize()

    const frame = (now: number) => {
      raf = requestAnimationFrame(frame)
      const { state: st, level: lvProp, levelSource: src } = target.current
      const lv = src ? src() : lvProp
      const idle = st === 'idle' || st === 'muted'
      if (idle && now - lastFrame < 50) return // 20 fps when calm
      lastFrame = now
      const dt = Math.min((now - last) / 1000, 0.1)
      last = now
      const lightGoal = document.documentElement.dataset.theme === 'dark' ? 0 : 1
      if (now - accentReadAt > 1000) { readAccent(); accentReadAt = now }
      let goal = (lightGoal && LIGHT_LOOKS[st]) || LOOKS[st]
      if (accent && (st === 'idle' || st === 'listening' || st === 'muted')) {
        const [a, b] = accent
        const w = st === 'muted' ? 0.35 : 0.6
        const mix = (c: Vec3, t: Vec3): Vec3 => [c[0] + (t[0] - c[0]) * w, c[1] + (t[1] - c[1]) * w, c[2] + (t[2] - c[2]) * w]
        goal = { ...goal, c: [mix(goal.c[0], a), mix(goal.c[1], b), mix(goal.c[2], a), mix(goal.c[3], b)] }
      }
      const k = 1 - Math.exp(-dt * 3.2) // ~300 ms ease between states
      cur.c.forEach((c, i) => c.forEach((v, j) => (c[j] = v + (goal.c[i][j] - v) * k)))
      cur.energy += (goal.energy - cur.energy) * k
      cur.swirl += (goal.swirl - cur.swirl) * k
      cur.sat += (goal.sat - cur.sat) * k
      // fast attack, slow release for a lively but smooth reaction
      const lt = Math.min(1, Math.max(0, lv))
      lvl += (lt - lvl) * (1 - Math.exp(-dt * (lt > lvl ? 18 : 4)))
      time += dt * (0.6 + cur.energy * 1.4 + lvl * 1.5)
      gl.uniform2f(uRes, canvas.width, canvas.height)
      gl.uniform1f(uTime, time)
      gl.uniform1f(uLevel, lvl)
      gl.uniform1f(uEnergy, cur.energy)
      gl.uniform1f(uSwirl, cur.swirl)
      gl.uniform1f(uSat, cur.sat)
      lightMix += (lightGoal - lightMix) * k
      gl.uniform1f(uLightLoc, lightMix)
      cur.c.forEach((c, i) => gl.uniform3f(uC[i], c[0], c[1], c[2]))
      gl.clearColor(0, 0, 0, 0)
      gl.clear(gl.COLOR_BUFFER_BIT)
      gl.drawArrays(gl.TRIANGLES, 0, 3)
    }

    // stop rendering while the page/window isn't on screen (hidden tab, or a
    // hidden/minimised native window — see lib/surface)
    const onVis = () => {
      cancelAnimationFrame(raf)
      if (isSurfaceActive()) {
        last = performance.now()
        raf = requestAnimationFrame(frame)
      }
    }
    document.addEventListener('visibilitychange', onVis)
    const offSurface = onSurfaceActive(onVis)
    if (isSurfaceActive()) raf = requestAnimationFrame(frame)
    return () => {
      cancelAnimationFrame(raf)
      offSurface()
      document.removeEventListener('visibilitychange', onVis)
      ro.disconnect()
      // free GPU objects but keep the context: React StrictMode re-runs this
      // effect on the same canvas, and a lost context cannot be revived.
      gl.deleteBuffer(buf)
      gl.deleteProgram(prog)
    }
  }, [])

  return (
    <canvas
      ref={canvasRef}
      className={className}
      style={{ width: size, height: size }}
      role="img"
      aria-label={`Jarvis: ${state}`}
    />
  )
}
