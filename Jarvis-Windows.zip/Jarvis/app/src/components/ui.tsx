import clsx from 'clsx'
import { Loader2 } from 'lucide-react'
import type { ButtonHTMLAttributes, InputHTMLAttributes, ReactNode, SelectHTMLAttributes } from 'react'

export function Button({
  variant = 'secondary',
  size = 'md',
  loading,
  className,
  children,
  disabled,
  ...rest
}: ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: 'primary' | 'secondary' | 'ghost' | 'danger'
  size?: 'sm' | 'md'
  loading?: boolean
}) {
  return (
    <button
      {...rest}
      disabled={disabled || loading}
      className={clsx(
        'inline-flex items-center justify-center gap-2 rounded-full font-normal whitespace-nowrap transition-all duration-200',
        'disabled:cursor-not-allowed disabled:opacity-40 active:scale-[0.97]',
        size === 'sm' ? 'h-8 px-3 text-[12.5px]' : 'h-10 px-5 text-[14px]',
        variant === 'primary' && 'bg-fg text-bg hover:opacity-90',
        variant === 'secondary' && 'bg-fill text-fg ring-1 ring-line ring-inset hover:bg-fill-strong',
        variant === 'ghost' && 'text-fg-muted hover:bg-fill-strong hover:text-fg',
        variant === 'danger' && 'text-fg-subtle hover:bg-red-500/10 hover:text-red-600 dark:text-red-300',
        className,
      )}
    >
      {loading && <Loader2 className="size-4 animate-spin" />}
      {children}
    </button>
  )
}

export function Card({ className, children }: { className?: string; children: ReactNode }) {
  return <div className={clsx('panel', className)}>{children}</div>
}

export function Toggle({
  checked,
  onChange,
  label,
  disabled,
}: {
  checked: boolean
  onChange: (v: boolean) => void
  label?: string
  disabled?: boolean
}) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      aria-label={label}
      disabled={disabled}
      onClick={() => onChange(!checked)}
      className={clsx(
        'relative h-[26px] w-[46px] shrink-0 rounded-full transition-all duration-300 disabled:opacity-40',
        checked
          ? 'bg-gradient-to-r from-[#8f6bff] to-[#46b8f0] shadow-[0_0_18px_-4px_#8f6bff]'
          : 'bg-fill ring-1 ring-line ring-inset',
      )}
    >
      <span
        className={clsx(
          'absolute top-[3px] left-[3px] size-5 rounded-full bg-white shadow-md transition-transform duration-300 ease-[cubic-bezier(.22,1,.36,1)]',
          checked && 'translate-x-5',
        )}
      />
    </button>
  )
}

export function Badge({
  tone = 'neutral',
  children,
}: {
  tone?: 'neutral' | 'ok' | 'warn' | 'danger' | 'accent'
  children: ReactNode
}) {
  return (
    <span
      className={clsx(
        'inline-flex items-center gap-1 rounded-full px-2.5 py-0.5 text-[11px] whitespace-nowrap',
        tone === 'neutral' && 'bg-fill text-fg-muted',
        tone === 'ok' && 'bg-emerald-500/10 text-emerald-700 dark:text-emerald-300',
        tone === 'warn' && 'bg-amber-500/12 text-amber-700 dark:text-amber-200',
        tone === 'danger' && 'bg-red-500/10 text-red-600 dark:text-red-300',
        tone === 'accent' && 'bg-accent-soft text-accent',
      )}
    >
      {children}
    </span>
  )
}

// no width here: callers decide (w-full / flex-1 / w-64)
const fieldClass =
  'h-10 rounded-xl bg-fill px-3.5 text-[14px] text-fg ring-1 ring-line ring-inset transition placeholder:text-fg-subtle focus:bg-surface-2 focus:ring-accent/50 focus:outline-none'

export function Input(props: InputHTMLAttributes<HTMLInputElement>) {
  return <input {...props} className={clsx(fieldClass, props.className)} />
}

export function Select(props: SelectHTMLAttributes<HTMLSelectElement>) {
  return <select {...props} className={clsx(fieldClass, 'pr-8 [&>option]:bg-bg', props.className)} />
}

export function PageHeader({ title, subtitle, actions }: { title: string; subtitle?: string; actions?: ReactNode }) {
  return (
    <header className="flex flex-wrap items-end justify-between gap-4 pt-4 pb-8">
      <div>
        <h1 className="font-display text-[30px] font-light tracking-tight">{title}</h1>
        {subtitle && <p className="mt-1.5 max-w-xl text-[14px] leading-relaxed text-fg-muted">{subtitle}</p>}
      </div>
      {actions}
    </header>
  )
}

export function SectionTitle({ children }: { children: ReactNode }) {
  return <h2 className="mb-3 px-1 text-[13px] text-fg-muted">{children}</h2>
}

export function Row({ title, description, children }: { title: string; description?: string; children: ReactNode }) {
  return (
    <div className="flex flex-wrap items-center justify-between gap-x-6 gap-y-3 px-5 py-4">
      <div className="min-w-0 flex-1 basis-60">
        <div className="text-[14px]">{title}</div>
        {description && <div className="mt-0.5 text-[12.5px] leading-relaxed text-fg-muted">{description}</div>}
      </div>
      <div className="shrink-0">{children}</div>
    </div>
  )
}
