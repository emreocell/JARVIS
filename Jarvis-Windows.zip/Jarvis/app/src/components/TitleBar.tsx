import { Minus, Moon, Square, Sun, X } from 'lucide-react'
import { client } from '../lib/rpc'
import { useThemeMode } from '../lib/theme'

type Api = { minimize(): void; toggle_maximize(): void; close(): void }
const api = (): Api | undefined => (window as unknown as { pywebview?: { api: Api } }).pywebview?.api

/**
 * Custom title bar for the frameless native window. The whole bar is a drag
 * region (pywebview-drag-region); buttons opt out of dragging.
 */
export function TitleBar() {
  const native = typeof window !== 'undefined' && 'pywebview' in window
  return (
    <div className="pywebview-drag-region relative z-20 flex h-10 shrink-0 items-center justify-between pr-1 pl-4 select-none">
      <div className="pointer-events-none flex items-center gap-2 text-[12.5px] tracking-wide text-fg-muted">
        <span className="size-2 rounded-full bg-gradient-to-br from-[#8f6bff] to-[#46e0e6] shadow-[0_0_10px_#8f6bff]" />
        Jarvis
      </div>
      <div className="flex items-center">
        <ThemeToggle />
      {native && (
        <div className="flex">
          {[
            { icon: Minus, label: 'Küçült', on: () => api()?.minimize() },
            { icon: Square, label: 'Büyüt', on: () => api()?.toggle_maximize() },
            { icon: X, label: 'Kapat (arka planda çalışmaya devam eder)', on: () => api()?.close(), danger: true },
          ].map(({ icon: Icon, label, on, danger }) => (
            <button key={label} onClick={on} aria-label={label} title={label}
              className={`grid h-8 w-11 place-items-center rounded-lg text-fg-muted transition-colors ${
                danger ? 'hover:bg-red-500/80 hover:text-white' : 'hover:bg-fill-strong hover:text-fg'}`}>
              <Icon className={Icon === Square ? 'size-3' : 'size-3.5'} strokeWidth={1.75} />
            </button>
          ))}
        </div>
      )}
      </div>
    </div>
  )
}

function ThemeToggle() {
  const mode = useThemeMode()
  const next = mode === 'dark' ? 'light' : 'dark'
  return (
    <button
      onClick={() => client.call('config.patch', { patch: { ui: { theme: next } } }).catch(() => {
        document.documentElement.dataset.theme = next // core offline: preview only
      })}
      aria-label={mode === 'dark' ? 'Açık temaya geç' : 'Koyu temaya geç'}
      title={mode === 'dark' ? 'Açık tema' : 'Koyu tema'}
      className="mr-1 grid h-8 w-9 place-items-center rounded-lg text-fg-muted transition-colors hover:bg-fill-strong hover:text-fg"
    >
      {mode === 'dark' ? <Sun className="size-[15px]" strokeWidth={1.75} /> : <Moon className="size-[15px]" strokeWidth={1.75} />}
    </button>
  )
}
