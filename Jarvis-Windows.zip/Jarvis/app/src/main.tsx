import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import App from './App.tsx'
import { CommandBar } from './pages/CommandBar.tsx'
import { Overlay } from './pages/Overlay.tsx'
import { OrbLab } from './pages/OrbLab.tsx'

// one bundle, four surfaces: main window, floating orb overlay, command bar, dev orb lab
const route = window.location.hash
const Root = route === '#overlay' ? Overlay : route === '#command' ? CommandBar : route === '#orb-lab' ? OrbLab : App
if (/Mac/i.test(navigator.platform || navigator.userAgent)) document.documentElement.classList.add('mac')
if (route === '#overlay') document.documentElement.classList.add('overlay')
if (route === '#command') document.documentElement.classList.add('command')

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <Root />
  </StrictMode>,
)
