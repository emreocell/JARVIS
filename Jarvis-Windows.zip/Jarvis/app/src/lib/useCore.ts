import { useEffect, useSyncExternalStore } from 'react'
import { client, type ConnectionStatus, type CoreEvent } from './rpc'
import type { Snapshot } from './types'

/**
 * Single source of UI truth: the last snapshot from the core, patched in
 * place by events. Components subscribe with useCore().
 */
let snapshot: Snapshot | null = null
const listeners = new Set<() => void>()
const notify = () => listeners.forEach((l) => l())

client.onSnapshot((s) => {
  snapshot = s as unknown as Snapshot
  notify()
})

client.onEvent((e: CoreEvent) => {
  if (!snapshot) return
  switch (e.topic) {
    case 'state.changed':
      snapshot = { ...snapshot, state: { ...snapshot.state, ...(e.data as object) } }
      break
    case 'config.changed':
      // cheap and always correct: refetch the snapshot
      void client.call<Snapshot>('app.snapshot').then((s) => {
        snapshot = s
        notify()
      })
      return
    case 'secrets.changed':
      snapshot = { ...snapshot, secrets: e.data.secrets as Snapshot['secrets'] }
      break
    case 'voice.wake_rejected':
      snapshot = {
        ...snapshot,
        wake_rejected: (e.data.phrases as Record<string, string>) ?? {},
        wake_approx: (e.data.approx as Record<string, string>) ?? {},
      }
      break
    case 'hotkeys.status':
      snapshot = { ...snapshot, hotkeys_failed: (e.data.failed as Record<string, string>) ?? {} }
      break
    case 'providers.quota':
      snapshot = {
        ...snapshot,
        providers: { ...snapshot.providers, quota: e.data.quota as Snapshot['providers']['quota'] },
      }
      break
    default:
      return
  }
  notify()
})

client.onStatus(notify)

function subscribe(l: () => void) {
  listeners.add(l)
  return () => void listeners.delete(l)
}

export function useCore(): { snapshot: Snapshot | null; status: ConnectionStatus } {
  const snap = useSyncExternalStore(subscribe, () => snapshot)
  const status = useSyncExternalStore(subscribe, () => client.status)
  return { snapshot: snap, status }
}

export function useCoreEvent(topic: string, handler: (e: CoreEvent) => void) {
  useEffect(
    () =>
      client.onEvent((e) => {
        if (e.topic === topic || (topic.endsWith('.*') && e.topic.startsWith(topic.slice(0, -1))))
          handler(e)
      }),
    [topic, handler],
  )
}
