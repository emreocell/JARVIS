/**
 * Is this window actually on screen? WebView2 inside WinForms keeps
 * reporting visibilityState 'visible' for hidden/minimised windows, so the
 * native shell tells us via window.__jarvisSetActive(bool). While inactive,
 * render loops stop and CSS animations pause (near-zero idle load).
 */
type Listener = (active: boolean) => void

let active = true
const listeners = new Set<Listener>()

export function isSurfaceActive() {
  return active && !document.hidden
}

export function onSurfaceActive(fn: Listener): () => void {
  listeners.add(fn)
  return () => void listeners.delete(fn)
}

;(window as unknown as { __jarvisSetActive: (v: boolean) => void }).__jarvisSetActive = (v: boolean) => {
  if (v === active) return
  active = v
  document.documentElement.classList.toggle('surface-paused', !v)
  listeners.forEach((l) => l(v))
}
