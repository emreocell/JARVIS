export type VoiceState = 'idle' | 'listening' | 'thinking' | 'speaking' | 'muted' | 'error'

export interface WakeWord {
  phrase: string
  engine: 'openwakeword' | 'vosk' | 'porcupine'
  sensitivity: number
  enabled: boolean
}

export interface ProviderConfig {
  id: string
  type: 'openai_compatible' | 'gemini' | 'typesafe'
  label: string
  base_url: string | null
  keys: string[]
  models: { id: string; caps: string[] }[]
  quota_profile: string | null
  headers: Record<string, string>
  enabled: boolean
}

export interface RouteTarget {
  provider: string
  model: string
}

export interface AppConfig {
  version: number
  assistant: { name: string; user_name: string; user_rules: string; location?: string }
  voice: {
    enabled: boolean
    mode: 'live' | 'cascade'
    echo_profile: 'full_duplex' | 'half_duplex' | 'key_only' | 'auto'
    echo_text_filter: boolean
    wake_words: WakeWord[]
    follow_up_seconds: number
    session_idle_seconds: number
    push_to_talk_hotkey: string
    language: string
    live_model: string
    voice_name: string
    input_device: string | null
    output_device: string | null
  }
  providers: ProviderConfig[]
  routes: Record<string, RouteTarget[]>
  features: Record<string, boolean | string>
  privacy: { privacy_mode: boolean; excluded_apps: string[] }
  integrations?: { spotify_client_id: string }
  remote?: { telegram_allowed_ids: number[]; forward_questions: boolean; forward_reminders: boolean }
  ui: {
    theme: 'dark' | 'light' | 'system'
    accent: string
    locale: 'tr' | 'en'
    command_bar_hotkey: string
    start_with_windows: boolean
  }
}

export interface SecretInfo {
  name: string
  ref: string
  masked: string
}

export interface QuotaRow {
  provider: string
  key: string
  model: string
  rpm_used: number
  rpm_limit: number | null
  rpd_used: number
  rpd_limit: number | null
  tpm_used: number
  tpm_limit: number | null
  cooldown_s: number
}

export interface Snapshot {
  version: string
  uptime_s: number
  state: { voice: VoiceState; [k: string]: unknown }
  config: AppConfig
  secrets: SecretInfo[]
  providers: { stats: Record<string, { ok: number; failed: number; latency_ms: number }>; quota: QuotaRow[] }
  wake_rejected?: Record<string, string>
  wake_approx?: Record<string, string>
  hotkeys_failed?: Record<string, string>
}

export interface JsonSchema {
  type?: string
  title?: string
  description?: string
  enum?: string[]
  default?: unknown
  minimum?: number
  maximum?: number
  properties?: Record<string, JsonSchema>
  $ref?: string
  allOf?: JsonSchema[]
  anyOf?: JsonSchema[]
  items?: JsonSchema
  $defs?: Record<string, JsonSchema>
}
