import { client } from './rpc'

/**
 * Latest audio level from the core (mic while listening, speaker while
 * speaking), readable at animation-frame rate without React re-renders.
 * The core sends ~10 updates/s only while Jarvis is active.
 */
let mic = 0
let out = 0
let at = 0

client.onEvent((e) => {
  if (e.topic === 'voice.level') {
    mic = Number(e.data.mic) || 0
    out = Number(e.data.out) || 0
    at = performance.now()
  } else if (e.topic === 'voice.state' && (e.data.state === 'idle' || e.data.state === 'muted')) {
    mic = out = 0
  }
})

/** 0..1; decays to 0 if updates stop arriving. */
export function currentLevel(): number {
  const age = performance.now() - at
  const decay = age > 250 ? Math.max(0, 1 - (age - 250) / 500) : 1
  return Math.max(mic, out) * decay
}
