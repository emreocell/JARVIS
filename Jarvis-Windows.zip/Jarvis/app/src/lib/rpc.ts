/**
 * WebSocket client for the Jarvis core.
 *
 * Handles discovery (runtime.json), auth, request/response correlation,
 * event fan-out and reconnection with backoff. After every (re)connect the
 * core sends a full snapshot, so UI state never drifts.
 */

export type ConnectionStatus = 'connecting' | 'online' | 'offline'

export interface CoreEvent {
  topic: string
  data: Record<string, unknown>
}

type Pending = { resolve: (v: unknown) => void; reject: (e: Error) => void; timer: number }
type Listener<T> = (value: T) => void

export class RpcError extends Error {
  details?: unknown
  constructor(message: string, details?: unknown) {
    super(message)
    this.details = details
  }
}

type Runtime = { port: number; token: string }

async function discover(): Promise<Runtime | null> {
  // native window: ask the Python shell directly (window.pywebview.api)
  const pv = (window as unknown as { pywebview?: { api?: { runtime?: () => Promise<Runtime> } } }).pywebview
  if (pv?.api?.runtime) {
    try {
      const info = await pv.api.runtime()
      return typeof info?.port === 'number' ? info : null
    } catch {
      return null
    }
  }
  if ('pywebview' in window) return null // bridge not injected yet; retry shortly
  try {
    const res = await fetch('/__jarvis/runtime', { cache: 'no-store' })
    if (!res.ok) return null
    const info = await res.json()
    return typeof info.port === 'number' && typeof info.token === 'string' ? info : null
  } catch {
    return null
  }
}

export class JarvisClient {
  status: ConnectionStatus = 'connecting'
  snapshot: Record<string, unknown> | null = null

  private ws: WebSocket | null = null
  private nextId = 1
  private pending = new Map<number, Pending>()
  private statusListeners = new Set<Listener<ConnectionStatus>>()
  private snapshotListeners = new Set<Listener<Record<string, unknown>>>()
  private eventListeners = new Set<Listener<CoreEvent>>()
  private retry = 0
  private stopped = false

  // Bumped on every start/stop so stale async connects (React StrictMode
  // mounts twice in dev) can tell they were superseded.
  private generation = 0

  start() {
    this.stopped = false
    const gen = ++this.generation
    void this.connect(gen)
  }

  stop() {
    this.stopped = true
    this.generation++
    this.ws?.close()
  }

  private setStatus(status: ConnectionStatus) {
    if (this.status === status) return
    this.status = status
    this.statusListeners.forEach((l) => l(status))
  }

  private scheduleReconnect(gen: number) {
    if (this.stopped || gen !== this.generation) return
    const delay = Math.min(10_000, 500 * 2 ** this.retry++)
    window.setTimeout(() => void this.connect(gen), delay)
  }

  private async connect(gen: number) {
    if (gen !== this.generation) return
    this.setStatus(this.retry === 0 ? 'connecting' : 'offline')
    const info = await discover()
    if (gen !== this.generation) return
    if (!info) {
      this.setStatus('offline')
      this.scheduleReconnect(gen)
      return
    }
    const ws = new WebSocket(`ws://127.0.0.1:${info.port}`)
    this.ws = ws
    ws.onopen = () => ws.send(JSON.stringify({ type: 'auth', token: info.token }))
    ws.onmessage = (ev) => this.onMessage(ev.data as string)
    ws.onclose = () => {
      if (this.ws === ws) this.ws = null
      if (gen !== this.generation) return
      this.failPending('connection closed')
      this.setStatus('offline')
      this.scheduleReconnect(gen)
    }
  }

  private onMessage(raw: string) {
    const msg = JSON.parse(raw)
    if (msg.type === 'snapshot') {
      this.retry = 0
      this.snapshot = msg.data
      this.setStatus('online')
      this.snapshotListeners.forEach((l) => l(msg.data))
      return
    }
    if (msg.type === 'event') {
      this.eventListeners.forEach((l) => l({ topic: msg.topic, data: msg.data }))
      return
    }
    const p = this.pending.get(msg.id)
    if (!p) return
    this.pending.delete(msg.id)
    window.clearTimeout(p.timer)
    if (msg.error) p.reject(new RpcError(msg.error.message, msg.error.details))
    else p.resolve(msg.result)
  }

  private failPending(reason: string) {
    for (const [id, p] of this.pending) {
      window.clearTimeout(p.timer)
      p.reject(new RpcError(reason))
      this.pending.delete(id)
    }
  }

  call<T = unknown>(method: string, params: Record<string, unknown> = {}, timeoutMs = 60_000): Promise<T> {
    const ws = this.ws
    if (!ws || ws.readyState !== WebSocket.OPEN || this.status !== 'online') {
      return Promise.reject(new RpcError('Çekirdeğe bağlı değil'))
    }
    const id = this.nextId++
    return new Promise<T>((resolve, reject) => {
      const timer = window.setTimeout(() => {
        this.pending.delete(id)
        reject(new RpcError('Zaman aşımı'))
      }, timeoutMs)
      this.pending.set(id, { resolve: resolve as (v: unknown) => void, reject, timer })
      ws.send(JSON.stringify({ id, method, params }))
    })
  }

  onStatus(l: Listener<ConnectionStatus>) {
    this.statusListeners.add(l)
    return () => void this.statusListeners.delete(l)
  }

  onSnapshot(l: Listener<Record<string, unknown>>) {
    this.snapshotListeners.add(l)
    return () => void this.snapshotListeners.delete(l)
  }

  onEvent(l: Listener<CoreEvent>) {
    this.eventListeners.add(l)
    return () => void this.eventListeners.delete(l)
  }
}

export const client = new JarvisClient()
