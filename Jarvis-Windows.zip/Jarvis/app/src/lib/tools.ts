import { useEffect, useState } from 'react'
import { client } from './rpc'
import { useCore } from './useCore'

export interface ToolInfo {
  name: string
  title?: string
  icon?: string
  say?: string
  skill?: string
  category?: string
  category_title?: string
  category_icon?: string
  risk?: string
  description?: string
  available: boolean
  reason?: string
}

let cache: ToolInfo[] | null = null
let inflight: Promise<ToolInfo[]> | null = null

/** The core's tool catalogue (titles, icons, examples), fetched once. */
export function useToolCatalog(): ToolInfo[] {
  const { status } = useCore()
  const [tools, setTools] = useState<ToolInfo[]>(cache ?? [])
  useEffect(() => {
    if (status !== 'online' || cache) return
    inflight ??= client.call<ToolInfo[]>('tools.list').then((t) => (cache = t))
    void inflight.then(setTools).catch(() => { inflight = null })
  }, [status])
  return tools
}

export const RISK_LABEL: Record<string, { label: string; tone: 'neutral' | 'ok' | 'warn' | 'danger' | 'accent' }> = {
  read: { label: 'Sadece okur', tone: 'neutral' },
  low: { label: 'Serbest', tone: 'ok' },
  write: { label: 'Bir kez sorar', tone: 'accent' },
  send: { label: 'Her seferinde sorar', tone: 'warn' },
  destructive: { label: 'Her zaman onaylatır', tone: 'danger' },
}
