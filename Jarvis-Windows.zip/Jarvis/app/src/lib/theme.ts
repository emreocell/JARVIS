import { useEffect, useSyncExternalStore } from 'react'
import { useCore } from './useCore'

/** Current resolved theme ('light' | 'dark'), following <html data-theme>. */
function subscribe(cb: () => void) {
  const obs = new MutationObserver(cb)
  obs.observe(document.documentElement, { attributes: true, attributeFilter: ['data-theme'] })
  return () => obs.disconnect()
}

export function useThemeMode(): 'light' | 'dark' {
  return useSyncExternalStore(subscribe, () =>
    document.documentElement.dataset.theme === 'dark' ? 'dark' : 'light',
  )
}

/** Resolve config.ui.theme (light/dark/system) onto <html data-theme>. */
export function useApplyTheme() {
  const theme = useCore().snapshot?.config.ui.theme ?? 'system'
  useApplyAccent()
  useEffect(() => {
    const media = window.matchMedia('(prefers-color-scheme: light)')
    const apply = () => {
      const light = theme === 'light' || (theme === 'system' && media.matches)
      document.documentElement.dataset.theme = light ? 'light' : 'dark'
    }
    apply()
    media.addEventListener('change', apply)
    return () => media.removeEventListener('change', apply)
  }, [theme])
}

/** Curated accent palettes (accent, secondary). The first is the built-in default. */
export const ACCENTS: { id: string; name: string; a: string; b: string }[] = [
  { id: '#5b6cff', name: 'İndigo', a: '#5b6cff', b: '#9b7bff' },
  { id: '#8b5cf6', name: 'Mor', a: '#8b5cf6', b: '#d946ef' },
  { id: '#0ea5e9', name: 'Okyanus', a: '#0ea5e9', b: '#22d3ee' },
  { id: '#10b981', name: 'Zümrüt', a: '#10b981', b: '#84cc16' },
  { id: '#f97316', name: 'Gün batımı', a: '#f97316', b: '#f43f5e' },
  { id: '#e11d48', name: 'Gül', a: '#e11d48', b: '#f472b6' },
]

/** Apply config.ui.accent as CSS variables (legacy default = built-in palette). */
export function useApplyAccent() {
  const accent = (useCore().snapshot?.config.ui as { accent?: string } | undefined)?.accent
  useEffect(() => {
    const root = document.documentElement.style
    const p = ACCENTS.find((x) => x.id === accent)
    if (!accent || accent === '#7c5cff' || !p || p === ACCENTS[0]) {
      root.removeProperty('--accent')
      root.removeProperty('--accent-2')
      return
    }
    root.setProperty('--accent', p.a)
    root.setProperty('--accent-2', p.b)
  }, [accent])
}
