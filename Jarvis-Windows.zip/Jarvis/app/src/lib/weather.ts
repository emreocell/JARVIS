import { Cloud, CloudDrizzle, CloudFog, CloudLightning, CloudRain, CloudSnow, CloudSun, Moon, Sun, type LucideIcon } from 'lucide-react'
import { useEffect, useState } from 'react'
import { client } from './rpc'
import { useCore } from './useCore'

export interface Weather {
  place: string
  now: { temp: number; feels_like: number; humidity: number; wind_kmh: number; summary: string; code: number; is_day: boolean }
  days: { date: string; label: string; summary: string; code: number; max: number; min: number; rain_chance: number | null; sunrise: string; sunset: string }[]
  hours: { time: string; temp: number; rain_chance: number; code: number }[]
}

export function weatherIcon(code: number, day = true): LucideIcon {
  if (code === 0) return day ? Sun : Moon
  if (code <= 2) return day ? CloudSun : Cloud
  if (code === 3) return Cloud
  if (code === 45 || code === 48) return CloudFog
  if (code >= 51 && code <= 57) return CloudDrizzle
  if ((code >= 61 && code <= 67) || (code >= 80 && code <= 82)) return CloudRain
  if ((code >= 71 && code <= 77) || code === 85 || code === 86) return CloudSnow
  if (code >= 95) return CloudLightning
  return Cloud
}

// one fetch shared by every component on screen; refreshed every 15 min
let cache: { at: number; data: Weather | null; error: string | null } | null = null
let inflight: Promise<void> | null = null
const subs = new Set<() => void>()

async function refresh() {
  inflight ??= client.call<Weather & { error?: string }>('tools.run', { name: 'get_weather', args: { days: 3 } })
    .then((r) => { cache = { at: Date.now(), data: r.error ? null : r, error: r.error ?? null } })
    .catch((e) => { cache = { at: Date.now(), data: null, error: String(e) } })
    .finally(() => { inflight = null; subs.forEach((s) => s()) })
  return inflight
}

export function useWeather(): { weather: Weather | null; error: string | null } {
  const { status, snapshot } = useCore()
  const location = snapshot?.config.assistant?.location ?? ''
  const [, bump] = useState(0)
  useEffect(() => {
    const s = () => bump((n) => n + 1)
    subs.add(s)
    return () => void subs.delete(s)
  }, [])
  useEffect(() => {
    if (status !== 'online') return
    cache = cache && Date.now() - cache.at < 15 * 60_000 ? cache : null
    if (!cache) void refresh()
    const t = window.setInterval(() => void refresh(), 15 * 60_000)
    return () => window.clearInterval(t)
  }, [status])
  // the user changed the city in settings
  useEffect(() => { if (status === 'online' && cache) void refresh() }, [location]) // eslint-disable-line react-hooks/exhaustive-deps
  return { weather: cache?.data ?? null, error: cache?.error ?? null }
}
