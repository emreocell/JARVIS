import { useSyncExternalStore } from 'react'
import { client } from './rpc'

export interface Activity {
  id: string
  tool: string
  title?: string
  steps?: { action: string; thought: string }[]
  status: 'running' | 'ok' | 'error'
  started: number
  ms?: number
  result?: string
  background?: boolean
}

export interface Approval {
  token: string
  tool: string
  summary: string
  risk: string
}

let activities: Activity[] = []
let approvals: Approval[] = []
const listeners = new Set<() => void>()
const notify = () => listeners.forEach((l) => l())
let seq = 0

client.onEvent((e) => {
  const d = e.data as Record<string, unknown>
  switch (e.topic) {
    case 'tool.started':
      activities = [
        { id: String(d.call_id || `t${++seq}`), tool: String(d.tool), title: d.title ? String(d.title) : undefined,
          status: 'running' as const, started: Date.now() },
        ...activities,
      ].slice(0, 100)
      break
    case 'tool.finished': {
      const id = String(d.call_id || '')
      const idx = activities.findIndex((a) => a.status === 'running' && a.tool === d.tool && (!id || a.id === id))
      const done: Partial<Activity> = {
        status: d.ok ? 'ok' : 'error', ms: Number(d.ms), result: String(d.result ?? ''), background: Boolean(d.background),
      }
      activities = idx >= 0
        ? activities.map((a, i) => (i === idx ? { ...a, ...done } : a))
        : [{ id: `t${++seq}`, tool: String(d.tool), started: Date.now(), ...done } as Activity, ...activities]
      break
    }
    case 'browser.step': {
      // live progress of the browser agent: attach to the newest running browser task
      const idx = activities.findIndex((a) => a.status === 'running' && (a.tool === 'browser_task' || a.tool === 'ask_web_ai'))
      if (idx < 0) return
      const step = { action: String(d.action), thought: String(d.thought ?? '') }
      activities = activities.map((a, i) => (i === idx ? { ...a, steps: [...(a.steps ?? []), step].slice(-12) } : a))
      break
    }
    case 'approval.requested':
      approvals = [...approvals, { token: String(d.token), tool: String(d.tool), summary: String(d.summary), risk: String(d.risk) }]
      break
    case 'approval.resolved':
      approvals = approvals.filter((a) => a.token !== d.token)
      break
    default:
      return
  }
  notify()
})

function subscribe(l: () => void) {
  listeners.add(l)
  return () => void listeners.delete(l)
}

export const useActivities = () => useSyncExternalStore(subscribe, () => activities)
export const useApprovals = () => useSyncExternalStore(subscribe, () => approvals)

export function dismissApproval(token: string) {
  approvals = approvals.filter((a) => a.token !== token)
  notify()
}
