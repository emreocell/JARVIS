import pytest

from jarvis.skills.media import _videos
from jarvis.skills.text import clean_name, norm, similarity


def test_norm_turkish():
    assert norm("Görev Yöneticisi") == "gorev yoneticisi"
    assert norm("  İNDİRİLENLER! ") == "indirilenler"


@pytest.mark.parametrize("spoken,expected", [("spotify'ı", "spotify"), ("WhatsApp'tan", "whatsapp"),
                                             ("Ahmet'e", "ahmet")])
def test_clean_name_strips_apostrophe_suffix(spoken, expected):
    assert clean_name(spoken) == expected


def test_similarity_ranking():
    assert similarity("opera", "Opera GX tarayıcı") > similarity("opera", "Kamera")
    assert similarity("hesap makinesi", "Hesap Makinesi") == 1.0
    assert similarity("calculator", "CapCut") < 0.6
    assert similarity("vs code", "Visual Studio Code") < 0.6  # needs the alias table


def test_youtube_parser_skips_non_video_renderers():
    data = {"contents": [
        {"adSlotRenderer": {"videoId": "AD"}},
        {"reelShelfRenderer": {"items": [{"reelItemRenderer": {"videoId": "SHORT"}}]}},
        {"videoRenderer": {"videoId": "abc123def45", "title": {"runs": [{"text": "Şarkı"}]},
                           "ownerText": {"runs": [{"text": "Kanal"}]}, "lengthText": {"simpleText": "3:21"}}},
    ]}
    out: list = []
    _videos(data, out, 5)
    assert out == [{"id": "abc123def45", "title": "Şarkı", "channel": "Kanal", "length": "3:21"}]
