from datetime import datetime

from jarvis.journal.day import build_blocks
from jarvis.journal.store import JournalStore, Span


def t(h, m):
    return datetime(2026, 9, 26, h, m).timestamp()


def span(i, a, b, app, title, project=None):
    return Span(i, a, b, app, title, project)


def test_blocks_group_project_with_short_detours():
    spans = [
        span(1, t(9, 32), t(10, 0), "VS Code", "hero.tsx - webioo-growth - Visual Studio Code", "webioo-growth"),
        span(2, t(10, 0), t(10, 6), "Opera GX", "Tailwind docs - Opera"),               # detour
        span(3, t(10, 6), t(10, 48), "VS Code", "ads.php - webioo-growth - Visual Studio Code", "webioo-growth"),
        span(4, t(11, 3), t(11, 42), "VS Code", "pay.py - wpanel-2 - Visual Studio Code", "wpanel-2"),
        span(5, t(12, 0), t(12, 1), "Spotify", "x"),                                      # too short
    ]
    blocks = build_blocks(spans)
    assert [b["project"] for b in blocks] == ["webioo-growth", "wpanel-2"]
    first = blocks[0]
    assert (first["start"], first["end"]) == ("09:32", "10:48")
    assert "Opera GX" in first["apps"] and set(first["files"]) == {"hero.tsx", "ads.php"}


def test_store_roundtrip(tmp_path):
    s = JournalStore(tmp_path / "a.sqlite3")
    sid = s.open_span(100.0, "VS Code", "t", "p")
    s.extend(sid, 400.0)
    s.event("jarvis", "not alındı", ts=200.0)
    assert s.spans(0, 1000)[0].seconds == 300
    assert s.events(0, 1000)[0][2] == "not alındı"
