from jarvis.notifications.watcher import Notice, NotificationStore, app_name, filetime_to_unix, heuristic, parse_payload


def test_payload_and_app_names():
    xml = b'<toast><visual><binding template="ToastGeneric"><text>Ahmet</text><text>Yar\xc4\xb1n gel</text></binding></visual></toast>'
    assert parse_payload(xml) == ("Ahmet", "Yarın gel")
    assert app_name("5319275A.WhatsAppDesktop_cv1g1gvanyjgm!App") == "WhatsApp"
    assert app_name("Claude_pzs8sxrjxfjjc!Claude") == "Claude"
    assert round(filetime_to_unix(134348498796562045)) > 1_700_000_000


def test_heuristics():
    assert heuristic(Notice(1, 0, "GitHub", "CI failed", "")) == "onemli"
    assert heuristic(Notice(2, 0, "WhatsApp", "Ahmet", "selam")) == "normal"
    assert heuristic(Notice(3, 0, "Edge", "İndirme tamamlandı", "")) == "onemsiz"


def test_store(tmp_path):
    s = NotificationStore(tmp_path / "n.sqlite3")
    s.add([Notice(10, 100.0, "WhatsApp", "Ahmet", "selam", "normal")])
    s.add([Notice(10, 100.0, "WhatsApp", "Ahmet", "selam", "normal")])   # duplicate ignored
    assert s.last_wpn_id() == 10 and len(s.since(0)) == 1
