from jarvis.skills.screen import map_point, parse_point


def test_parse_point_and_map():
    frac = parse_point('Tamam: [{"point": [250, 500], "label": "ayarlar"}]')
    assert frac == (0.5, 0.25)
    assert map_point(frac, {"left": -1920, "top": 100, "width": 1000, "height": 800}) == (-1420, 300)


def test_parse_point_rejects_garbage():
    assert parse_point("[]") is None
    assert parse_point("bulamadım") is None
    assert parse_point('[{"point": [1500, 20]}]') is None
