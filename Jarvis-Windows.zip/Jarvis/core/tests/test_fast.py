import pytest

from jarvis.brain.fast import FastPath, fold, match


@pytest.mark.parametrize("text,tool,args", [
    ("Sesi 30 yap", "set_volume", {"level": 30}),
    ("ses %45", "set_volume", {"level": 45}),
    ("sesi biraz kıs", "set_volume", {"change": -10}),
    ("sesi aç", "set_volume", {"change": 10, "mute": False}),
    ("sessize al", "set_volume", {"mute": True}),
    ("sonraki şarkı", "media_control", {"action": "next"}),
    ("şarkıyı geç", "media_control", {"action": "next"}),
    ("önceki şarkı", "media_control", {"action": "previous"}),
    ("müziği durdur", "media_control", {"action": "pause"}),
    ("muzige devam", "media_control", {"action": "play"}),
    ("Saat kaç?", "current_time", {}),
    ("ekranı kilitle", "lock_screen", {}),
    ("10 dakika sonra çayı demlemeyi hatırlat", "set_reminder", {"text": "çayı demlemeyi", "in_minutes": 10}),
    ("2 saat sonra toplantıyı hatırlat bana", "set_reminder", {"text": "toplantıyı", "in_minutes": 120}),
    ("7'de alarm kur", "set_alarm", {"at": "07:00"}),
    ("saat 6.45'e alarm", "set_alarm", {"at": "06:45"}),
])
def test_matches(text, tool, args):
    cmd = match(text)
    assert cmd is not None and cmd.tool == tool and cmd.args == args


@pytest.mark.parametrize("text,names", [
    ("Spotify'ı aç", ["Spotify"]),
    ("hesap makinesini aç", ["hesap makinesini", "hesap makinesi"]),
    ("hesap makinesi aç", ["hesap makinesi"]),
    ("discordu başlat", ["discordu", "discord"]),
    ("WhatsApp'ı kapat", ["WhatsApp"]),
])
def test_app_commands_carry_name_candidates(text, names):
    cmd = match(text)
    assert cmd is not None and cmd.app_names == names


@pytest.mark.parametrize("text", [
    "youtube'da lofi aç",           # needs search
    "spotify'da rahatlatıcı bir şey aç",
    "bunu aç",
    "sesi biraz daha açsan mı",
    "bana bir şaka anlat",
    "devam et",                      # ambiguous without context
    "sonraki adımda ne yapmalıyım",
    "ocağı kapatmayı unutma dedim ya aç şunu",
    "99 saat 25 dakika alarm",
    "25'te alarm kur",
])
def test_non_commands_fall_through(text):
    cmd = match(text)
    assert cmd is None or cmd.app_names  # app candidates still need the confidence check


def test_fold_keeps_length_for_span_mapping():
    s = "İstanbul'da ÇAY için Şükrü!"
    assert len(fold(s)) == len(s)
    assert fold(s).startswith("istanbul'da cay icin sukru")


async def test_fast_path_requires_confident_app_and_formats_reply():
    calls = []

    async def execute(tool, args, source="voice"):
        calls.append((tool, args, source))
        return {"output": f"{args.get('name')} açıldı."}

    fp = FastPath(execute, confident_app=lambda n: n.lower() == "discord")
    assert await fp.try_run("bunu aç") is None
    assert await fp.try_run("rastgele şey aç") is None
    r = await fp.try_run("discordu aç")
    assert r == {"text": "discord açıldı.", "steps": ["open_app"], "model": "fast"}
    assert calls == [("open_app", {"name": "discord"}, "text")]


async def test_fast_path_surfaces_confirmation_and_errors():
    async def needs_ok(tool, args, source="voice"):
        return {"status": "needs_confirmation", "token": "x"}

    r = await FastPath(needs_ok, lambda n: True).try_run("spotify'ı kapat")
    assert r and "onay" in r["text"]

    async def fails(tool, args, source="voice"):
        return {"error": "pycaw yok"}

    r = await FastPath(fails, lambda n: True).try_run("sesi 20 yap")
    assert r and r["text"] == "pycaw yok"


@pytest.mark.parametrize("text,args", [
    ("5 dakika zamanlayıcı kur", {"minutes": 5, "seconds": 0, "label": "Zamanlayıcı"}),
    ("çay için 7 dakika", {"minutes": 7, "seconds": 0, "label": "Çay"}),
    ("30 saniyelik sayaç", {"minutes": 0, "seconds": 30, "label": "Zamanlayıcı"}),
    ("2 saat zamanlayıcı", {"minutes": 120, "seconds": 0, "label": "Zamanlayıcı"}),
])
def test_timers(text, args):
    cmd = match(text)
    assert cmd is not None and cmd.tool == "set_timer" and cmd.args == args


def test_bare_duration_is_not_a_timer():
    assert match("5 dakika") is None


@pytest.mark.parametrize("text,tool,args", [
    ("not al: yarın faturayı öde", "take_note", {"text": "yarın faturayı öde"}),
    ("Not al yarın 10da diş randevusu", "take_note", {"text": "yarın 10da diş randevusu"}),
    ("şunu not et: kira 5 Ekim", "take_note", {"text": "kira 5 Ekim"}),
    ("not: toplantı notları", "take_note", {"text": "toplantı notları"}),
    ("süt almayı diye not al", "take_note", {"text": "süt almayı"}),
    ("notlarımı oku", "list_notes", {}),
    ("odak modunu başlat", "focus_mode", {"minutes": 25}),
    ("50 dakika odaklanmam lazım", "focus_mode", {"minutes": 50}),
])
def test_notes_and_focus(text, tool, args):
    cmd = match(text)
    assert cmd is not None and cmd.tool == tool and cmd.args == args


def test_notepad_is_an_app_not_a_note():
    cmd = match("not defterini aç")
    assert cmd is not None and cmd.tool == "open_app"


@pytest.mark.parametrize("text,tool,args,names", [
    ("VS Code'u sola al", "arrange_window", {"position": "left"}, ["VS Code"]),
    ("spotifyı sağa al", "arrange_window", {"position": "right"}, ["spotifyı", "spotify", "spotif"]),
    ("bu pencereyi tam ekran yap", "arrange_window", {"app": "__foreground__", "position": "full"}, []),
    ("VS Code ile Chrome'u yan yana koy", "side_by_side", {"left_app": "VS Code", "right_app": "Chrome"}, []),
    ("masaüstünü göster", "show_desktop", {}, []),
    ("ekran görüntüsü al", "take_screenshot", {"target": "screen"}, []),
])
def test_window_commands(text, tool, args, names):
    cmd = match(text)
    assert cmd is not None and cmd.tool == tool and cmd.args == args and cmd.app_names == names


async def test_fast_path_fills_the_right_app_argument():
    calls = []

    async def execute(tool, args, source="voice"):
        calls.append((tool, args))
        return {"output": "ok"}

    await FastPath(execute, confident_app=lambda n: n == "spotify").try_run("spotifyı sağa al")
    assert calls == [("arrange_window", {"position": "right", "app": "spotify"})]


@pytest.mark.parametrize("text,args", [
    ("bu penceredeki metni kopyala", {"target": "window", "to_clipboard": True}),
    ("ekrandaki yazıyı oku", {"target": "screen", "to_clipboard": False}),
])
def test_screen_text_commands(text, args):
    cmd = match(text)
    assert cmd is not None and cmd.tool == "read_screen_text" and cmd.args == args
