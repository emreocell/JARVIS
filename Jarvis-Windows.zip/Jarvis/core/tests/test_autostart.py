import sys

import pytest

from jarvis import autostart


class FakeReg:
    HKEY_CURRENT_USER = "HKCU"
    KEY_SET_VALUE = 2
    REG_SZ = 1

    def __init__(self, values=None):
        self.values = dict(values or {})

    def OpenKey(self, *a):
        reg = self

        class K:
            def __enter__(self):
                return reg

            def __exit__(self, *e):
                return False
        return K()

    def QueryValueEx(self, key, name):
        if name not in self.values:
            raise FileNotFoundError(name)
        return self.values[name], 1

    def SetValueEx(self, key, name, _r, _t, value):
        self.values[name] = value

    def DeleteValue(self, key, name):
        del self.values[name]


@pytest.fixture
def reg(monkeypatch):
    fake = FakeReg({"OneDrive": "onedrive.exe /background"})
    monkeypatch.setattr(autostart, "_winreg", lambda: fake)
    monkeypatch.setattr(sys, "platform", "win32")
    return fake


def test_enable_disable_roundtrip(reg):
    assert autostart.sync(True) is True
    assert reg.values["Jarvis"].endswith("-m jarvis --tray")
    assert autostart.sync(True) is False  # idempotent
    assert autostart.sync(False) is True
    assert "Jarvis" not in reg.values and "OneDrive" in reg.values


def test_never_deletes_a_foreign_value_named_jarvis(reg):
    reg.values["Jarvis"] = r"C:\Other\jarvis-thing.exe"
    assert autostart.sync(False) is False
    assert reg.values["Jarvis"] == r"C:\Other\jarvis-thing.exe"
