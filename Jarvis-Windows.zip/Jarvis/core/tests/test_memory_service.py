import json
from types import SimpleNamespace

import httpx

from jarvis import paths
from jarvis.bus import EventBus
from jarvis.config.schema import AppConfig, ProviderConfig, Role, RouteTarget
from jarvis.memory.service import MemoryService
from jarvis.memory.store import MemoryStore
from jarvis.providers import ProviderRegistry
from jarvis.secrets import SecretStore


def make(handler):
    secrets = SecretStore()
    cfg = AppConfig()
    cfg.providers = [ProviderConfig(id="gemini", type="gemini", keys=[secrets.set("g1", "k")])]
    cfg.routes = {Role.TEXT_WORKER: [RouteTarget(provider="gemini", model="gemini-3.5-flash-lite")],
                  Role.EMBEDDING: [RouteTarget(provider="gemini", model="gemini-embedding-2")]}
    reg = ProviderRegistry(secrets, client=httpx.AsyncClient(transport=httpx.MockTransport(handler)))
    reg.load(cfg)
    core = SimpleNamespace(bus=EventBus(), config=cfg, providers=reg)
    store = MemoryStore(paths.data_dir() / "mem.sqlite3")
    return MemoryService(core, store), store


async def test_session_extraction_adds_updates_and_summarizes():
    seen = {}

    def handler(req: httpx.Request):
        if req.url.path.endswith(":batchEmbedContents"):
            n = len(json.loads(req.content)["requests"])
            return httpx.Response(200, json={"embeddings": [{"values": [1.0, 0.0]} for _ in range(n)]})
        body = json.loads(req.content)
        prompt = body["contents"][0]["parts"][0]["text"]
        seen["prompt"] = prompt
        assert body["generationConfig"]["responseMimeType"] == "application/json"
        old_id = int(prompt.split("[")[1].split("]")[0])  # the known fact is offered with its id
        result = {"operations": [
            {"op": "add", "content": "Kullanıcının kedisinin adı Pamuk.", "category": "relationship"},
            {"op": "update", "id": old_id, "content": "Kullanıcı artık Ankara'da yaşıyor."},
            {"op": "forget", "id": 99999},  # unknown id is ignored
        ], "summary": "Kedisinden ve taşınmasından bahsetti."}
        return httpx.Response(200, json={"candidates": [{"content": {"parts": [{"text": json.dumps(result)}]}}]})

    svc, store = make(handler)
    store.add("Kullanıcı İstanbul'da yaşıyor.", "identity")
    await svc.bus.publish("voice.turn_complete", user="Kedimin adı Pamuk", assistant="Ne güzel isim!")
    await svc.bus.publish("voice.turn_complete", user="Bu arada İstanbul'dan Ankara'ya taşındım",
                          assistant="Hayırlı olsun.")
    assert svc.turns == 2
    await svc.end_session()
    await svc._extracting
    contents = sorted(f.content for f in store.list())
    assert contents == ["Kullanıcı artık Ankara'da yaşıyor.", "Kullanıcının kedisinin adı Pamuk."]
    assert store.last_episode()["summary"] == "Kedisinden ve taşınmasından bahsetti."
    assert store.missing_embeddings("gemini-embedding-2") == []
    assert "Kedimin adı Pamuk" in seen["prompt"]
    block = svc.prompt_block()
    assert "Pamuk" in block and "Son konuşma" in block
    store.close()


async def test_privacy_mode_logs_nothing():
    svc, store = make(lambda req: httpx.Response(500))
    svc.core.config.privacy.privacy_mode = True
    await svc.bus.publish("voice.turn_complete", user="gizli", assistant="tamam")
    assert svc.turns == 0 and store.recent_messages() == []
    assert svc.prompt_block() == ""
    store.close()
