from datetime import datetime as real_datetime
from types import SimpleNamespace

import pytest

from jarvis.bus import EventBus
from jarvis.proactive import morning as m


class FakeDT(real_datetime):
    hour_now = 8

    @classmethod
    def now(cls, tz=None):
        return real_datetime(2026, 9, 26, cls.hour_now, 30)


def make(enabled=True):
    said = []

    async def say(text, show=True):
        said.append(text)

    features = SimpleNamespace(morning_brief=enabled)
    core = SimpleNamespace(bus=EventBus(), config=SimpleNamespace(
        features=features, privacy=SimpleNamespace(privacy_mode=False),
        assistant=SimpleNamespace(user_name="Emre", location="")),
        voice=SimpleNamespace(say=say), context=None)
    brief = m.MorningBrief(core)

    async def gather():
        return {"weather": {"output": "Canik: 18°C, kapalı."}, "reminders": [{"time": "10:00", "text": "ders"}],
                "mail": {"unread": 2, "top": []}, "agenda": "", "projects": [], "now": "x"}
    brief.gather = gather
    return brief, said


@pytest.mark.asyncio
async def test_runs_once_in_the_morning(monkeypatch):
    monkeypatch.setattr(m, "datetime", FakeDT)
    monkeypatch.setattr(m, "busy_reason", lambda ctx: None)
    brief, said = make()
    await brief.maybe_run("start")
    assert len(said) == 1 and "Sabah özeti" in said[0] and "Canik" in said[0]
    await brief.maybe_run("returned")      # already done today
    assert len(said) == 1


@pytest.mark.asyncio
async def test_skips_outside_window_and_when_disabled(monkeypatch):
    monkeypatch.setattr(m, "datetime", FakeDT)
    monkeypatch.setattr(m, "busy_reason", lambda ctx: None)
    FakeDT.hour_now = 15
    brief, said = make()
    await brief.maybe_run("start")
    FakeDT.hour_now = 8
    off, said_off = make(enabled=False)
    await off.maybe_run("start")
    assert said == [] and said_off == []


def test_plain_summary():
    text = m._plain({"weather": {"output": "Canik: 18°C."}, "mail": {"unread": 3, "top": []},
                     "reminders": [{"time": "09:00", "text": "toplantı"}]})
    assert "3 okunmamış" in text and "toplantı" in text
