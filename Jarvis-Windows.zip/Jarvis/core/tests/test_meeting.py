import numpy as np

from jarvis.meeting.recorder import BLOCK, RATE, MeetingStore, Segmenter, transcript_text


def test_segmenter_cuts_speech_at_pauses():
    seg = Segmenter()
    rng = np.random.default_rng(0)
    speech = lambda: (rng.standard_normal(BLOCK) * 0.1).astype(np.float32)   # noqa: E731
    silence = lambda: np.zeros(BLOCK, np.float32)                               # noqa: E731
    out = [seg.feed(b) for b in [silence()] * 4 + [speech()] * 14 + [silence()] * 3]
    chunks = [c for c in out if c is not None]
    assert len(chunks) == 1 and chunks[0].dtype == np.int16 and len(chunks[0]) / RATE >= 6
    assert all(seg.feed(silence()) is None for _ in range(20))   # silence never becomes a chunk


def test_store_and_transcript(tmp_path):
    s = MeetingStore(tmp_path / "m.sqlite3")
    mid = s.create("Haftalık", 1000.0)
    s.add_segment(mid, 1065.0, "system", "Ödeme entegrasyonunu cumaya bitirelim.")
    s.finish(mid, 2000.0, "Haftalık", {"title": "Haftalık", "summary": "x", "decisions": [], "action_items": []})
    assert transcript_text(s.segments(mid), 1000.0) == "[01:05] (Uzak) Ödeme entegrasyonunu cumaya bitirelim."
    assert s.meetings()[0]["summary"]["title"] == "Haftalık"
