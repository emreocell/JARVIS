from jarvis.providers.profiles import limits_for
from jarvis.providers.quota import Limits, QuotaTracker


class Clock:
    def __init__(self, t: float = 1_800_000_000.0) -> None:
        self.t = t

    def __call__(self) -> float:
        return self.t


def test_rpm_window_slides():
    clock = Clock()
    q = QuotaTracker(clock=clock)
    lim = Limits(rpm=2)
    q.record("k", "m")
    q.record("k", "m")
    assert not q.available("k", "m", lim)
    clock.t += 61
    assert q.available("k", "m", lim)


def test_rpd_resets_at_pacific_midnight():
    clock = Clock()
    q = QuotaTracker(clock=clock)
    lim = Limits(rpd=1)
    q.record("k", "m")
    assert not q.available("k", "m", lim)
    clock.t += 24 * 3600
    assert q.available("k", "m", lim)


def test_keys_are_independent():
    q = QuotaTracker(clock=Clock())
    lim = Limits(rpd=1)
    q.record("a", "m")
    assert not q.available("a", "m", lim)
    assert q.available("b", "m", lim)


def test_tpm_estimate_blocks():
    q = QuotaTracker(clock=Clock())
    lim = Limits(tpm=1000)
    q.add_tokens("k", "m", 900)
    assert q.available("k", "m", lim, est_tokens=50)
    assert not q.available("k", "m", lim, est_tokens=200)


def test_cooldown_and_blocked_models():
    clock = Clock()
    q = QuotaTracker(clock=clock)
    q.cooldown("k", "m", 30)
    assert not q.available("k", "m", Limits())
    clock.t += 31
    assert q.available("k", "m", Limits())
    assert not q.available("k", "m", Limits(rpm=0, rpd=0))


def test_dump_restore_same_day_only():
    clock = Clock()
    q = QuotaTracker(clock=clock)
    q.record("k", "m")
    q.record("k", "m")
    data = q.dump()
    q2 = QuotaTracker(clock=clock)
    q2.restore(data)
    assert not q2.available("k", "m", Limits(rpd=2))
    clock.t += 24 * 3600
    q3 = QuotaTracker(clock=clock)
    q3.restore(data)
    assert q3.available("k", "m", Limits(rpd=2))


def test_profile_lookup():
    assert limits_for("gemini_free_2026", "gemini-3.5-flash-lite").rpd == 500
    assert limits_for("gemini_free_2026", "models/gemini-3.8-live").rpd is None
    assert limits_for("gemini_free_2026", "gemini-3.1-pro").blocked
    assert limits_for(None, "anything").rpm is None
    assert limits_for("gemini_free_2026", "brand-new-model").rpm == 10
