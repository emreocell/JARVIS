from jarvis.platform import mac


def test_keystroke_scripts_map_windows_habits():
    assert mac.keystroke_script("Enter") == 'tell application "System Events" to key code 36'
    assert mac.keystroke_script("Ctrl+S") == 'tell application "System Events" to keystroke "s" using {command down}'
    assert mac.keystroke_script("Cmd+Shift+T") == \
        'tell application "System Events" to keystroke "t" using {command down, shift down}'
    assert "key code 122" in mac.keystroke_script("F1")


def test_applescript_quoting():
    bs = chr(92)
    assert mac.as_string('say "hi"') == '"say ' + bs + '"hi' + bs + '""'
    assert mac.as_string("a" + bs + "b") == '"a' + bs + bs + 'b"'


def test_resolve_app_aliases_and_fuzzy(monkeypatch):
    monkeypatch.setattr(mac, "installed_apps", lambda: {"Spotify": "/A/Spotify.app", "Calculator": "/A/C.app",
                                                        "Visual Studio Code": "/A/V.app"})
    assert mac.resolve_app("spotify") == "Spotify"
    assert mac.resolve_app("hesap makinesi") == "Calculator"
    assert mac.resolve_app("vs code") == "Visual Studio Code"
    assert mac.resolve_app("photoshop") is None
