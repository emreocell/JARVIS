from jarvis.voice.vosk_wake import grammar_text, sounds_like, turkish_spelling

VOCAB = {"car", "vi", "is", "naber", "günaydın", "v", "s", "ms", "cay", "al", "red"}


def known(w: str) -> bool:
    return w in VOCAB


def test_grammar_text_keeps_turkish_letters():
    assert grammar_text("Günaydın, JARVIS!") == "günaydın jarvıs"
    assert grammar_text("İyi Işıklar") == "iyi ışıklar"


def test_english_words_get_turkish_spelling():
    assert turkish_spelling("jarvis") == "carvis"
    assert turkish_spelling("washington") == "vaşington"
    # Turkish-looking words are left alone
    assert turkish_spelling("cervis") == "cervis"


def test_sounds_like_splits_into_known_words_with_overlap():
    assert sounds_like("jarvis", known) == ["car", "vi", "is"]


def test_sounds_like_never_uses_letter_names_or_abbreviations():
    # "car"+"v"+"is" would read "car ve is"; "ms" has no vowel
    parts = sounds_like("carvis", known)
    assert parts and all(len(p) > 1 and set(p) & set("aeıioöuü") for p in parts)
    assert sounds_like("cayms", known) is None


def test_sounds_like_gives_up_on_unmappable_words():
    assert sounds_like("xyzqw", known) is None
