import asyncio
import time
from datetime import datetime
from types import SimpleNamespace
from typing import Annotated

import pytest

from jarvis import paths
from jarvis.bus import EventBus
from jarvis.routines import engine as engine_mod
from jarvis.routines.engine import RoutineEngine, next_rule_time
from jarvis.routines.store import RoutineStore, Rule, next_occurrence
from jarvis.skills.routines import parse_when
from jarvis.tools import Risk, ToolRuntime, tool
from jarvis.tools.approval import ApprovalStore

played: list[str] = []


@tool(risk=Risk.LOW, platforms=())
def play_music(query: Annotated[str, "q"]) -> dict:
    """Müzik çalar."""
    played.append(query)
    return {"output": "çalıyor"}


def test_parse_when():
    now = datetime(2026, 9, 24, 14, 0)
    assert datetime.fromtimestamp(parse_when("15:30", None, now)) == datetime(2026, 9, 24, 15, 30)
    assert datetime.fromtimestamp(parse_when("09:00", None, now)) == datetime(2026, 9, 25, 9, 0)  # tomorrow
    assert datetime.fromtimestamp(parse_when(None, 20, now)) == datetime(2026, 9, 24, 14, 20)
    assert datetime.fromtimestamp(parse_when("2026-09-26T08:15", None, now)) == datetime(2026, 9, 26, 8, 15)
    with pytest.raises(ValueError):
        parse_when("2026-01-01T10:00", None, now)
    with pytest.raises(ValueError):
        parse_when(None, None, now)


def test_next_occurrence_weekdays():
    fri = datetime(2026, 9, 25, 7, 30).timestamp()  # Friday
    nxt = next_occurrence(fri, "weekdays", now=fri + 1)
    assert datetime.fromtimestamp(nxt) == datetime(2026, 9, 28, 7, 30)  # Monday
    assert next_occurrence(fri, "none") is None


def test_next_rule_time():
    rule = Rule(1, "x", {"type": "time", "at": "09:00", "days": "weekends"}, {"type": "say", "text": "hi"})
    thu = datetime(2026, 9, 24, 10, 0).timestamp()
    assert datetime.fromtimestamp(next_rule_time(rule, thu)) == datetime(2026, 9, 26, 9, 0)  # Saturday


@pytest.fixture
async def eng(monkeypatch):
    played.clear()
    toasts: list[tuple] = []
    monkeypatch.setattr(engine_mod, "toast", lambda *a, **k: toasts.append(a) or True)
    bus = EventBus()
    notes: list[str] = []

    async def notify(text):
        notes.append(text)

    tools = ToolRuntime(bus, ApprovalStore(paths.data_dir() / "ap.json"))
    tools.register(play_music.__tool__)
    core = SimpleNamespace(bus=bus, tools=tools, notify_brain=notify)
    e = RoutineEngine(core, RoutineStore(paths.data_dir() / "r.sqlite3"))
    e.toasts, e.notes = toasts, notes
    yield e
    await e.stop()
    e.store.close()


async def test_reminder_fires_on_time_and_repeats(eng):
    fired = asyncio.Event()
    eng.core.bus.subscribe("routine.fired", lambda e: fired.set())
    rem = eng.store.add_reminder("ocağı kapat", time.time() + 0.3, "reminder", "daily")
    await eng.start()
    await asyncio.wait_for(fired.wait(), 2)
    assert eng.toasts[0][:2] == ("Hatırlatıcı", "ocağı kapat")
    assert "ocağı kapat" in eng.notes[0]
    again = eng.store.get_reminder(rem.id)
    assert again.status == "pending" and again.due > time.time() + 23 * 3600  # rescheduled tomorrow


async def test_missed_reminder_announced_at_start(eng):
    eng.store.add_reminder("toplantı", time.time() - 3600)
    await eng.start()
    assert eng.toasts[0][0] == "Kaçırılan hatırlatıcı"
    assert eng.store.pending() == []


async def test_ask_mode_creates_confirmation_and_yes_runs_it(eng):
    rule = eng.store.save_rule(Rule(0, "Kodlarken müzik", {"type": "app_opened", "app": "VS Code"},
                                    {"type": "tool", "tool": "play_music", "args": {"query": "lofi"}}, "ask",
                                    quiet_hours=[0, 0]))
    await eng.start()
    await eng.core.bus.publish("context.focus", app="VS Code", title="x")
    assert played == []  # asked, not done
    pending = eng.core.tools.approvals.pending()
    assert len(pending) == 1 and "Kodlarken müzik" in pending[0].summary
    assert "yapayım mı" in eng.notes[-1]
    await eng.core.bus.publish("user.text", role="user", text="evet aç", turn=1)
    out = await eng.core.tools.execute("confirm_pending_action", {"token": pending[0].token})
    assert out == {"output": "çalıyor"} and played == ["lofi"]
    # cooldown: reopening VS Code right away does not ask again
    await eng.core.bus.publish("context.focus", app="Chrome", title="y")
    eng._app_last_seen["VS Code"] = 0
    await eng.core.bus.publish("context.focus", app="VS Code", title="x")
    assert eng.core.tools.approvals.pending() == []
    assert eng.store.rules()[0].last_fired > 0 and rule.id


async def test_auto_mode_and_quiet_hours(eng):
    hour = datetime.now().hour
    quiet = eng.store.save_rule(Rule(0, "gece", {"type": "startup"}, {"type": "tool", "tool": "play_music",
                                     "args": {"query": "q"}}, "auto", quiet_hours=[hour, (hour + 1) % 24]))
    assert (await eng.run_rule(quiet, "test"))["skipped"] == "quiet hours"
    ok = eng.store.save_rule(Rule(0, "gündüz", {"type": "startup"}, {"type": "tool", "tool": "play_music",
                                  "args": {"query": "sabah"}}, "auto", quiet_hours=[0, 0]))
    assert (await eng.run_rule(ok, "test")) == {"output": "çalıyor"}
    assert played == ["sabah"]


def test_timer_duration_wording_follows_vowel_harmony():
    from jarvis.skills.routines import _lik, _span_text

    words = [(_span_text(s) + _lik(_span_text(s))) for s in (180, 30, 3600, 5400)]
    assert words == ["3 dakikalık", "30 saniyelik", "1 saatlik", "1 saat 30 dakikalık"]
