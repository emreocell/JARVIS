import asyncio

from jarvis.bus import EventBus
from jarvis.config.schema import VoiceSettings
from jarvis.voice.cascade import CascadeSession, sentences, speakable
from jarvis.voice.controller import VoiceController, VoiceState
from jarvis.voice.live import LiveCallbacks
from tests.test_voice import SILENCE, SPEECH, WAKE, FakeMic, FakeSpeaker, FakeWake, fake_vad, wait_for


class Recorder:
    def __init__(self):
        self.events = []

    def cb(self):
        async def tool(calls):
            return []
        return LiveCallbacks(lambda pcm: self.events.append(("audio", len(pcm))),
                             lambda t: self.events.append(("in", t)),
                             lambda t: self.events.append(("out", t)),
                             lambda: self.events.append(("done",)),
                             lambda: None, tool, lambda r: self.events.append(("closed", r)))


class FakeSynth:
    async def stream(self, text):
        for s in sentences(speakable(text)):
            yield b"\x00\x00" * 100


def session(rec, transcript="sesi kıs", reply="Tamam, kıstım.", delay=0.0):
    async def transcribe(wav):
        await asyncio.sleep(delay)
        return transcript

    async def respond(text):
        return reply
    return CascadeSession(transcribe, respond, FakeSynth(), rec.cb())


def test_speakable_strips_markdown_and_emoji():
    assert speakable("**Tamam** 👍 [link](http://x) `kod`") == "Tamam link kod"
    assert sentences("Evet. Hemen açıyorum, bir saniye. Başka bir şey? Tamam.") == [
        "Evet. Hemen açıyorum, bir saniye.", "Başka bir şey? Tamam."]


async def test_turn_transcribes_answers_and_speaks():
    rec = Recorder()
    s = session(rec)
    await s.connect()
    await s.activity_start()
    await s.send_audio(b"\x01\x00" * 16000)  # 1 s
    await s.activity_end()
    await wait_for(lambda: ("done",) in rec.events)
    assert rec.events[0] == ("in", "sesi kıs") and rec.events[1] == ("out", "Tamam, kıstım.")
    assert any(e[0] == "audio" for e in rec.events)


async def test_too_short_audio_is_ignored_but_turn_completes():
    rec = Recorder()
    s = session(rec)
    await s.activity_start()
    await s.send_audio(b"\x01\x00" * 1000)
    await s.activity_end()
    await wait_for(lambda: ("done",) in rec.events)
    assert rec.events == [("done",)]


async def test_new_speech_cancels_previous_turn_without_completing_it():
    rec = Recorder()
    s = session(rec, delay=0.3)
    await s.activity_start()
    await s.send_audio(b"\x01\x00" * 16000)
    await s.activity_end()
    await asyncio.sleep(0.05)
    await s.activity_start()  # user talks again
    await asyncio.sleep(0.4)
    assert rec.events == []


async def test_controller_falls_back_to_cascade_when_live_fails():
    class DeadLive:
        def __init__(self, *a):
            self.connected = False

        async def connect(self):
            raise ConnectionError("Live bağlantısı kurulamadı")

    rec = Recorder()
    made = []

    def cascade(cb):
        async def transcribe(wav):
            return "saat kaç"

        async def respond(text):
            return "Saat on."
        made.append(CascadeSession(transcribe, respond, FakeSynth(), cb))
        return made[-1]

    bus = EventBus()
    notices = []
    bus.subscribe("voice.pipeline", lambda e: notices.append(e.data))
    vc = VoiceController(bus, VoiceSettings(echo_profile="half_duplex", follow_up_seconds=0.2),
                         lambda: [], lambda: "sys", mic=FakeMic(), speaker=FakeSpeaker(), wake=FakeWake(),
                         vad=fake_vad, live_factory=DeadLive, cascade_factory=cascade)
    await vc.start()
    try:
        vc.mic.feed(WAKE)
        await wait_for(lambda: vc.state is VoiceState.ARMED)
        vc.mic.feed(SPEECH, 8)
        vc.mic.feed(SILENCE, 12)
        await wait_for(lambda: vc.speaker.chunks, timeout=3)
        assert vc.pipeline == "cascade" and made
        await wait_for(lambda: notices)
        assert notices[0]["reason"] == "Live bağlanamadı"
    finally:
        await vc.stop()
