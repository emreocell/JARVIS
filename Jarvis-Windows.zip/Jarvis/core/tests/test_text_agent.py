import json
from typing import Annotated

import httpx

from jarvis import paths
from jarvis.brain.text_agent import TextAgent
from jarvis.bus import EventBus
from jarvis.config.schema import AppConfig, ProviderConfig, Role, RouteTarget
from jarvis.providers import ProviderRegistry
from jarvis.secrets import SecretStore
from jarvis.tools import Risk, ToolRuntime, tool
from jarvis.tools.approval import ApprovalStore

opened: list[str] = []


@tool(risk=Risk.LOW, platforms=())
def open_app(name: Annotated[str, "Uygulama adı"]) -> dict:
    """Uygulama açar."""
    opened.append(name)
    return {"output": f"{name} açılıyor."}


def gemini(parts):
    return httpx.Response(200, json={"candidates": [{"content": {"role": "model", "parts": parts}}],
                                     "usageMetadata": {"promptTokenCount": 10, "candidatesTokenCount": 3}})


def make_agent(handler):
    secrets = SecretStore()
    cfg = AppConfig()
    cfg.providers = [ProviderConfig(id="gemini", type="gemini", keys=[secrets.set("g1", "k")],
                                    quota_profile="gemini_free_2026")]
    cfg.routes = {Role.TEXT_WORKER: [RouteTarget(provider="gemini", model="gemini-3.5-flash-lite")]}
    reg = ProviderRegistry(secrets, client=httpx.AsyncClient(transport=httpx.MockTransport(handler)))
    reg.load(cfg)
    bus = EventBus()
    rt = ToolRuntime(bus, ApprovalStore(paths.data_dir() / "a.json"))
    rt.register(open_app.__tool__)
    return TextAgent(bus, reg, rt, lambda: "sys")


async def test_tool_call_loop():
    opened.clear()
    bodies = []

    def handler(req):
        body = json.loads(req.content)
        bodies.append(body)
        if len(bodies) == 1:
            assert any(d["name"] == "open_app" for d in body["tools"][0]["functionDeclarations"])
            return gemini([{"functionCall": {"name": "open_app", "args": {"name": "spotify"}, "id": "c1"}}])
        last = body["contents"][-1]["parts"][0]["functionResponse"]
        assert last == {"name": "open_app", "response": {"output": "spotify açılıyor."}, "id": "c1"}
        return gemini([{"text": "Spotify'ı açtım."}])

    agent = make_agent(handler)
    out = await agent.run("spotify'ı aç")
    assert out == {"text": "Spotify'ı açtım.", "steps": ["open_app"], "model": "gemini-3.5-flash-lite", "route": "full"}
    assert opened == ["spotify"]
    # history kept for the next turn
    assert [c["role"] for c in agent.contents] == ["user", "model", "user", "model"]


async def test_step_limit():
    def handler(req):
        return gemini([{"functionCall": {"name": "open_app", "args": {"name": "x"}}}])

    agent = make_agent(handler)
    out = await agent.run("döngü")
    # loop guard blocks the 4th identical call; the step cap ends the turn
    assert out["text"] == "Bu işi adım sınırı içinde bitiremedim."
    assert len(out["steps"]) == 6


async def test_router_direct_skips_llm():
    import asyncio

    from jarvis.brain.router import Route
    from jarvis.tools import tool as mk

    @mk(risk=Risk.READ, platforms=())
    def current_time() -> dict:
        """Saat."""
        return {"time": "09:15", "date": "", "weekday": ""}

    async def slow_llm(request):  # the LLM call started in parallel must be dropped
        await asyncio.sleep(5)
        return gemini([{"text": "yavaş"}])

    class Router:
        def enabled(self):
            return True

        async def route(self, text, recent, available=None):
            return Route("direct", tool="current_time", confidence=0.95)

    agent = make_agent(lambda r: gemini([{"text": "x"}]))
    agent.tools.register(current_time.__tool__)
    agent.router = Router()
    agent.providers.client = httpx.AsyncClient(transport=httpx.MockTransport(slow_llm))
    out = await asyncio.wait_for(agent.run("saat kaç"), 2)
    assert out["text"] == "Saat 09:15." and out["route"] == "jev:direct:current_time"
