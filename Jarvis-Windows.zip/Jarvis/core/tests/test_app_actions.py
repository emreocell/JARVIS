from jarvis.app_actions import actions_for


def test_actions_depend_on_app():
    assert actions_for("Code.exe")["app"] == "Kod editörü"
    assert actions_for("opera.exe", "Lofi - YouTube")["actions"][0] == "Bu videoyu özetle"
    assert actions_for("unknown.exe")["app"] == "Masaüstü"
