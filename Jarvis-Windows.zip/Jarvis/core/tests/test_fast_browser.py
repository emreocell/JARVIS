from jarvis.browser import fast

ITEMS = [
    {"id": 1, "role": "link", "label": "Ana sayfa", "pos": "sol üst"},
    {"id": 2, "role": "searchbox", "label": "Vikipedi'de ara", "pos": "üst orta"},
    {"id": 3, "role": "button", "label": "Ara", "pos": "üst orta"},
    {"id": 4, "role": "link", "label": "Giriş yap", "pos": "sağ üst"},
    {"id": 5, "role": "button", "label": "Görünüm", "pos": "sağ üst"},
    {"id": 6, "role": "link", "label": "Hakkında", "pos": "aşağıda (kaydırınca)"},
]


def test_rank_uses_words_roles_and_positions():
    assert fast.rank(ITEMS, "sağ üstteki giriş bağlantısına tıkla")[0]["id"] == 4
    assert fast.rank(ITEMS, "arama kutusu")[0]["id"] == 2
    assert fast.rank(ITEMS, "sağdaki buton")[0]["id"] == 5


def test_paragraph_and_ordinals():
    snap = {"paragraphs": ["bir", "iki", "üç"]}
    assert fast.paragraph(snap, 3) == "üç" and fast.paragraph(snap, -1) == "üç"
    assert fast.paragraph(snap, 9) is None
    assert fast.ordinal("wikipedideki üçüncü paragrafı oku") == 3
    assert fast.ordinal("son paragrafı oku") == -1
    assert fast.ordinal("2. paragraf") == 2
