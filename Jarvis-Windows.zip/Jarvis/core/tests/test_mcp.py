from types import SimpleNamespace

from jarvis.mcpclient.manager import clean_schema, result_to_dict, risk_for, tool_name
from jarvis.tools.base import Risk


def test_tool_names_are_gemini_safe():
    assert tool_name("windows", "DisplayInventory") == "windows_display_inventory"
    assert tool_name("windows", "Click-Tool") == "windows_click_tool"
    assert tool_name("google", "send_gmail_message") == "google_send_gmail_message"
    assert len(tool_name("x", "a" * 100)) == 64


def test_risk_levels():
    assert risk_for("send_gmail_message") is Risk.SEND
    assert risk_for("manage_event") is Risk.SEND
    assert risk_for("manage_gmail_filter") is Risk.DESTRUCTIVE   # filters can forward mail
    assert risk_for("list_gmail_filters") is Risk.READ
    assert risk_for("PowerShell") is Risk.DESTRUCTIVE
    assert risk_for("Click") is Risk.LOW
    assert risk_for("draft_gmail_message") is Risk.WRITE
    assert risk_for("whatever", {"readOnlyHint": True}) is Risk.READ
    assert risk_for("something_new") is Risk.WRITE


def test_clean_schema_strips_noise():
    s = clean_schema({"$schema": "x", "title": "T", "properties": {"a": {"type": "string", "title": "A",
                                                                          "default": None}}})
    assert s == {"type": "object", "properties": {"a": {"type": "string"}}}
    assert clean_schema(None)["type"] == "object"


def test_result_conversion():
    ok = SimpleNamespace(content=[SimpleNamespace(type="text", text="merhaba"), SimpleNamespace(type="image")],
                         structured_content=None, is_error=False)
    out = result_to_dict(ok)
    assert out["output"].startswith("merhaba") and "görsel" in out["output"] and "note" in out
    err = SimpleNamespace(content=[SimpleNamespace(type="text", text="boom")], structured_content=None, is_error=True)
    assert result_to_dict(err) == {"error": "boom"}


def test_clean_schema_keeps_parameter_named_title():
    s = clean_schema({"type": "object", "title": "N", "required": ["title"],
                      "properties": {"title": {"type": "string", "title": "Title"}}})
    assert s["properties"] == {"title": {"type": "string"}} and s["required"] == ["title"]


def test_tool_cache_roundtrip(tmp_path, monkeypatch):
    from jarvis import paths
    from jarvis.config.schema import McpServerConfig
    from jarvis.mcpclient.manager import McpServer

    monkeypatch.setattr(paths, "data_dir", lambda: tmp_path)
    cfg = McpServerConfig(id="w", command="uvx", args=["a"], env={"X": "1", "S": "keyring:s"})
    s = McpServer(SimpleNamespace(), cfg)
    s.tools = [{"name": "Click", "description": "", "schema": {}, "annotations": {}}]
    s._save_cache()
    fresh = McpServer(SimpleNamespace(), cfg)
    assert fresh.load_cache() and fresh.tools[0]["name"] == "Click"
    changed = McpServer(SimpleNamespace(), cfg.model_copy(update={"env": {"X": "2"}}))
    assert not changed.load_cache()
