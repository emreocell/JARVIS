from jarvis.skills.whatsapp import clean_contact, pick_candidate


def test_clean_contact():
    assert clean_contact("Ahmet'e") == "Ahmet"
    assert clean_contact("Aile grubuna") == "Aile"
    assert clean_contact("Mehmet kişisine") == "Mehmet"
    assert clean_contact("+90 555 123 45 67") == "+90 555 123 45 67"


def test_pick_exact_among_similar():
    items = ["Ahmet Yılmaz, merhaba, 12:30", "Ahmet, tamam, dün", "Ahmet Kaya, görüşürüz, Pzt"]
    chosen, ambiguous = pick_candidate("Ahmet", items)
    assert chosen == "Ahmet, tamam, dün" and ambiguous == []


def test_pick_ambiguous_returns_candidates():
    items = ["Ahmet Yılmaz, merhaba, 12:30", "Ahmet Kaya, görüşürüz, Pzt"]
    chosen, ambiguous = pick_candidate("ahmet", items)
    assert chosen is None and ambiguous == ["Ahmet Yılmaz", "Ahmet Kaya"]


def test_pick_single_fuzzy_match_and_not_found():
    chosen, _ = pick_candidate("ayse", ["Ayşe Demir, selam, 10:00", "Market, indirim"])
    assert chosen.startswith("Ayşe Demir")
    assert pick_candidate("zeynep", ["Ayşe Demir, selam"]) == (None, [])


def test_message_box_label_must_name_the_target_chat():
    from jarvis.skills.whatsapp import box_targets_other_chat

    assert not box_targets_other_chat("Notlarım grup sohbetine bir mesaj yazın", "Notlarım")
    assert box_targets_other_chat("Annem grup sohbetine bir mesaj yazın", "Notlarım")
    assert not box_targets_other_chat("Bir mesaj yazın", "Notlarım")  # old builds: generic label
