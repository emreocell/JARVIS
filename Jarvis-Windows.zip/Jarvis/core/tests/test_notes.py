from jarvis.notes import NoteStore


def test_notes_crud_search_and_ordering(tmp_path):
    s = NoteStore(tmp_path / "n.sqlite3")
    a = s.add("Yarın faturayı öde")
    b = s.add("Süt ve ekmek al")
    c = s.add("Proje sunumunu hazırla")
    assert [n.text for n in s.list("fatura")] == ["Yarın faturayı öde"]
    assert [n.text for n in s.list("sut")] == ["Süt ve ekmek al"]  # diacritic-insensitive
    s.update(c.id, pinned=True)
    s.update(a.id, done=True)
    order = [n.id for n in s.list()]
    assert order[0] == c.id and order[-1] == a.id  # pinned first, done last
    assert a.id not in [n.id for n in s.list(include_done=False)]
    assert s.update(b.id, text="Süt al").text == "Süt al"
    assert s.delete(b.id) and s.get(b.id) is None
    s.close()
