import pytest

from jarvis import paths
from jarvis.memory.store import MemoryStore


@pytest.fixture
def mem():
    m = MemoryStore(paths.data_dir() / "memory.sqlite3")
    yield m
    m.close()


def test_add_search_with_turkish_suffixes(mem):
    mem.add("Kullanıcının kardeşinin adı Ayşe.", "relationship")
    mem.add("Kod editörü olarak VS Code kullanıyor.", "work")
    mem.add("Kahvesini şekersiz içiyor.", "preference")
    hits = mem.search("Ayşe'nin kim olduğunu hatırlıyor musun")
    assert hits and "Ayşe" in hits[0].content
    assert "VS Code" in mem.search("hangi kod editörünü kullanıyorum")[0].content


def test_small_talk_retrieves_nothing(mem):
    mem.add("Kullanıcı İstanbul'da yaşıyor.", "identity")
    assert mem.search("tamam teşekkürler") == []
    assert mem.search("evet") == []


def test_duplicate_is_reinforced_not_added(mem):
    fid, created = mem.add("Kullanıcı İstanbul'da yaşıyor.")
    fid2, created2 = mem.add("Kullanıcı İstanbul'da yaşıyor")
    assert created and not created2 and fid == fid2
    assert mem.count() == 1


def test_update_supersedes_and_keeps_history(mem):
    fid, _ = mem.add("Kullanıcı İstanbul'da yaşıyor.")
    new_id = mem.update(fid, "Kullanıcı Ankara'ya taşındı.")
    assert mem.count() == 1
    assert mem.search("istanbul") == []
    assert mem.search("ankara")[0].id == new_id
    kinds = [e["kind"] for e in mem.history()]
    assert kinds[:2] == ["update", "add"]


def test_forget_and_pin_profile(mem):
    a, _ = mem.add("Adı Emre.", "identity")
    b, _ = mem.add("Spotify Premium kullanıyor.", "device")
    mem.set_pinned(b, True)
    assert mem.profile()[0].id == b
    mem.forget(a)
    assert [f.id for f in mem.list()] == [b]


def test_vector_scores_merge(mem):
    a, _ = mem.add("Sabahları koşuya çıkıyor.", "habit")
    b, _ = mem.add("Python ile proje geliştiriyor.", "work")
    mem.set_embedding(a, "m", [1.0, 0.0, 0.0])
    mem.set_embedding(b, "m", [0.0, 1.0, 0.0])
    # no word overlap, but the vector is close to "a"
    hits = mem.search("spor alışkanlıkları", query_vec=[0.9, 0.1, 0.0], model="m")
    assert [h.id for h in hits] == [a]
    assert [f.id for f in mem.missing_embeddings("m")] == []


def test_messages_and_episodes(mem):
    mem.log_message("s1", "user", "merhaba")
    mem.log_message("s1", "assistant", "selam")
    assert [m["role"] for m in mem.session_messages("s1")] == ["user", "assistant"]
    mem.save_episode("s1", 1.0, 2.0, "Selamlaştık.")
    assert mem.last_episode()["summary"] == "Selamlaştık."


def test_sessions_listing_search_and_delete(tmp_path):
    from jarvis.memory.store import MemoryStore

    store = MemoryStore(tmp_path / "m.sqlite3")
    store.log_message("s1", "user", "Spotify'da odak müziği aç")
    store.log_message("s1", "assistant", "Açtım.")
    store.log_message("s2", "user", "100%_indirim ara")
    store.log_message("s2", "assistant", "Arıyorum")
    store.log_message("s2", "user", "teşekkürler")
    store.save_episode("s1", 0, 1, "Müzik açıldı")
    rows = store.sessions()
    assert [r["session"] for r in rows] == ["s2", "s1"]
    assert rows[0]["turns"] == 2 and rows[0]["opening"] == "100%_indirim ara"
    assert rows[1]["summary"] == "Müzik açıldı"
    assert [r["session"] for r in store.sessions(query="odak")] == ["s1"]
    assert [r["session"] for r in store.sessions(query="%_")] == ["s2"]  # LIKE wildcards escaped
    assert store.sessions(query="a_c") == []
    assert store.delete_session("s1") == 2
    assert [r["session"] for r in store.sessions()] == ["s2"]
    assert store.last_episode() is None
    store.close()
