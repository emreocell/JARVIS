import json

import pytest
from websockets.asyncio.client import connect
from websockets.exceptions import ConnectionClosed, InvalidStatus

from jarvis import paths
from jarvis.core import Core
from jarvis.fsutil import read_json


@pytest.fixture
async def core():
    c = Core(port=0, enable_voice=False)
    await c.start()
    yield c
    await c.stop()


async def _authed(core):
    ws = await connect(f"ws://127.0.0.1:{core.api.port}")
    await ws.send(json.dumps({"type": "auth", "token": core.token}))
    snap = json.loads(await ws.recv())
    assert snap["type"] == "snapshot"
    return ws, snap


async def _call(ws, method, params=None, id_=1):
    await ws.send(json.dumps({"id": id_, "method": method, "params": params or {}}))
    while True:
        msg = json.loads(await ws.recv())
        if msg.get("id") == id_:
            return msg


async def test_runtime_file_written(core):
    info = read_json(paths.runtime_path())
    assert info["port"] == core.api.port and info["token"] == core.token


async def test_bad_token_closed_1008(core):
    async with connect(f"ws://127.0.0.1:{core.api.port}") as ws:
        await ws.send(json.dumps({"type": "auth", "token": "nope"}))
        with pytest.raises(ConnectionClosed) as exc:
            await ws.recv()
        assert exc.value.rcvd.code == 1008


async def test_foreign_origin_rejected(core):
    with pytest.raises(InvalidStatus):
        await connect(f"ws://127.0.0.1:{core.api.port}", origin="https://evil.example")


async def test_snapshot_and_config_patch_event(core):
    ws, snap = await _authed(core)
    assert snap["data"]["config"]["voice"]["mode"] == "live"
    reply = await _call(ws, "config.patch", {"patch": {"features": {"telegram_remote": True}}})
    assert reply["result"]["features"]["telegram_remote"] is True
    # the change is also broadcast as an event
    await ws.send(json.dumps({"id": 2, "method": "config.get"}))
    topics = []
    while True:
        msg = json.loads(await ws.recv())
        if msg.get("type") == "event":
            topics.append(msg["topic"])
        if msg.get("id") == 2:
            break
    assert "config.changed" in topics or core.config.features.telegram_remote
    await ws.close()


async def test_validation_error_is_reported(core):
    ws, _ = await _authed(core)
    reply = await _call(ws, "config.patch", {"patch": {"voice": {"follow_up_seconds": -1}}})
    assert reply["error"]["message"] == "validation failed"
    reply = await _call(ws, "nope.method", id_=3)
    assert "unknown method" in reply["error"]["message"]
    await ws.close()


async def test_secret_attached_to_provider(core):
    ws, _ = await _authed(core)
    reply = await _call(ws, "secrets.set", {"name": "gemini_1", "value": "AIzaTEST12345678",
                                            "provider": "gemini"})
    assert reply["result"]["ref"] == "keyring:gemini_1"
    assert "keyring:gemini_1" in core.config.provider("gemini").keys
    listed = await _call(ws, "secrets.list", id_=2)
    assert listed["result"][0]["masked"] == "AIza…5678"
    assert "AIzaTEST12345678" not in json.dumps(listed)
    await _call(ws, "secrets.delete", {"name": "gemini_1"}, id_=3)
    assert core.config.provider("gemini").keys == []
    await ws.close()
