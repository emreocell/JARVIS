import pytest

from jarvis.tools import verify as v


class Flaky(v.Verifier):
    def __init__(self):
        self.recovered = False

    async def check(self, ctx, args, result, pre):
        return v.Verdict(self.recovered, "açıldı" if self.recovered else "pencere yok")

    async def recover(self, ctx, args, result, pre):
        self.recovered = True
        return {"recovery": "Başlat menüsünden tekrar denedim"}


class Broken(v.Verifier):
    async def check(self, ctx, args, result, pre):
        return v.Verdict(False, "değişiklik yok")


async def _noop(*a, **k):
    pass


@pytest.mark.asyncio
async def test_recovery_then_verified(monkeypatch):
    monkeypatch.setitem(v.VERIFIERS, "t_flaky", Flaky())

    async def act():
        return {"output": "Açılıyor."}
    out = await v.run_verified("t_flaky", None, {}, act, _noop)
    assert out["verified"] is True and out["recovery"].startswith("Başlat") and "problem" not in out


@pytest.mark.asyncio
async def test_failure_is_reported_honestly(monkeypatch):
    monkeypatch.setitem(v.VERIFIERS, "t_broken", Broken())

    async def act():
        return {"output": "Tamam."}
    out = await v.run_verified("t_broken", None, {}, act, _noop)
    assert out["verified"] is False and "doğrulayamadım" in out["problem"]


@pytest.mark.asyncio
async def test_errors_and_unknown_tools_pass_through(monkeypatch):
    monkeypatch.setitem(v.VERIFIERS, "t_broken", Broken())

    async def err():
        return {"error": "yok"}
    assert await v.run_verified("t_broken", None, {}, err, _noop) == {"error": "yok"}

    async def ok():
        return {"output": "x"}
    assert await v.run_verified("no_such_tool", None, {}, ok, _noop) == {"output": "x"}
