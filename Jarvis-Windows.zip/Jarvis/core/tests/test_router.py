from types import SimpleNamespace

import pytest

from jarvis.brain.router import DIRECT, IntentRouter, Route


def _core(answers, exc=None):
    async def decide(state, questions):
        if exc:
            raise exc
        assert set(questions) == {"direct", "area"}
        return {"answers": answers}
    features = SimpleNamespace(jev_decider=True, jev_router=True)
    return SimpleNamespace(config=SimpleNamespace(features=features), providers=SimpleNamespace(decide=decide),
                           context=None)


@pytest.mark.asyncio
async def test_direct_route_when_confident():
    r = await IntentRouter(_core({"direct": {"choice": "next", "confidence": 0.95},
                                  "area": {"choice": "media", "confidence": 0.9}})).route("şarkıyı geç")
    assert r.kind == "direct" and r.tool == "media_control" and r.args == {"action": "next"}


@pytest.mark.asyncio
async def test_area_route_and_fallbacks():
    r = await IntentRouter(_core({"direct": {"choice": "yok", "confidence": 0.9},
                                  "area": {"choice": "mail", "confidence": 0.8}})).route("ahmet'e mail yaz")
    assert r.kind == "area" and r.area == "mail"
    r = await IntentRouter(_core({"direct": {"choice": "next", "confidence": 0.5},
                                  "area": {"choice": "birden_fazla", "confidence": 0.9}})).route("x")
    assert r.kind == "full"
    r = await IntentRouter(_core({}, exc=RuntimeError("503"))).route("x")
    assert r.kind == "full"


def test_tools_for_area_keeps_core_tools():
    specs = [SimpleNamespace(name=n, category=c, skill="s") for n, c in
             [("gmail_send", "mail"), ("play_spotify", "media"), ("confirm_pending_action", "system")]]
    names = {s.name for s in IntentRouter.tools_for(Route("area", area="mail"), specs)}
    assert names == {"gmail_send", "confirm_pending_action"}
    assert all(t for t, _, _ in DIRECT.values())


def test_direct_answers_are_formatted_locally():
    from jarvis.brain.router import spoken

    assert spoken("current_time", {"time": "09:15"}, {}) == "Saat 09:15."
    assert spoken("media_control", {"output": "Tamam."}, {"action": "next"}) == "Sonrakine geçtim."
    assert spoken("list_windows", {"windows": ["Jarvis", "Spotify"]}, {}) == "Açık pencereler: Spotify."
    assert spoken("list_reminders", {"items": []}, {}) == "Kurulu hatırlatıcın yok."
    assert spoken("get_weather", {"error": "x"}, {}) is None
    assert spoken("gmail_unread", {"mails": []}, {}) is None   # needs the LLM to summarise


def test_catalog_retrieval_finds_multi_tool_candidates():
    from types import SimpleNamespace as NS

    from jarvis.brain.router import IntentRouter

    specs = [NS(name="set_reminder", category="routines", description="Hatırlatıcı kurar.", skill="r"),
             NS(name="gmail_search", category="mail", description="Gmail'de mail arar (fatura, ödeme…).", skill="g"),
             NS(name="play_spotify", category="media", description="Spotify'da şarkı çalar.", skill="m")]
    route = IntentRouter.retrieve("faturayı mailde bul ve bana hatırlat", specs, k=5)
    assert route.kind == "set" and set(route.names) >= {"set_reminder", "gmail_search"}
    assert "play_spotify" not in route.names
