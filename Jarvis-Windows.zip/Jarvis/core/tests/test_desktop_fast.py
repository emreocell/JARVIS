from jarvis.browser import fast
from jarvis.skills import desktop_control as dc


def test_position_words():
    assert dc.position(0.9, 0.05) == "sağ üst"
    assert dc.position(0.1, 0.9) == "sol alt"
    assert dc.position(0.5, 0.5) == "orta"
    assert dc.position(0.5, 0.1) == "üst"


def test_candidates_rank_positional_field_first():
    snap = {"window": "VS Code", "items": [
        {"id": 1, "type": "Edit", "name": "metin/kod editörü (a.md)", "value": "", "pos": "üst"},
        {"id": 2, "type": "Edit", "name": "sohbet giriş kutusu", "value": "", "pos": "sağ alt"},
        {"id": 3, "type": "Button", "name": "New Chat", "value": "", "pos": "sağ üst"},
    ]}
    cand = dc.as_candidates(snap)
    assert {it["role"] for it in cand["items"]} == {"textbox", "button"}
    fields = [it for it in cand["items"] if it["role"] in dc.TEXT_ROLES]
    assert fast.rank(fields, "sağdaki sohbet kutusu")[0]["id"] == 2
