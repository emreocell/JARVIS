from jarvis import launcher


def test_rank_prefers_prefix_word_start_and_initials():
    assert launcher.rank("spo", "Spotify") > launcher.rank("spo", "Microsoft Solitaire")
    assert launcher.rank("studio", "Visual Studio Code") >= 0.88
    assert launcher.rank("vsc", "Visual Studio Code") == 0.84
    assert launcher.rank("xyz", "Spotify") == 0.0


def test_calculator_is_safe_and_turkish_friendly():
    assert launcher.calculate("12*7+3") == 87
    assert launcher.calculate("2^10") == 1024
    assert launcher.calculate("%18 250") == 45
    assert launcher.calculate("3,5*2") == 7
    assert launcher.calculate("sqrt(16)") == 4
    assert launcher.calculate("__import__('os')") is None
    assert launcher.calculate("spotify") is None
    assert launcher.calculate("2024") is None  # a bare number is not a calculation
    assert launcher.calculate("9**99999") is None
    assert launcher.format_number(13911.625) == "13.911,625"


def test_search_orders_results_and_always_offers_ask_and_web(monkeypatch):
    monkeypatch.setattr(launcher, "recent_files", lambda limit=200: [])
    monkeypatch.setattr(launcher, "frecency", lambda item: 0.0)
    apps = [("Spotify", "spotify!app"), ("Steam", "steam"), ("Ayarlar", "settings")]
    r = launcher.search("spo", apps)
    assert r[0]["title"] == "Spotify" and r[-2]["kind"] == "ask" and r[-1]["kind"] == "web"
    r = launcher.search("sesi 30 yap", apps, fast_preview="Sesi %30 yap")
    assert r[0]["kind"] == "action"
    assert launcher.search("   ", apps) == []


def test_frecency_boosts_used_items(monkeypatch, tmp_path):
    monkeypatch.setattr(launcher, "_usage_path", lambda: tmp_path / "u.json")
    monkeypatch.setattr(launcher, "_usage", None)
    assert launcher.frecency("app:x") == 0
    for _ in range(3):
        launcher.record_use("app:x")
    assert 0.08 < launcher.frecency("app:x") <= 0.12
