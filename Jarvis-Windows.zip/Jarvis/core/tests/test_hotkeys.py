import pytest

from jarvis.hotkeys import MOD_NOREPEAT, parse


def test_parse_combos():
    assert parse("ctrl+alt+space") == (MOD_NOREPEAT | 0x0002 | 0x0001, 0x20)
    assert parse("Alt+Space") == (MOD_NOREPEAT | 0x0001, 0x20)
    assert parse("ctrl+alt+j") == (MOD_NOREPEAT | 0x0003, ord("J"))
    assert parse("win+f5")[1] == 0x74


@pytest.mark.parametrize("bad", ["ctrl+alt", "ctrl+banana", ""])
def test_parse_rejects(bad):
    with pytest.raises(ValueError):
        parse(bad)
