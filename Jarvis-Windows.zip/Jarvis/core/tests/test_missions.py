import asyncio
import json
from types import SimpleNamespace

import pytest

from jarvis.bus import EventBus
from jarvis.missions.engine import MissionEngine


def resp(parts, text=""):
    return SimpleNamespace(raw={"content": {"role": "model", "parts": parts}, "parts": parts}, text=text, model="m")


@pytest.mark.asyncio
async def test_mission_plans_acts_and_reports():
    calls = []
    script = [
        resp([{"functionCall": {"name": "take_note", "args": {"text": "3 kafe"}}}]),
        resp([{"functionCall": {"name": "mission_step_done", "args": {"step": 1, "note": "not alındı"}}}]),
        resp([{"functionCall": {"name": "mission_finish", "args": {"report": "3 kafe not edildi.", "success": True}}}]),
    ]

    async def chat(role, req):
        return SimpleNamespace(text=json.dumps({"title": "Kafe araştırması", "steps": ["Not al"]}))

    async def route(role, fn, **kw):
        return script.pop(0)

    async def execute(name, args, source="text"):
        calls.append((name, source))
        return {"output": "Not alındı."}

    announced = []

    async def notify(text):
        announced.append(text)

    spec = SimpleNamespace(name="take_note", description="Not al.", parameters={"properties": {"text": {}}},
                           category="notes", skill="notes")
    core = SimpleNamespace(bus=EventBus(), providers=SimpleNamespace(chat=chat, route=route),
                           tools=SimpleNamespace(enabled=lambda: [spec], execute=execute),
                           config=SimpleNamespace(assistant=SimpleNamespace(user_name="Emre", location="")),
                           notify_brain=notify, enable_voice=False)
    engine = MissionEngine(core)
    m = await engine.start("Samsun'da 3 kafe araştır ve not al")
    await asyncio.wait_for(engine._tasks[m.id], 5)
    assert m.status == "done" and m.report == "3 kafe not edildi."
    assert m.steps[0]["status"] == "done" and calls == [("take_note", "mission")]
    assert announced and "Kafe araştırması" in announced[0]
