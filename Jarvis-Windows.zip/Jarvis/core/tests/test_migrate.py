from jarvis.migrate import collect_keys


def test_collect_keys_dedupes_and_skips_empty():
    raw = {
        "gemini_api_key": "A",
        "gemini_secondary_api_key": "B",
        "gemini_extra_api_keys": ["", "A", "C"],
        "groq_api_key": "G",
        "nvidia_api_key": "",
        "voice": "Charon",
    }
    assert collect_keys(raw) == [("gemini", "A"), ("gemini", "B"), ("groq", "G"), ("gemini", "C")]
