import pytest

from jarvis.integrations.spotify import REFRESH_SECRET, SpotifyClient, SpotifyError
from jarvis.secrets import SecretStore


class FakeSpotify(SpotifyClient):
    def __init__(self, devices_after_open=True):
        super().__init__(SecretStore(), "cid")
        self.calls = []
        self.opened = False
        self.devices_after_open = devices_after_open

    async def api(self, method, path, **kw):
        self.calls.append((method, path, kw.get("params"), kw.get("json")))
        if path == "/search":
            kind = kw["params"]["type"]
            return {f"{kind}s": {"items": [{"uri": f"spotify:{kind}:1", "name": "Numb",
                                            "artists": [{"name": "Linkin Park"}]}]}}
        if path == "/me/player/play" and not (kw.get("params") or {}).get("device_id"):
            raise SpotifyError("no_device")
        if path == "/me/player/devices":
            return {"devices": [{"id": "pc", "type": "Computer"}] if self.opened and self.devices_after_open else []}
        return {}


async def open_app(client):
    client.opened = True


async def test_play_transfers_to_desktop_after_opening_app():
    sp = FakeSpotify()
    name = await sp.play("numb", "track", ensure_device=lambda: open_app(sp))
    assert name == "Numb — Linkin Park"
    assert sp.calls[-1] == ("PUT", "/me/player/play", {"device_id": "pc"}, {"uris": ["spotify:track:1"]})


async def test_album_uses_context_uri_and_no_device_error():
    sp = FakeSpotify(devices_after_open=False)
    with pytest.raises(SpotifyError, match="cihaz"):
        await sp.play("meteora", "album", ensure_device=lambda: open_app(sp))
    assert ("PUT", "/me/player/play", None, {"context_uri": "spotify:album:1"}) in sp.calls


def test_linked_requires_client_id_and_refresh_token():
    s = SecretStore()
    sp = SpotifyClient(s, None)
    assert not sp.linked
    s.set(REFRESH_SECRET, "r")
    assert not sp.linked
    sp.client_id = "cid"
    assert sp.linked
    sp.unlink()
    assert not sp.linked


def test_already_playing_detection():
    from jarvis.skills.media import _mentions

    assert _mentions("Pink Floyd Time", "Time Pink Floyd")
    assert not _mentions("Pink Floyd Time", "Money Pink Floyd")
    assert not _mentions("a", "anything")
