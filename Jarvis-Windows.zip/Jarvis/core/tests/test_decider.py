import asyncio
import json
from types import SimpleNamespace

from jarvis.brain.decider import Decider
from jarvis.bus import EventBus
from jarvis.config.schema import AppConfig
from jarvis.providers.base import ProviderError


class FakeProviders:
    def __init__(self, jev_choice="b", jev_conf=0.9, jev_fail=False, llm_choice="a"):
        self.jev_choice, self.jev_conf, self.jev_fail, self.llm_choice = jev_choice, jev_conf, jev_fail, llm_choice
        self.llm_calls = 0
        self.jev_calls = 0

    async def decide(self, state, questions):
        self.jev_calls += 1
        if self.jev_fail:
            raise ProviderError("jev down")
        return {"answers": {"q": {"type": "choice", "choice": self.jev_choice, "confidence": self.jev_conf,
                                  "probabilities": {self.jev_choice: self.jev_conf}}}, "latency_ms": 5}

    async def chat(self, role, request):
        self.llm_calls += 1
        return SimpleNamespace(text=json.dumps({"choice": self.llm_choice, "confidence": 0.8}))


def make(**kw):
    cfg = AppConfig()
    core = SimpleNamespace(config=cfg, providers=FakeProviders(**kw), bus=EventBus())
    return Decider(core), core


OPTS = {"a": "birinci", "b": "ikinci"}


async def test_shadow_mode_uses_llm_and_records_agreement():
    d, core = make(jev_choice="a")
    out = await d.choose("durum", "hangisi?", OPTS)
    assert out.source == "llm" and out.choice == "a"
    await asyncio.gather(*d._shadow_tasks)
    assert d.stats.as_dict()["agreement"] == 1.0


async def test_live_mode_uses_confident_jev_and_falls_back():
    d, core = make(jev_choice="b", jev_conf=0.9)
    core.config.features.jev_shadow_mode = False
    out = await d.choose("durum", "?", OPTS)
    assert out.source == "jev" and out.choice == "b" and core.providers.llm_calls == 0
    d2, core2 = make(jev_conf=0.3)  # low confidence -> llm
    core2.config.features.jev_shadow_mode = False
    assert (await d2.choose("durum", "?", OPTS)).source == "llm"
    d3, core3 = make(jev_fail=True)  # jev down -> llm
    core3.config.features.jev_shadow_mode = False
    assert (await d3.choose("durum", "?", OPTS)).source == "llm"


async def test_compare_costs_no_llm_call():
    d, core = make(jev_choice="b")
    d.compare("durum", "?", OPTS, reference="a")
    await asyncio.gather(*d._shadow_tasks)
    assert core.providers.llm_calls == 0 and core.providers.jev_calls == 1
    assert d.stats.as_dict()["agreement"] == 0.0
