"""Voice state machine tests with fake audio, wake word, VAD and Live session."""

import asyncio
import queue

import numpy as np
import pytest

from jarvis.bus import EventBus
from jarvis.config.schema import VoiceSettings
from jarvis.voice.controller import VoiceController, VoiceState, similar
from jarvis.voice.detect import Endpointer

WAKE, SPEECH, SILENCE = 3, 2, 1  # marker value in frame[0]


def frame(kind: int) -> np.ndarray:
    f = np.zeros(1280, dtype=np.int16)
    f[0] = kind
    if kind == SPEECH:
        f[1:] = 8000  # loud enough to pass the barge-in energy gate
    return f


class FakeMic:
    def __init__(self):
        self.frames = queue.Queue()
        self.running = False

    def start(self):
        self.running = True

    def stop(self):
        self.running = False

    def feed(self, kind: int, n: int = 1):
        for _ in range(n):
            self.frames.put(frame(kind))


class FakeSpeaker:
    def __init__(self):
        self.chunks = []
        self.level = 0.0
        self.cleared = 0

    def write(self, pcm):
        self.chunks.append(pcm)

    def clear(self):
        self.chunks.clear()
        self.cleared += 1

    def playing(self, tail=0.0):
        return bool(self.chunks)

    def stop(self):
        self.clear()


class FakeWake:
    def process(self, f):
        return "hey jarvis" if f[0] == WAKE else None

    def reset(self):
        pass


def fake_vad(f):
    return 1.0 if f[0] == SPEECH else 0.0


class FakeLive:
    instances = []

    def __init__(self, keys, settings, cb):
        self.cb = cb
        self.connected = False
        self.log = []
        FakeLive.instances.append(self)

    async def connect(self):
        self.connected = True
        self.log.append("connect")

    async def close(self, reason="idle"):
        self.connected = False
        self.log.append(f"close:{reason}")
        self.cb.on_closed(reason)

    async def activity_start(self):
        self.log.append("start")

    async def activity_end(self):
        self.log.append("end")

    async def send_audio(self, pcm):
        self.log.append("audio")

    async def send_text(self, text):
        self.log.append(f"text:{text}")


async def wait_for(pred, timeout=2.0):
    loop = asyncio.get_running_loop()
    end = loop.time() + timeout
    while not pred():
        if loop.time() > end:
            raise AssertionError("condition not met")
        await asyncio.sleep(0.01)


@pytest.fixture
async def vc():
    FakeLive.instances.clear()
    settings = VoiceSettings(echo_profile="half_duplex", follow_up_seconds=0.3, session_idle_seconds=5)
    c = VoiceController(EventBus(), settings, lambda: [("k", "s")], lambda: "sys",
                        mic=FakeMic(), speaker=FakeSpeaker(), wake=FakeWake(), vad=fake_vad,
                        live_factory=FakeLive)
    await c.start()
    yield c
    await c.stop()


async def test_idle_does_not_touch_cloud(vc):
    vc.mic.feed(SILENCE, 20)
    vc.mic.feed(SPEECH, 10)  # speech without wake word is ignored in idle
    await asyncio.sleep(0.2)
    assert vc.state is VoiceState.IDLE
    assert FakeLive.instances == []


async def test_full_turn_wake_listen_think_speak_followup_idle(vc):
    vc.mic.feed(WAKE)
    await wait_for(lambda: vc.state is VoiceState.ARMED)
    vc.mic.feed(SPEECH, 5)
    await wait_for(lambda: vc.state is VoiceState.LISTENING)
    vc.mic.feed(SILENCE, 12)  # > 0.7 s of silence
    await wait_for(lambda: vc.state is VoiceState.THINKING)
    live = FakeLive.instances[0]
    await wait_for(lambda: "end" in live.log)
    assert live.log[:2] == ["connect", "start"]
    assert live.log[-1] == "end"  # ordered outbox: nothing after activity_end
    assert "end" in live.log and live.log.count("audio") >= 5

    live.cb.on_audio(b"\x00\x01" * 100)
    assert vc.state is VoiceState.SPEAKING
    live.cb.on_turn_complete()
    vc.speaker.chunks.clear()  # playback finished
    await wait_for(lambda: vc.state is VoiceState.FOLLOW_UP)
    await wait_for(lambda: vc.state is VoiceState.IDLE)


async def test_half_duplex_ignores_mic_while_speaking(vc):
    vc.mic.feed(WAKE)
    vc.mic.feed(SPEECH, 4)
    await wait_for(lambda: vc.state is VoiceState.LISTENING)
    vc.mic.feed(SILENCE, 12)
    await wait_for(lambda: vc.state is VoiceState.THINKING)
    live = FakeLive.instances[0]
    live.cb.on_audio(b"\x00\x01" * 100)
    starts = live.log.count("start")
    vc.mic.feed(SPEECH, 10)  # our own voice through the speakers
    await asyncio.sleep(0.2)
    assert vc.state is VoiceState.SPEAKING
    assert live.log.count("start") == starts
    assert vc.speaker.cleared == 0


async def test_full_duplex_barge_in(vc):
    vc.settings = VoiceSettings(echo_profile="full_duplex", follow_up_seconds=0.3)
    vc._profile = vc._resolve_profile()
    vc.mic.feed(WAKE)
    vc.mic.feed(SPEECH, 4)
    await wait_for(lambda: vc.state is VoiceState.LISTENING)
    vc.mic.feed(SILENCE, 12)
    await wait_for(lambda: vc.state is VoiceState.THINKING)
    live = FakeLive.instances[0]
    live.cb.on_audio(b"\x00\x01" * 100)
    vc.mic.feed(SPEECH, 4)  # user talks over Jarvis
    await wait_for(lambda: vc.state is VoiceState.LISTENING)
    assert vc.speaker.cleared >= 1
    await wait_for(lambda: live.log.count("start") == 2)


async def test_armed_timeout_returns_to_idle(vc, monkeypatch):
    monkeypatch.setattr("jarvis.voice.controller.ARMED_TIMEOUT", 0.2)
    vc.mic.feed(WAKE)
    await wait_for(lambda: vc.state is VoiceState.ARMED)
    await wait_for(lambda: vc.state is VoiceState.IDLE)
    assert "start" not in FakeLive.instances[0].log  # never streamed silence


async def test_push_to_talk_ignores_vad_end(vc):
    await vc.push_to_talk(True)
    assert vc.state is VoiceState.LISTENING
    await wait_for(lambda: FakeLive.instances and "start" in FakeLive.instances[0].log)
    vc.mic.feed(SPEECH, 2)
    vc.mic.feed(SILENCE, 15)
    await asyncio.sleep(0.2)
    assert vc.state is VoiceState.LISTENING  # held key keeps the turn open
    await vc.push_to_talk(False)
    assert vc.state is VoiceState.THINKING


async def test_session_closes_after_idle(vc):
    vc.settings = VoiceSettings(follow_up_seconds=0, session_idle_seconds=5)
    await vc.say("merhaba")
    await wait_for(lambda: FakeLive.instances and "text:merhaba" in FakeLive.instances[0].log)
    live = FakeLive.instances[0]
    live.cb.on_turn_complete()
    assert vc.state is VoiceState.IDLE
    vc._timers["close"].cancel()
    await vc._close_live()
    assert live.log[-1] == "close:idle"


def test_endpointer():
    ep = Endpointer(start_frames=2, end_silence=0.24, frame_seconds=0.08)
    assert ep.update(0.9) is None
    assert ep.update(0.9) == "start"
    assert [ep.update(0.1) for _ in range(3)] == [None, None, "end"]


def test_similarity():
    assert similar("bugün hava güzel", "Bugün hava güzel, dışarı çıkabilirsin") == 1.0
    assert similar("müziği aç", "hava durumu yağmurlu") < 0.5


async def test_live_drops_transcription_hints_when_rejected(monkeypatch):
    from jarvis.voice import live as live_mod

    configs = []

    class FakeCM:
        def __init__(self, config):
            self.config = config

        async def __aenter__(self):
            configs.append(self.config)
            if self.config.input_audio_transcription.language_codes:
                raise RuntimeError('1007 Invalid JSON payload received. Unknown name "languageCodes"')
            return object()

        async def __aexit__(self, *a):
            return False

    class FakeClient:
        def __init__(self, **kw):
            self.aio = type("A", (), {"live": type("L", (), {"connect": staticmethod(
                lambda model, config: FakeCM(config))})()})()

    monkeypatch.setattr(live_mod.genai, "Client", FakeClient)
    session = live_mod.LiveSession(lambda: [("k1", "secret")],
                                   live_mod.LiveSettings("m", "v", "tr-TR", "sys", []), None)

    async def no_loop():
        return None

    monkeypatch.setattr(session, "_receive_loop", no_loop)
    await session.connect()
    assert session.connected and len(configs) == 2
    assert configs[0].input_audio_transcription.language_codes == ["tr-TR", "en-US"]
    assert not configs[1].input_audio_transcription.language_codes


async def test_tool_call_turn_complete_does_not_end_the_turn(vc):
    events = []
    vc.bus.subscribe("voice.turn_complete", lambda e: events.append(dict(e.data)))
    vc.mic.feed(WAKE)
    await wait_for(lambda: vc.state is VoiceState.ARMED)
    vc.mic.feed(SPEECH, 5)
    vc.mic.feed(SILENCE, 12)
    await wait_for(lambda: vc.state is VoiceState.THINKING)
    vc._on_input_text("Saat kaç?")
    await vc._on_tool_call([])          # model calls a tool…
    vc._on_turn_complete()               # …and Live closes that turn without speech
    await asyncio.sleep(0.05)
    assert events == [] and vc.state is VoiceState.THINKING
    vc._on_output_text("Saat on.")       # continuation turn with the answer
    vc._on_turn_complete()
    await asyncio.sleep(0.05)
    assert events == [{"user": "Saat kaç?", "assistant": "Saat on."}]
