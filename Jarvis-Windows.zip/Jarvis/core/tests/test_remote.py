from types import SimpleNamespace

from jarvis.bus import EventBus
from jarvis.config.schema import AppConfig
from jarvis.remote.telegram import TOKEN_SECRET, TelegramRemote
from jarvis.secrets import SecretStore


def make():
    cfg = AppConfig()
    core = SimpleNamespace(bus=EventBus(), config=cfg, secrets=SecretStore())
    return TelegramRemote(core), core


async def test_status_without_token_and_sync_does_nothing():
    remote, core = make()
    core.config.features.telegram_remote = True
    await remote.sync()  # no token -> not started, no network
    s = remote.status()
    assert s["running"] is False and s["has_token"] is False
    assert len(s["pair_code"]) == 6 and s["pair_code"].isdigit()


async def test_forwarding_is_silent_when_not_running():
    remote, core = make()
    core.secrets.set(TOKEN_SECRET, "123:abc")
    core.config.remote.telegram_allowed_ids = [42]
    # not started: publishing approval/reminder events must not raise or try to send
    await core.bus.publish("approval.requested", token="t", summary="x", source="routine")
    await core.bus.publish("routine.fired", kind="alarm", text="uyan")
    assert remote.status()["allowed"] == [42]
