import wave
from pathlib import Path

import numpy as np
import pytest

CLIP = Path(__file__).parent / "fixtures" / "hey_jarvis_16k.wav"


@pytest.fixture(scope="module")
def engine():
    pytest.importorskip("openwakeword")
    from jarvis.voice.detect import OpenWakeWordEngine, PhraseSpec

    try:
        eng = OpenWakeWordEngine([PhraseSpec("hey jarvis", 0.5)], refractory=0)
    except Exception as exc:  # model files not downloaded on this machine
        pytest.skip(f"openWakeWord model unavailable: {exc}")
    return eng


def test_one_phrase_fires_exactly_once(engine):
    with wave.open(str(CLIP)) as w:
        audio = np.frombuffer(w.readframes(w.getnframes()), np.int16)
    frames = np.concatenate([np.zeros(12800, np.int16), audio, np.zeros(1280 * 40, np.int16)])
    engine.reset()
    hits = sum(1 for i in range(0, len(frames) - 1280, 1280) if engine.process(frames[i:i + 1280]))
    assert hits == 1  # Model.reset() alone left the phrase in the feature buffer -> fired twice
