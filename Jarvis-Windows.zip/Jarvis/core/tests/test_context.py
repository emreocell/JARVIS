import pytest
import time

from jarvis.context.tracker import ContextTracker, Focus, project_of


def test_project_from_editor_titles():
    assert project_of(Focus(0, "VS Code", "app.py - jarvis - Visual Studio Code", "Code.exe")) == "jarvis"
    assert project_of(Focus(0, "PyCharm", "backend – main.py", "pycharm64.exe")) == "backend"
    assert project_of(Focus(0, "Opera GX", "YouTube - Opera", "opera.exe")) is None


def test_summary_durations_and_projects():
    t = ContextTracker()
    now = time.time()
    t.history.extend([
        Focus(now - 1800, "VS Code", "a.py - jarvis - Visual Studio Code", "Code.exe"),
        Focus(now - 600, "Opera GX", "Docs - Opera", "opera.exe"),
        Focus(now - 300, "VS Code", "b.py - jarvis - Visual Studio Code", "Code.exe"),
    ])
    t.current = lambda: t.history[-1]  # type: ignore[method-assign]
    s = t.summary(60)
    apps = {a["app"]: a["minutes"] for a in s["apps_last_hour"]}
    assert 24 < apps["VS Code"] < 26 and 4.9 < apps["Opera GX"] < 5.1
    assert s["projects"] == ["jarvis"]
    assert s["active"]["project"] == "jarvis"


def test_excluded_apps_are_hidden():
    t = ContextTracker(excluded=["Bitwarden"])
    f = t._make_focus("Bitwarden.exe", "Kasa - Bitwarden")
    assert f.title == "(gizli)"
    assert t._make_focus("Code.exe", "x - y - Visual Studio Code").app == "VS Code"


@pytest.mark.parametrize("title,expected", [
    ("main.py - jarvis - Visual Studio Code", "jarvis"),
    ("jarvis - Visual Studio Code", "jarvis"),
    ("Release Notes: 1.138.0 - Visual Studio Code", None),
    ("Hoş Geldiniz - Visual Studio Code", None),
    ("notes.md - Visual Studio Code", None),
    ("● app.tsx - web-shop - Visual Studio Code", "web-shop"),
])
def test_project_parsing_ignores_editor_tabs(title, expected):
    from jarvis.context.tracker import Focus, project_of

    assert project_of(Focus(ts=0.0, app="VS Code", title=title, exe="Code.exe")) == expected
