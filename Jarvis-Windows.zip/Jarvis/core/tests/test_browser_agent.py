import json
from types import SimpleNamespace

import pytest

from jarvis.skills import browser as mod
from jarvis.tools import ToolContext


class FakeSession:
    def __init__(self, pages):
        self.pages = pages
        self.i = 0
        self.log = []

    async def ensure(self, mode="jarvis_profile"):
        return None

    async def goto(self, url, mode="jarvis_profile"):
        self.log.append(("goto", url))

    async def snapshot(self, max_items=160):
        return self.pages[min(self.i, len(self.pages) - 1)]

    async def click(self, element_id):
        self.log.append(("click", element_id))
        self.i += 1

    async def type(self, element_id, text, submit=False):
        self.log.append(("type", element_id, text, submit))
        self.i += 1


def page(items, text=""):
    return {"url": "https://shop.test", "title": "Shop", "text": text,
            "items": [{"id": i, "role": r, "label": l} for i, r, l in items]}


class FakeProviders:
    def __init__(self, actions):
        self.actions = list(actions)
        self.prompts = []

    async def chat(self, role, request):
        self.prompts.append(request.messages[-1].content)
        return SimpleNamespace(text=json.dumps(self.actions.pop(0)))


def ctx_with(actions):
    async def publish(*a, **k):
        return None

    core = SimpleNamespace(
        providers=FakeProviders(actions),
        bus=SimpleNamespace(publish=publish),
        config=SimpleNamespace(features=SimpleNamespace(browser_access=SimpleNamespace(value="jarvis_profile"))),
    )
    return ToolContext(core=core)


@pytest.fixture
def fake(monkeypatch):
    def install(pages):
        s = FakeSession(pages)
        monkeypatch.setattr(mod, "_session", s)
        return s
    return install


async def test_agent_searches_and_reports(fake):
    s = fake([
        page([(1, "text", "Ara"), (2, "button", "Bul")]),
        page([(1, "link", "SSD 2TB - 2.999 TL")], text="SSD 2TB 2.999 TL"),
    ])
    ctx = ctx_with([
        {"thought": "arama kutusuna yaz", "action": "type", "id": 1, "text": "2tb ssd", "submit": True},
        {"thought": "fiyat görünüyor", "action": "done", "answer": "En ucuzu 2.999 TL."},
    ])
    out = await mod.run_browser_agent(ctx, "2TB SSD fiyatı", "shop.test")
    assert out["output"] == "En ucuzu 2.999 TL."
    assert s.log == [("goto", "shop.test"), ("type", 1, "2tb ssd", True)]
    assert "<page>" in ctx.core.providers.prompts[0]  # page content is fenced as untrusted


async def test_agent_stops_before_risky_click(fake):
    s = fake([page([(7, "button", "Satın al")])])
    ctx = ctx_with([{"thought": "al", "action": "click", "id": 7}])
    out = await mod.run_browser_agent(ctx, "satın al", None)
    assert "onayın gerekiyor" in out["output"]
    assert ("click", 7) not in s.log


async def test_agent_invalid_id_and_step_limit(fake):
    fake([page([(1, "button", "A")])])
    ctx = ctx_with([{"thought": "x", "action": "click", "id": 99}] * 3)
    out = await mod.run_browser_agent(ctx, "hedef", None, max_steps=3)
    assert out["error"] == "Adım sınırına ulaşıldı."
    assert all("geçersiz" in h for h in out["steps"])


def test_risky_labels():
    assert mod.RISKY_LABEL.search("Siparişi tamamla")
    assert mod.RISKY_LABEL.search("Place order")
    assert not mod.RISKY_LABEL.search("Ürünleri listele")
