import asyncio

import pytest

from jarvis.bus import EventBus
from jarvis.secrets import SecretStore, mask


def test_secret_roundtrip_and_index():
    s = SecretStore()
    ref = s.set("gemini_1", "  AIzaSyABCDEF123456  ")
    assert ref == "keyring:gemini_1"
    assert s.resolve(ref) == "AIzaSyABCDEF123456"
    assert s.names() == ["gemini_1"]
    assert s.describe()[0]["masked"] == "AIza…3456"
    s.delete("gemini_1")
    assert s.resolve(ref) is None and s.names() == []


def test_secret_validation():
    s = SecretStore()
    with pytest.raises(ValueError):
        s.set("bad name!", "x")
    with pytest.raises(ValueError):
        s.set("ok", "   ")


def test_mask_short():
    assert mask("abc") == "•••"


async def test_bus_wildcards_and_error_isolation():
    bus = EventBus()
    got: list[str] = []

    def boom(e):
        raise RuntimeError("handler bug")

    async def record(e):
        got.append(e.topic)

    bus.subscribe("voice.*", boom)
    bus.subscribe("voice.*", record)
    bus.subscribe("*", record)
    unsub = bus.subscribe("config.changed", record)
    await bus.publish("voice.state", state="listening")
    unsub()
    await bus.publish("config.changed")
    assert got == ["voice.state", "voice.state", "config.changed"]


async def test_emit_threadsafe():
    bus = EventBus()
    bus.bind_loop(asyncio.get_running_loop())
    done = asyncio.Event()
    bus.subscribe("x", lambda e: done.set())
    await asyncio.to_thread(bus.emit_threadsafe, "x")
    await asyncio.wait_for(done.wait(), 1)
