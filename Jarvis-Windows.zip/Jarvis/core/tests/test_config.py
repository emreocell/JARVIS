import json

import pytest
from pydantic import ValidationError

from jarvis import paths
from jarvis.bus import EventBus
from jarvis.config import AppConfig, ConfigStore
from jarvis.config.store import deep_merge


def test_defaults_written_on_first_load():
    store = ConfigStore(paths.config_path())
    cfg = store.load()
    assert cfg.voice.wake_words[0].phrase == "hey jarvis"
    assert paths.config_path().exists()


def test_bom_file_is_accepted():
    data = AppConfig().model_dump(mode="json")
    data["voice"]["follow_up_seconds"] = 12
    paths.config_path().write_text(json.dumps(data), encoding="utf-8-sig")
    assert ConfigStore(paths.config_path()).load().voice.follow_up_seconds == 12


def test_invalid_file_is_backed_up():
    paths.config_path().write_text("{not json", encoding="utf-8")
    cfg = ConfigStore(paths.config_path()).load()
    assert cfg == AppConfig()
    assert list(paths.data_dir().glob("config.invalid-*.json"))


async def test_patch_validates_and_publishes():
    bus = EventBus()
    seen = []
    bus.subscribe("config.changed", lambda e: seen.append(e.data))
    store = ConfigStore(paths.config_path(), bus)
    store.load()
    await store.patch({"voice": {"echo_profile": "half_duplex"}})
    assert store.config.voice.echo_profile == "half_duplex"
    assert seen and seen[0]["sections"] == ["voice"]
    with pytest.raises(ValidationError):
        await store.patch({"voice": {"follow_up_seconds": 999}})
    assert store.config.voice.follow_up_seconds == 8.0  # unchanged
    reloaded = ConfigStore(paths.config_path()).load()
    assert reloaded.voice.echo_profile == "half_duplex"


def test_deep_merge_replaces_lists():
    assert deep_merge({"a": {"b": 1, "c": [1, 2]}}, {"a": {"c": [3]}}) == {"a": {"b": 1, "c": [3]}}


def test_schema_has_turkish_titles():
    schema = AppConfig.model_json_schema()
    assert schema["$defs"]["VoiceSettings"]["properties"]["echo_profile"]["title"] == "Yankı / araya girme"
