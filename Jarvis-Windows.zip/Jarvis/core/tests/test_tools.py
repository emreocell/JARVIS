import asyncio
from typing import Annotated

import pytest

from jarvis import paths
from jarvis.bus import EventBus
from jarvis.tools import Risk, ToolContext, ToolRuntime, tool
from jarvis.tools.approval import ApprovalStore, is_affirmative
from jarvis.tools.guard import LoopGuard

calls: list[tuple] = []


@tool(risk=Risk.LOW, platforms=())
def set_volume(level: Annotated[int, "0-100 arası ses seviyesi"], mute: bool = False) -> dict:
    """Sistem sesini ayarlar."""
    calls.append(("set_volume", level, mute))
    return {"output": f"ses {level}"}


@tool(risk=Risk.SEND, platforms=())
async def send_message(contact: Annotated[str, "Kişi"], text: Annotated[str, "Mesaj"]) -> dict:
    """Mesaj gönderir."""
    calls.append(("send", contact, text))
    return {"output": "gönderildi"}


send_message._describe = lambda contact, text: f"{contact} kişisine “{text}” gönder"  # type: ignore[attr-defined]
send_message._fingerprint_keys = ("contact",)  # type: ignore[attr-defined]


@tool(risk=Risk.READ, platforms=(), timeout=0.1)
async def slow() -> str:
    """Yavaş araç."""
    await asyncio.sleep(1)
    return "never"


@tool(risk=Risk.READ, platforms=(), background=True)
async def long_job(ctx: ToolContext) -> str:
    """Uzun iş."""
    await asyncio.sleep(0.05)
    return f"bitti {ctx.call_id}"


@tool(risk=Risk.READ, platforms=("nonexistent-os",))
def windows_only() -> str:
    """Sadece başka platform."""
    return "x"


@pytest.fixture
def rt():
    calls.clear()
    bus = EventBus()
    r = ToolRuntime(bus, ApprovalStore(paths.data_dir() / "approvals.json"))
    for fn in (set_volume, send_message, slow, long_job, windows_only):
        r.register(fn.__tool__)
    return r


def test_schema_from_type_hints():
    decl = set_volume.__tool__.declaration()
    schema = decl["parameters_json_schema"]
    assert schema["properties"]["level"] == {"type": "integer", "description": "0-100 arası ses seviyesi"}
    assert schema["required"] == ["level"]
    assert "ctx" not in long_job.__tool__.parameters.get("properties", {})


def test_gemini_declarations_are_valid(rt):
    tools = rt.gemini_tools()
    names = {d.name for d in tools[0].function_declarations}
    assert {"set_volume", "send_message", "confirm_pending_action"} <= names
    assert "windows_only" not in names
    assert rt.unavailable["windows_only"].startswith("platform")


async def test_low_risk_runs_directly(rt):
    out = await rt.execute("set_volume", {"level": 30})
    assert out == {"output": "ses 30"}
    assert calls == [("set_volume", 30, False)]


async def test_send_requires_real_user_yes(rt):
    await rt.bus.publish("voice.transcript", role="user", text="Ahmet'e merhaba gönder", turn=1)
    out = await rt.execute("send_message", {"contact": "Ahmet", "text": "merhaba"})
    assert out["status"] == "needs_confirmation"
    token = out["token"]
    # the request itself ("... gönder") must not count as approval, even if it arrives late
    await rt.bus.publish("voice.transcript", role="user", text="Ahmet'e merhaba gönder, lütfen", turn=1)
    denied = await rt.execute("confirm_pending_action", {"token": token})
    assert "onayını duymadım" in denied["error"] and calls == []
    await rt.bus.publish("voice.transcript", role="user", text="evet", turn=2)
    ok = await rt.execute("confirm_pending_action", {"token": token})
    assert ok == {"output": "gönderildi"}
    assert calls == [("send", "Ahmet", "merhaba")]


async def test_user_says_no(rt):
    out = await rt.execute("send_message", {"contact": "Ali", "text": "x"})
    await rt.bus.publish("voice.transcript", role="user", text="hayır gönderme", turn=5)
    denied = await rt.execute("confirm_pending_action", {"token": out["token"]})
    assert "error" in denied and calls == []


async def test_ui_approval_and_remember(rt):
    out = await rt.execute("send_message", {"contact": "Ayşe", "text": "selam"})
    result = await rt.approve_from_ui(out["token"], allow=True, remember=True)
    assert result == {"output": "gönderildi"}
    # remembered per contact: no question the second time, even with a different text
    again = await rt.execute("send_message", {"contact": "Ayşe", "text": "nasılsın"})
    assert again == {"output": "gönderildi"}
    # other contacts still ask
    other = await rt.execute("send_message", {"contact": "Mehmet", "text": "selam"})
    assert other["status"] == "needs_confirmation"


async def test_timeout_and_background(rt):
    assert "bitmedi" in (await rt.execute("slow", {}))["error"]
    finished = asyncio.Event()
    rt.bus.subscribe("tool.finished", lambda e: e.data.get("background") and finished.set())
    notes = []

    async def notify(text):
        notes.append(text)

    rt.notify_brain = notify
    out = await rt.execute("long_job", {}, call_id="c1")
    assert out["status"] == "started"
    await asyncio.wait_for(finished.wait(), 1)
    await asyncio.sleep(0)
    assert "bitti c1" in notes[0]


async def test_unknown_tool(rt):
    assert "kullanılamıyor" in (await rt.execute("nope", {}))["error"]


def test_loop_guard():
    g = LoopGuard(max_repeats=3)
    assert [g.check("a", {"x": 1}) for _ in range(3)] == [None, None, None]
    assert g.check("a", {"x": 1}) is not None
    g.reset()
    assert g.check("a", {}) is None and g.check("b", {}) is None and g.check("a", {}) is None
    assert "döngü" in g.check("b", {})


@pytest.mark.parametrize("text,expected", [
    ("evet gönder", True), ("tamam", True), ("hayır", False), ("yok dur", False),
    ("bilmiyorum", None), ("evet ama hayır", False),
])
def test_affirmative(text, expected):
    assert is_affirmative(text) is expected


def test_every_visible_tool_has_a_human_title():
    """The UI never shows raw function names: new tools need an entry in titles.py."""
    import pathlib
    import tempfile

    from jarvis.bus import EventBus
    from jarvis.skills import BUILTIN_SKILLS
    from jarvis.tools import ToolRuntime
    from jarvis.tools.approval import ApprovalStore
    from jarvis.tools.titles import CATEGORIES, TOOLS

    rt = ToolRuntime(EventBus(), ApprovalStore(pathlib.Path(tempfile.mkdtemp()) / "a.json"))
    for module in BUILTIN_SKILLS:
        rt.register_module(module)
    specs = [s for s in rt.tools.values() if not s.hidden and not s.name.endswith("_pending_action")]
    assert not [s.name for s in specs if s.name not in TOOLS]
    assert not {s.category for s in specs} - set(CATEGORIES)
