import numpy as np

from jarvis.games import snake
from jarvis.games.vision import blobs


def test_blobs_find_disc_and_describe():
    img = np.zeros((200, 300, 3), np.uint8)
    img[:] = (43, 135, 209)                       # Human Benchmark blue
    yy, xx = np.mgrid[:200, :300]
    img[(yy - 50) ** 2 + (xx - 240) ** 2 < 20 ** 2] = (255, 255, 255)
    found = blobs(img)
    assert len(found) == 1
    b = found[0]
    assert b.shape == "yuvarlak" and b.color_name == "beyaz" and "üst sağ" in b.describe()


def test_snake_goes_for_apple_and_avoids_walls():
    assert snake.choose((5, 5), "right", {(4, 5), (3, 5)}, (5, 2)) == "up"
    # at the right wall heading right: must turn
    assert snake.choose((16, 5), "right", {(15, 5)}, None) in ("up", "down")


def test_snake_next_turn_cell():
    cell, dist = snake.next_turn_cell((3.6, 7.5), "right")   # head centre 3.4: centre 3.5 is too close
    assert cell == (4, 7) and dist > snake.LATE
    cell, _ = snake.next_turn_cell((6.0, 9.9), "up")
    assert cell == (6, 9)   # head centre 10.1 → next centre up is row 9
