import numpy as np

from jarvis.voice import sound_events as se


class FakeSession:
    def __init__(self, hot):
        self.hot = hot

    def get_inputs(self):
        class I:  # noqa: N801
            name = "waveform"
        return [I()]

    def run(self, _, feeds):
        scores = np.zeros((2, 521), np.float32)
        scores[:, self.hot] = 0.9
        return [scores]


def test_loud_ringtone_triggers_once_quiet_room_skips():
    got = []
    d = se.SoundEvents(lambda kind, score: got.append(kind))
    d._session = FakeSession(hot=7)
    d._index = {"phone": [7], "doorbell": [8], "alarm": [9], "baby": [10]}
    quiet = np.zeros(1280, np.int16)
    for _ in range(40):
        d.feed(quiet)
    assert got == []
    loud = (np.sin(np.arange(1280) / 3) * 12000).astype(np.int16)
    for _ in range(40):
        d.feed(loud)
    assert got == ["phone"]            # cooldown keeps it to one event
