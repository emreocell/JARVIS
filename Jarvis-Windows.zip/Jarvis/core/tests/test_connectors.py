from jarvis import paths
from jarvis.connectors.registry import Connector, find_project_dir, load_connectors
from jarvis.skills import connectors as mod


def test_builtins_and_user_override():
    (paths.data_dir() / "connectors.yaml").write_text(
        "connectors:\n"
        "  - id: antigravity\n"
        "    open_chat: \"{Ctrl}{Shift}l\"\n"
        "  - id: aider\n"
        "    name: Aider\n"
        "    kind: cli\n"
        "    command: [aider, --message, \"{prompt}\"]\n",
        encoding="utf-8")
    cs = load_connectors()
    assert cs["antigravity"].open_chat == "{Ctrl}{Shift}l"
    assert cs["antigravity"].window == "Antigravity"  # other built-in fields kept
    assert cs["aider"].kind == "cli" and "claude-code" in cs


def test_pick_by_alias():
    assert mod._pick("claude code").id == "claude-code"
    assert mod._pick("ChatGPT'ye").id == "chatgpt" or mod._pick("chatgpt").id == "chatgpt"
    assert mod._pick("vs code").id == "vscode"
    assert mod._pick("tamamen alakasız") is None


def test_cmd_shim_prompt_is_neutralized(monkeypatch):
    c = Connector(id="x", name="X", kind="cli", command=["x", "-p", "{prompt}"])
    monkeypatch.setattr(mod.shutil, "which", lambda e: r"C:\npm\x.cmd")
    argv = mod.build_argv(c, 'düzelt & del /q C:\\ | echo "%PATH%"', None)
    assert argv[0].endswith("x.cmd")
    assert not any(ch in argv[2] for ch in '&|%"')
    monkeypatch.setattr(mod.shutil, "which", lambda e: r"C:\bin\x.exe")
    assert mod.build_argv(c, "a & b", None)[2] == "a & b"  # real exe: no shell, keep text


def test_find_project_dir(tmp_path, monkeypatch):
    proj = tmp_path / "dev" / "jarvis"
    (proj / ".git").mkdir(parents=True)
    monkeypatch.setenv("USERPROFILE", str(tmp_path))
    assert find_project_dir("jarvis") == proj or find_project_dir("jarvis") is not None
    assert find_project_dir(str(proj)) == proj


def test_chat_input_guard():
    from jarvis.skills.connectors import is_chat_input

    assert is_chat_input("Chat Input")
    assert is_chat_input("Copilot'a sor")
    assert not is_chat_input("main.py - Editor content")
    assert not is_chat_input("")
    assert not is_chat_input("app.tsx - Cursor")
    assert is_chat_input("The editor is not accessible overflow-guard chat-input-container focused workbench.panel.chat")
    assert not is_chat_input("The editor is not accessible overflow-guard editor-instance workbench.parts.editor")  # "sor" inside a word must not count
