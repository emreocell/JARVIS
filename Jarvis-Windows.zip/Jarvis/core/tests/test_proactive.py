import time
from types import SimpleNamespace

import pytest

from jarvis.bus import EventBus
from jarvis.proactive import engine as eng


def make(decision="simdi", quiet=(0, 0)):
    said = []

    async def say(text, show=True):
        said.append(text)

    async def decide(state, questions):
        return {"answers": {"m": {"choice": decision, "confidence": 0.9}}}

    features = SimpleNamespace(proactive=True, jev_decider=True, break_reminders=False)
    core = SimpleNamespace(bus=EventBus(), config=SimpleNamespace(
        features=features, privacy=SimpleNamespace(privacy_mode=False), ui=SimpleNamespace(quiet_hours=quiet)),
        voice=SimpleNamespace(say=say, state=SimpleNamespace(value="idle")), context=None,
        providers=SimpleNamespace(decide=decide), presence=None, meeting=None, started_at=time.time())
    return eng.ProactiveEngine(core), said


@pytest.mark.asyncio
async def test_speaks_then_rate_limits(monkeypatch):
    monkeypatch.setattr(eng, "busy_reason", lambda ctx: None)
    e, said = make()
    e.add(eng.Candidate("notification", "Ahmet: yarın 10'da toplantı", "normal"))
    await e.pump()
    e.add(eng.Candidate("notification", "Ayşe: selam", "normal"))
    await e.pump()                      # within MIN_GAP: waits
    assert len(said) == 1 and "Ahmet" in said[0] and len(e.queue) == 1


@pytest.mark.asyncio
async def test_jev_can_postpone_and_quiet_mode_blocks(monkeypatch):
    monkeypatch.setattr(eng, "busy_reason", lambda ctx: None)
    e, said = make(decision="sonra")
    e.add(eng.Candidate("x", "önemsiz bir şey", "low"))
    await e.pump()
    assert said == [] and len(e.queue) == 1          # kept for a better moment
    e2, said2 = make()
    e2.silence(30)
    e2.add(eng.Candidate("battery", "Pil %10", "high"))
    await e2.pump()
    assert said2 == []


@pytest.mark.asyncio
async def test_quiet_hours_let_only_high_priority_through(monkeypatch):
    monkeypatch.setattr(eng, "busy_reason", lambda ctx: None)
    hour = time.localtime().tm_hour
    e, said = make(quiet=(hour, (hour + 1) % 24))
    e.add(eng.Candidate("x", "normal şey", "normal"))
    await e.pump()
    assert said == []
    e.queue.clear()
    e.add(eng.Candidate("battery", "Pil %9", "high"))
    await e.pump()
    assert len(said) == 1
