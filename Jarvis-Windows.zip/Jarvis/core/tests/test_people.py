from jarvis.people.store import PeopleStore


def test_people_roundtrip_and_fuzzy_find(tmp_path):
    s = PeopleStore(tmp_path / "p.sqlite3")
    s.log("Ahmet Yılmaz", "whatsapp", "out", "Yarın 10'da görüşelim", ts=100.0)
    s.log("ahmet yilmaz", "mail", "out", "teklif dosyası", ts=200.0)
    s.upsert("Ahmet Yılmaz", relation="iş ortağı", notes="Webioo tasarım")
    p = s.find("Ahmet")
    assert p is not None and p.relation == "iş ortağı" and "Webioo" in p.notes
    items = s.interactions(p.id)
    assert [i["channel"] for i in items] == ["mail", "whatsapp"] and items[0]["direction"] == "giden"
    assert s.find("Zeynep") is None
