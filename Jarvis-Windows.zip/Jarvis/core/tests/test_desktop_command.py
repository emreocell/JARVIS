from jarvis.desktop import app as desk


class FakeWindow:
    title = "Jarvis Komut"
    native = None

    def __init__(self):
        self.calls = []

    def resize(self, w, h):
        self.calls.append(("resize", w, h))

    def show(self):
        self.calls.append(("show",))

    def hide(self):
        self.calls.append(("hide",))

    def evaluate_js(self, js):
        self.calls.append(("js", js))


def make_shell():
    shell = desk.DesktopShell.__new__(desk.DesktopShell)  # skip pywebview window creation
    shell.command = FakeWindow()
    shell._command_visible = False
    shell._command_h = desk.COMMAND_MIN_H
    shell.light = True
    return shell


def test_resize_is_ignored_while_hidden():
    shell = make_shell()
    shell.resize_command(300)  # SetWindowPos would show a hidden window
    assert shell.command.calls == []


def test_show_resets_to_compact_then_follows_content_with_clamping():
    shell = make_shell()
    shell.show_command()
    calls = shell.command.calls
    kinds = [c[0] for c in calls]
    # page activated and reset *before* it becomes visible (its blur-grace starts then)
    assert any("__jarvisSetActive(true)" in c[1] for c in calls if c[0] == "js")
    reset = next(i for i, c in enumerate(calls) if c[0] == "js" and "__jarvisCommandShow" in c[1])
    assert reset < kinds.index("resize") < kinds.index("show")
    shell.command.calls.clear()
    shell.resize_command(201)
    shell.resize_command(202)  # < 2 px jitter ignored
    shell.resize_command(5000)
    assert shell.command.calls == [("resize", desk.COMMAND_W, 201), ("resize", desk.COMMAND_W, desk.COMMAND_MAX_H)]


def test_hide_only_once():
    shell = make_shell()
    shell.show_command()
    shell.command.calls.clear()
    shell.hide_command()
    shell.hide_command()
    assert [c[0] for c in shell.command.calls].count("hide") == 1
    assert "__jarvisSetActive(false)" in shell.command.calls[-1][1]  # stops rendering once hidden
