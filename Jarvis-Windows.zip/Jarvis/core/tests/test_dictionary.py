from types import SimpleNamespace

from jarvis import dictionary
from jarvis.config.schema import DictEntry


def cfg(*entries):
    return SimpleNamespace(assistant=SimpleNamespace(dictionary=list(entries)))


def test_fix_replaces_mishearings_case_and_accent_insensitive():
    c = cfg(DictEntry(term="Webioo", sounds_like=["web yo", "vebio"]), DictEntry(term="WPanel", sounds_like=["ve panel"]))
    assert dictionary.fix("Web Yo sitesini aç", c) == "Webioo sitesini aç"
    assert dictionary.fix("vebionun ve panel tarafı", c) == "vebionun WPanel tarafı"   # whole words only
    assert dictionary.terms(c) == ["Webioo", "WPanel"]
    assert "Webioo" in dictionary.prompt_block(c) and "web yo" in dictionary.prompt_block(c)


def test_fix_without_entries_is_identity():
    assert dictionary.fix("merhaba", cfg()) == "merhaba"
