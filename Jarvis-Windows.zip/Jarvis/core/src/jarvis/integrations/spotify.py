"""Spotify Web API (Premium tier) with OAuth PKCE and a loopback redirect.

Spotify's 2026 developer rules: development-mode apps need a Premium owner
and allow 5 users, so every user registers their own (free) developer app
and pastes its Client ID. PKCE means no client secret. Redirect URIs must use
``http://127.0.0.1:<port>/callback`` (``localhost`` is rejected).
"""

from __future__ import annotations

import asyncio
import base64
import hashlib
import logging
import secrets
import time
import urllib.parse
from typing import Any

import httpx

from jarvis.secrets import SecretStore

log = logging.getLogger(__name__)

AUTH_URL = "https://accounts.spotify.com/authorize"
TOKEN_URL = "https://accounts.spotify.com/api/token"
API = "https://api.spotify.com/v1"
REDIRECT_PORT = 8765
REDIRECT_URI = f"http://127.0.0.1:{REDIRECT_PORT}/callback"
SCOPES = "user-read-playback-state user-modify-playback-state user-read-currently-playing user-read-private playlist-read-private"
REFRESH_SECRET = "spotify_refresh"


class SpotifyError(Exception):
    pass


class SpotifyClient:
    def __init__(self, secrets_store: SecretStore, client_id: str | None) -> None:
        self.secrets = secrets_store
        self.client_id = client_id
        self._access: str | None = None
        self._expires = 0.0
        self.product: str | None = None

    @property
    def linked(self) -> bool:
        return bool(self.client_id) and self.secrets.get(REFRESH_SECRET) is not None

    # ------------------------------------------------------------- OAuth

    async def authorize(self, open_url) -> str:
        """Run the PKCE flow: open the consent page, wait for the loopback
        redirect, store the refresh token. Returns the account's product."""
        if not self.client_id:
            raise SpotifyError("Önce Spotify Client ID gir.")
        verifier = secrets.token_urlsafe(64)[:96]
        challenge = base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest()).rstrip(b"=").decode()
        state = secrets.token_urlsafe(16)
        url = AUTH_URL + "?" + urllib.parse.urlencode({
            "client_id": self.client_id, "response_type": "code", "redirect_uri": REDIRECT_URI,
            "code_challenge_method": "S256", "code_challenge": challenge, "scope": SCOPES, "state": state,
        })
        code_future: asyncio.Future[str] = asyncio.get_running_loop().create_future()

        async def handle(reader: asyncio.StreamReader, writer: asyncio.StreamWriter) -> None:
            request_line = (await reader.readline()).decode(errors="replace")
            while (await reader.readline()) not in (b"\r\n", b""):
                pass
            query = urllib.parse.urlparse(request_line.split(" ")[1] if " " in request_line else "").query
            params = dict(urllib.parse.parse_qsl(query))
            ok = params.get("state") == state and "code" in params
            body = ("<h2>Spotify bağlandı ✓</h2><p>Bu sekmeyi kapatıp Jarvis'e dönebilirsin.</p>" if ok
                    else "<h2>Bağlantı başarısız</h2><p>Jarvis'ten tekrar dene.</p>")
            writer.write(("HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\nConnection: close\r\n\r\n"
                          f"<html><body style='font-family:sans-serif;background:#0b0b11;color:#eee;padding:40px'>{body}"
                          "</body></html>").encode())
            await writer.drain()
            writer.close()
            if not code_future.done():
                if ok:
                    code_future.set_result(params["code"])
                elif "error" in params or params.get("state") == state:
                    code_future.set_exception(SpotifyError(params.get("error", "reddedildi")))

        server = await asyncio.start_server(handle, "127.0.0.1", REDIRECT_PORT)
        try:
            open_url(url)
            code = await asyncio.wait_for(code_future, 300)
        finally:
            server.close()
        async with httpx.AsyncClient(timeout=20) as client:
            r = await client.post(TOKEN_URL, data={
                "grant_type": "authorization_code", "code": code, "redirect_uri": REDIRECT_URI,
                "client_id": self.client_id, "code_verifier": verifier})
        if r.status_code != 200:
            raise SpotifyError(f"Token alınamadı: {r.text[:200]}")
        self._store_tokens(r.json())
        me = await self.api("GET", "/me")
        self.product = me.get("product")
        return self.product or "unknown"

    def _store_tokens(self, data: dict[str, Any]) -> None:
        self._access = data["access_token"]
        self._expires = time.time() + int(data.get("expires_in", 3600)) - 60
        if data.get("refresh_token"):
            self.secrets.set(REFRESH_SECRET, data["refresh_token"])

    async def _token(self) -> str:
        if self._access and time.time() < self._expires:
            return self._access
        refresh = self.secrets.get(REFRESH_SECRET)
        if not refresh or not self.client_id:
            raise SpotifyError("Spotify hesabı bağlı değil.")
        async with httpx.AsyncClient(timeout=20) as client:
            r = await client.post(TOKEN_URL, data={"grant_type": "refresh_token", "refresh_token": refresh,
                                                   "client_id": self.client_id})
        if r.status_code != 200:
            raise SpotifyError("Spotify oturumu süresi doldu; Ayarlar'dan yeniden bağlan.")
        self._store_tokens(r.json())
        return self._access  # type: ignore[return-value]

    def unlink(self) -> None:
        self.secrets.delete(REFRESH_SECRET)
        self._access = None

    # --------------------------------------------------------------- API

    async def api(self, method: str, path: str, **kwargs: Any) -> dict[str, Any]:
        token = await self._token()
        async with httpx.AsyncClient(timeout=15) as client:
            r = await client.request(method, API + path, headers={"Authorization": f"Bearer {token}"}, **kwargs)
        if r.status_code == 204 or not r.content:
            return {}
        if r.status_code == 403 and "PREMIUM" in r.text.upper():
            raise SpotifyError("premium_required")
        if r.status_code == 404 and "NO_ACTIVE_DEVICE" in r.text.upper():
            raise SpotifyError("no_device")
        if r.status_code >= 400:
            raise SpotifyError(f"Spotify {r.status_code}: {r.text[:200]}")
        return r.json()

    async def search(self, query: str, kind: str = "track") -> dict[str, Any] | None:
        data = await self.api("GET", "/search", params={"q": query, "type": kind, "limit": 5})
        items = (data.get(f"{kind}s") or {}).get("items") or []
        return next((i for i in items if i), None)

    async def devices(self) -> list[dict[str, Any]]:
        return (await self.api("GET", "/me/player/devices")).get("devices", [])

    async def play(self, query: str, kind: str = "track", ensure_device=None) -> str:
        item = await self.search(query, kind)
        if item is None:
            raise SpotifyError(f"'{query}' Spotify'da bulunamadı.")
        body = {"uris": [item["uri"]]} if kind == "track" else {"context_uri": item["uri"]}
        name = item.get("name", query)
        if kind == "track" and item.get("artists"):
            name += " — " + ", ".join(a["name"] for a in item["artists"][:2])
        try:
            await self.api("PUT", "/me/player/play", json=body)
        except SpotifyError as exc:
            if str(exc) != "no_device":
                raise
            devices = await self.devices()
            if not devices and ensure_device:
                await ensure_device()
                for _ in range(20):
                    await asyncio.sleep(0.5)
                    devices = await self.devices()
                    if devices:
                        break
            if not devices:
                raise SpotifyError("Açık bir Spotify cihazı yok.") from exc
            target = next((d for d in devices if d.get("type") == "Computer"), devices[0])
            await self.api("PUT", "/me/player/play", params={"device_id": target["id"]}, json=body)
        return name
