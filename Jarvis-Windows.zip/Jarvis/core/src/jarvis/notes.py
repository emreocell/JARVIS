"""Quick notes: capture by voice/command bar, list, search, pin, check off.

Local SQLite (``notes.sqlite3``); searched with the same Turkish-aware
normalisation as the rest of Jarvis.
"""

from __future__ import annotations

import sqlite3
import threading
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

from jarvis.skills.text import norm

SCHEMA = """
CREATE TABLE IF NOT EXISTS notes (
    id INTEGER PRIMARY KEY,
    text TEXT NOT NULL,
    created REAL NOT NULL,
    updated REAL NOT NULL,
    pinned INTEGER NOT NULL DEFAULT 0,
    done INTEGER NOT NULL DEFAULT 0,
    source TEXT NOT NULL DEFAULT 'user'
);
CREATE INDEX IF NOT EXISTS notes_updated ON notes(updated);
"""


@dataclass(slots=True)
class Note:
    id: int
    text: str
    created: float
    updated: float
    pinned: bool
    done: bool
    source: str

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


def _row(r: sqlite3.Row) -> Note:
    return Note(r["id"], r["text"], r["created"], r["updated"], bool(r["pinned"]), bool(r["done"]), r["source"])


class NoteStore:
    def __init__(self, path: Path) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        self._db = sqlite3.connect(path, check_same_thread=False, isolation_level=None)
        self._db.row_factory = sqlite3.Row
        self._db.executescript(SCHEMA)
        self._lock = threading.Lock()

    def close(self) -> None:
        self._db.close()

    def add(self, text: str, source: str = "user") -> Note:
        now = time.time()
        with self._lock:
            cur = self._db.execute("INSERT INTO notes(text, created, updated, source) VALUES (?,?,?,?)",
                                   (text.strip(), now, now, source))
        return self.get(int(cur.lastrowid))  # type: ignore[return-value]

    def get(self, nid: int) -> Note | None:
        r = self._db.execute("SELECT * FROM notes WHERE id=?", (nid,)).fetchone()
        return _row(r) if r else None

    def list(self, query: str = "", limit: int = 200, include_done: bool = True) -> list[Note]:
        rows = [_row(r) for r in self._db.execute(
            "SELECT * FROM notes ORDER BY pinned DESC, done ASC, updated DESC LIMIT ?", (max(limit, 1) * 5,))]
        if not include_done:
            rows = [n for n in rows if not n.done]
        q = norm(query)
        if q:
            words = q.split()
            rows = [n for n in rows if all(w in norm(n.text) for w in words)]
        return rows[:limit]

    def update(self, nid: int, *, text: str | None = None, pinned: bool | None = None,
               done: bool | None = None) -> Note | None:
        sets, args = [], []
        for col, val in (("text", text.strip() if text is not None else None),
                         ("pinned", None if pinned is None else int(pinned)),
                         ("done", None if done is None else int(done))):
            if val is not None:
                sets.append(f"{col}=?")
                args.append(val)
        if not sets:
            return self.get(nid)
        with self._lock:
            self._db.execute(f"UPDATE notes SET {', '.join(sets)}, updated=? WHERE id=?", (*args, time.time(), nid))
        return self.get(nid)

    def delete(self, nid: int) -> bool:
        with self._lock:
            return self._db.execute("DELETE FROM notes WHERE id=?", (nid,)).rowcount > 0
