"""Action → observe → verify → recover.

Computer-use agents usually click and say "done". Jarvis checks: a tool can
have a verifier that captures the state *before* the action, looks at the
world *after* it, and — if the effect isn't there — tries a recovery once
before reporting honestly what it observed.

Verifiers live next to their skills and register with :func:`verifies`::

    @verifies("open_app")
    class OpenAppCheck(Verifier):
        async def before(self, ctx, args): ...          # optional snapshot
        async def check(self, ctx, args, result, pre) -> Verdict: ...
        async def recover(self, ctx, args, result, pre) -> dict | None: ...   # optional

The runtime adds ``verified`` (True/False) and ``observed`` to the tool
result, and a clear ``problem`` when the effect could not be confirmed.
"""

from __future__ import annotations

import asyncio
import logging
import time
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from typing import Any, TypeVar

log = logging.getLogger(__name__)

VERIFIERS: dict[str, Verifier] = {}
CHECK_TIMEOUT = 12.0


@dataclass(slots=True)
class Verdict:
    ok: bool | None          # None = could not tell (no penalty, no claim)
    observed: str = ""


class Verifier:
    """Base class: override ``check`` (and optionally ``before`` / ``recover``)."""

    async def before(self, ctx: Any, args: dict[str, Any]) -> Any:
        return None

    async def check(self, ctx: Any, args: dict[str, Any], result: dict[str, Any], pre: Any) -> Verdict:
        return Verdict(None)

    async def recover(self, ctx: Any, args: dict[str, Any], result: dict[str, Any], pre: Any) -> dict[str, Any] | None:
        return None


V = TypeVar("V", bound=type)


def verifies(*tool_names: str) -> Callable[[V], V]:
    def register(cls: V) -> V:
        for name in tool_names:
            VERIFIERS[name] = cls()
        return cls
    return register


async def poll(fn: Callable[[], Awaitable[Any] | Any], timeout: float, interval: float = 0.3) -> Any:
    """Call ``fn`` until it returns something truthy or the time is up."""
    deadline = time.monotonic() + timeout
    while True:
        value = fn()
        if asyncio.iscoroutine(value):
            value = await value
        if value or time.monotonic() >= deadline:
            return value
        await asyncio.sleep(interval)


def needs_check(result: dict[str, Any]) -> bool:
    return "error" not in result and "status" not in result and not result.get("verified_by_tool")


async def run_verified(name: str, ctx: Any, args: dict[str, Any], action: Callable[[], Awaitable[dict[str, Any]]],
                       publish: Callable[..., Awaitable[None]]) -> dict[str, Any]:
    """Run ``action`` under the tool's verifier (if any)."""
    verifier = VERIFIERS.get(name)
    if verifier is None:
        return await action()
    try:
        pre = await asyncio.wait_for(verifier.before(ctx, args), 3)
    except Exception:
        log.debug("verify before(%s) failed", name, exc_info=True)
        pre = None
    result = await action()
    if not needs_check(result):
        return result
    await publish("tool.verify", tool=name, state="checking")
    verdict = await _check(verifier, ctx, args, result, pre)
    if verdict.ok is False:
        await publish("tool.verify", tool=name, state="recovering", observed=verdict.observed)
        log.info("verify %s failed (%s); recovering", name, verdict.observed)
        try:
            recovered = await asyncio.wait_for(verifier.recover(ctx, args, result, pre), CHECK_TIMEOUT)
        except Exception as exc:
            log.info("recovery for %s failed: %s", name, exc)
            recovered = None
        if recovered is not None:
            result = {**result, **recovered, "recovery": recovered.get("recovery", "yeniden denendi")}
            verdict = await _check(verifier, ctx, args, result, pre)
    out = {**result, "verified": verdict.ok, "observed": verdict.observed} if verdict.ok is not None else \
        {**result, "observed": verdict.observed} if verdict.observed else result
    if verdict.ok is False:
        out["problem"] = (f"İşlemi yaptım ama sonucunu doğrulayamadım: {verdict.observed}. Kullanıcıya bunu dürüstçe "
                          "söyle; 'tamamdır' deme.")
    await publish("tool.verify", tool=name, state="ok" if verdict.ok else "failed" if verdict.ok is False else "unknown",
                  observed=verdict.observed)
    return out


async def _check(verifier: Verifier, ctx: Any, args: dict[str, Any], result: dict[str, Any], pre: Any) -> Verdict:
    try:
        return await asyncio.wait_for(verifier.check(ctx, args, result, pre), CHECK_TIMEOUT)
    except TimeoutError:
        return Verdict(None, "doğrulama zaman aşımına uğradı")
    except Exception as exc:
        log.debug("verify check failed", exc_info=True)
        return Verdict(None, f"doğrulanamadı ({type(exc).__name__})")
