"""Tool registry + execution pipeline.

``execute`` runs every call through the same gates:
unknown/disabled → loop guard → approval policy → timeout → audit event.

Risky calls do not block the (synchronous) Live tool call while waiting for
the user: they return ``needs_confirmation`` with a token and a question.
The model asks the question; when the user answers yes, the model calls
``confirm_pending_action`` and the runtime verifies the answer against the
real user transcript before running the original call.
"""

from __future__ import annotations

import asyncio
import functools
import importlib
import inspect
import logging
import time
from collections import deque
from collections.abc import Awaitable, Callable, Iterable
from types import ModuleType
from typing import Annotated, Any

from jarvis.bus import Event, EventBus
from jarvis.tools.approval import ApprovalStore, PendingAction, is_affirmative
from jarvis.tools.base import Risk, ToolContext, ToolSpec, tool
from jarvis.tools.guard import LoopGuard
from jarvis.tools.verify import CHECK_TIMEOUT, VERIFIERS, run_verified

log = logging.getLogger(__name__)

Notify = Callable[[str], Awaitable[None]]


def _summarize(spec: ToolSpec, args: dict[str, Any]) -> str:
    describe = getattr(spec.handler, "_describe", None)
    if callable(describe):
        try:
            return str(describe(**args))
        except Exception:
            pass
    shown = ", ".join(f"{k}={v!r}" for k, v in args.items())
    return f"{spec.name}({shown})"


class ToolRuntime:
    def __init__(self, bus: EventBus, approvals: ApprovalStore, core: Any = None) -> None:
        self.bus = bus
        self.approvals = approvals
        self.core = core
        self.tools: dict[str, ToolSpec] = {}
        self.unavailable: dict[str, str] = {}   # name -> reason
        self.guard = LoopGuard()
        self.notify_brain: Notify | None = None  # tells the voice brain about async results
        # (turn key, text) of recent user utterances; the key changes per spoken/typed turn
        self._user_said: deque[tuple[str, str]] = deque(maxlen=20)
        self._turns_seen = 0
        self._background: set[asyncio.Task[Any]] = set()
        # (tool name, args, result) observers: person memory, journal… (errors are theirs to swallow)
        self.after_hooks: list[Callable[[str, dict[str, Any], dict[str, Any]], None]] = []
        bus.subscribe("voice.transcript", self._on_transcript)
        bus.subscribe("user.text", self._on_transcript)
        bus.subscribe("voice.turn_complete", lambda e: self.guard.reset())
        self._register_builtins()

    # ------------------------------------------------------------ registry

    def register(self, spec: ToolSpec) -> None:
        reason = spec.unavailable_reason()
        if reason:
            # the same tool may exist per platform (skills/mac/…): never drop a working implementation
            if spec.name not in self.tools:
                self.unavailable[spec.name] = reason
        else:
            self.tools[spec.name] = spec
            self.unavailable.pop(spec.name, None)

    def unregister_skill(self, skill: str) -> None:
        for name in [n for n, s in self.tools.items() if s.skill == skill]:
            del self.tools[name]

    def register_module(self, module: ModuleType | str) -> list[str]:
        if isinstance(module, str):
            module = importlib.import_module(module)
        names = []
        for _, fn in inspect.getmembers(module, callable):
            spec = getattr(fn, "__tool__", None)
            if isinstance(spec, ToolSpec) and fn.__module__ == module.__name__:
                self.register(spec)
                names.append(spec.name)
        return names

    def enabled(self, disabled_skills: Iterable[str] = ()) -> list[ToolSpec]:
        off = set(disabled_skills)
        return [s for s in self.tools.values() if s.skill not in off and not s.hidden]

    def gemini_tools(self, disabled_skills: Iterable[str] = ()) -> list[Any]:
        from google.genai import types

        decls = [types.FunctionDeclaration(**s.declaration()) for s in self.enabled(disabled_skills)]
        return [types.Tool(function_declarations=decls)] if decls else []

    def describe(self) -> list[dict[str, Any]]:
        from jarvis.tools.titles import CATEGORIES, TOOLS, title_of

        rows = [{"name": s.name, "skill": s.skill, "category": s.category, "risk": s.risk.value,
                 "description": s.description.splitlines()[0], "available": True,
                 "title": title_of(s.name), "icon": TOOLS.get(s.name, {}).get("icon", ""),
                 "say": TOOLS.get(s.name, {}).get("say", ""),
                 "category_title": CATEGORIES.get(s.category, {}).get("title", s.category),
                 "category_icon": CATEGORIES.get(s.category, {}).get("icon", "")}
                for s in self.tools.values() if not s.hidden and not s.name.endswith("_pending_action")]
        rows += [{"name": n, "available": False, "reason": r} for n, r in self.unavailable.items()]
        return sorted(rows, key=lambda r: (r.get("skill", ""), r["name"]))

    # ------------------------------------------------------------- inputs

    def _on_transcript(self, event: Event) -> None:
        if event.data.get("role", "user") != "user":
            return
        text = str(event.data.get("text", ""))
        key = f"{event.topic}:{event.data.get('turn', time.monotonic())}"
        # voice transcripts are cumulative within a turn: update that turn's entry in place
        if self._user_said and self._user_said[-1][0] == key:
            self._user_said[-1] = (key, text)
        else:
            self._user_said.append((key, text))
            self._turns_seen += 1

    @property
    def turn_marker(self) -> int:
        return self._turns_seen

    def user_said_after(self, marker: int) -> list[str]:
        """Utterances from turns that *started* after ``marker``."""
        new = self._turns_seen - marker
        return [text for _, text in list(self._user_said)[-new:]] if new > 0 else []

    # ---------------------------------------------------------- execution

    async def execute(self, name: str, args: dict[str, Any] | None, call_id: str = "",
                      source: str = "voice") -> dict[str, Any]:
        args = dict(args or {})
        spec = self.tools.get(name)
        if spec is None or (spec.hidden and source in ("voice", "text", "mission")):
            reason = self.unavailable.get(name, "böyle bir araç yok")
            return {"error": f"{name} kullanılamıyor: {reason}"}
        if not spec.name.startswith(("confirm_pending", "cancel_pending")):
            blocked = self.guard.check(name, args)
            if blocked:
                return {"error": blocked}
            if self.approvals.needs_approval(spec, args):
                action = self.approvals.create(spec, args, _summarize(spec, args))
                action.after_turn = self.turn_marker
                await self.bus.publish("approval.requested", token=action.token, tool=name,
                                       summary=action.summary, risk=spec.risk.value, source=source)
                return {
                    "status": "needs_confirmation",
                    "token": action.token,
                    "instruction": (f"Bunu yapmadan önce kullanıcıya sor: \"{action.summary} — onaylıyor musun?\" "
                                    "Kullanıcı evet derse confirm_pending_action(token) çağır; hayır derse "
                                    "cancel_pending_action(token) çağır. Kullanıcı adına onay verme."),
                }
        return await self._run(spec, args, call_id)

    async def ask(self, name: str, args: dict[str, Any], summary: str, source: str = "routine") -> str:
        """Create a pending confirmation for a tool call regardless of its risk
        (routines in "ask" mode). Returns the token."""
        spec = self.tools.get(name)
        if spec is None:
            raise KeyError(name)
        action = self.approvals.create(spec, args, summary)
        action.after_turn = self.turn_marker
        await self.bus.publish("approval.requested", token=action.token, tool=name, summary=summary,
                               risk=spec.risk.value, source=source)
        return action.token

    async def _run(self, spec: ToolSpec, args: dict[str, Any], call_id: str) -> dict[str, Any]:
        plain_args = dict(args)
        if spec.wants_ctx:
            args = {**args, "ctx": ToolContext(core=self.core, call_id=call_id)}
        from jarvis.tools.titles import title_of

        await self.bus.publish("tool.started", tool=spec.name, title=title_of(spec.name), call_id=call_id)
        started = time.perf_counter()

        async def act() -> dict[str, Any]:
            if inspect.iscoroutinefunction(spec.handler):
                r = await spec.handler(**args)
            elif spec.uia:
                from jarvis.skills import uia

                r = await uia.run(functools.partial(spec.handler, **args))
            else:
                r = await asyncio.to_thread(spec.handler, **args)
            return r if isinstance(r, dict) else {"output": r}

        # verifiers belong to the built-in skills (a test double or MCP tool with the same name must not
        # trigger real-world checks)
        verified = spec.name in VERIFIERS and getattr(spec.handler, "__module__", "").startswith("jarvis.skills.")

        async def invoke() -> dict[str, Any]:
            if not verified:
                return await act()
            # action → observe → verify → recover
            return await run_verified(spec.name, ToolContext(core=self.core, call_id=call_id), plain_args, act,
                                      self.bus.publish)

        timeout = spec.timeout + (2 * CHECK_TIMEOUT if verified else 0)

        if spec.background:
            task = asyncio.create_task(self._finish_background(spec, invoke(), call_id, started))
            self._background.add(task)
            task.add_done_callback(self._background.discard)
            return {"status": "started", "note": "Arka planda başladı; bitince kullanıcıya haber verilecek."}

        try:
            result = await asyncio.wait_for(invoke(), timeout)
            out = result if isinstance(result, dict) else {"output": result}
        except TimeoutError:
            out = {"error": f"{spec.name} {spec.timeout:.0f} sn içinde bitmedi"}
        except Exception as exc:
            log.exception("tool %s failed", spec.name)
            out = {"error": f"{type(exc).__name__}: {exc}"}
        await self.bus.publish("tool.finished", tool=spec.name, call_id=call_id,
                               ok="error" not in out, ms=int((time.perf_counter() - started) * 1000),
                               result=_preview(out))
        for hook in self.after_hooks:
            try:
                hook(spec.name, plain_args, out)
            except Exception:
                log.debug("after-hook failed", exc_info=True)
        return out

    async def _finish_background(self, spec: ToolSpec, coro: Awaitable[Any], call_id: str,
                                 started: float) -> None:
        try:
            result = await coro
            out = result if isinstance(result, dict) else {"output": result}
        except Exception as exc:
            log.exception("background tool %s failed", spec.name)
            out = {"error": f"{type(exc).__name__}: {exc}"}
        await self.bus.publish("tool.finished", tool=spec.name, call_id=call_id, background=True,
                               ok="error" not in out, ms=int((time.perf_counter() - started) * 1000),
                               result=_preview(out))
        if self.notify_brain:
            await self.notify_brain(f"[Arka plan görevi bitti: {spec.name}] Sonuç: {_preview(out)}. "
                                    "Kullanıcıya kısaca bildir.")

    # -------------------------------------------------------- approvals

    async def approve_from_ui(self, token: str, allow: bool, remember: bool = False) -> dict[str, Any]:
        action = self.approvals.resolve(token, allow, remember)
        if action is None:
            return {"error": "onay isteği bulunamadı veya süresi doldu"}
        await self.bus.publish("approval.resolved", token=token, allow=allow, via="ui")
        if not allow:
            if self.notify_brain:
                await self.notify_brain(f"[Kullanıcı reddetti: {action.summary}] İşlemi yapma.")
            return {"status": "cancelled"}
        result = await self._run(self.tools[action.tool], action.args, "")
        if self.notify_brain:
            await self.notify_brain(f"[Kullanıcı arayüzden onayladı: {action.summary}] Sonuç: {_preview(result)}. "
                                    "Kullanıcıya kısaca bildir.")
        return result

    def _register_builtins(self) -> None:
        runtime = self

        @tool(risk=Risk.READ, category="system", platforms=())
        async def confirm_pending_action(token: Annotated[str, "needs_confirmation cevabındaki token"]) -> dict:
            """Kullanıcı sesli olarak onay verdikten SONRA bekleyen işlemi çalıştırır. Kullanıcı açıkça
            'evet' demeden asla çağırma."""
            action: PendingAction | None = runtime.approvals.get(token) or runtime.approvals.latest()
            if action is None:
                return {"error": "bekleyen işlem yok veya süresi doldu"}
            answers = runtime.user_said_after(action.after_turn)
            verdicts = [is_affirmative(a) for a in answers]
            if not any(v is True for v in verdicts) or any(v is False for v in verdicts[-1:]):
                return {"error": "Kullanıcının onayını duymadım. Kullanıcıya sor ve cevabını bekle."}
            runtime.approvals.resolve(action.token, True)
            await runtime.bus.publish("approval.resolved", token=action.token, allow=True, via="voice")
            return await runtime._run(runtime.tools[action.tool], action.args, "")

        @tool(risk=Risk.READ, category="system", platforms=())
        async def cancel_pending_action(token: Annotated[str, "needs_confirmation cevabındaki token"]) -> dict:
            """Kullanıcı hayır dediğinde veya vazgeçtiğinde bekleyen işlemi iptal eder."""
            action = runtime.approvals.resolve(token, False)
            if action is None:
                return {"status": "zaten yok"}
            await runtime.bus.publish("approval.resolved", token=token, allow=False, via="voice")
            return {"status": "cancelled"}

        self.register(confirm_pending_action.__tool__)  # type: ignore[attr-defined]
        self.register(cancel_pending_action.__tool__)  # type: ignore[attr-defined]


def _preview(out: dict[str, Any], limit: int = 600) -> str:
    text = str(out.get("error") or out.get("output") or out.get("message") or out)
    return text if len(text) <= limit else text[:limit] + "…"
