"""Tool declaration.

A tool is a plain (async or sync) function decorated with :func:`tool`. The
parameter schema is generated from type hints, and per-parameter
descriptions come from ``Annotated[..., "description"]``::

    @tool(risk=Risk.SEND, category="communication")
    async def send_whatsapp(contact: Annotated[str, "Kişi adı"],
                            message: Annotated[str, "Gönderilecek mesaj"]) -> dict:
        '''WhatsApp masaüstünden bir kişiye mesaj gönderir.'''

Handlers may take a ``ctx: ToolContext`` parameter; it is injected and not
part of the schema.
"""

from __future__ import annotations

import inspect
import sys
from collections.abc import Callable
from dataclasses import dataclass, field
from enum import StrEnum
from typing import Annotated, Any, get_args, get_origin, get_type_hints

from pydantic import Field, create_model


class Risk(StrEnum):
    """How much confirmation a tool needs (see ApprovalPolicy)."""

    READ = "read"          # reads state; never asks
    LOW = "low"            # harmless changes (volume, open an app); never asks
    WRITE = "write"        # changes files/settings; asks once, remembered
    SEND = "send"          # talks to other people / the internet on your behalf; asks unless remembered
    DESTRUCTIVE = "destructive"  # deletes, shuts down, pays; always asks


@dataclass(slots=True)
class ToolSpec:
    name: str
    description: str
    handler: Callable[..., Any]
    parameters: dict[str, Any]
    risk: Risk = Risk.READ
    category: str = "general"
    timeout: float = 20.0
    background: bool = False   # long-running: return "started" immediately, announce result later
    platforms: tuple[str, ...] = ("win32",)
    requires: tuple[str, ...] = ()  # importable modules
    wants_ctx: bool = False
    skill: str = ""
    hidden: bool = False  # internal: runnable by the runtime/routines, never offered to the model
    uia: bool = False  # sync tool that uses UI Automation: run on the single UIA thread

    def unavailable_reason(self) -> str | None:
        if self.platforms and sys.platform not in self.platforms:
            return f"platform {sys.platform} desteklenmiyor"
        import importlib.util

        missing = [m for m in self.requires if importlib.util.find_spec(m) is None]
        if missing:
            return "eksik paket: " + ", ".join(missing)
        return None

    def declaration(self) -> dict[str, Any]:
        """Gemini FunctionDeclaration as a plain dict (JSON schema parameters)."""
        decl: dict[str, Any] = {"name": self.name, "description": self.description}
        if self.parameters.get("properties"):
            decl["parameters_json_schema"] = self.parameters
        return decl


@dataclass(slots=True)
class ToolContext:
    """Per-call context handed to tools that ask for it."""

    core: Any
    call_id: str = ""
    extras: dict[str, Any] = field(default_factory=dict)


def _param_schema(fn: Callable[..., Any]) -> tuple[dict[str, Any], bool]:
    hints = get_type_hints(fn, include_extras=True)
    sig = inspect.signature(fn)
    fields: dict[str, Any] = {}
    wants_ctx = False
    for name, param in sig.parameters.items():
        hint = hints.get(name, str)
        if name == "ctx" or hint is ToolContext:
            wants_ctx = True
            continue
        description = None
        if get_origin(hint) is Annotated:
            base, *meta = get_args(hint)
            description = next((m for m in meta if isinstance(m, str)), None)
            hint = base
        default = ... if param.default is inspect.Parameter.empty else param.default
        fields[name] = (hint, Field(default, description=description))
    model = create_model(f"{fn.__name__}_params", **fields)
    schema = model.model_json_schema()
    schema.pop("title", None)
    for prop in schema.get("properties", {}).values():
        prop.pop("title", None)
    return schema, wants_ctx


def tool(*, name: str | None = None, risk: Risk = Risk.READ, category: str = "general",
         timeout: float = 20.0, background: bool = False,
         platforms: tuple[str, ...] = ("win32",), requires: tuple[str, ...] = (),
         hidden: bool = False, uia: bool = False) -> Callable:
    def decorate(fn: Callable[..., Any]) -> Callable[..., Any]:
        doc = inspect.getdoc(fn) or ""
        if not doc:
            raise ValueError(f"tool {fn.__name__} needs a docstring (it is the LLM-facing description)")
        schema, wants_ctx = _param_schema(fn)
        fn.__tool__ = ToolSpec(  # type: ignore[attr-defined]
            name=name or fn.__name__, description=doc, handler=fn, parameters=schema, risk=risk,
            category=category, timeout=timeout, background=background, platforms=platforms,
            requires=requires, wants_ctx=wants_ctx, skill=fn.__module__.rsplit(".", 1)[-1], hidden=hidden,
            uia=uia,
        )
        return fn
    return decorate
