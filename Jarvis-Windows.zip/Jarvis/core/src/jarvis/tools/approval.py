"""Confirmation policy for risky tool calls.

The *runtime* decides whether a call needs approval — never the model.
Approval can come from:

* the UI (approval card buttons / notification action), or
* the user's own voice: the model asks, the user answers, and the model calls
  ``confirm_pending_action``. The runtime then checks the **actual user
  transcript** received after the question for an affirmative answer, so the
  model cannot approve on the user's behalf.

Decisions can be remembered per fingerprint (e.g. "send to Ahmet").
"""

from __future__ import annotations

import asyncio
import json
import re
import secrets
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from jarvis.fsutil import atomic_write_json, read_json
from jarvis.tools.base import Risk, ToolSpec

PENDING_TTL = 120.0

_YES = re.compile(
    r"\b(evet|tamam|olur|onayl[ıi]yorum|onay|g[öo]nder|yap|devam|kesinlikle|aynen|tabii|tabi|yes|sure|ok(ey)?)\b",
    re.I,
)
_NO = re.compile(r"\b(hay[ıi]r|dur|iptal|vazge[çc]|yapma|g[öo]nderme|istemiyorum|no|cancel)\b", re.I)


def is_affirmative(text: str) -> bool | None:
    """True for yes, False for no, None if unclear. "No" wins ties."""
    t = text.lower()
    if _NO.search(t):
        return False
    if _YES.search(t):
        return True
    return None


@dataclass(slots=True)
class PendingAction:
    token: str
    tool: str
    args: dict[str, Any]
    summary: str
    fingerprint: str
    created: float = field(default_factory=time.monotonic)
    after_turn: int = 0  # only user turns started after this count as the answer
    future: asyncio.Future[bool] | None = None

    def expired(self) -> bool:
        return time.monotonic() - self.created > PENDING_TTL


def fingerprint(spec: ToolSpec, args: dict[str, Any]) -> str:
    """Stable key for "remember this decision". Tools can narrow it by naming
    a ``_fingerprint_keys`` attribute on the handler (e.g. only the contact)."""
    keys = getattr(spec.handler, "_fingerprint_keys", None)
    subset = {k: args.get(k) for k in keys} if keys else args
    return f"{spec.name}:{json.dumps(subset, sort_keys=True, ensure_ascii=False)}"


class ApprovalStore:
    def __init__(self, path: Path) -> None:
        self.path = path
        self._pending: dict[str, PendingAction] = {}
        self._remembered: dict[str, bool] = {}
        if path.exists():
            try:
                self._remembered = {k: bool(v) for k, v in read_json(path).get("remembered", {}).items()}
            except Exception:
                self._remembered = {}

    def _save(self) -> None:
        atomic_write_json(self.path, {"remembered": self._remembered})

    # ------------------------------------------------------------ policy

    def needs_approval(self, spec: ToolSpec, args: dict[str, Any]) -> bool:
        if spec.risk in (Risk.READ, Risk.LOW):
            return False
        if spec.risk is Risk.DESTRUCTIVE:
            return True
        return self._remembered.get(fingerprint(spec, args)) is not True

    def remember(self, fp: str, allow: bool) -> None:
        self._remembered[fp] = allow
        self._save()

    def forget_all(self) -> None:
        self._remembered.clear()
        self._save()

    # ----------------------------------------------------------- pending

    def create(self, spec: ToolSpec, args: dict[str, Any], summary: str) -> PendingAction:
        self._gc()
        action = PendingAction(secrets.token_hex(4), spec.name, args, summary, fingerprint(spec, args))
        action.future = asyncio.get_running_loop().create_future()
        self._pending[action.token] = action
        return action

    def get(self, token: str) -> PendingAction | None:
        self._gc()
        return self._pending.get(token)

    def latest(self) -> PendingAction | None:
        self._gc()
        return max(self._pending.values(), key=lambda a: a.created, default=None)

    def resolve(self, token: str, allow: bool, remember: bool = False) -> PendingAction | None:
        action = self._pending.pop(token, None)
        if action is None:
            return None
        if remember:
            self.remember(action.fingerprint, allow)
        if action.future and not action.future.done():
            action.future.set_result(allow)
        return action

    def pending(self) -> list[PendingAction]:
        self._gc()
        return list(self._pending.values())

    def _gc(self) -> None:
        for token in [t for t, a in self._pending.items() if a.expired()]:
            action = self._pending.pop(token)
            if action.future and not action.future.done():
                action.future.set_result(False)
