"""Loop guard: stops an agent from hammering the same tool.

* the same (tool, args) more than ``max_repeats`` times in the window → block
* A-B-A-B style cycles in the recent history → block
"""

from __future__ import annotations

import hashlib
import json
from collections import deque
from typing import Any


def _digest(tool: str, args: dict[str, Any]) -> str:
    raw = json.dumps([tool, args], sort_keys=True, ensure_ascii=False, default=str)
    return hashlib.sha256(raw.encode()).hexdigest()[:16]


class LoopGuard:
    def __init__(self, max_repeats: int = 3, window: int = 8) -> None:
        self.max_repeats = max_repeats
        self._history: deque[str] = deque(maxlen=window)

    def reset(self) -> None:
        self._history.clear()

    def check(self, tool: str, args: dict[str, Any]) -> str | None:
        """Record the call; return a reason string if it should be blocked."""
        d = _digest(tool, args)
        h = self._history
        if list(h).count(d) >= self.max_repeats:
            return f"{tool} aynı argümanlarla {self.max_repeats} kez çağrıldı; farklı bir yol dene."
        h.append(d)
        items = list(h)
        if len(items) >= 4 and items[-1] == items[-3] and items[-2] == items[-4] and items[-1] != items[-2]:
            return "Araç çağrıları bir döngüye girdi (A-B-A-B); dur ve kullanıcıya durumu anlat."
        return None
