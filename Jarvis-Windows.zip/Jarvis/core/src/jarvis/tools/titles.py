"""Human-facing names for tools and categories (the UI never shows raw
function names). ``icon`` values are lucide icon names; ``say`` is an
example of how to ask for it."""

from __future__ import annotations

TOOLS: dict[str, dict[str, str]] = {
    # apps & files
    "open_app": {"title": "Uygulama aç", "icon": "AppWindow", "say": "Spotify'ı aç"},
    "close_app": {"title": "Uygulama kapat", "icon": "XSquare", "say": "Discord'u kapat"},
    "list_running_apps": {"title": "Açık uygulamalar", "icon": "LayoutGrid", "say": "Hangi uygulamalar açık?"},
    "open_path": {"title": "Dosya / klasör aç", "icon": "FolderOpen", "say": "İndirilenler klasörünü aç"},
    "find_files": {"title": "Dosya bul", "icon": "FileSearch", "say": "Bütçe dosyamı bul"},
    # system
    "set_volume": {"title": "Ses seviyesi", "icon": "Volume2", "say": "Sesi 30 yap"},
    "set_app_volume": {"title": "Uygulama sesi", "icon": "SlidersHorizontal", "say": "Spotify'ın sesini kıs"},
    "set_brightness": {"title": "Parlaklık", "icon": "SunMedium", "say": "Parlaklığı artır"},
    "lock_screen": {"title": "Ekranı kilitle", "icon": "Lock", "say": "Ekranı kilitle"},
    "power": {"title": "Kapat / yeniden başlat", "icon": "Power", "say": "Bilgisayarı 30 dakika sonra kapat"},
    "system_info": {"title": "Sistem durumu", "icon": "Cpu", "say": "Bilgisayarın durumu nasıl?"},
    "current_time": {"title": "Saat ve tarih", "icon": "Clock", "say": "Saat kaç?"},
    "open_settings": {"title": "Windows ayarları", "icon": "Settings2", "say": "Bluetooth ayarlarını aç"},
    # media
    "play_spotify": {"title": "Spotify'da çal", "icon": "Music2", "say": "Spotify'da lofi çal"},
    "play_youtube": {"title": "YouTube'da aç", "icon": "Youtube", "say": "YouTube'da yemek tarifi aç"},
    "media_control": {"title": "Medya kontrolü", "icon": "SkipForward", "say": "Sonraki şarkı"},
    "now_playing": {"title": "Ne çalıyor?", "icon": "Disc3", "say": "Bu şarkı ne?"},
    # communication
    "send_whatsapp": {"title": "WhatsApp mesajı", "icon": "MessageCircle", "say": "Annem'e 'geliyorum' yaz"},
    # memory
    "remember": {"title": "Hatırla", "icon": "BookmarkPlus", "say": "Kahvemi şekersiz içtiğimi unutma"},
    "recall": {"title": "Hafızadan getir", "icon": "Brain", "say": "Ben ne tür müzik seviyordum?"},
    "forget": {"title": "Unut", "icon": "Eraser", "say": "Adresimi unut"},
    # screen & context
    "look_at_screen": {"title": "Ekrana bak", "icon": "Eye", "say": "Ekranımda ne var?"},
    "click_on_screen": {"title": "Ekranda tıkla", "icon": "MousePointerClick", "say": "Kaydet düğmesine tıkla"},
    "get_user_context": {"title": "Ne üzerinde çalışıyorum?", "icon": "Radar", "say": "Şu an ne yapıyordum?"},
    # desktop control
    "desktop_task": {"title": "Masaüstünde iş yap", "icon": "Bot", "say": "Not Defteri'ne alışveriş listesi yaz"},
    "read_window": {"title": "Pencereyi oku", "icon": "ScanText", "say": "Bu penceredeki düğmeler neler?"},
    "click_element": {"title": "Öğeye tıkla", "icon": "Pointer", "say": ""},
    "play_browser_game": {"title": "Tarayıcıda oyun oyna", "icon": "Target", "say": "Aim trainer oyna, ne kadar hızlısın görelim"},
    "google_sign_in": {"title": "Google'a giriş", "icon": "Mail", "say": ""},
    "gmail_unread": {"title": "Okunmamış mailler", "icon": "Mail", "say": "Yeni mail var mı?"},
    "gmail_search": {"title": "Maillerde ara", "icon": "Mail", "say": "Ahmet'ten gelen son maili bul"},
    "gmail_read": {"title": "Maili oku", "icon": "Mail", "say": ""},
    "gmail_draft": {"title": "Mail taslağı", "icon": "Mail", "say": "Hocama ödev için bir taslak hazırla"},
    "gmail_send": {"title": "Mail gönder", "icon": "Mail", "say": ""},
    "calendar_agenda": {"title": "Takvime bak", "icon": "CalendarDays", "say": "Bu hafta takvimimde ne var?"},
    "calendar_add_event": {"title": "Takvime ekle", "icon": "CalendarDays", "say": "Cuma saat üçe dişçi randevusu ekle"},
    "add_to_dictionary": {"title": "Sözlüğe ekle", "icon": "BookOpen", "say": "Webioo'yu öğren, web yo diye anlıyorsun"},
    "start_mission": {"title": "Otonom görev", "icon": "Workflow", "say": "Samsun'da hafta sonu için 3 kafe araştır ve not çıkar"},
    "list_missions": {"title": "Görev durumu", "icon": "ListChecks", "say": "Görev ne durumda?"},
    "cancel_mission": {"title": "Görevi durdur", "icon": "XSquare", "say": "Görevi iptal et"},
    "what_can_you_do": {"title": "Yeteneklerim", "icon": "Sparkles", "say": "Faturayı bulup bana hatırlatabilir misin?"},
    "who_is": {"title": "Kişi hafızası", "icon": "Brain", "say": "Ahmet kimdi?"},
    "remember_person": {"title": "Kişiyi kaydet", "icon": "BookmarkPlus", "say": "Ahmet iş ortağım, bunu hatırla"},
    "start_meeting_mode": {"title": "Toplantı modu", "icon": "Mic", "say": "Toplantı modunu başlat"},
    "stop_meeting_mode": {"title": "Toplantıyı bitir", "icon": "Mic", "say": "Toplantı modunu kapat"},
    "ask_meeting": {"title": "Toplantıya sor", "icon": "NotebookText", "say": "Toplantıda ödeme sistemiyle ilgili ne kararlaştırdık?"},
    "my_action_items": {"title": "Bana kalan işler", "icon": "ListChecks", "say": "Benim üzerime kalan işler ne?"},
    "be_quiet": {"title": "Rahatsız etme", "icon": "BellOff", "say": "Bir saat rahatsız etme"},
    "notifications_summary": {"title": "Bildirim özeti", "icon": "Bell", "say": "Ben yokken önemli bir şey oldu mu?"},
    "what_did_i_do": {"title": "Bugün ne yaptım?", "icon": "ListChecks", "say": "Bugün ne yaptım?"},
    "save_to_second_brain": {"title": "İkinci beyne kaydet", "icon": "Brain", "say": "Bugünkü işlerimi ikinci beynime özetle"},
    "what_is_this": {"title": "“Bu” ne?", "icon": "ScanText", "say": "Bunu İngilizceye çevir"},
    "replace_selection": {"title": "Seçimi değiştir", "icon": "TextCursorInput", "say": "Bunu daha profesyonel yaz"},
    "start_live_translation": {"title": "Canlı çeviri", "icon": "ScanText", "say": "Bu videoyu canlı Türkçeye çevir"},
    "stop_live_translation": {"title": "Çeviriyi durdur", "icon": "XSquare", "say": "Çeviriyi durdur"},
    "translate_screen": {"title": "Ekranı çevir", "icon": "ScanText", "say": "Ekrandakini Türkçeye çevir"},
    "point_at": {"title": "Ekranda göster", "icon": "Target", "say": "Ayarlar düğmesi nerede?"},
    "desktop_do": {"title": "Uygulamada tıkla (hızlı)", "icon": "MousePointerClick", "say": "Sağdaki ayarlar düğmesine bas"},
    "desktop_type": {"title": "Uygulamada yaz (hızlı)", "icon": "Keyboard", "say": "Sağdaki sohbet kutusuna merhaba yaz"},
    "type_into": {"title": "Alana yaz", "icon": "Keyboard", "say": ""},
    "press_keys": {"title": "Tuşa bas", "icon": "Command", "say": "Ctrl+S'ye bas"},
    "focus_window": {"title": "Pencereye geç", "icon": "PanelTop", "say": "VS Code'a geç"},
    # browser
    "browser_task": {"title": "Tarayıcı görevi", "icon": "Globe", "say": "Hepsiburada'da SSD fiyatlarına bak"},
    "ask_web_ai": {"title": "ChatGPT / Gemini / Claude'a sor", "icon": "Sparkles",
                   "say": "ChatGPT'ye bu hatanın nedenini sor"},
    "browser_do": {"title": "Sayfada tıkla (hızlı)", "icon": "MousePointerClick", "say": "Sağ üstteki giriş butonuna tıkla"},
    "browser_type_into": {"title": "Alana yaz (hızlı)", "icon": "TextCursorInput", "say": "Arama kutusuna kedi yaz ve ara"},
    "browser_scroll": {"title": "Sayfayı kaydır", "icon": "ChevronsDown", "say": "Aşağı kaydır"},
    "browser_back": {"title": "Geri git", "icon": "Undo2", "say": "Geri git"},
    "browser_read_paragraph": {"title": "Paragraf oku", "icon": "BookOpen", "say": "Üçüncü paragrafı oku"},
    "browser_fill_form": {"title": "Formu doldur", "icon": "ClipboardList", "say": "Bu formu benim bilgilerimle doldur"},
    "browser_open": {"title": "Sayfa aç", "icon": "Link", "say": "github.com'u aç"},
    "browser_read": {"title": "Sayfayı oku", "icon": "BookOpen", "say": "Bu sayfayı özetle"},
    "browser_click": {"title": "Sayfada tıkla", "icon": "MousePointer2", "say": ""},
    "browser_type": {"title": "Sayfaya yaz", "icon": "TextCursorInput", "say": ""},
    # routines
    "set_reminder": {"title": "Hatırlatıcı", "icon": "Bell", "say": "20 dakika sonra ocağı hatırlat"},
    "set_timer": {"title": "Zamanlayıcı", "icon": "Timer", "say": "Çay için 7 dakika kur"},
    "set_alarm": {"title": "Alarm", "icon": "AlarmClock", "say": "Yarın 7'de uyandır"},
    "list_reminders": {"title": "Hatırlatıcılarım", "icon": "ListChecks", "say": "Bugün neler var?"},
    "cancel_reminder": {"title": "Hatırlatıcı iptal", "icon": "BellOff", "say": "Alarmı iptal et"},
    "snooze_reminder": {"title": "Ertele", "icon": "TimerReset", "say": "10 dakika ertele"},
    "focus_mode": {"title": "Odak modu", "icon": "Target", "say": "Odak modunu başlat"},
    "create_routine": {"title": "Rutin kur", "icon": "Workflow", "say": "VS Code açılınca müzik açmayı sor"},
    # notes
    "take_note": {"title": "Not al", "icon": "StickyNote", "say": "Not al: yarın faturayı öde"},
    "list_notes": {"title": "Notlarım", "icon": "NotebookText", "say": "Notlarımı oku"},
    "delete_note": {"title": "Not sil", "icon": "Trash2", "say": ""},
    "complete_note": {"title": "Notu tamamla", "icon": "CheckSquare", "say": "Fatura notunu tamamlandı yap"},
    # windows
    "arrange_window": {"title": "Pencere yerleştir", "icon": "PanelLeft", "say": "VS Code'u sola al"},
    "side_by_side": {"title": "Yan yana diz", "icon": "Columns2", "say": "VS Code ile Chrome'u yan yana koy"},
    "show_desktop": {"title": "Masaüstünü göster", "icon": "Monitor", "say": "Masaüstünü göster"},
    "list_windows": {"title": "Açık pencereler", "icon": "LayoutGrid", "say": ""},
    "read_screen_text": {"title": "Ekrandaki yazıyı oku", "icon": "ScanText", "say": "Bu penceredeki metni kopyala"},
    "take_screenshot": {"title": "Ekran görüntüsü", "icon": "Camera", "say": "Ekran görüntüsü al"},
    # info
    "get_weather": {"title": "Hava durumu", "icon": "CloudSun", "say": "Yarın yağmur yağacak mı?"},
    "set_my_location": {"title": "Konumumu ayarla", "icon": "MapPin", "say": "Ben Canik'teyim"},
    "get_exchange_rate": {"title": "Döviz kuru", "icon": "BadgeDollarSign", "say": "100 euro kaç TL?"},
    "get_news": {"title": "Haberler", "icon": "Newspaper", "say": "Bugün neler oluyor?"},
    "daily_brief": {"title": "Günün özeti", "icon": "Sunrise", "say": "Günaydın, günü özetle"},
    # AI tools / editors
    "send_to_ai_tool": {"title": "Kod editörüne / AI aracına gönder", "icon": "Code2",
                        "say": "Claude Code'a bu testi düzeltmesini söyle"},
    "list_ai_tools": {"title": "Bağlı AI araçları", "icon": "Blocks", "say": "Hangi AI araçlarına bağlısın?"},
}

CATEGORIES: dict[str, dict[str, str]] = {
    "apps": {"title": "Uygulamalar", "icon": "AppWindow"},
    "files": {"title": "Dosyalar", "icon": "Folder"},
    "system": {"title": "Sistem", "icon": "Cpu"},
    "media": {"title": "Müzik ve video", "icon": "Music2"},
    "communication": {"title": "Mesajlaşma", "icon": "MessageCircle"},
    "memory": {"title": "Hafıza", "icon": "Brain"},
    "screen": {"title": "Ekran ve bağlam", "icon": "Eye"},
    "desktop": {"title": "Masaüstü kontrolü", "icon": "MousePointerClick"},
    "browser": {"title": "Tarayıcı", "icon": "Globe"},
    "routines": {"title": "Hatırlatıcı ve rutinler", "icon": "Repeat"},
    "info": {"title": "Bilgi", "icon": "CloudSun"},
    "ai-tools": {"title": "Kod editörleri ve AI araçları", "icon": "Code2"},
    "notes": {"title": "Notlar", "icon": "StickyNote"},
    "windows": {"title": "Pencereler", "icon": "PanelLeft"},
    "mail": {"title": "E-posta ve takvim", "icon": "Mail"},
    "mcp": {"title": "MCP araçları", "icon": "Plug"},
}


# MCP preset tools (names are "<server>_<tool>")
TOOLS.update({
    "google_search_gmail_messages": {"title": "Maillerde ara", "icon": "Mail", "say": "Bugün gelen mailleri özetle"},
    "google_get_gmail_message_content": {"title": "Maili oku", "icon": "Mail", "say": ""},
    "google_get_gmail_messages_content_batch": {"title": "Mailleri oku", "icon": "Mail", "say": ""},
    "google_get_gmail_thread_content": {"title": "Mail yazışmasını oku", "icon": "Mail", "say": ""},
    "google_send_gmail_message": {"title": "Mail gönder", "icon": "Mail", "say": "Ahmet'e yarınki toplantıyı soran bir mail yaz"},
    "google_draft_gmail_message": {"title": "Mail taslağı hazırla", "icon": "Mail", "say": "Hocama ödev için bir taslak hazırla"},
    "google_list_calendars": {"title": "Takvimleri listele", "icon": "CalendarDays", "say": ""},
    "google_get_events": {"title": "Takvime bak", "icon": "CalendarDays", "say": "Bu hafta takvimimde ne var?"},
    "google_manage_event": {"title": "Takvim etkinliği", "icon": "CalendarDays", "say": "Cuma saat 3'e dişçi randevusu ekle"},
    "google_query_freebusy": {"title": "Boş zamanları bul", "icon": "CalendarDays", "say": ""},
    "windows_snapshot": {"title": "Ekranı çözümle (Windows-MCP)", "icon": "ScanText", "say": ""},
    "windows_click": {"title": "Tıkla (Windows-MCP)", "icon": "MousePointerClick", "say": ""},
    "windows_type": {"title": "Yaz (Windows-MCP)", "icon": "Keyboard", "say": ""},
    "windows_app": {"title": "Uygulama (Windows-MCP)", "icon": "AppWindow", "say": ""},
})


def title_of(name: str) -> str:
    return TOOLS.get(name, {}).get("title") or name.replace("_", " ").capitalize()
