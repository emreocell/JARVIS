"""Real app icons for the launcher via the Windows shell.

``shell:AppsFolder\\<AppID>`` covers Store and desktop apps alike;
IShellItemImageFactory renders the icon, which is cached as a small PNG
under the data dir and returned as a data URL.
"""

from __future__ import annotations

import base64
import ctypes
import hashlib
import io
import logging
import threading
from ctypes import wintypes

from jarvis import paths

log = logging.getLogger(__name__)

SIZE = 64
_lock = threading.Lock()
_mem: dict[str, str | None] = {}


class _SIZE(ctypes.Structure):
    _fields_ = [("cx", ctypes.c_long), ("cy", ctypes.c_long)]


def _render(parsing_name: str) -> bytes | None:
    import comtypes
    from comtypes import GUID, HRESULT, COMMETHOD, IUnknown

    class IShellItemImageFactory(IUnknown):
        _iid_ = GUID("{bcc18b79-ba16-442f-80c4-8a59c30c463b}")
        _methods_ = [COMMETHOD([], HRESULT, "GetImage", (["in"], _SIZE, "size"), (["in"], ctypes.c_int, "flags"),
                               (["out"], ctypes.POINTER(wintypes.HBITMAP), "phbm"))]

    comtypes.CoInitialize()
    try:
        shell32 = ctypes.windll.shell32
        ptr = ctypes.POINTER(IShellItemImageFactory)()
        hr = shell32.SHCreateItemFromParsingName(ctypes.c_wchar_p(parsing_name), None,
                                                 ctypes.byref(IShellItemImageFactory._iid_), ctypes.byref(ptr))
        if hr != 0 or not ptr:
            return None
        hbm = ptr.GetImage(_SIZE(SIZE, SIZE), 0x1)  # SIIGBF_BIGGERSIZEOK
        return _hbitmap_to_png(hbm)
    finally:
        comtypes.CoUninitialize()


def _hbitmap_to_png(hbm: int) -> bytes | None:
    from PIL import Image

    gdi32 = ctypes.windll.gdi32

    class BITMAP(ctypes.Structure):
        _fields_ = [("bmType", ctypes.c_long), ("bmWidth", ctypes.c_long), ("bmHeight", ctypes.c_long),
                    ("bmWidthBytes", ctypes.c_long), ("bmPlanes", wintypes.WORD), ("bmBitsPixel", wintypes.WORD),
                    ("bmBits", ctypes.c_void_p)]

    class BITMAPINFOHEADER(ctypes.Structure):
        _fields_ = [("biSize", wintypes.DWORD), ("biWidth", ctypes.c_long), ("biHeight", ctypes.c_long),
                    ("biPlanes", wintypes.WORD), ("biBitCount", wintypes.WORD), ("biCompression", wintypes.DWORD),
                    ("biSizeImage", wintypes.DWORD), ("biXPelsPerMeter", ctypes.c_long),
                    ("biYPelsPerMeter", ctypes.c_long), ("biClrUsed", wintypes.DWORD), ("biClrImportant", wintypes.DWORD)]

    try:
        bm = BITMAP()
        gdi32.GetObjectW(ctypes.c_void_p(hbm), ctypes.sizeof(bm), ctypes.byref(bm))
        w, h = bm.bmWidth, bm.bmHeight
        if w <= 0 or h <= 0:
            return None
        info = BITMAPINFOHEADER(ctypes.sizeof(BITMAPINFOHEADER), w, -h, 1, 32, 0, 0, 0, 0, 0, 0)
        buf = ctypes.create_string_buffer(w * h * 4)
        hdc = ctypes.windll.user32.GetDC(None)
        try:
            gdi32.GetDIBits(hdc, ctypes.c_void_p(hbm), 0, h, buf, ctypes.byref(info), 0)
        finally:
            ctypes.windll.user32.ReleaseDC(None, hdc)
        img = Image.frombuffer("RGBA", (w, h), buf.raw, "raw", "BGRA", 0, 1)
        if img.getextrema()[3][1] == 0:  # icon without alpha channel: treat as opaque
            img.putalpha(255)
        img = img.resize((SIZE, SIZE), Image.LANCZOS) if (w, h) != (SIZE, SIZE) else img
        img = _plate_if_light(img)
        out = io.BytesIO()
        img.save(out, "PNG", optimize=True)
        return out.getvalue()
    finally:
        gdi32.DeleteObject(ctypes.c_void_p(hbm))


def _plate_if_light(img):
    """Store apps like Spotify ship a white glyph meant for a coloured tile —
    invisible on a light UI. Put such glyphs on a dark rounded plate."""
    from PIL import Image, ImageDraw

    px = [p for p in img.getdata() if p[3] > 128]
    if not px:
        return img
    lum = sum(0.299 * r + 0.587 * g + 0.114 * b for r, g, b, _ in px) / len(px) / 255
    sat = sum(max(r, g, b) - min(r, g, b) for r, g, b, _ in px) / len(px) / 255
    coverage = len(px) / (img.width * img.height)
    if lum < 0.85 or sat > 0.12 or coverage > 0.75:  # only near-white, colourless glyphs
        return img
    plate = Image.new("RGBA", img.size, (0, 0, 0, 0))
    ImageDraw.Draw(plate).rounded_rectangle((0, 0, img.width - 1, img.height - 1), radius=img.width // 4,
                                            fill=(30, 32, 44, 255))
    glyph = img.resize((int(img.width * 0.78),) * 2, Image.LANCZOS)
    offset = (img.width - glyph.width) // 2
    plate.alpha_composite(glyph, (offset, offset))
    return plate


def app_icon(app_id: str) -> str | None:
    """Data URL for a Start-menu AppID (cached in memory and on disk)."""
    if app_id in _mem:
        return _mem[app_id]
    folder = paths.data_dir() / "icons"
    path = folder / (hashlib.sha1(app_id.encode("utf-8")).hexdigest()[:16] + ".png")
    data: bytes | None = None
    with _lock:
        try:
            if path.exists():
                data = path.read_bytes()
            else:
                data = _render(f"shell:AppsFolder\\{app_id}")
                if data:
                    folder.mkdir(parents=True, exist_ok=True)
                    path.write_bytes(data)
        except Exception:
            log.debug("icon failed for %s", app_id, exc_info=True)
    url = f"data:image/png;base64,{base64.b64encode(data).decode()}" if data else None
    _mem[app_id] = url
    return url
