"""Filesystem locations for user data.

All mutable state lives outside the source tree (and outside OneDrive) under
``%LOCALAPPDATA%\\Jarvis`` by default. Set ``JARVIS_HOME`` to override, which
tests use to isolate themselves.
"""

from __future__ import annotations

import os
from pathlib import Path

from platformdirs import user_data_dir


def data_dir() -> Path:
    override = os.environ.get("JARVIS_HOME")
    path = Path(override) if override else Path(user_data_dir("Jarvis", appauthor=False))
    path.mkdir(parents=True, exist_ok=True)
    return path


def config_path() -> Path:
    return data_dir() / "config.json"


def runtime_path() -> Path:
    """Connection info (port + token) the UI reads to find the core."""
    return data_dir() / "runtime.json"


def state_path() -> Path:
    return data_dir() / "state.json"
