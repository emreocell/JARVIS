"""``python -m jarvis`` — start Jarvis as a desktop app (core + native windows).

Use ``python -m jarvis.app`` to run only the headless core.
"""

import sys

if sys.platform == "darwin":
    from jarvis.desktop.mac_app import main
else:
    from jarvis.desktop.app import main

raise SystemExit(main())
