"""One-click import from the previous JARVIS (v2) installation.

Reads the old ``config/api_keys.json``, stores every non-empty API key in
Credential Manager and attaches it to the matching provider. Only runs when
the user explicitly asks for it from the UI.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

from jarvis.fsutil import read_json

log = logging.getLogger(__name__)

DEFAULT_LEGACY_PATHS = [
    Path.home() / "OneDrive" / "Masaüstü" / "jev-jarvis" / "jarvis" / "config" / "api_keys.json",
    Path.home() / "Desktop" / "jev-jarvis" / "jarvis" / "config" / "api_keys.json",
]

# legacy field -> (provider id, secret name prefix)
_FIELDS = {
    "gemini_api_key": ("gemini", "gemini"),
    "gemini_secondary_api_key": ("gemini", "gemini"),
    "groq_api_key": ("groq", "groq"),
    "openrouter_api_key": ("openrouter", "openrouter"),
    "nvidia_api_key": ("nvidia", "nvidia"),
}

_EXTRA_PROVIDERS = {
    "openrouter": {"id": "openrouter", "type": "openai_compatible", "label": "OpenRouter",
                   "base_url": "https://openrouter.ai/api/v1", "enabled": True},
    "nvidia": {"id": "nvidia", "type": "openai_compatible", "label": "NVIDIA NIM",
               "base_url": "https://integrate.api.nvidia.com/v1", "enabled": False},
}


def find_legacy_config() -> Path | None:
    return next((p for p in DEFAULT_LEGACY_PATHS if p.exists()), None)


def collect_keys(raw: dict[str, Any]) -> list[tuple[str, str]]:
    """Return ``[(provider_id, key), ...]`` without duplicates."""
    found: list[tuple[str, str]] = []
    for field, (provider, _) in _FIELDS.items():
        value = raw.get(field)
        if isinstance(value, str) and value.strip():
            found.append((provider, value.strip()))
    for value in raw.get("gemini_extra_api_keys") or []:
        if isinstance(value, str) and value.strip():
            found.append(("gemini", value.strip()))
    seen: set[str] = set()
    unique = []
    for provider, key in found:
        if key not in seen:
            seen.add(key)
            unique.append((provider, key))
    return unique


def plan_import(path: Path) -> list[tuple[str, str]]:
    return collect_keys(read_json(path))


def extra_provider(provider_id: str) -> dict[str, Any] | None:
    return _EXTRA_PROVIDERS.get(provider_id)
