"""macOS context tracker: same interface as the Windows one (history of
Focus, current(), summary(), prompt_block()), fed by polling the frontmost
app (NSWorkspace) and its focused window title (Accessibility) once a second."""

from __future__ import annotations

import logging
import threading
import time

from jarvis.context.tracker import ContextTracker, Focus

log = logging.getLogger(__name__)

MAC_APP_NAMES = {"Code": "VS Code", "Visual Studio Code": "VS Code", "Google Chrome": "Chrome", "Opera": "Opera GX",
                 "Opera GX": "Opera GX", "Microsoft Edge": "Edge", "iTerm2": "Terminal"}


def _front() -> tuple[str, str]:
    from jarvis.platform import mac

    name, pid = mac.frontmost()
    title = ""
    try:
        win = mac.ax_focused_window(pid)
        if win is not None:
            title = str(mac.ax_attr(win, "AXTitle") or "")
    except Exception:
        pass
    return name, title


class MacContextTracker(ContextTracker):
    def __init__(self, *args, **kwargs) -> None:
        super().__init__(*args, **kwargs)
        self._stop_evt = threading.Event()

    def _make_focus(self, exe: str, title: str) -> Focus:
        app = MAC_APP_NAMES.get(exe, exe or "?")
        if any(x in app.lower() or x in title.lower() for x in self.excluded):
            return Focus(time.time(), app, "(gizli)", exe)
        # "file.py — project" (VS Code on macOS uses an em dash too): project_of() understands both
        return Focus(time.time(), app, title, exe)

    def start(self) -> None:
        if self._thread is None:
            self._stop_evt.clear()
            self._thread = threading.Thread(target=self._poll, name="context-tracker", daemon=True)
            self._thread.start()
            log.info("context tracker started (macOS)")

    def stop(self) -> None:
        self._stop_evt.set()
        self._thread = None

    def _poll(self) -> None:
        while not self._stop_evt.is_set():
            try:
                name, title = _front()
                if name and name not in ("Python", "Jarvis"):
                    focus = self._make_focus(name, title)
                    last = self.history[-1] if self.history else None
                    if last is None or (last.app, last.title) != (focus.app, focus.title):
                        self.history.append(focus)
                        if self.on_focus and (last is None or last.app != focus.app):
                            self.on_focus(focus)
            except Exception:
                log.debug("mac focus poll failed", exc_info=True)
            self._stop_evt.wait(1.0)

    def current(self) -> Focus | None:
        try:
            name, title = _front()
            return self._make_focus(name, title) if name else (self.history[-1] if self.history else None)
        except Exception:
            return self.history[-1] if self.history else None
