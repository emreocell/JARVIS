"""What is the user working on? — event-driven, local-only.

A ``SetWinEventHook(EVENT_SYSTEM_FOREGROUND)`` fires only when the foreground
window changes; there is no polling and nothing leaves the machine. We keep a
ring buffer of (time, app, title) and derive "projects" from well-known
window-title formats (VS Code, JetBrains, browsers...). Apps on the privacy
exclusion list are recorded as hidden.
"""

from __future__ import annotations

import ctypes
import logging
import re
import threading
import time
from collections import Counter, deque
from collections.abc import Callable
from ctypes import wintypes
from dataclasses import dataclass

import psutil

log = logging.getLogger(__name__)

EVENT_SYSTEM_FOREGROUND = 0x0003
WINEVENT_OUTOFCONTEXT = 0x0000
WM_QUIT = 0x0012

APP_NAMES = {
    "code.exe": "VS Code", "cursor.exe": "Cursor", "zed.exe": "Zed", "antigravity.exe": "Antigravity",
    "opera.exe": "Opera GX", "chrome.exe": "Chrome", "msedge.exe": "Edge", "firefox.exe": "Firefox",
    "spotify.exe": "Spotify", "whatsapp.exe": "WhatsApp", "whatsapp.root.exe": "WhatsApp",
    "discord.exe": "Discord", "explorer.exe": "Dosya Gezgini", "windowsterminal.exe": "Terminal",
    "notion.exe": "Notion", "claude.exe": "Claude", "chatgpt.exe": "ChatGPT", "winword.exe": "Word",
    "excel.exe": "Excel", "powerpnt.exe": "PowerPoint", "idea64.exe": "IntelliJ IDEA",
    "pycharm64.exe": "PyCharm", "webstorm64.exe": "WebStorm", "steam.exe": "Steam",
}
EDITORS = {"VS Code", "Cursor", "Zed", "Antigravity", "IntelliJ IDEA", "PyCharm", "WebStorm"}
BROWSERS = {"Opera GX", "Chrome", "Edge", "Firefox"}


@dataclass(slots=True)
class Focus:
    ts: float
    app: str
    title: str
    exe: str

    def as_dict(self) -> dict[str, str]:
        return {"app": self.app, "title": self.title, "project": project_of(self) or ""}


_NOT_PROJECTS = re.compile(
    r"^(release notes|sürüm notları|welcome|hoş geldiniz|get started|başlarken|settings|ayarlar|keyboard shortcuts|"
    r"klavye kısayolları|extension|uzantı|untitled|adsız|search|arama|output|çıkış|problems|sorunlar|"
    r"walkthrough|interactive|copilot|chat)\b", re.I)


def _plausible_project(name: str | None) -> str | None:
    """Reject editor-internal tabs ('Release Notes: 1.138.0') and bare file names."""
    if not name:
        return None
    name = name.lstrip("●○* ").strip()
    if not name or _NOT_PROJECTS.match(name) or re.search(r"\.[a-z0-9]{1,5}$", name, re.I):
        return None
    return name


def project_of(f: Focus) -> str | None:
    """Extract a project/workspace name from editor titles.

    VS Code / Cursor: "file.py - my-project - Visual Studio Code"
    JetBrains: "my-project – file.py"
    """
    if f.app in ("VS Code", "Cursor", "Antigravity"):
        parts = [p.strip() for p in re.split(r"\s+[-–—]\s+", f.title)]
        if len(parts) >= 3:
            return _plausible_project(parts[-2])
        if len(parts) == 2:
            return _plausible_project(parts[0])
    if f.app in ("IntelliJ IDEA", "PyCharm", "WebStorm", "Zed"):
        return _plausible_project(re.split(r"\s+[-–—]\s+", f.title)[0].strip())
    return None


def _foreground() -> tuple[int, str, str]:
    user32 = ctypes.windll.user32
    hwnd = user32.GetForegroundWindow()
    n = user32.GetWindowTextLengthW(hwnd)
    buf = ctypes.create_unicode_buffer(n + 1)
    user32.GetWindowTextW(hwnd, buf, n + 1)
    pid = wintypes.DWORD()
    user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
    try:
        exe = psutil.Process(pid.value).name()
    except psutil.Error:
        exe = ""
    return hwnd, exe, buf.value


class ContextTracker:
    def __init__(self, excluded: list[str] | None = None, maxlen: int = 300,
                 on_focus: Callable[[Focus], None] | None = None) -> None:
        self.excluded = [e.lower() for e in (excluded or [])]
        self.on_focus = on_focus  # called from the hook thread
        self.history: deque[Focus] = deque(maxlen=maxlen)
        self._thread: threading.Thread | None = None
        self._thread_id = 0
        self._proc = None  # keep the ctypes callback alive

    # ----------------------------------------------------------- recording

    def _make_focus(self, exe: str, title: str) -> Focus:
        app = APP_NAMES.get(exe.lower(), exe.removesuffix(".exe") or "?")
        if any(x in app.lower() or x in title.lower() or x in exe.lower() for x in self.excluded):
            return Focus(time.time(), app, "(gizli)", exe)
        return Focus(time.time(), app, title, exe)

    def _record(self) -> None:
        _, exe, title = _foreground()
        if not title or exe.lower() in ("python.exe", "pythonw.exe"):
            return
        focus = self._make_focus(exe, title)
        last = self.history[-1] if self.history else None
        if last is None or (last.app, last.title) != (focus.app, focus.title):
            self.history.append(focus)
            if self.on_focus and (last is None or last.app != focus.app):
                self.on_focus(focus)

    def _run(self) -> None:
        user32 = ctypes.windll.user32
        self._thread_id = ctypes.windll.kernel32.GetCurrentThreadId()
        WinEventProc = ctypes.WINFUNCTYPE(None, wintypes.HANDLE, wintypes.DWORD, wintypes.HWND,
                                          wintypes.LONG, wintypes.LONG, wintypes.DWORD, wintypes.DWORD)

        def callback(hook, event, hwnd, id_object, id_child, thread, ms):
            try:
                self._record()
            except Exception:
                log.debug("context record failed", exc_info=True)

        self._proc = WinEventProc(callback)
        hook = user32.SetWinEventHook(EVENT_SYSTEM_FOREGROUND, EVENT_SYSTEM_FOREGROUND, 0,
                                      self._proc, 0, 0, WINEVENT_OUTOFCONTEXT)
        self._record()
        msg = wintypes.MSG()
        while user32.GetMessageW(ctypes.byref(msg), 0, 0, 0) > 0:
            user32.TranslateMessage(ctypes.byref(msg))
            user32.DispatchMessageW(ctypes.byref(msg))
        user32.UnhookWinEvent(hook)

    def start(self) -> None:
        if self._thread is None:
            self._thread = threading.Thread(target=self._run, name="context-tracker", daemon=True)
            self._thread.start()
            log.info("context tracker started")

    def stop(self) -> None:
        if self._thread is not None and self._thread_id:
            ctypes.windll.user32.PostThreadMessageW(self._thread_id, WM_QUIT, 0, 0)
            self._thread.join(2)
        self._thread = None

    # ------------------------------------------------------------ queries

    def current(self) -> Focus | None:
        """Live read (titles change without a focus switch, e.g. browser tabs)."""
        try:
            _, exe, title = _foreground()
        except Exception:
            return self.history[-1] if self.history else None
        return self._make_focus(exe, title) if title else (self.history[-1] if self.history else None)

    def summary(self, minutes: float = 60) -> dict[str, object]:
        since = time.time() - minutes * 60
        items = [f for f in self.history if f.ts >= since]
        # time share per app: each focus lasts until the next one
        durations: Counter[str] = Counter()
        for a, b in zip(items, [*items[1:], None]):
            end = b.ts if b else time.time()
            durations[a.app] += end - a.ts
        projects = Counter(p for f in items if (p := project_of(f)))
        current = self.current()
        return {
            "active": current.as_dict() if current else None,
            "apps_last_hour": [{"app": a, "minutes": round(s / 60, 1)} for a, s in durations.most_common(6)],
            "projects": [p for p, _ in projects.most_common(3)],
            "recent_titles": [f"{f.app}: {f.title}" for f in items[-6:] if f.title != "(gizli)"],
        }

    def prompt_block(self) -> str:
        s = self.summary(90)
        active = s["active"]
        lines = []
        if active:
            lines.append(f"- Öndeki pencere başlığı (yalnızca başlık, ekran içeriği değil): {active['app']} — {active['title']}")
        if s["projects"]:
            lines.append(f"- Son projeler: {', '.join(s['projects'])}")  # type: ignore[arg-type]
        return "\n".join(lines)
