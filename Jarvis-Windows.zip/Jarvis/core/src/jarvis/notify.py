"""Native Windows toast notifications.

Unpackaged apps need a registered AppUserModelID to show toasts. Until the
Tauri installer registers "Jarvis", we borrow PowerShell's AUMID, which is
always registered.
"""

from __future__ import annotations

import logging
from xml.sax.saxutils import escape

log = logging.getLogger(__name__)

FALLBACK_AUMID = r"{1AC14E77-02E7-4E5D-B744-2EB1AE5198B7}\WindowsPowerShell\v1.0\powershell.exe"
SOUNDS = {"default": "Notification.Default", "reminder": "Notification.Reminder",
          "alarm": "Notification.Looping.Alarm", "silent": ""}


APP_AUMID = {"value": FALLBACK_AUMID}   # becomes "Jarvis.Assistant" once the Start-menu shortcut carries it


def toast(title: str, body: str, sound: str = "default", aumid: str | None = None) -> bool:
    aumid = aumid or APP_AUMID["value"]
    import sys

    if sys.platform == "darwin":
        import subprocess

        def q(s: str) -> str:
            return '"' + s.replace("\\", "\\\\").replace('"', '\\"') + '"'
        snd = "" if sound == "silent" else ' sound name "Glass"'
        r = subprocess.run(["osascript", "-e", f"display notification {q(body[:240])} with title {q(title[:80])}{snd}"],
                           capture_output=True)
        return r.returncode == 0
    try:
        from winrt.windows.data.xml.dom import XmlDocument
        from winrt.windows.ui.notifications import ToastNotification, ToastNotificationManager
    except ImportError:
        log.info("toast unavailable: %s — %s", title, body)
        return False
    snd = SOUNDS.get(sound, SOUNDS["default"])
    audio = '<audio silent="true"/>' if not snd else (
        f'<audio src="ms-winsoundevent:{snd}" loop="true"/>' if "Looping" in snd
        else f'<audio src="ms-winsoundevent:{snd}"/>')
    scenario = ' scenario="alarm"' if sound == "alarm" else (' scenario="reminder"' if sound == "reminder" else "")
    actions = '<actions><action content="Kapat" arguments="dismiss" activationType="system"/></actions>' \
        if scenario else ""
    xml = (f'<toast{scenario}><visual><binding template="ToastGeneric"><text>{escape(title)}</text>'
           f"<text>{escape(body)}</text></binding></visual>{audio}{actions}</toast>")
    try:
        doc = XmlDocument()
        doc.load_xml(xml)
        ToastNotificationManager.create_toast_notifier_with_id(aumid).show(ToastNotification(doc))
        return True
    except Exception:
        log.exception("toast failed")
        return False
