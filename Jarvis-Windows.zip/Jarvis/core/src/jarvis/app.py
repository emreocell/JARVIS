"""Command-line entry point: ``jarvis-core [--port N] [--log-level LEVEL]``."""

from __future__ import annotations

import argparse
import asyncio
import logging
import sys
from logging.handlers import RotatingFileHandler

from jarvis import paths
from jarvis.core import Core


def _setup_logging(level: str) -> None:
    # Windows consoles default to cp1254 here; an emoji in a song title would crash logging.
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(encoding="utf-8", errors="replace")
    log_dir = paths.data_dir() / "logs"
    log_dir.mkdir(exist_ok=True)
    fmt = logging.Formatter("%(asctime)s %(levelname)-7s %(name)s: %(message)s")
    file_handler = RotatingFileHandler(log_dir / "core.log", maxBytes=2_000_000,
                                       backupCount=3, encoding="utf-8")
    file_handler.setFormatter(fmt)
    console = logging.StreamHandler(sys.stderr)
    console.setFormatter(fmt)
    logging.basicConfig(level=level.upper(), handlers=[file_handler, console])


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="jarvis-core")
    parser.add_argument("--port", type=int, default=0, help="0 = pick a free port")
    parser.add_argument("--log-level", default="info")
    parser.add_argument("--no-voice", action="store_true",
                        help="UI development: no microphone, hotkeys, context tracking or remote")
    args = parser.parse_args(argv)
    _setup_logging(args.log_level)
    if sys.platform == "win32":
        import ctypes

        try:  # physical-pixel coordinates for screenshots / clicks on scaled displays
            ctypes.windll.shcore.SetProcessDpiAwareness(2)
        except Exception:
            pass
    core = Core(port=args.port, enable_voice=not args.no_voice)
    try:
        asyncio.run(core.run_forever())
    except KeyboardInterrupt:
        pass
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
