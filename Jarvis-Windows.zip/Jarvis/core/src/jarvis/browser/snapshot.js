// Page snapshot for the browser agent (injected via page.evaluate).
// Numbers every visible, interactive element (data-jarvis-id) and returns a
// compact table plus visible text. The model may only reference these ids —
// it never writes selectors or code.
(maxItems) => {
  const vw = window.innerWidth, vh = window.innerHeight
  const sel = [
    'a[href]', 'button', 'input:not([type=hidden])', 'textarea', 'select', 'summary',
    '[role=button]', '[role=link]', '[role=textbox]', '[role=searchbox]', '[role=combobox]',
    '[role=checkbox]', '[role=radio]', '[role=tab]', '[role=menuitem]', '[role=option]', '[role=switch]',
    '[contenteditable=""]', '[contenteditable=true]', '[onclick]', '[tabindex]:not([tabindex="-1"])',
  ].join(',')
  document.querySelectorAll('[data-jarvis-id]').forEach((e) => e.removeAttribute('data-jarvis-id'))
  const items = []
  let n = 0
  for (const el of document.querySelectorAll(sel)) {
    if (items.length >= maxItems) break
    const r = el.getBoundingClientRect()
    if (r.width < 4 || r.height < 4 || r.bottom < 0 || r.right < 0 || r.top > vh * 2.5 || r.left > vw) continue
    const st = getComputedStyle(el)
    if (st.visibility === 'hidden' || st.display === 'none' || Number(st.opacity) < 0.05) continue
    if (el.closest('[aria-hidden="true"]')) continue
    const tag = el.tagName.toLowerCase()
    const role = el.getAttribute('role') || (tag === 'a' ? 'link' : tag === 'input' ? (el.type || 'text') : tag)
    const label = (
      el.getAttribute('aria-label') || el.getAttribute('title') || el.getAttribute('placeholder') ||
      el.getAttribute('alt') || (tag === 'input' || tag === 'textarea' ? '' : el.innerText) || el.getAttribute('name') || ''
    ).replace(/\s+/g, ' ').trim().slice(0, 80)
    const value = (tag === 'input' || tag === 'textarea') ? String(el.value || '').slice(0, 60) : ''
    if (!label && !value && !['input', 'textarea', 'select'].includes(tag) && !el.isContentEditable) continue
    const id = ++n
    el.setAttribute('data-jarvis-id', String(id))
    // where it is on screen, in words the user uses ("sağ üst", "orta", "sol alt")
    const cx = (r.left + r.width / 2) / vw, cy = (r.top + r.height / 2) / vh
    const h = cx < 0.34 ? 'sol' : cx > 0.66 ? 'sağ' : 'orta'
    const v = cy < 0.34 ? 'üst' : cy > 0.66 ? 'alt' : ''
    const pos = r.top > vh ? 'aşağıda (kaydırınca)' : v ? (h === 'orta' ? `${v} orta` : `${h} ${v}`) : (h === 'orta' ? 'orta' : `${h} orta`)
    items.push({
      id, role, label, value, pos, x: Math.round(cx * 100), y: Math.round(cy * 100),
      disabled: !!el.disabled || el.getAttribute('aria-disabled') === 'true',
      checked: el.checked ?? (el.getAttribute('aria-checked') === 'true' ? true : undefined),
      offscreen: r.top > vh || r.bottom < 0,
    })
  }
  const text = (document.body?.innerText || '').replace(/\n{3,}/g, '\n\n').slice(0, 6000)
  // numbered content paragraphs ("üçüncü paragrafı oku")
  const root = document.querySelector('main, article, #mw-content-text, #content, [role=main]') || document.body
  const paragraphs = []
  for (const p of root.querySelectorAll('p, li')) {
    const t = (p.innerText || '').replace(/\s+/g, ' ').trim()
    if (t.length < 60 || p.closest('nav, header, footer, aside, [role=navigation]')) continue
    if (p.getBoundingClientRect().width < 50) continue
    paragraphs.push(t.slice(0, 1200))
    if (paragraphs.length >= 40) break
  }
  return { url: location.href, title: document.title, items, text, paragraphs }
}
