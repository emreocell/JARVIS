"""Browser control over CDP (Playwright ``connect_over_cdp``).

Modes (``features.browser_access``):
* ``jarvis_profile`` (default) — the user's browser (Opera GX / Chrome / Edge,
  from the default-browser setting) started with a dedicated Jarvis profile and
  a local debugging port. The user signs in to sites there once.
* ``full`` — attach to a browser the user started with remote debugging
  enabled (Chromium no longer allows debugging the default profile from the
  command line, so this requires opting in on the browser side).
* ``open_only`` — no control; links just open normally.
"""

from __future__ import annotations

import asyncio
import json
import logging
import shlex
import socket
import subprocess
from pathlib import Path
from typing import Any

import httpx

from jarvis import paths

log = logging.getLogger(__name__)

SNAPSHOT_JS = (Path(__file__).parent / "snapshot.js").read_text(encoding="utf-8")
DEFAULT_PORT = 9333


def default_browser_exe() -> str | None:
    """Executable of the user's default https handler (Opera GX here)."""
    import sys

    if sys.platform == "darwin":   # a Chromium browser (CDP): the first installed one
        for app, binary in (("Google Chrome", "Google Chrome"), ("Opera GX", "Opera"), ("Opera", "Opera"),
                            ("Brave Browser", "Brave Browser"), ("Microsoft Edge", "Microsoft Edge"),
                            ("Chromium", "Chromium")):
            for base in ("/Applications", str(Path.home() / "Applications")):
                exe = Path(base) / f"{app}.app" / "Contents" / "MacOS" / binary
                if exe.exists():
                    return str(exe)
        return None
    try:
        import winreg

        with winreg.OpenKey(winreg.HKEY_CURRENT_USER,
                            r"Software\Microsoft\Windows\Shell\Associations\UrlAssociations\https\UserChoice") as k:
            progid = winreg.QueryValueEx(k, "ProgId")[0]
        with winreg.OpenKey(winreg.HKEY_CLASSES_ROOT, rf"{progid}\shell\open\command") as k:
            cmd = winreg.QueryValueEx(k, "")[0]
        exe = shlex.split(cmd, posix=False)[0].strip('"')
        return exe if Path(exe).exists() else None
    except OSError:
        return None


def _port_open(port: int) -> bool:
    with socket.socket() as s:
        s.settimeout(0.3)
        return s.connect_ex(("127.0.0.1", port)) == 0


def _minimize_process_windows(pid: int) -> None:
    """Minimize the browser's top-level windows without activating them."""
    import ctypes
    from ctypes import wintypes

    user32 = ctypes.windll.user32
    found: list[int] = []

    @ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
    def each(hwnd, _):
        owner = wintypes.DWORD()
        user32.GetWindowThreadProcessId(hwnd, ctypes.byref(owner))
        if owner.value == pid and user32.IsWindowVisible(hwnd):
            found.append(hwnd)
        return True

    user32.EnumWindows(each, 0)
    for hwnd in found:
        user32.ShowWindow(hwnd, 7)   # SW_SHOWMINNOACTIVE


def _host(url: str) -> str:
    from urllib.parse import urlparse

    return (urlparse(url).hostname or "").removeprefix("www.")


class BrowserSession:
    def __init__(self, port: int = DEFAULT_PORT, headless: bool = False, profile_dir: Path | None = None) -> None:
        self.port = port
        self.headless = headless
        self._pw: Any = None
        self._browser: Any = None
        self._page: Any = None
        self._lock = asyncio.Lock()
        self.profile_dir = profile_dir or paths.data_dir() / "browser-profile"

    @property
    def connected(self) -> bool:
        return self._browser is not None and self._browser.is_connected()

    async def _launch(self, exe: str, background: bool = False) -> None:
        self.profile_dir.mkdir(parents=True, exist_ok=True)
        args = [exe, f"--remote-debugging-port={self.port}", f"--user-data-dir={self.profile_dir}",
                "--no-first-run", "--no-default-browser-check"]
        if self.headless:
            args.append("--headless=new")
        import sys

        flags = 0x08000000 if sys.platform == "win32" else 0
        self._proc = subprocess.Popen([*args, "about:blank"], creationflags=flags)
        for _ in range(60):
            if _port_open(self.port):
                if background:
                    import sys

                    await asyncio.sleep(0.6)
                    if sys.platform == "win32":
                        _minimize_process_windows(self._proc.pid)
                return
            await asyncio.sleep(0.25)
        raise RuntimeError("tarayıcı hata ayıklama portu açılmadı")

    async def ensure(self, mode: str = "jarvis_profile", background: bool = False) -> Any:
        """``background``: for proactive work (morning brief) — start the browser
        minimized and don't bring it to the front."""
        async with self._lock:
            if self.connected and self._page and not self._page.is_closed():
                return await self._follow_active()
            if mode == "open_only":
                raise PermissionError("Tarayıcı kontrolü kapalı (Ayarlar → Tarayıcı erişimi).")
            if not _port_open(self.port):
                if mode == "full":
                    raise RuntimeError(f"Tarayıcın {self.port} portunda uzaktan hata ayıklamayla açık değil.")
                exe = default_browser_exe()
                if exe is None:
                    raise RuntimeError("Varsayılan tarayıcı bulunamadı.")
                await self._launch(exe, background)
            from playwright.async_api import async_playwright

            if self._pw is None:
                self._pw = await async_playwright().start()
            self._browser = await self._pw.chromium.connect_over_cdp(f"http://127.0.0.1:{self.port}")
            context = self._browser.contexts[0] if self._browser.contexts else await self._browser.new_context()
            pages = [p for p in context.pages if not p.url.startswith(("devtools://", "chrome-extension://"))]
            self._page = pages[-1] if pages else await context.new_page()
            if not background:
                await self._page.bring_to_front()
            return self._page

    async def _follow_active(self) -> Any:
        """The user may have switched tabs (or opened one) in the Jarvis browser:
        act on the tab they are looking at. Background tabs also pause
        requestAnimationFrame, so clicks there never become "stable"."""
        page = self._page
        try:
            if await asyncio.wait_for(page.evaluate("document.visibilityState"), 0.5) == "visible":
                return page
        except Exception:
            pass
        for other in reversed(page.context.pages):
            if other is page or other.is_closed() or other.url.startswith(("devtools://", "chrome-extension://")):
                continue
            try:
                if await asyncio.wait_for(other.evaluate("document.visibilityState"), 0.5) == "visible":
                    log.info("browser: following the active tab %s", other.url[:80])
                    self._page = other
                    return other
            except Exception:
                continue
        return page

    async def page(self, mode: str = "jarvis_profile") -> Any:
        return await self.ensure(mode)

    async def goto(self, url: str, mode: str = "jarvis_profile") -> dict[str, Any]:
        page = await self.ensure(mode)
        if "://" not in url and not url.startswith(("about:", "data:")):
            url = "https://" + url
        page = await self._reuse_tab(page, url)
        try:
            await page.goto(url, wait_until="domcontentloaded", timeout=30_000)
        except Exception as exc:
            # SPAs (chatgpt.com) often supersede the initial navigation with their
            # own redirect/service worker: Chromium reports ERR_ABORTED although
            # the page does load. Only fail if we really didn't get there.
            if "ERR_ABORTED" not in str(exc):
                raise
            # Opera GX opens some sites (chatgpt.com) in a *new tab* and aborts
            # the navigation in ours: adopt the newest tab that got there.
            target, adopted = _host(url), None
            for _ in range(20):
                adopted = next((p for p in reversed(page.context.pages)
                                if not p.is_closed() and _host(p.url) == target), None)
                if adopted is not None:
                    break
                await asyncio.sleep(0.25)
            if adopted is None:
                raise
            if adopted is not page:
                self._page = adopted
                await adopted.bring_to_front()
                if page.url in ("", "about:blank"):
                    await page.close()
                page = adopted
            await page.wait_for_load_state("domcontentloaded", timeout=15_000)
        await self._settle(page)
        return {"url": page.url, "title": await page.title()}

    async def _reuse_tab(self, page: Any, url: str) -> Any:
        """Prefer a tab already on that site (and close its duplicates) so
        repeated tasks don't pile up tabs in the Jarvis browser."""
        target = _host(url)
        if not target or _host(page.url) == target:
            return page
        same = [p for p in page.context.pages if not p.is_closed() and _host(p.url) == target]
        if not same:
            return page
        keep, extra = same[-1], same[:-1]
        for p in extra:
            await p.close()
        if page.url in ("", "about:blank") and page is not keep:
            await page.close()
        self._page = keep
        await keep.bring_to_front()
        return keep

    async def snapshot(self, max_items: int = 160) -> dict[str, Any]:
        page = await self.ensure()
        for attempt in range(3):
            try:
                return await page.evaluate(SNAPSHOT_JS, max_items)
            except Exception as exc:
                # a click/submit may still be navigating: wait for the new page, then read it
                if "context was destroyed" not in str(exc) and "navigat" not in str(exc).lower() or attempt == 2:
                    raise
                try:
                    await page.wait_for_load_state("domcontentloaded", timeout=10_000)
                except Exception:
                    await asyncio.sleep(0.5)
        raise RuntimeError("unreachable")

    async def _settle(self, page: Any, ms: int = 2500) -> None:
        """Wait until the page is usable — not for network silence (many sites
        never go idle, which cost a fixed 2.5 s per action)."""
        try:
            await page.wait_for_load_state("domcontentloaded", timeout=ms)
        except Exception:
            pass
        try:  # short idle window catches quick XHR-driven updates
            await page.wait_for_load_state("networkidle", timeout=min(ms, 700))
        except Exception:
            pass

    def _loc(self, page: Any, element_id: int) -> Any:
        return page.locator(f'[data-jarvis-id="{int(element_id)}"]').first

    async def click(self, element_id: int) -> None:
        page = await self.ensure()
        loc = self._loc(page, element_id)
        await self._show_click(page, loc)
        await loc.click(timeout=8000)
        await self._settle(page)

    async def _show_click(self, page: Any, loc: Any) -> None:
        """HUD ripple where the click lands (viewport → screen coordinates)."""
        try:
            from jarvis.skills.desktop_control import HUD_ON

            if not HUD_ON["value"]:
                return
            box = await asyncio.wait_for(loc.bounding_box(), 1.0)
            win = await asyncio.wait_for(page.evaluate(
                "[screenX, screenY, outerWidth - innerWidth, outerHeight - innerHeight, devicePixelRatio]"), 1.0)
            if not box:
                return
            sx, sy, dw, dh, dpr = win
            left = (sx + dw / 2 + box["x"]) * dpr
            top = (sy + dh - dw / 2 + box["y"]) * dpr
            from jarvis.desktop.hud import HUD

            HUD.box(int(left), int(top), int(box["width"] * dpr), int(box["height"] * dpr), seconds=0.9)
            HUD.ripple(int(left + box["width"] * dpr / 2), int(top + box["height"] * dpr / 2))
        except Exception:
            pass

    async def type(self, element_id: int, text: str, submit: bool = False) -> None:
        page = await self.ensure()
        loc = self._loc(page, element_id)
        editable = await loc.evaluate("e => e.isContentEditable")
        if editable:
            await loc.click(timeout=8000)
            await page.keyboard.insert_text(text)
        else:
            await loc.fill(text, timeout=8000)
        if submit:
            await page.keyboard.press("Enter")
            await self._settle(page)

    async def press(self, key: str) -> None:
        page = await self.ensure()
        await page.keyboard.press(key)
        await self._settle(page, 1500)

    async def scroll(self, direction: str = "down") -> None:
        page = await self.ensure()
        await page.mouse.wheel(0, 700 if direction == "down" else -700)
        await asyncio.sleep(0.4)

    async def back(self) -> None:
        page = await self.ensure()
        await page.go_back(wait_until="domcontentloaded", timeout=15_000)
        await self._settle(page, 1500)

    async def close(self) -> None:
        # disconnect only — the browser window stays for the user
        if self._pw is not None:
            try:
                await self._pw.stop()
            except Exception:
                pass
        self._pw = self._browser = self._page = None


def format_snapshot(snap: dict[str, Any], text_chars: int = 2500) -> str:
    """Compact, model-friendly rendering of a snapshot."""
    lines = [f"URL: {snap['url']}", f"Başlık: {snap['title']}", "Elemanlar:"]
    for it in snap["items"]:
        flags = "".join([" [pasif]" if it.get("disabled") else "", " [aşağıda]" if it.get("offscreen") else "",
                         f" [değer: {it['value']}]" if it.get("value") else "",
                         " [seçili]" if it.get("checked") is True else ""])
        where = f" ({it['pos']})" if it.get("pos") else ""
        lines.append(f"  [{it['id']}] {it['role']}: {it['label']}{where}{flags}")
    lines.append("Sayfa metni:\n" + snap["text"][:text_chars])
    return "\n".join(lines)


def to_json(obj: Any) -> str:
    return json.dumps(obj, ensure_ascii=False)
