"""Fast browser decisions with Jev.

Picking "which element?" is a choice problem, not a writing problem: Jev
(TypeSafe System One) answers it in ~300 ms, where a language-model step
takes 1.5–3 s. The LLM stays for what needs language (what to type, reading
the answer); everything else goes through Jev, with an LLM fallback when Jev
is unavailable or unsure.

Candidates carry their on-screen position ("sağ üst", "orta"...) so spatial
instructions ("sağdaki butona tıkla", "ortadaki seçeneği seç") resolve.
"""

from __future__ import annotations

import logging
import re
import time
from dataclasses import dataclass
from typing import Any

from jarvis.skills.text import norm

log = logging.getLogger(__name__)

MAX_OPTIONS = 30
CLICK_CONFIDENCE = 0.75

ROLE_WORDS = {
    "button": ("buton", "düğme", "dugme", "button", "tuş"),
    "link": ("bağlantı", "baglanti", "link"),
    "textbox": ("kutu", "alan", "arama", "search", "input", "yazı"),
    "checkbox": ("kutucuk", "onay kutusu", "checkbox", "işaretle"),
    "option": ("seçenek", "secenek", "option"),
    "tab": ("sekme", "tab"),
    "menuitem": ("menü", "menu"),
}


@dataclass(slots=True)
class Pick:
    item: dict[str, Any] | None
    choice: str
    confidence: float
    source: str  # "jev" | "llm"
    ms: int


def describe(it: dict[str, Any]) -> str:
    extra = f" [değer: {it['value']}]" if it.get("value") else ""
    return f"{it['role']} “{it['label'] or '(etiketsiz)'}” ({it.get('pos', '?')}){extra}"


def rank(items: list[dict[str, Any]], instruction: str, limit: int = MAX_OPTIONS) -> list[dict[str, Any]]:
    """Keep the most plausible candidates: word overlap with the instruction,
    matching role words ("buton", "bağlantı") and position words ("sağ üst")."""
    q = norm(instruction)
    words = {w for w in q.split() if len(w) > 2}
    roles = {role for role, keys in ROLE_WORDS.items() if any(k in q for k in keys)}
    stems = (("sag", "sag"), ("sol", "sol"), ("ust", "ust"), ("yukari", "ust"), ("alt", "alt"), ("asagi", "alt"),
             ("orta", "orta"))
    wanted_pos = {canon for w in q.split() for stem, canon in stems if w.startswith(stem)}

    def score(it: dict[str, Any]) -> float:
        label = norm(it.get("label", ""))
        s = 3.0 * sum(1 for w in words if w in label)
        role = it.get("role", "")
        if any(r in role for r in roles) or ("textbox" in roles and role in ("search", "text", "searchbox", "textarea")):
            s += 2.0
        pos = it.get("pos", "")
        s += 1.5 * sum(1 for p in wanted_pos if p in norm(pos))
        if it.get("disabled"):
            s -= 5
        if "aşağıda" in pos:
            s -= 1
        return s

    ranked = sorted(items, key=score, reverse=True)
    return ranked[:limit]


def page_state(snap: dict[str, Any], goal: str, history: list[str] | None = None, text_chars: int = 600) -> str:
    lines = [f"Hedef: {goal}", f"Sayfa: {snap.get('title', '')} ({snap.get('url', '')})"]
    if history:
        lines.append("Yapılanlar: " + " | ".join(history[-6:]))
    lines.append("Sayfa metni (başı): " + (snap.get("text") or "")[:text_chars].replace("\n", " "))
    return "\n".join(lines)


async def pick_element(core: Any, snap: dict[str, Any], instruction: str,
                       roles: tuple[str, ...] | None = None) -> Pick:
    """Which element does the instruction mean? Jev first, LLM if Jev fails."""
    items = [it for it in snap["items"] if not roles or any(r in it.get("role", "") for r in roles)]
    candidates = rank(items, instruction)
    if not candidates:
        return Pick(None, "", 0.0, "none", 0)
    options = {str(it["id"]): describe(it) for it in candidates}
    state = page_state(snap, instruction)
    question = f"Kullanıcının isteği: “{instruction}”. Bu istek hangi sayfa öğesini kastediyor?"
    started = time.perf_counter()
    decider = core.decider
    decision = None
    if getattr(core.config.features, "jev_decider", False):
        try:
            decision = await decider._jev(state, question, options)
            if decision.choice not in options:
                decision = None
        except Exception as exc:
            log.info("jev pick failed (%s); using llm", exc)
    if decision is None or decision.confidence < 0.5:
        decision = await decider._llm(state, question, options)
    by_id = {str(it["id"]): it for it in candidates}
    return Pick(by_id.get(decision.choice), decision.choice, decision.confidence, decision.source,
                int((time.perf_counter() - started) * 1000))


NEXT_SPECIAL = {
    "__type__": "Bir metin kutusuna yazı yazmak gerekiyor",
    "__done__": "Hedefe ulaşıldı; istenen bilgi sayfada görünüyor",
    "__scroll__": "İstenen şey görünmüyor; aşağı kaydırmak gerekiyor",
    "__other__": "Hiçbiri / emin değilim",
}


async def next_action(core: Any, snap: dict[str, Any], goal: str, history: list[str]) -> Pick | None:
    """One fast agent step: Jev chooses between clicking a candidate element or a
    special action. None = let the LLM decide this step."""
    if not getattr(getattr(core.config, "features", None), "jev_decider", False) or not hasattr(core, "decider"):
        return None
    candidates = rank([it for it in snap["items"] if "aşağıda" not in it.get("pos", "")], goal, 24)
    options = {str(it["id"]): "Tıkla: " + describe(it) for it in candidates}
    options.update(NEXT_SPECIAL)
    started = time.perf_counter()
    try:
        d = await core.decider._jev(page_state(snap, goal, history), "Hedefe ilerlemek için şimdi ne yapılmalı?",
                                    options)
    except Exception as exc:
        log.info("jev step failed: %s", exc)
        return None
    ms = int((time.perf_counter() - started) * 1000)
    by_id = {str(it["id"]): it for it in candidates}
    return Pick(by_id.get(d.choice), d.choice, d.confidence, "jev", ms)


def paragraph(snap: dict[str, Any], n: int) -> str | None:
    paras = snap.get("paragraphs") or []
    if not paras:
        return None
    idx = n - 1 if n > 0 else len(paras) + n
    return paras[idx] if 0 <= idx < len(paras) else None


ORDINALS = {"birinci": 1, "ilk": 1, "ikinci": 2, "üçüncü": 3, "ucuncu": 3, "dördüncü": 4, "dorduncu": 4,
            "beşinci": 5, "besinci": 5, "altıncı": 6, "altinci": 6, "yedinci": 7, "sekizinci": 8,
            "dokuzuncu": 9, "onuncu": 10, "son": -1, "sonuncu": -1}


def ordinal(text: str) -> int | None:
    t = text.lower()
    for word, n in ORDINALS.items():
        if re.search(rf"\b{word}\b", t):
            return n
    m = re.search(r"(\d+)\s*\.?\s*(?:sıra|paragraf)", t)
    return int(m.group(1)) if m else None
