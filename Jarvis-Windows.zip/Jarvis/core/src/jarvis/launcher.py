"""Command-bar launcher: instant local results while typing.

Everything here is local and fast (no LLM, no network): installed apps,
recently used files, Jarvis pages, fast-command previews, an inline
calculator, plus "search the web" / "ask Jarvis" fallbacks.
"""

from __future__ import annotations

import ast
import math
import operator
import os
import re
import time
import urllib.parse
import webbrowser
from pathlib import Path
from typing import Any

from jarvis.skills.text import norm

PAGES = {
    "home": "Ana Sayfa", "history": "Sohbetler", "notes": "Notlar", "tasks": "Görevler", "routines": "Rutinler",
    "memory": "Hafıza", "skills": "Yetenekler", "providers": "Modeller", "settings": "Ayarlar",
}
PAGE_ALIASES = {"settings": "ayarlar settings tercihler", "providers": "modeller api anahtar key sağlayıcı",
                "memory": "hafıza bellek memory", "notes": "notlar notes not defteri", "history": "sohbetler geçmiş history",
                "routines": "rutinler hatırlatıcı alarm", "skills": "yetenekler araçlar tools",
                "tasks": "görevler tasks", "home": "ana sayfa home"}


def rank(query: str, title: str) -> float:
    """Typing-oriented match score: prefixes and word starts beat fuzziness."""
    q, t = norm(query), norm(title)
    if not q or not t:
        return 0.0
    if t == q:
        return 1.0
    if t.startswith(q):
        return 0.95 - min(0.1, (len(t) - len(q)) / 200)
    words = t.split()
    if any(w.startswith(q) for w in words):
        return 0.88
    initials = "".join(w[0] for w in words if w)
    if len(q) >= 2 and initials.startswith(q.replace(" ", "")):
        return 0.84  # "vsc" -> Visual Studio Code
    if q in t:
        return 0.72
    qw = q.split()
    if len(qw) > 1 and all(any(w.startswith(x) for w in words) for x in qw):
        return 0.8
    return 0.0


# ------------------------------------------------------------ calculator

_OPS = {ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul, ast.Div: operator.truediv,
        ast.Pow: operator.pow, ast.Mod: operator.mod, ast.FloorDiv: operator.floordiv,
        ast.USub: operator.neg, ast.UAdd: operator.pos}
_FUNCS = {"sqrt": math.sqrt, "kok": math.sqrt, "sin": math.sin, "cos": math.cos, "tan": math.tan,
          "log": math.log10, "ln": math.log, "abs": abs, "round": round}
_CONSTS = {"pi": math.pi, "e": math.e}


def calculate(expr: str) -> float | None:
    """Safe arithmetic: '12*7', '2^10', '%18 of 250' → None if not math."""
    s = expr.strip().lower().replace("×", "*").replace("÷", "/").replace("^", "**").replace(",", ".")
    s = re.sub(r"%\s*(\d+(?:\.\d+)?)\s*(?:of|nin|nın|in|ın)?\s+(\d+(?:\.\d+)?)", r"(\1/100*\2)", s)
    if not re.search(r"\d", s) or not re.fullmatch(r"[\d\s.+\-*/%()a-z_]+", s) or re.fullmatch(r"[\d.\s]+", s):
        return None

    def ev(node: ast.AST) -> float:
        if isinstance(node, ast.Expression):
            return ev(node.body)
        if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)):
            return float(node.value)
        if isinstance(node, ast.BinOp) and type(node.op) in _OPS:
            left, right = ev(node.left), ev(node.right)
            if isinstance(node.op, ast.Pow) and abs(right) > 1000:
                raise ValueError("too big")
            return _OPS[type(node.op)](left, right)
        if isinstance(node, ast.UnaryOp) and type(node.op) in _OPS:
            return _OPS[type(node.op)](ev(node.operand))
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id in _FUNCS:
            return float(_FUNCS[node.func.id](*[ev(a) for a in node.args]))
        if isinstance(node, ast.Name) and node.id in _CONSTS:
            return _CONSTS[node.id]
        raise ValueError("unsupported")

    try:
        value = ev(ast.parse(s, mode="eval"))
    except (SyntaxError, ValueError, ZeroDivisionError, TypeError, OverflowError):
        return None
    return value if math.isfinite(value) else None


def format_number(v: float) -> str:
    if abs(v - round(v)) < 1e-9 and abs(v) < 1e15:
        return f"{int(round(v)):,}".replace(",", ".")
    return f"{v:,.6f}".rstrip("0").rstrip(".").replace(",", "X").replace(".", ",").replace("X", ".")


# ---------------------------------------------------------- recent files

_recent_cache: tuple[float, list[tuple[str, str, float]]] = (0.0, [])


def recent_files(limit: int = 200) -> list[tuple[str, str, float]]:
    """(display name, .lnk path, mtime) from the Windows 'Recent' folder."""
    global _recent_cache
    if time.monotonic() - _recent_cache[0] < 30:
        return _recent_cache[1]
    folder = Path(os.environ.get("APPDATA", "")) / "Microsoft" / "Windows" / "Recent"
    items: list[tuple[str, str, float]] = []
    try:
        for entry in os.scandir(folder):
            if entry.name.lower().endswith(".lnk") and entry.is_file():
                items.append((entry.name[:-4], entry.path, entry.stat().st_mtime))
    except OSError:
        pass
    items.sort(key=lambda x: x[2], reverse=True)
    _recent_cache = (time.monotonic(), items[:limit])
    return _recent_cache[1]


# ------------------------------------------------------------- frecency

_usage: dict[str, list[float]] | None = None


def _usage_path() -> Path:
    from jarvis import paths

    return paths.data_dir() / "launcher_usage.json"


def record_use(item_id: str) -> None:
    """Remember launches so frequently/recently used results rank higher."""
    from jarvis.fsutil import atomic_write_json

    usage = _load_usage()
    usage.setdefault(item_id, []).append(time.time())
    usage[item_id] = usage[item_id][-20:]
    atomic_write_json(_usage_path(), usage)


def _load_usage() -> dict[str, list[float]]:
    global _usage
    if _usage is None:
        from jarvis.fsutil import read_json

        try:
            _usage = read_json(_usage_path())
        except Exception:
            _usage = {}
    return _usage


def frecency(item_id: str) -> float:
    """0..0.12 bonus: each use counts, decaying with a ~2-week half-life."""
    now = time.time()
    score = sum(0.5 ** ((now - t) / (14 * 86400)) for t in _load_usage().get(item_id, []))
    return min(0.12, 0.03 * score)


# ---------------------------------------------------------------- search

def search(query: str, apps: list[tuple[str, str]], fast_preview: str | None = None,
           limit: int = 8, notes: list[tuple[int, str]] | None = None) -> list[dict[str, Any]]:
    q = query.strip()
    if not q:
        return []
    results: list[dict[str, Any]] = []

    value = calculate(q)
    if value is not None:
        results.append({"id": f"calc:{format_number(value)}", "kind": "calc", "title": f"= {format_number(value)}",
                        "subtitle": "Enter ile panoya kopyala", "score": 1.2})
    if fast_preview:
        results.append({"id": f"fast:{q}", "kind": "action", "title": fast_preview,
                        "subtitle": "Anında çalışır · modele gitmez", "score": 1.1})

    for name, app_id in apps:
        s = rank(q, name)
        if s >= 0.7:
            results.append({"id": f"app:{app_id}", "kind": "app", "title": name, "subtitle": "Uygulama",
                            "score": s + 0.02 + frecency(f"app:{app_id}")})
    for page, label in PAGES.items():
        s = max(rank(q, label), rank(q, PAGE_ALIASES.get(page, "")) * 0.95)
        if s >= 0.8:
            results.append({"id": f"page:{page}", "kind": "page", "title": f"Jarvis · {label}",
                            "subtitle": "Sayfayı aç", "score": s - 0.05})
    if len(q) >= 2:
        for name, path, _ in recent_files():
            s = rank(q, name)
            if s >= 0.72:
                results.append({"id": f"file:{path}", "kind": "file", "title": name,
                                "subtitle": "Son kullanılan", "score": s - 0.08 + frecency(f"file:{path}")})

    for nid, text in (notes or [])[:3]:
        first = text.strip().splitlines()[0] if text.strip() else ""
        results.append({"id": f"note:{nid}", "kind": "note", "title": first[:90], "subtitle": "Not", "score": 0.74})

    results.sort(key=lambda r: r["score"], reverse=True)
    seen: set[str] = set()
    unique = []
    for r in results:
        key = norm(r["title"])
        if key not in seen:
            seen.add(key)
            unique.append(r)
    out = unique[: limit - 2]
    out.append({"id": f"ask:{q}", "kind": "ask", "title": f"Jarvis'e sor: {q}", "subtitle": "Yapay zekâ ile",
                "score": 0})
    out.append({"id": f"web:{q}", "kind": "web", "title": f"Web'de ara: {q}", "subtitle": "Varsayılan tarayıcı",
                "score": 0})
    return out


def open_file(path: str) -> None:
    os.startfile(path)  # type: ignore[attr-defined]


def web_search(query: str) -> None:
    webbrowser.open("https://www.google.com/search?q=" + urllib.parse.quote(query))
