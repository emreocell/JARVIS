"""Per-app mini commands: the command bar suggests what makes sense for the
app that was in front when it opened (VS Code ≠ Chrome ≠ Spotify)."""

from __future__ import annotations

from typing import Any

APP_ACTIONS: list[tuple[tuple[str, ...], str, list[str]]] = [
    (("code.exe", "cursor.exe", "antigravity.exe", "zed.exe", "idea64.exe", "pycharm64.exe", "webstorm64.exe"),
     "Kod editörü", ["Bu hatayı açıkla", "Seçili kodu açıkla", "Seçili kodu Claude'a gönder",
                     "Bugün bu projede ne yaptım?"]),
    (("opera.exe", "chrome.exe", "msedge.exe", "firefox.exe", "brave.exe", "vivaldi.exe"),
     "Tarayıcı", ["Bu sayfayı özetle", "Bu sayfayı Türkçeye çevir", "Bu sayfanın ana fikirlerini ikinci beynime kaydet",
                  "Bu sayfada önemli olan ne?"]),
    (("spotify.exe",), "Spotify", ["Şu an ne çalıyor?", "Buna benzer şarkılar çal", "Odak modunu başlat"]),
    (("whatsapp.exe", "whatsapp.root.exe", "telegram.exe"), "Mesajlaşma",
     ["Ben yokken kim yazdı?", "Son mesaja nazik bir cevap taslağı yaz"]),
    (("explorer.exe",), "Dosya Gezgini", ["Seçili dosyaları özetle", "Bu klasörde en son değişenleri bul"]),
    (("winword.exe", "notion.exe", "obsidian.exe", "notepad.exe"), "Yazı",
     ["Bunu daha profesyonel yaz", "Bunu özetle", "Yazım hatalarını düzelt", "Bunu İngilizceye çevir"]),
    (("excel.exe",), "Excel", ["Bu tablodaki garip değerleri bul", "Bu tabloyu özetle"]),
    (("powerpnt.exe",), "PowerPoint", ["Bu slaytı daha etkili yaz", "Konuşma notu çıkar"]),
    (("zoom.exe", "ms-teams.exe", "teams.exe", "discord.exe"), "Görüşme",
     ["Toplantı modunu başlat", "Toplantıda bana kalan işler ne?"]),
    (("windowsterminal.exe", "powershell.exe", "cmd.exe"), "Terminal", ["Bu hatayı açıkla", "Bu komut ne yapıyor?"]),
]
DEFAULT = ("Masaüstü", ["Ekranda ne var?", "Bugün ne yaptım?", "Ben yokken önemli bir şey oldu mu?"])


def actions_for(exe: str, title: str = "") -> dict[str, Any]:
    low = (exe or "").lower()
    for exes, label, actions in APP_ACTIONS:
        if low in exes:
            out = list(actions)
            if label == "Tarayıcı" and any(w in title.lower() for w in ("youtube", "video")):
                out.insert(0, "Bu videoyu özetle")
            return {"app": label, "actions": out}
    return {"app": DEFAULT[0], "actions": list(DEFAULT[1])}
