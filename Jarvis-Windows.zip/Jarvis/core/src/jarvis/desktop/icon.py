"""Procedural app icon: the pearly liquid orb of the UI (no binary assets in the repo)."""

from __future__ import annotations


def make_icon(size: int = 64):
    from PIL import Image, ImageChops, ImageDraw, ImageFilter

    ss = 4
    s = size * ss
    pad = s * 0.06
    box = (pad, pad, s - pad, s - pad)
    d = s - 2 * pad

    def blob(color: tuple[int, int, int], alpha: int, rect: tuple[float, float, float, float], blur: float):
        layer = Image.new("RGBA", (s, s), (0, 0, 0, 0))
        ImageDraw.Draw(layer).ellipse(rect, fill=(*color, alpha))
        return layer.filter(ImageFilter.GaussianBlur(blur))

    # body: lavender pearl, darker toward the rim
    body = Image.new("RGBA", (s, s), (0, 0, 0, 0))
    grad = Image.radial_gradient("L").resize((int(d), int(d)))  # 0 centre -> 255 edge
    base = Image.new("RGBA", (int(d), int(d)), (238, 234, 255, 255))
    rim = Image.new("RGBA", (int(d), int(d)), (104, 92, 236, 255))
    body.paste(Image.composite(rim, base, grad), (int(pad), int(pad)))

    # liquid light inside
    for color, alpha, rect, blur in (
        ((91, 108, 255), 210, (s * 0.12, s * 0.10, s * 0.62, s * 0.55), s * 0.08),   # indigo, top-left
        ((70, 224, 230), 190, (s * 0.46, s * 0.40, s * 0.94, s * 0.86), s * 0.09),   # cyan, lower-right
        ((255, 122, 200), 150, (s * 0.10, s * 0.52, s * 0.52, s * 0.92), s * 0.10),  # pink, lower-left
        ((255, 255, 255), 120, (s * 0.30, s * 0.34, s * 0.72, s * 0.70), s * 0.10),  # pearly core
    ):
        body.alpha_composite(blob(color, alpha, rect, blur))

    # rim shade + speculars
    shade = Image.new("RGBA", (s, s), (0, 0, 0, 0))
    ImageDraw.Draw(shade).ellipse(box, outline=(60, 50, 170, 110), width=int(s * 0.035))
    body.alpha_composite(shade.filter(ImageFilter.GaussianBlur(s * 0.02)))
    body.alpha_composite(blob((255, 255, 255), 200, (s * 0.24, s * 0.14, s * 0.56, s * 0.34), s * 0.035))
    body.alpha_composite(blob((255, 255, 255), 255, (s * 0.32, s * 0.19, s * 0.40, s * 0.25), s * 0.008))

    # crisp circular silhouette
    mask = Image.new("L", (s, s), 0)
    ImageDraw.Draw(mask).ellipse(box, fill=255)
    body.putalpha(ImageChops.multiply(body.getchannel("A"), mask))
    return body.resize((size, size), Image.LANCZOS)
