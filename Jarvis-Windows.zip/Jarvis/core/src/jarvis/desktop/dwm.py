"""Windows 11 DWM effects: rounded corners, dark frame, Mica/Acrylic backdrop."""

from __future__ import annotations

import ctypes
from ctypes import wintypes

DWMWA_USE_IMMERSIVE_DARK_MODE = 20
DWMWA_WINDOW_CORNER_PREFERENCE = 33
DWMWA_SYSTEMBACKDROP_TYPE = 38
BACKDROPS = {"none": 1, "mica": 2, "acrylic": 3, "tabbed": 4}
DWMWCP_ROUND = 2


class MARGINS(ctypes.Structure):
    _fields_ = [("left", ctypes.c_int), ("right", ctypes.c_int), ("top", ctypes.c_int), ("bottom", ctypes.c_int)]


def _set(hwnd: int, attr: int, value: int) -> int:
    v = ctypes.c_int(value)
    return ctypes.windll.dwmapi.DwmSetWindowAttribute(wintypes.HWND(hwnd), attr, ctypes.byref(v), ctypes.sizeof(v))


def clip_round(hwnd: int, width: int, height: int, radius: int) -> bool:
    """Cut the window itself into a rounded shape (works for any HWND,
    including WebView2 hosts where DWM backdrops and colour keys don't)."""
    try:
        gdi32, user32 = ctypes.windll.gdi32, ctypes.windll.user32
        scale = user32.GetDpiForWindow(wintypes.HWND(hwnd)) / 96 if hasattr(user32, "GetDpiForWindow") else 1
        w, h, r = int(width * scale), int(height * scale), int(radius * scale)
        region = gdi32.CreateRoundRectRgn(0, 0, w + 1, h + 1, r, r)
        return bool(user32.SetWindowRgn(wintypes.HWND(hwnd), region, True))
    except OSError:
        return False


def apply_backdrop(hwnd: int, kind: str = "acrylic", dark: bool = True) -> bool:
    """Returns True when the system accepted the backdrop (Windows 11 22H2+)."""
    try:
        _set(hwnd, DWMWA_USE_IMMERSIVE_DARK_MODE, int(dark))
        _set(hwnd, DWMWA_WINDOW_CORNER_PREFERENCE, DWMWCP_ROUND)
        ok = _set(hwnd, DWMWA_SYSTEMBACKDROP_TYPE, BACKDROPS.get(kind, 3)) == 0
        margins = MARGINS(-1, -1, -1, -1)  # extend the frame over the whole client area
        ctypes.windll.dwmapi.DwmExtendFrameIntoClientArea(wintypes.HWND(hwnd), ctypes.byref(margins))
        return ok
    except OSError:
        return False
