"""Screen HUD: Jarvis draws on top of everything — a box around the element
it means, a pointer with a label, a ripple where it clicks.

A native layered window (per-pixel alpha via UpdateLayeredWindow),
click-through, topmost, never activated, invisible to Alt+Tab. It is sized
to what is drawn (not the whole screen) and only renders while something
animates; idle it costs nothing. Coordinates are physical screen pixels
(the same as UI Automation's).
"""

from __future__ import annotations

import ctypes
import logging
import math
import queue
import sys
import threading
import time
from ctypes import wintypes
from dataclasses import dataclass, field

log = logging.getLogger(__name__)

ACCENT = (124, 92, 255)
FPS = 60


@dataclass
class Item:
    kind: str                    # box | pointer | ripple
    x: int
    y: int
    w: int = 0
    h: int = 0
    label: str = ""
    color: tuple[int, int, int] = ACCENT
    born: float = field(default_factory=time.monotonic)
    ttl: float = 3.0

    def alpha(self, now: float) -> float:
        age = now - self.born
        if self.kind == "ripple":
            return max(0.0, 1 - age / self.ttl)
        fade_in = min(1.0, age / 0.18)
        fade_out = min(1.0, max(0.0, (self.ttl - age) / 0.35))
        return fade_in * fade_out

    def bbox(self) -> tuple[int, int, int, int]:
        if self.kind == "caption":
            return self.x - self.w // 2 - 20, self.y - 20, self.x + self.w // 2 + 20, self.y + self.h + 20
        pad = 60
        if self.kind == "box":
            return self.x - pad, self.y - pad - 40, self.x + self.w + pad, self.y + self.h + pad
        if self.kind == "pointer":
            return self.x - 90, self.y - 90, self.x + 90 + 12 * len(self.label) + 60, self.y + 90
        r = 60
        return self.x - r - 6, self.y - r - 6, self.x + r + 6, self.y + r + 6


class _BLEND(ctypes.Structure):
    _fields_ = [("BlendOp", ctypes.c_ubyte), ("BlendFlags", ctypes.c_ubyte),
                ("SourceConstantAlpha", ctypes.c_ubyte), ("AlphaFormat", ctypes.c_ubyte)]


class _BMIH(ctypes.Structure):
    _fields_ = [("biSize", wintypes.DWORD), ("biWidth", wintypes.LONG), ("biHeight", wintypes.LONG),
                ("biPlanes", wintypes.WORD), ("biBitCount", wintypes.WORD), ("biCompression", wintypes.DWORD),
                ("biSizeImage", wintypes.DWORD), ("biXPelsPerMeter", wintypes.LONG),
                ("biYPelsPerMeter", wintypes.LONG), ("biClrUsed", wintypes.DWORD), ("biClrImportant", wintypes.DWORD)]


class Hud:
    def __init__(self) -> None:
        self._q: queue.Queue[Item | str] = queue.Queue()
        self._items: list[Item] = []
        self._thread: threading.Thread | None = None
        self._hwnd = 0
        self._visible = False

    # ------------------------------------------------------------ public

    def start(self) -> None:
        if self._thread is None and sys.platform == "win32":
            self._thread = threading.Thread(target=self._run, name="hud", daemon=True)
            self._thread.start()

    def box(self, x: int, y: int, w: int, h: int, label: str = "", seconds: float = 3.0) -> None:
        self.start()
        self._q.put(Item("box", int(x), int(y), int(w), int(h), label, ttl=seconds))

    def pointer(self, x: int, y: int, label: str = "", seconds: float = 3.5) -> None:
        self.start()
        self._q.put(Item("pointer", int(x), int(y), label=label, ttl=seconds))

    def ripple(self, x: int, y: int) -> None:
        self.start()
        self._q.put(Item("ripple", int(x), int(y), ttl=0.6))

    def clear(self) -> None:
        self._q.put("clear")

    def caption(self, text: str, seconds: float = 6.0) -> None:
        """Subtitle at the bottom centre of the primary screen (replaces the previous one)."""
        self.start()
        user32 = ctypes.windll.user32
        sw, sh = user32.GetSystemMetrics(0), user32.GetSystemMetrics(1)
        lines = _wrap(text, 70)[-2:]
        w = min(sw - 80, 24 + 13 * max((len(ln) for ln in lines), default=10))
        h = 18 + 34 * len(lines)
        self._q.put("clear-captions")
        self._q.put(Item("caption", sw // 2, sh - 160 - h, w, h, "\n".join(lines), ttl=seconds))

    # ------------------------------------------------------------ thread

    def _run(self) -> None:
        user32 = ctypes.windll.user32
        kernel32 = ctypes.windll.kernel32
        user32.DefWindowProcW.argtypes = [wintypes.HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM]
        user32.DefWindowProcW.restype = ctypes.c_ssize_t
        WNDPROC = ctypes.WINFUNCTYPE(ctypes.c_ssize_t, wintypes.HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM)
        self._proc = WNDPROC(lambda h, m, w, l: user32.DefWindowProcW(h, m, w, l))

        class WNDCLASSW(ctypes.Structure):
            _fields_ = [("style", wintypes.UINT), ("lpfnWndProc", WNDPROC), ("cbClsExtra", ctypes.c_int),
                        ("cbWndExtra", ctypes.c_int), ("hInstance", wintypes.HINSTANCE), ("hIcon", wintypes.HICON),
                        ("hCursor", wintypes.HANDLE), ("hbrBackground", wintypes.HBRUSH),
                        ("lpszMenuName", wintypes.LPCWSTR), ("lpszClassName", wintypes.LPCWSTR)]

        hinst = kernel32.GetModuleHandleW(None)
        wc = WNDCLASSW(0, self._proc, 0, 0, hinst, None, None, None, None, "JarvisHud")
        user32.RegisterClassW(ctypes.byref(wc))
        ex = 0x00080000 | 0x00000020 | 0x00000008 | 0x00000080 | 0x08000000  # LAYERED|TRANSPARENT|TOPMOST|TOOL|NOACTIVATE
        user32.CreateWindowExW.restype = wintypes.HWND
        self._hwnd = user32.CreateWindowExW(ex, "JarvisHud", "Jarvis HUD", 0x80000000, 0, 0, 1, 1,
                                            None, None, hinst, None)
        msg = wintypes.MSG()
        while True:
            while user32.PeekMessageW(ctypes.byref(msg), None, 0, 0, 1):
                user32.TranslateMessage(ctypes.byref(msg))
                user32.DispatchMessageW(ctypes.byref(msg))
            try:
                cmd = self._q.get(timeout=1 / FPS if self._items else 0.5)
                if cmd == "clear":
                    self._items.clear()
                elif cmd == "clear-captions":
                    self._items = [i for i in self._items if i.kind != "caption"]
                elif isinstance(cmd, Item):
                    self._items.append(cmd)
            except queue.Empty:
                pass
            now = time.monotonic()
            self._items = [i for i in self._items if now - i.born < i.ttl]
            if self._items:
                try:
                    self._render(now)
                except Exception:
                    log.debug("hud render failed", exc_info=True)
                    self._items.clear()
            elif self._visible:
                user32.ShowWindow(self._hwnd, 0)
                self._visible = False

    def compose(self, now: float):
        """The frame to show: (left, top, RGBA image) in screen pixels."""
        from PIL import Image, ImageDraw, ImageFilter

        boxes = [i.bbox() for i in self._items]
        left, top = min(b[0] for b in boxes), min(b[1] for b in boxes)
        right, bottom = max(b[2] for b in boxes), max(b[3] for b in boxes)
        w, h = max(1, right - left), max(1, bottom - top)
        img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
        glow = Image.new("RGBA", (w, h), (0, 0, 0, 0))
        d, g = ImageDraw.Draw(img), ImageDraw.Draw(glow)
        for it in self._items:
            a = it.alpha(now)
            x, y = it.x - left, it.y - top
            r, gg, b = it.color
            if it.kind == "box":
                rect = (x - 6, y - 6, x + it.w + 6, y + it.h + 6)
                g.rounded_rectangle(rect, 14, outline=(r, gg, b, int(170 * a)), width=10)
                d.rounded_rectangle(rect, 14, fill=(r, gg, b, int(28 * a)))   # fill first: Draw replaces pixels
                d.rounded_rectangle(rect, 14, outline=(r, gg, b, int(255 * a)), width=3)
                if it.label:
                    self._label(d, x - 6, y - 44, it.label, it.color, a)
            elif it.kind == "pointer":
                pulse = 1 + 0.12 * math.sin((now - it.born) * 7)
                rr = 14 * pulse
                g.ellipse((x - rr - 10, y - rr - 10, x + rr + 10, y + rr + 10), fill=(r, gg, b, int(120 * a)))
                d.ellipse((x - rr, y - rr, x + rr, y + rr), outline=(255, 255, 255, int(255 * a)), width=3,
                          fill=(r, gg, b, int(210 * a)))
                if it.label:
                    self._label(d, x + 26, y - 18, it.label, it.color, a)
            elif it.kind == "caption":
                from PIL import ImageFont

                try:
                    font = ImageFont.truetype("segoeui.ttf", 24)
                except OSError:
                    font = ImageFont.load_default()
                x0, y0 = x - it.w // 2, y
                d.rounded_rectangle((x0, y0, x0 + it.w, y0 + it.h), 18, fill=(18, 16, 30, int(200 * a)))
                for n, line in enumerate(it.label.split("\n")):
                    tw = d.textlength(line, font=font)
                    d.text((x - tw / 2, y0 + 9 + 34 * n), line, font=font, fill=(255, 255, 255, int(255 * a)))
            else:
                t = (now - it.born) / it.ttl
                rr = 10 + 48 * t
                d.ellipse((x - rr, y - rr, x + rr, y + rr), outline=(r, gg, b, int(230 * a)), width=4)
                d.ellipse((x - 7, y - 7, x + 7, y + 7), fill=(255, 255, 255, int(255 * a)))
        glow = glow.filter(ImageFilter.GaussianBlur(9))
        return left, top, Image.alpha_composite(glow, img)

    def _render(self, now: float) -> None:
        from PIL import Image

        user32, gdi32 = ctypes.windll.user32, ctypes.windll.gdi32
        left, top, frame = self.compose(now)
        w, h = frame.size
        # premultiplied BGRA for UpdateLayeredWindow
        rch, gch, bch, ach = frame.split()
        from PIL import ImageChops

        pre = Image.merge("RGBA", (ImageChops.multiply(bch, ach), ImageChops.multiply(gch, ach),
                                   ImageChops.multiply(rch, ach), ach))
        data = pre.tobytes()
        hdc_screen = user32.GetDC(None)
        hdc = gdi32.CreateCompatibleDC(hdc_screen)
        bmi = _BMIH(ctypes.sizeof(_BMIH), w, -h, 1, 32, 0, 0, 0, 0, 0, 0)
        bits = ctypes.c_void_p()
        gdi32.CreateDIBSection.restype = wintypes.HBITMAP
        hbmp = gdi32.CreateDIBSection(hdc, ctypes.byref(bmi), 0, ctypes.byref(bits), None, 0)
        ctypes.memmove(bits, data, len(data))
        old = gdi32.SelectObject(hdc, hbmp)
        pos, size, src = wintypes.POINT(left, top), wintypes.SIZE(w, h), wintypes.POINT(0, 0)
        blend = _BLEND(0, 0, 255, 1)
        user32.UpdateLayeredWindow(self._hwnd, hdc_screen, ctypes.byref(pos), ctypes.byref(size), hdc,
                                   ctypes.byref(src), 0, ctypes.byref(blend), 2)
        gdi32.SelectObject(hdc, old)
        gdi32.DeleteObject(hbmp)
        gdi32.DeleteDC(hdc)
        user32.ReleaseDC(None, hdc_screen)
        if not self._visible:
            user32.ShowWindow(self._hwnd, 8)   # SW_SHOWNA
            user32.SetWindowPos(self._hwnd, wintypes.HWND(-1), 0, 0, 0, 0, 0x0001 | 0x0002 | 0x0010)
            self._visible = True

    @staticmethod
    def _label(d, x: int, y: int, text: str, color: tuple[int, int, int], a: float) -> None:
        from PIL import ImageFont

        try:
            font = ImageFont.truetype("segoeui.ttf", 17)
        except OSError:
            font = ImageFont.load_default()
        tw = d.textlength(text, font=font)
        d.rounded_rectangle((x, y, x + tw + 22, y + 32), 16, fill=(*color, int(235 * a)))
        d.text((x + 11, y + 5), text, font=font, fill=(255, 255, 255, int(255 * a)))


def _wrap(text: str, width: int) -> list[str]:
    words, lines, cur = text.split(), [], ""
    for w in words:
        if len(cur) + len(w) + 1 > width and cur:
            lines.append(cur)
            cur = w
        else:
            cur = f"{cur} {w}".strip()
    if cur:
        lines.append(cur)
    return lines


HUD = Hud()
