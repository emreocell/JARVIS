"""macOS desktop shell: the same UI in native Cocoa windows (pywebview →
WKWebView). Differences from Windows:

* the orb pill is a truly transparent, non-activating floating panel
  (WKWebView supports per-pixel transparency, so no corner tricks);
* windows join every Space and stay above full-screen apps when needed;
* a single-instance lock file instead of a named mutex;
* the Dock icon and menu replace the tray.
"""

from __future__ import annotations

import fcntl
import logging
import os
import sys
from typing import Any

from jarvis import paths
from jarvis.desktop.app import (COMMAND_MIN_H, COMMAND_W, OVERLAY_H, OVERLAY_W, Bridge, CoreThread, DesktopShell,
                                _drop_stale_ui_cache, _prefers_light, _ui_url, _wake_running_instance)

log = logging.getLogger(__name__)


def _screen() -> tuple[float, float, float, float]:
    """Main screen's visible frame (x, y from top-left, w, h) in points."""
    try:
        from AppKit import NSScreen

        s = NSScreen.mainScreen()
        full, vis = s.frame(), s.visibleFrame()
        top = full.size.height - (vis.origin.y + vis.size.height)
        return vis.origin.x, top, vis.size.width, vis.size.height
    except Exception:
        return 0, 25, 1440, 875


class MacDesktopShell(DesktopShell):
    def __init__(self, start_hidden: bool = False) -> None:   # noqa: D107 — same windows, Cocoa flavour
        import webview

        self.start_hidden = start_hidden
        self.webview = webview
        self.core_thread = CoreThread(on_exit=self._core_exited)
        self.bridge = Bridge(self)
        self.maximized = False
        self.tray: Any = None
        url = _ui_url()
        self.light = _prefers_light()
        mw, mh, mx, my = self._main_geometry()
        self.main = webview.create_window(
            "Jarvis", url, js_api=self.bridge, width=mw, height=mh, x=mx, y=my, min_size=(420, 520),
            frameless=True, easy_drag=False, background_color="#f5f6fb" if self.light else "#070812",
            text_select=True, hidden=start_hidden)
        ox, oy = self._overlay_position()
        self.overlay = webview.create_window(
            "Jarvis Orb", f"{url}#overlay", js_api=self.bridge, width=OVERLAY_W, height=OVERLAY_H, x=ox, y=oy,
            frameless=True, on_top=True, hidden=True, focus=False, resizable=False, shadow=False, transparent=True)
        cx, cy = self._command_position()
        self.command = webview.create_window(
            "Jarvis Komut", f"{url}#command", js_api=self.bridge, width=COMMAND_W, height=COMMAND_MIN_H, x=cx, y=cy,
            frameless=True, min_size=(COMMAND_W, COMMAND_MIN_H), on_top=True, hidden=True, resizable=False,
            shadow=True, transparent=True)
        self._command_visible = False
        self._command_h = COMMAND_MIN_H
        self.main.events.closing += self._on_closing

    @staticmethod
    def _overlay_position() -> tuple[int, int]:
        x, y, w, h = _screen()
        return int(x + (w - OVERLAY_W) / 2), int(y + h - OVERLAY_H - 40)

    @staticmethod
    def _main_geometry() -> tuple[int, int, int, int]:
        x, y, w, h = _screen()
        mw, mh = int(min(1360, w * 0.9)), int(min(860, h * 0.9))
        return mw, mh, int(x + (w - mw) / 2), int(y + (h - mh) / 2)

    @staticmethod
    def _command_position() -> tuple[int, int]:
        x, y, w, h = _screen()
        return int(x + (w - COMMAND_W) / 2), int(y + h * 0.22)

    # ------------------------------------------------------------ overlay

    def _floating(self, window: Any, activate: bool) -> None:
        """Panel behaviour: above other apps, on every Space, never steals focus."""
        try:
            from AppKit import (NSFloatingWindowLevel, NSWindowCollectionBehaviorCanJoinAllSpaces,
                                NSWindowCollectionBehaviorFullScreenAuxiliary)

            ns = getattr(window, "native", None)
            ns = getattr(ns, "window", None) or ns
            if ns is None:
                return
            ns.setLevel_(NSFloatingWindowLevel)
            ns.setCollectionBehavior_(NSWindowCollectionBehaviorCanJoinAllSpaces |
                                      NSWindowCollectionBehaviorFullScreenAuxiliary)
            ns.setHidesOnDeactivate_(False)
            if not activate:
                ns.setIgnoresMouseEvents_(False)
        except Exception:
            log.debug("floating style failed", exc_info=True)

    def _show_overlay(self) -> None:
        self._set_active(self.overlay, True)
        self.overlay.show()
        self._floating(self.overlay, activate=False)

    def _hide_overlay(self) -> None:
        self.overlay.hide()
        self._set_active(self.overlay, False)

    def _popup_style(self, window: Any, noactivate: bool) -> None:
        self._floating(window, activate=not noactivate)

    @staticmethod
    def _round_native(window: Any) -> None:
        return None   # the page's own rounded, transparent background does it

    def show_command(self) -> None:
        self._command_h = COMMAND_MIN_H
        self._command_visible = True
        self._set_active(self.command, True)
        try:
            self.command.evaluate_js("window.__jarvisCommandShow && window.__jarvisCommandShow()")
        except Exception:
            log.debug("command bar reset failed", exc_info=True)
        self.command.resize(COMMAND_W, COMMAND_MIN_H)
        self.command.show()
        self._floating(self.command, activate=True)

    def _apply_icons(self) -> None:
        return None   # the .app bundle carries the icon

    def _round_main(self) -> None:
        return None

    def _start_tray(self) -> None:
        return None   # Dock icon + menu bar; pystray can't share Cocoa's main thread with pywebview

    def run(self) -> None:
        self.core_thread.start()
        _drop_stale_ui_cache(paths.data_dir() / "webview")
        self.webview.start(self._after_gui_start, gui="cocoa", debug=os.environ.get("JARVIS_DEBUG") == "1",
                           private_mode=False, storage_path=str(paths.data_dir() / "webview"))


_lock_file: Any = None


def _single_instance() -> bool:
    global _lock_file
    _lock_file = open(paths.data_dir() / "jarvis.lock", "w")  # noqa: SIM115 — held for the process lifetime
    try:
        fcntl.flock(_lock_file, fcntl.LOCK_EX | fcntl.LOCK_NB)
        return True
    except OSError:
        return False


def main() -> int:
    from jarvis.app import _setup_logging

    _setup_logging(os.environ.get("JARVIS_LOG", "info"))
    if not _single_instance():
        log.info("Jarvis is already running; bringing it forward")
        if "--tray" not in sys.argv[1:]:
            _wake_running_instance()
        return 0
    MacDesktopShell(start_hidden="--tray" in sys.argv[1:]).run()
    return 0
