"""Give the Start-menu shortcut Jarvis' AppUserModelID, so Windows shows
Jarvis' own name and icon on its notifications (instead of PowerShell's).

Windows only shows toasts for an AUMID that a Start-menu shortcut carries;
the shortcut gets System.AppUserModel.ID through IPropertyStore (comtypes).
"""

from __future__ import annotations

import logging
import os
from pathlib import Path

log = logging.getLogger(__name__)

AUMID = "Jarvis.Assistant"


def start_menu_link() -> Path:
    return Path(os.environ.get("APPDATA", "")) / "Microsoft" / "Windows" / "Start Menu" / "Programs" / "Jarvis.lnk"


def stamp(link: Path | None = None, aumid: str = AUMID) -> bool:
    """Write System.AppUserModel.ID onto the shortcut. True when it carries the id."""
    link = link or start_menu_link()
    if not link.exists():
        return False
    try:
        import comtypes
        import comtypes.client
        from comtypes import GUID, HRESULT, COMMETHOD, IUnknown
        from ctypes import POINTER, Structure, c_ulong, c_ushort, c_void_p, c_wchar_p, byref
        from ctypes.wintypes import DWORD

        class PROPERTYKEY(Structure):
            _fields_ = [("fmtid", GUID), ("pid", DWORD)]

        class PROPVARIANT(Structure):
            _fields_ = [("vt", c_ushort), ("r1", c_ushort), ("r2", c_ushort), ("r3", c_ushort),
                        ("pwszVal", c_wchar_p), ("pad", c_void_p)]

        class IPropertyStore(IUnknown):
            _iid_ = GUID("{886D8EEB-8CF2-4446-8D02-CDBA1DBDCF99}")
            _methods_ = [
                COMMETHOD([], HRESULT, "GetCount", (["out"], POINTER(DWORD), "cProps")),
                COMMETHOD([], HRESULT, "GetAt", (["in"], DWORD, "iProp"), (["out"], POINTER(PROPERTYKEY), "pkey")),
                COMMETHOD([], HRESULT, "GetValue", (["in"], POINTER(PROPERTYKEY), "key"),
                          (["out"], POINTER(PROPVARIANT), "pv")),
                COMMETHOD([], HRESULT, "SetValue", (["in"], POINTER(PROPERTYKEY), "key"),
                          (["in"], POINTER(PROPVARIANT), "propvar")),
                COMMETHOD([], HRESULT, "Commit"),
            ]

        import ctypes

        shell32 = ctypes.windll.shell32
        SHGetPropertyStoreFromParsingName = shell32.SHGetPropertyStoreFromParsingName
        SHGetPropertyStoreFromParsingName.argtypes = [c_wchar_p, c_void_p, c_ulong, POINTER(GUID),
                                                      POINTER(POINTER(IPropertyStore))]
        comtypes.CoInitialize()
        store = POINTER(IPropertyStore)()
        GPS_READWRITE = 2
        hr = SHGetPropertyStoreFromParsingName(str(link), None, GPS_READWRITE, byref(IPropertyStore._iid_),
                                               byref(store))
        if hr != 0:
            return False
        key = PROPERTYKEY(GUID("{9F4C2855-9F79-4B39-A8D0-E1D42DE1D5F3}"), 5)
        value = PROPVARIANT()
        value.vt = 31   # VT_LPWSTR
        value.pwszVal = aumid
        store.SetValue(byref(key), byref(value))
        store.Commit()
        return True
    except Exception:
        log.debug("could not stamp AUMID on the shortcut", exc_info=True)
        return False
