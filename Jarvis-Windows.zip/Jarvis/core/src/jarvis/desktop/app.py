"""Native desktop shell: ``python -m jarvis``.

* The core runs on a background thread with its own asyncio loop.
* The UI is shown in native windows (pywebview → Windows WebView2), not a
  browser: a frameless main window and a pill-shaped, always-on-top orb
  overlay that appears when Jarvis wakes up.
* A tray icon keeps Jarvis reachable when the main window is closed.
"""

from __future__ import annotations

import asyncio
import ctypes
from ctypes import wintypes
import logging
import os
import sys
import threading
import time
from concurrent.futures import Future
from pathlib import Path
from typing import Any

from jarvis import paths
from jarvis.core import Core

from jarvis.fsutil import read_json

log = logging.getLogger(__name__)

REPO_APP = Path(__file__).resolve().parents[4] / "app"
DEV_URL = "http://127.0.0.1:5173"
OVERLAY_W, OVERLAY_H = 400, 76
COMMAND_W, COMMAND_MIN_H, COMMAND_MAX_H = 680, 64, 460


def _ui_url() -> str:
    if os.environ.get("JARVIS_DEV") == "1":
        return DEV_URL
    dist = REPO_APP / "dist" / "index.html"
    if dist.exists():
        return str(dist)
    return DEV_URL  # no build yet: fall back to the dev server


def _drop_stale_ui_cache(storage: Path) -> None:
    """WebView2 keeps an HTTP cache across runs, so after a UI rebuild it can
    serve the old index.html. Clear the page caches whenever dist changed."""
    index = REPO_APP / "dist" / "index.html"
    if not index.exists():
        return
    stamp = storage / ".dist-stamp"
    current = str(index.stat().st_mtime_ns)
    try:
        if stamp.read_text() == current:
            return
    except OSError:
        pass
    import shutil

    for sub in ("Cache", "Code Cache", "GPUCache"):
        shutil.rmtree(storage / "EBWebView" / "Default" / sub, ignore_errors=True)
    storage.mkdir(parents=True, exist_ok=True)
    stamp.write_text(current)
    log.info("UI rebuilt; cleared WebView2 page cache")


class CoreThread:
    """Runs the Core on its own event loop so the GUI can own the main thread."""

    def __init__(self, on_exit: Any = None) -> None:
        self.core = Core()
        self.on_exit = on_exit  # the core stopped by itself (app.shutdown, crash): close the windows too
        self.loop = asyncio.new_event_loop()
        self.ready = threading.Event()
        self.thread = threading.Thread(target=self._run, name="jarvis-core", daemon=True)

    def _run(self) -> None:
        asyncio.set_event_loop(self.loop)

        async def main() -> None:
            await self.core.start()
            self.ready.set()
            await self.core._stop.wait()
            await self.core.stop()

        try:
            self.loop.run_until_complete(main())
        except Exception:
            log.exception("core crashed")
        finally:
            self.ready.set()
            if self.on_exit:
                self.on_exit()

    def start(self) -> None:
        self.thread.start()
        if not self.ready.wait(60) or not self.thread.is_alive():
            raise RuntimeError("core did not start (see core.log)")

    def call(self, coro: Any) -> Future[Any]:
        return asyncio.run_coroutine_threadsafe(coro, self.loop)

    def stop(self) -> None:
        self.loop.call_soon_threadsafe(self.core.request_stop)
        self.thread.join(10)


class Bridge:
    """Exposed to the UI as ``window.pywebview.api``."""

    def __init__(self, shell: DesktopShell) -> None:
        self._shell = shell

    def runtime(self) -> dict[str, Any]:
        return read_json(paths.runtime_path())

    def minimize(self) -> None:
        self._shell.main.minimize()

    def toggle_maximize(self) -> None:
        self._shell.toggle_maximize()

    def close(self) -> None:
        self._shell.main.hide()  # keep running in the tray

    def open_main(self) -> None:
        self._shell.hide_command()
        self._shell.show_main()

    def command_hide(self) -> None:
        self._shell.hide_command()

    def command_resize(self, height: int) -> None:
        self._shell.resize_command(int(height))

    def quit(self) -> None:
        self._shell.quit()


def _prefers_light() -> bool:
    """Resolve the saved ui.theme before the core starts, so native windows
    don't flash the wrong colour while the page loads."""
    theme = "light"
    try:
        theme = (read_json(paths.config_path()).get("ui") or {}).get("theme", "light")
    except Exception:
        pass
    if theme != "system":
        return theme != "dark"
    try:
        import winreg

        with winreg.OpenKey(winreg.HKEY_CURRENT_USER,
                            r"Software\Microsoft\Windows\CurrentVersion\Themes\Personalize") as key:
            return bool(winreg.QueryValueEx(key, "AppsUseLightTheme")[0])
    except OSError:
        return True


class DesktopShell:
    def __init__(self, start_hidden: bool = False) -> None:
        self.start_hidden = start_hidden
        import webview

        self.webview = webview
        self.core_thread = CoreThread(on_exit=self._core_exited)
        self.bridge = Bridge(self)
        self.maximized = False
        self.tray: Any = None
        url = _ui_url()
        self.light = _prefers_light()
        mw, mh, mx, my = self._main_geometry()
        self.main = webview.create_window(
            "Jarvis", url, js_api=self.bridge, width=mw, height=mh, x=mx, y=my, min_size=(420, 520),
            frameless=True, easy_drag=False, background_color="#f5f6fb" if self.light else "#070812",
            text_select=True, hidden=start_hidden,
        )
        ox, oy = self._overlay_position()
        self.overlay = webview.create_window(
            "Jarvis Orb", f"{url}#overlay" if url.startswith("http") else f"file:///{url}#overlay",
            js_api=self.bridge, width=OVERLAY_W, height=OVERLAY_H, x=ox, y=oy, frameless=True,
            on_top=True, hidden=True, focus=False, resizable=False, shadow=False,
            background_color="#eef0fa" if self.light else "#0b0b11",
        )
        cx, cy = self._command_position()
        self.command = webview.create_window(
            "Jarvis Komut", f"{url}#command" if url.startswith("http") else f"file:///{url}#command",
            js_api=self.bridge, width=COMMAND_W, height=COMMAND_MIN_H, x=cx, y=cy, frameless=True,
            min_size=(COMMAND_W, COMMAND_MIN_H),
            on_top=True, hidden=True, resizable=False, shadow=False,
            background_color="#fcfcff" if self.light else "#0c0d18",
        )
        self._command_visible = False
        self._command_h = COMMAND_MIN_H
        self.main.events.closing += self._on_closing

    @staticmethod
    def _overlay_position() -> tuple[int, int]:
        try:
            user32 = ctypes.windll.user32
            sw, sh = user32.GetSystemMetrics(0), user32.GetSystemMetrics(1)
            return (sw - OVERLAY_W) // 2, sh - OVERLAY_H - 72
        except Exception:
            return 400, 700

    @staticmethod
    def _main_geometry() -> tuple[int, int, int, int]:
        """1360x860 (or smaller on small screens), centred in the work area
        (never under the taskbar). Logical pixels."""
        try:
            rect = wintypes.RECT()
            ctypes.windll.user32.SystemParametersInfoW(0x0030, 0, ctypes.byref(rect), 0)  # SPI_GETWORKAREA
            scale = ctypes.windll.user32.GetDpiForSystem() / 96
            left, top = rect.left / scale, rect.top / scale
            aw, ah = (rect.right - rect.left) / scale, (rect.bottom - rect.top) / scale
            w, h = int(min(1360, aw * 0.9)), int(min(860, ah * 0.9))
            return w, h, int(left + (aw - w) / 2), int(top + (ah - h) / 2)
        except Exception:
            return 1360, 860, None, None  # type: ignore[return-value]

    @staticmethod
    def _command_position() -> tuple[int, int]:
        try:
            user32 = ctypes.windll.user32
            sw, sh = user32.GetSystemMetrics(0), user32.GetSystemMetrics(1)
            return (sw - COMMAND_W) // 2, int(sh * 0.24)
        except Exception:
            return 400, 200

    def _on_closing(self) -> bool:
        # the title-bar X hides to tray; real quit goes through quit()
        if getattr(self, "_quitting", False):
            return True
        self.main.hide()
        self._in_thread(lambda: self._set_active(self.main, False))
        return False

    def toggle_maximize(self) -> None:
        if self.maximized:
            self.main.restore()
        else:
            self.main.maximize()
        self.maximized = not self.maximized

    def show_main(self) -> None:
        self.main.show()
        self.main.restore()
        self._set_active(self.main, True)

    # ----------------------------------------------------------- overlay

    def _on_voice_state(self, event: Any) -> None:
        state = event.data.get("state")
        if state in ("armed", "listening", "thinking", "speaking"):
            self._cancel_hide()
            self._in_thread(self._show_overlay)
        elif state in ("idle", "muted", "error"):
            self._schedule_hide(1.2 if state == "idle" else 3.0)

    _hide_timer: threading.Timer | None = None

    def _schedule_hide(self, delay: float) -> None:
        self._cancel_hide()
        self._hide_timer = threading.Timer(delay, self._hide_overlay)
        self._hide_timer.daemon = True
        self._hide_timer.start()

    def _show_overlay(self) -> None:
        """Show the orb pill like a HUD, not a window: no taskbar entry, no open
        animation, never steals focus from the app the user is in."""
        self._set_active(self.overlay, True)
        form = getattr(self.overlay, "native", None)
        if form is None:
            self.overlay.show()
            return
        self._popup_style(self.overlay, noactivate=True)
        self._round_native(self.overlay)
        from System import Action  # type: ignore[import-not-found]

        def show() -> None:  # on the form's UI thread
            user32 = ctypes.windll.user32
            user32.SetWindowPos.argtypes = [wintypes.HWND, wintypes.HWND, ctypes.c_int, ctypes.c_int,
                                            ctypes.c_int, ctypes.c_int, wintypes.UINT]
            hwnd = wintypes.HWND(int(form.Handle.ToInt64()))
            user32.ShowWindow(hwnd, 4)  # SW_SHOWNOACTIVATE
            # HWND_TOPMOST; SWP_NOMOVE|SWP_NOSIZE|SWP_NOACTIVATE
            user32.SetWindowPos(hwnd, wintypes.HWND(-1), 0, 0, 0, 0, 0x0001 | 0x0002 | 0x0010)

        form.Invoke(Action(show))
        log.debug("overlay shown: %s", bool(ctypes.windll.user32.IsWindowVisible(int(form.Handle.ToInt64()))))

    def _hide_overlay(self) -> None:
        form = getattr(self.overlay, "native", None)
        if form is not None:
            from System import Action  # type: ignore[import-not-found]

            form.Invoke(Action(lambda: ctypes.windll.user32.ShowWindow(wintypes.HWND(int(form.Handle.ToInt64())), 0)))
        else:
            self.overlay.hide()
        self._set_active(self.overlay, False)

    _styled: set[str] = set()

    def _popup_style(self, window: Any, noactivate: bool) -> None:
        """Tool-window style (no taskbar / Alt+Tab), no DWM open/close animation."""
        if window.title in self._styled:
            return
        form = getattr(window, "native", None)
        if form is None:
            return
        try:
            user32 = ctypes.windll.user32
            hwnd = int(form.Handle.ToInt64())
            ex = user32.GetWindowLongW(hwnd, -20)
            ex = (ex | 0x80) & ~0x40000  # +WS_EX_TOOLWINDOW, -WS_EX_APPWINDOW
            if noactivate:
                ex |= 0x08000000  # WS_EX_NOACTIVATE
            user32.SetWindowLongW(hwnd, -20, ex)
            off = ctypes.c_int(1)
            ctypes.windll.dwmapi.DwmSetWindowAttribute(wintypes.HWND(hwnd), 3, ctypes.byref(off), ctypes.sizeof(off))
            self._styled.add(window.title)
        except Exception:
            log.debug("popup style failed for %s", window.title, exc_info=True)

    def _cancel_hide(self) -> None:
        if self._hide_timer:
            self._hide_timer.cancel()
            self._hide_timer = None

    # --------------------------------------------------------------- tray

    def _start_tray(self) -> None:
        try:
            import pystray
        except ImportError:
            return
        from jarvis.desktop.icon import make_icon

        core = self.core_thread.core

        def toggle_voice(icon: Any, item: Any) -> None:
            enabled = not core.config.voice.enabled
            self.core_thread.call(core.config_store.patch({"voice": {"enabled": enabled}}))

        menu = pystray.Menu(
            pystray.MenuItem("Jarvis'i aç", lambda i, it: self.show_main(), default=True),
            pystray.MenuItem("Sesli asistan", toggle_voice, checked=lambda it: core.config.voice.enabled),
            pystray.MenuItem("Uyandır", lambda i, it: self.core_thread.call(self._wake())),
            pystray.MenuItem(lambda it: f"Komut çubuğu ({core.config.ui.command_bar_hotkey})",
                             lambda i, it: threading.Thread(target=self.show_command, daemon=True).start()),
            pystray.Menu.SEPARATOR,
            pystray.MenuItem("Çıkış", lambda i, it: self.quit()),
        )
        self.tray = pystray.Icon("jarvis", make_icon(64), "Jarvis", menu)
        self.tray.run_detached()

    async def _wake(self) -> None:
        voice = self.core_thread.core.voice
        if voice:
            await voice.wake()

    # ---------------------------------------------------------- lifecycle

    def _prepare_overlay(self) -> None:
        """Round the orb window natively and make sure it starts hidden.

        WebView2 in a WinForms host can't be per-pixel transparent and window
        regions don't clip its DirectComposition output (black corners), so the
        compositor's own rounded corners are used instead."""
        self._shape_overlay()
        self.overlay.hide()

    def _shape_overlay(self) -> None:
        self._round_native(self.overlay)

    @staticmethod
    def _round_native(window: Any) -> None:
        """Windows 11 rounds the window in the compositor (anti-aliased, clips
        WebView2's DirectComposition content — which window regions don't),
        with no border line."""
        form = getattr(window, "native", None)
        if form is None:
            return
        try:
            hwnd = wintypes.HWND(int(form.Handle.ToInt64()))
            pref = ctypes.c_int(2)  # DWMWCP_ROUND
            ctypes.windll.dwmapi.DwmSetWindowAttribute(hwnd, 33, ctypes.byref(pref), 4)
            none = ctypes.c_uint(0xFFFFFFFE)  # DWMWA_COLOR_NONE
            ctypes.windll.dwmapi.DwmSetWindowAttribute(hwnd, 34, ctypes.byref(none), 4)
        except Exception:
            log.debug("native rounding failed", exc_info=True)

    def show_command(self) -> None:
        self._command_h = COMMAND_MIN_H
        self._command_visible = True
        self._set_active(self.command, True)
        try:  # reset the page first so it starts its focus grace period before it becomes visible
            self.command.evaluate_js("window.__jarvisCommandShow && window.__jarvisCommandShow()")
        except Exception:
            log.debug("command bar reset failed", exc_info=True)
        self._popup_style(self.command, noactivate=False)
        self.command.resize(COMMAND_W, COMMAND_MIN_H)  # (SetWindowPos also shows it)
        self.command.show()
        self._round_native(self.command)
        form = getattr(self.command, "native", None)
        try:
            from System import Action  # type: ignore[import-not-found]

            if form is not None and getattr(form, "browser", None) is not None:
                form.Invoke(Action(lambda: form.browser.webview.Focus()))
        except Exception:
            log.debug("command bar webview focus failed", exc_info=True)

    def hide_command(self) -> None:
        log.debug("command bar hide requested")
        if self._command_visible:
            self._command_visible = False
            self.command.hide()
            self._set_active(self.command, False)

    def resize_command(self, height: int) -> None:
        height = max(COMMAND_MIN_H, min(COMMAND_MAX_H, height))
        if not self._command_visible or abs(height - self._command_h) < 2:
            return  # resizing a hidden window would show it
        self._command_h = height
        self.command.resize(COMMAND_W, height)

    def _apply_icons(self) -> None:
        """Jarvis icon on every window (the process is pythonw.exe, whose Python
        icon Windows would otherwise show in the taskbar)."""
        try:
            from System import Action  # type: ignore[import-not-found]
            from System.Drawing import Icon  # type: ignore[import-not-found]

            from jarvis.shortcuts import icon_path

            path = str(paths.data_dir() / "jarvis.ico")
            if not os.path.exists(path):
                path = str(icon_path())
            for window in (self.main, self.overlay, self.command):
                form = getattr(window, "native", None)
                if form is not None:
                    form.Invoke(Action(lambda f=form: setattr(f, "Icon", Icon(path))))
        except Exception:
            log.debug("could not set window icons", exc_info=True)

    def _round_main(self) -> None:
        """Windows 11 draws rounded corners (and the system border/shadow) for
        frameless windows only when asked to."""
        form = getattr(self.main, "native", None)
        if form is None or sys.platform != "win32":
            return
        try:
            from System import Action  # type: ignore[import-not-found]

            from jarvis.desktop import dwm

            def apply() -> None:
                hr = dwm._set(int(form.Handle.ToInt64()), dwm.DWMWA_WINDOW_CORNER_PREFERENCE, dwm.DWMWCP_ROUND)
                log.info("main window corner preference -> %s", "ok" if hr == 0 else f"hr={hr & 0xFFFFFFFF:#x}")

            if form.InvokeRequired:
                form.Invoke(Action(apply))
            else:
                apply()
        except Exception:
            log.warning("could not round main window", exc_info=True)

    def _after_gui_start(self) -> None:
        # Subscriptions first: window preparation below waits on pywebview
        # events and must never be able to keep hotkeys/overlay from working.
        bus = self.core_thread.core.bus
        bus.subscribe("voice.state", self._on_voice_state)
        bus.subscribe("app.show", lambda e: self._in_thread(self.show_main))
        bus.subscribe("hotkey.command_bar", lambda e: self._in_thread(self.show_command))
        bus.subscribe("ui.navigate", lambda e: self._in_thread(self._navigate))
        for step in (self._start_tray, self._round_main, self._apply_icons):
            try:
                step()
            except Exception:
                log.exception("desktop startup step %s failed", step.__name__)
        self.main.events.shown += self._round_main
        self.main.events.shown += lambda: self._in_thread(self._apply_icons)
        self.overlay.events.shown += self._shape_overlay
        # hidden-at-start windows must not render; main follows minimise/restore
        self.command.events.loaded += lambda: self._in_thread(lambda: self._set_active(self.command, self._command_visible))
        self.overlay.events.loaded += lambda: self._in_thread(lambda: self._set_active(self.overlay, False))
        self.main.events.loaded += lambda: self._in_thread(lambda: self._set_active(self.main, not self.start_hidden))
        self.main.events.minimized += lambda: self._in_thread(lambda: self._set_active(self.main, False))
        self.main.events.restored += lambda: self._in_thread(lambda: self._set_active(self.main, True))
        self.main.events.maximized += lambda: self._in_thread(lambda: self._set_active(self.main, True))
        self._in_thread(self._prepare_overlay)

    @staticmethod
    def _set_active(window: Any, active: bool) -> None:
        """Tell a page whether its window is on screen (WebView2 in WinForms keeps
        reporting 'visible' for hidden windows) so render loops can stop."""
        try:
            window.evaluate_js(f"window.__jarvisSetActive && window.__jarvisSetActive({'true' if active else 'false'})")
        except Exception:
            log.debug("could not set surface state for %s", getattr(window, "title", window), exc_info=True)

    def _navigate(self) -> None:
        self.hide_command()
        self.show_main()

    @staticmethod
    def _in_thread(fn: Any) -> None:
        """pywebview window calls block until the window is ready — never run
        them on the core's event loop."""
        def run() -> None:
            try:
                fn()
            except Exception:
                log.exception("desktop action %s failed", getattr(fn, "__name__", fn))
        threading.Thread(target=run, daemon=True).start()

    def _core_exited(self) -> None:
        if getattr(self, "_quitting", False):
            return
        log.info("core stopped; closing the desktop shell")
        self._quitting = True
        if self.tray:
            self.tray.stop()
        for w in list(self.webview.windows):
            try:
                w.destroy()
            except Exception:
                pass

    def quit(self) -> None:
        self._quitting = True
        if self.tray:
            self.tray.stop()
        self.core_thread.stop()
        for w in list(self.webview.windows):
            w.destroy()

    def run(self) -> None:
        self.core_thread.start()
        _drop_stale_ui_cache(paths.data_dir() / "webview")
        self.webview.start(self._after_gui_start, gui="edgechromium", debug=os.environ.get("JARVIS_DEBUG") == "1",
                           private_mode=False, storage_path=str(paths.data_dir() / "webview"))


MUTEX_NAME = r"Local\JarvisDesktopSingleton"


def _acquire_single_instance() -> Any:
    """Named mutex; returns a handle, or None when Jarvis already runs."""
    kernel32 = ctypes.windll.kernel32
    kernel32.CreateMutexW.restype = ctypes.c_void_p
    handle = kernel32.CreateMutexW(None, False, MUTEX_NAME)
    if kernel32.GetLastError() == 183:  # ERROR_ALREADY_EXISTS
        kernel32.CloseHandle(ctypes.c_void_p(handle))
        return None
    return handle


def _wake_running_instance() -> bool:
    import json

    from websockets.sync.client import connect

    try:
        rt = read_json(paths.runtime_path())
        with connect(f"ws://127.0.0.1:{rt['port']}", open_timeout=3) as ws:
            ws.send(json.dumps({"type": "auth", "token": rt["token"]}))
            ws.send(json.dumps({"id": 1, "method": "app.show", "params": {}}))
            deadline = time.monotonic() + 3
            while time.monotonic() < deadline:
                msg = json.loads(ws.recv(timeout=3))
                if msg.get("id") == 1:
                    return "result" in msg
    except Exception:
        log.warning("could not reach the running Jarvis", exc_info=True)
    return False


def main() -> int:
    from jarvis.app import _setup_logging

    _setup_logging(os.environ.get("JARVIS_LOG", "info"))
    if sys.platform == "win32":
        try:  # crisp rendering on high-DPI displays
            ctypes.windll.shcore.SetProcessDpiAwareness(2)
        except Exception:
            pass
    if sys.platform == "win32":
        try:  # own taskbar identity + icon instead of python's
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("Jarvis.Assistant")
        except Exception:
            pass
        mutex = _acquire_single_instance()
        if mutex is None:
            log.info("Jarvis is already running; bringing it forward")
            if "--tray" not in sys.argv[1:]:
                _wake_running_instance()
            return 0
    # --tray: started with Windows — stay in the tray until called
    DesktopShell(start_hidden="--tray" in sys.argv[1:]).run()
    return 0
