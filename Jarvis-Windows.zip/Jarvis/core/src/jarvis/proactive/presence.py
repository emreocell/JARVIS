"""Is the user at the computer? Cheap presence tracking for proactive features.

Polls GetLastInputInfo every few seconds (one syscall) and publishes
``user.away`` / ``user.returned`` on the bus. Also answers "is this a good
moment to talk?" (no fullscreen game/video, no call app in front).
"""

from __future__ import annotations

import asyncio
import ctypes
import logging
import sys
import time
from ctypes import wintypes
from typing import Any

log = logging.getLogger(__name__)

AWAY_AFTER = 10 * 60          # seconds without input = away
POLL = 15.0
CALL_APPS = ("zoom", "teams", "discord", "skype", "whatsapp call", "google meet", "meet.google", "webex")


class LASTINPUTINFO(ctypes.Structure):
    _fields_ = [("cbSize", wintypes.UINT), ("dwTime", wintypes.DWORD)]


def idle_seconds() -> float:
    if sys.platform == "darwin":
        try:
            from jarvis.platform.mac import idle_seconds as mac_idle

            return mac_idle()
        except Exception:
            return 0.0
    if sys.platform != "win32":
        return 0.0
    info = LASTINPUTINFO(ctypes.sizeof(LASTINPUTINFO), 0)
    if not ctypes.windll.user32.GetLastInputInfo(ctypes.byref(info)):
        return 0.0
    return max(0.0, (ctypes.windll.kernel32.GetTickCount() - info.dwTime) / 1000.0)


def fullscreen_foreground() -> bool:
    """A game or video covers the whole monitor (the desktop/shell doesn't count)."""
    if sys.platform != "win32":
        return False
    user32 = ctypes.windll.user32
    hwnd = user32.GetForegroundWindow()
    if not hwnd or hwnd in (user32.GetDesktopWindow(), user32.GetShellWindow()):
        return False
    buf = ctypes.create_unicode_buffer(64)
    user32.GetClassNameW(hwnd, buf, 64)
    if buf.value in ("Progman", "WorkerW", "Shell_TrayWnd"):
        return False
    rect = wintypes.RECT()
    user32.GetWindowRect(hwnd, ctypes.byref(rect))

    class MONITORINFO(ctypes.Structure):
        _fields_ = [("cbSize", wintypes.DWORD), ("rcMonitor", wintypes.RECT), ("rcWork", wintypes.RECT),
                    ("dwFlags", wintypes.DWORD)]

    user32.MonitorFromWindow.restype = wintypes.HMONITOR
    mon = user32.MonitorFromWindow(hwnd, 2)
    mi = MONITORINFO(ctypes.sizeof(MONITORINFO))
    if not user32.GetMonitorInfoW(mon, ctypes.byref(mi)):
        return False
    m = mi.rcMonitor
    return rect.left <= m.left and rect.top <= m.top and rect.right >= m.right and rect.bottom >= m.bottom


def busy_reason(context: Any = None) -> str | None:
    """Why now is a bad moment to start talking, or None."""
    if fullscreen_foreground():
        return "tam ekran uygulama"
    focus = context.current() if context is not None else None
    if focus is not None:
        name = f"{focus.app} {focus.title}".lower()
        if any(app in name for app in CALL_APPS) and any(w in name for w in ("call", "arama", "meeting", "toplantı")):
            return "görüşme"
    return None


class Presence:
    def __init__(self, bus: Any) -> None:
        self.bus = bus
        self.away = False
        self.away_since = 0.0
        self.last_away_start = 0.0      # start of the most recent away period ("ben yokken")
        self.returned_at = time.time()  # start of the current stretch at the computer
        self._task: asyncio.Task[None] | None = None

    def start(self) -> None:
        if self._task is None and sys.platform in ("win32", "darwin"):
            self._task = asyncio.create_task(self._run(), name="presence")

    def stop(self) -> None:
        if self._task:
            self._task.cancel()
            self._task = None

    async def _run(self) -> None:
        while True:
            try:
                idle = idle_seconds()
                now = time.time()
                if not self.away and idle >= AWAY_AFTER:
                    self.away, self.away_since = True, now - idle
                    await self.bus.publish("user.away", since=self.away_since)
                elif self.away and idle < POLL * 2:
                    self.away = False
                    self.last_away_start = self.away_since
                    self.returned_at = now - idle
                    away_for = now - idle - self.away_since
                    log.info("user returned after %.0f min", away_for / 60)
                    await self.bus.publish("user.returned", away_s=round(away_for))
            except Exception:
                log.debug("presence poll failed", exc_info=True)
            await asyncio.sleep(POLL)
