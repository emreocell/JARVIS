"""Call awareness: is the user on a call (Zoom, Teams, Discord, WhatsApp,
the browser…) or is the phone ringing through Phone Link?

Windows records which apps are using the microphone right now
(CapabilityAccessManager: LastUsedTimeStop == 0 means "in use"). Another
app holding the microphone means a call; Jarvis then stops talking, ignores
the wake word (push-to-talk still works) and keeps proactive messages for
later. An incoming-call notification from Phone Link counts too.
"""

from __future__ import annotations

import asyncio
import logging
import os
import sys
import time
from typing import Any

log = logging.getLogger(__name__)

BASE = r"Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\microphone"
POLL = 3.0
OWN = ("python.exe", "pythonw.exe")
RING_SECONDS = 45.0


def mic_users() -> list[str]:
    """Apps (other than Jarvis) that are using the microphone right now."""
    if sys.platform != "win32":
        return []
    import winreg

    users: list[str] = []

    def scan(path: str, packaged: bool) -> None:
        try:
            key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, path)
        except OSError:
            return
        i = 0
        while True:
            try:
                sub = winreg.EnumKey(key, i)
            except OSError:
                break
            i += 1
            if sub == "NonPackaged":
                scan(path + "\\" + sub, False)
                continue
            try:
                with winreg.OpenKey(key, sub) as sk:
                    stop = winreg.QueryValueEx(sk, "LastUsedTimeStop")[0]
            except OSError:
                continue
            if stop == 0:
                name = sub.replace("#", "\\").rsplit("\\", 1)[-1] if not packaged else sub.split("_")[0]
                if name.lower() not in OWN:
                    users.append(name)

    scan(BASE, True)
    return users


class CallWatcher:
    def __init__(self, core: Any) -> None:
        self.core = core
        self.in_call = False
        self.apps: list[str] = []
        self._ringing_until = 0.0
        self._task: asyncio.Task[None] | None = None
        core.bus.subscribe("notification.new", self._on_notification)

    def start(self) -> None:
        if self._task is None and sys.platform == "win32":
            self._task = asyncio.create_task(self._run(), name="calls")

    def stop(self) -> None:
        if self._task:
            self._task.cancel()
            self._task = None

    def _on_notification(self, event: Any) -> None:
        d = event.data
        text = f"{d.get('app', '')} {d.get('title', '')} {d.get('body', '')}".lower()
        if ("telefon" in text or "phone" in text) and any(w in text for w in ("gelen arama", "incoming call", "arıyor",
                                                                              "is calling")):
            self._ringing_until = time.time() + RING_SECONDS

    async def _run(self) -> None:
        while True:
            try:
                apps = await asyncio.to_thread(mic_users)
                calling = bool(apps) or time.time() < self._ringing_until
                if calling != self.in_call:
                    self.in_call, self.apps = calling, apps
                    await self._changed(calling)
            except Exception:
                log.debug("call watch failed", exc_info=True)
            await asyncio.sleep(POLL)

    async def _changed(self, calling: bool) -> None:
        voice = getattr(self.core, "voice", None)
        if voice is not None:
            voice.call_mode = calling
            if calling and str(getattr(voice.state, "value", "")) == "speaking":
                try:
                    voice._barge_in()   # stop talking over the call
                except Exception:
                    pass
        log.info("call %s (%s)", "started" if calling else "ended", ", ".join(self.apps) or "phone")
        await self.core.bus.publish("call.state", active=calling, apps=self.apps)
