"""Fast commands: simple typed commands that run without any LLM call.

"spotify'ı aç", "sesi 30 yap", "sonraki şarkı", "saat kaç",
"10 dakika sonra çayı hatırlat" … are matched with strict patterns and sent
straight to the tool runtime (same risk/approval gates as the LLM path).
Anything that doesn't match *exactly* falls through to the text agent — the
fast path must never guess.
"""

from __future__ import annotations

import asyncio
import re
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from typing import Any

_UPPER = str.maketrans({"İ": "i", "I": "ı"})
_FOLD = str.maketrans("ışçğöüâîû", "iscgouaiu")


def fold(text: str) -> str:
    """Lowercase, drop Turkish diacritics, turn punctuation (except ' % : .)
    into spaces — *without changing length*, so match spans index the
    original text."""
    t = text.translate(_UPPER).lower().translate(_FOLD)
    t = "".join(c if c.isalnum() or c in " '%:." else " " for c in t)
    return t if len(t) == len(text) else ""


@dataclass(slots=True)
class FastCommand:
    tool: str
    args: dict[str, Any] = field(default_factory=dict)
    # app-name spellings to try (first confident one wins); args[app_arg] is set from it
    app_names: list[str] = field(default_factory=list)
    app_arg: str = "name"
    format: Callable[[dict[str, Any]], str] | None = None


def _time_reply(r: dict[str, Any]) -> str:
    return f"Saat {r.get('time', '?')}."


def _date_reply(r: dict[str, Any]) -> str:
    return f"Bugün {r.get('date', '?')}, {r.get('weekday', '')}.".replace(", .", ".")


def _weather_reply(tomorrow: bool) -> Callable[[dict[str, Any]], str]:
    def fmt(r: dict[str, Any]) -> str:
        if tomorrow and len(r.get("days", [])) > 1:
            d = r["days"][1]
            rain = f", yağış ihtimali %{d['rain_chance']}" if (d.get("rain_chance") or 0) >= 30 else ""
            return f"Yarın {r['place']}: {d['summary']}, {d['min']}°–{d['max']}°{rain}."
        return str(r.get("output", ""))
    return fmt


_S = r"\s+"
_APP_VERBS = r"(?:ac|baslat|calistir)"
_NOT_APPS = {"sesi", "ses", "muzigi", "muzik", "sarkiyi", "sarki", "ekrani", "isiklari", "bilgisayari",
             "bunu", "onu", "sunu", "sonraki", "onceki", "siradaki", "biraz", "hepsini", "pencereyi"}


def match(text: str) -> FastCommand | None:
    t = fold(text.strip())
    if not t or len(t) > 80:
        return None
    t = re.sub(r"\s+$", "", t)

    # ---- volume
    if m := re.fullmatch(rf"(?:sesi|ses){_S}(?:seviyesini{_S})?(?:%|yuzde{_S}?)?(\d{{1,3}})(?:{_S}(?:yap|ayarla|olsun))?", t):
        return FastCommand("set_volume", {"level": min(100, int(m[1]))})
    if re.fullmatch(rf"sesi(?:{_S}biraz)?{_S}(?:yukselt|artir|ac)", t):
        return FastCommand("set_volume", {"change": 10, "mute": False})
    if re.fullmatch(rf"sesi(?:{_S}biraz)?{_S}(?:kis|azalt|dusur)", t):
        return FastCommand("set_volume", {"change": -10})
    if re.fullmatch(rf"sessize{_S}al|sesi{_S}(?:kapat|sustur)", t):
        return FastCommand("set_volume", {"mute": True})

    # ---- media
    if re.fullmatch(rf"(?:sonraki|siradaki)(?:{_S}(?:sarki|parca))?(?:{_S}(?:ac|gec))?|(?:sarkiyi|parcayi){_S}(?:gec|atla)", t):
        return FastCommand("media_control", {"action": "next"})
    if re.fullmatch(rf"onceki(?:{_S}(?:sarki|parca))?(?:{_S}ac)?", t):
        return FastCommand("media_control", {"action": "previous"})
    if re.fullmatch(rf"(?:muzigi|sarkiyi|videoyu){_S}(?:durdur|duraklat)|muzik{_S}dursun", t):
        return FastCommand("media_control", {"action": "pause"})
    if re.fullmatch(rf"(?:muzigi|sarkiyi|videoyu){_S}(?:devam{_S}ettir|surdur|baslat)|muzige{_S}devam(?:{_S}et)?", t):
        return FastCommand("media_control", {"action": "play"})

    # ---- time / date
    if re.fullmatch(r"saat\s+kac\s*\??", t):
        return FastCommand("current_time", format=_time_reply)
    if re.fullmatch(r"(?:bugun\s+)?(?:gunlerden\s+ne|hangi\s+gun(?:deyiz)?|tarih\s+ne|bugunun\s+tarihi(?:\s+ne)?)\s*\??", t):
        return FastCommand("current_time", format=_date_reply)

    # ---- weather / money / brief
    if re.fullmatch(r"(?:bugun\s+|yarin\s+)?hava(?:\s+durumu)?(?:\s+nasil(?:\s+olacak)?)?\s*\??", t):
        return FastCommand("get_weather", {"days": 2}, format=_weather_reply(tomorrow="yarin" in t))
    if m := re.fullmatch(r"(\d+(?:[.,]\d+)?\s+)?(dolar|euro|avro|sterlin|pound)(?:\s+kuru)?(?:\s+(?:kac(?:\s+(?:tl|lira))?|ne\s+kadar))?\s*\??", t):
        code = {"dolar": "USD", "euro": "EUR", "avro": "EUR", "sterlin": "GBP", "pound": "GBP"}[m[2]]
        amount = float((m[1] or "1").strip().replace(",", "."))
        return FastCommand("get_exchange_rate", {"amount": amount, "from_currency": code, "to_currency": "TRY"})
    if re.fullmatch(r"(?:gunun\s+ozeti|gunu\s+ozetle|bugun\s+neler\s+var)\s*\??", t):
        return FastCommand("daily_brief")

    # ---- notes: "not al: …", "şunu not et: …", "… diye not al", "notlarımı oku"
    if m := re.match(r"(?:(?:sunu\s+)?not\s+(?:al|et|dus)\s*[:,-]?|not\s*:)\s*(.+)$", t):
        body = text.strip()[m.start(1):].strip()
        if body and len(body) >= 2:
            return FastCommand("take_note", {"text": body})
    if m := re.fullmatch(r"(.+?)\s+diye\s+not\s+(?:al|et|dus)", t):
        return FastCommand("take_note", {"text": text.strip()[m.start(1):m.end(1)].strip()})
    if re.fullmatch(r"(?:notlarimi|notlari)\s*(?:oku|goster|listele|soyle)?|notlarim(?:\s+neler)?\s*\??", t):
        return FastCommand("list_notes")

    # ---- focus: "odak modu", "odak modunu başlat", "50 dakika odaklanmam lazım"
    if m := re.fullmatch(r"(?:(\d{1,3})\s*(?:dakika|dk)(?:lik)?\s+)?(?:odak\s+modu(?:nu)?|odaklan(?:mam\s+lazim|alim)?)(?:\s+(?:baslat|ac|kur))?", t):
        return FastCommand("focus_mode", {"minutes": int(m[1]) if m[1] else 25})

    # ---- screen
    if re.fullmatch(rf"(?:ekrani|bilgisayari){_S}kilitle", t):
        return FastCommand("lock_screen")

    # ---- reminders: "10 dakika sonra çayı hatırlat"
    if m := re.fullmatch(rf"(\d{{1,4}}){_S}?(dakika|dk|saat|sa){_S}sonra{_S}(.+?){_S}(?:bana{_S})?hatirlat(?:{_S}bana)?", t):
        minutes = int(m[1]) * (60 if m[2] in ("saat", "sa") else 1)
        what = text.strip()[m.start(3):m.end(3)].strip()
        if 0 < minutes <= 7 * 24 * 60 and what:
            return FastCommand("set_reminder", {"text": what, "in_minutes": minutes})
    # timers: "5 dakika zamanlayıcı kur", "çay için 7 dakika", "30 saniyelik sayaç"
    if m := re.fullmatch(rf"(?:(.{{1,30}}?){_S}icin{_S})?(\d{{1,3}}){_S}?(saniye|sn|dakika|dk|saat)(?:'?l[iı]k|lik)?(?:{_S}(?:zamanlay[iı]c[iı]|sayac|geri{_S}sayim))?(?:{_S}(?:kur|baslat|ayarla))?", t):
        n, unit = int(m[2]), m[3]
        secs = n * (1 if unit in ("saniye", "sn") else 3600 if unit == "saat" else 60)
        label = text.strip()[m.start(1):m.end(1)].strip() if m[1] else "Zamanlayıcı"
        explicit = m[1] or re.search(r"zamanlay|sayac|geri\s+sayim|kur|baslat|ayarla", t)
        if explicit and 0 < secs <= 24 * 3600:
            return FastCommand("set_timer", {"minutes": secs // 60, "seconds": secs % 60, "label": label.capitalize()})
    # alarms: "7'de alarm kur", "saat 7.30'a alarm"
    if m := re.fullmatch(rf"(?:saat{_S})?(\d{{1,2}})(?:[:.](\d{{2}}))?(?:'?(?:de|da|te|ta|e|a|ye|ya))?{_S}alarm(?:{_S}kur)?", t):
        h, mi = int(m[1]), int(m[2] or 0)
        if h < 24 and mi < 60:
            return FastCommand("set_alarm", {"at": f"{h:02d}:{mi:02d}"})

    # ---- windows: "vs code'u sola al", "bu pencereyi tam ekran yap", "A ile B'yi yan yana koy"
    if re.fullmatch(r"masaustunu\s+goster|tum\s+pencereleri\s+kucult", t):
        return FastCommand("show_desktop")
    if re.fullmatch(r"(?:bu\s+pencerenin\s+|pencerenin\s+)ekran\s+goruntusu(?:nu)?\s+al", t):
        return FastCommand("take_screenshot", {"target": "window"})
    if m := re.fullmatch(r"(bu\s+penceredeki|penceredeki|ekrandaki)\s+(?:yaziyi|yazilari|metni|metinleri)\s+(kopyala|oku|getir)", t):
        return FastCommand("read_screen_text", {"target": "screen" if m[1] == "ekrandaki" else "window",
                                                "to_clipboard": m[2] == "kopyala"})
    if re.fullmatch(r"ekran\s+goruntusu\s+al|ss\s+al", t):
        return FastCommand("take_screenshot", {"target": "screen"})
    if m := re.fullmatch(r"(.{2,30}?)'?(?:y?[iıuü]|n[iıuü])?\s+ile\s+(.{2,30}?)'?(?:y?[iıuü]|n[iıuü])?\s+yan\s+yana\s+(?:koy|diz|getir|al|ac)", t):
        a = _app_words(text, m, 1)
        b = _app_words(text, m, 2)
        if a and b:
            return FastCommand("side_by_side", {"left_app": a, "right_app": b})
    positions = [(r"sol(?:\s+(?:yariya|tarafa))?|sola", "left"), (r"sag(?:\s+(?:yariya|tarafa))?|saga", "right"),
                 (r"yukari|ust\s+yariya", "top"), (r"asagi|alt\s+yariya", "bottom"), (r"ortaya", "center")]
    for pat, pos in positions:
        if m := re.fullmatch(rf"(.{{2,30}}?)\s+(?:{pat})\s+(?:al|tasi|yasla|koy|getir|cek)", t):
            return _window_cmd(text, m, pos)
    if m := re.fullmatch(r"(.{2,30}?)\s+(?:tam\s+ekran\s+yap|buyut|ekrani\s+kaplasin)", t):
        return _window_cmd(text, m, "full")
    if m := re.fullmatch(r"(.{2,30}?)\s+(?:simge\s+durumuna\s+)?kucult", t):
        return _window_cmd(text, m, "minimize")

    # ---- apps: "spotify'ı aç", "hesap makinesini aç", "discord kapat"
    if "'" in t and re.search(r"'(?:d|t)[ae]\b|'n?[iı]n\b", t):
        return None  # "youtube'da lofi aç", "spotify'ın sesini…" need understanding
    if m := re.fullmatch(rf"(.{{2,40}}?){_S}({_APP_VERBS}|kapat)", t):
        words = re.sub(r"'\w*", "", m[1]).split()
        if not words or len(words) > 3 or words[0] in _NOT_APPS:
            return None
        orig = re.sub(r"['’]\w*", "", text.strip()[m.start(1):m.end(1)]).strip()
        # accusative without apostrophe: "hesap makinesini" -> "hesap makinesi", "spotifyı" -> "spotify"
        names = _name_candidates(orig, len(words) > 1)
        tool = "close_app" if m[2] == "kapat" else "open_app"
        return FastCommand(tool, {}, app_names=names)
    return None


class FastPath:
    def __init__(self, execute: Callable[..., Awaitable[dict[str, Any]]],
                 confident_app: Callable[[str], bool]) -> None:
        self.execute = execute
        self.confident_app = confident_app

    async def try_run(self, text: str) -> dict[str, Any] | None:
        """Run ``text`` as a fast command; ``None`` means "not a fast command"."""
        cmd = match(text)
        if cmd is None:
            return None
        if cmd.app_names:
            name = None
            for candidate in cmd.app_names:
                try:
                    if await asyncio.to_thread(self.confident_app, candidate):
                        name = candidate
                        break
                except Exception:
                    break
            if name is None:
                return None
            cmd.args[cmd.app_arg] = name
        result = await self.execute(cmd.tool, cmd.args, source="text")
        if result.get("status") == "needs_confirmation":
            reply = "Bunun için onayın gerekiyor — ekrandaki karttan onaylayabilirsin."
        elif "error" in result:
            reply = str(result["error"])
        elif cmd.format:
            reply = cmd.format(result)
        else:
            reply = str(result.get("output") or "Tamam.")
        return {"text": reply, "steps": [cmd.tool], "model": "fast"}


def _name_candidates(name: str, multiword: bool) -> list[str]:
    """Spellings to try for an app name with a Turkish accusative suffix but no
    apostrophe: 'spotifyı' -> spotify, 'kamerayı' -> kamera, 'hesap makinesini' -> hesap makinesi."""
    if multiword:
        variants = [name, re.sub(r"(?<=\w)n[iıuü]$", "", name)]
    else:
        variants = [name, re.sub(r"(?<=\w\w)[iıuü]$", "", name), re.sub(r"(?<=\w\w)y[iıuü]$", "", name)]
    return list(dict.fromkeys(v for v in variants if v))


_THIS_WINDOW = {"bu pencere", "bu pencereyi", "pencereyi", "pencere", "bunu", "bu"}


def _app_words(text: str, m: re.Match, group: int) -> str:
    """Original-cased app name from a match group, without Turkish case suffixes."""
    raw = re.sub(r"['’]\w*", "", text.strip()[m.start(group):m.end(group)]).strip()
    return raw


def _window_cmd(text: str, m: re.Match, position: str) -> FastCommand | None:
    name = _app_words(text, m, 1)
    folded = fold(name).strip()
    if folded in _THIS_WINDOW:
        return FastCommand("arrange_window", {"app": "__foreground__", "position": position})
    words = folded.split()
    if not words or len(words) > 3 or words[0] in _NOT_APPS - {"pencereyi"}:
        return None
    return FastCommand("arrange_window", {"position": position}, app_names=_name_candidates(name, len(words) > 1),
                       app_arg="app")


def describe(cmd: FastCommand) -> str | None:
    """Human preview for the launcher ("Sesi %30 yap"); None for app commands
    (the launcher lists apps itself)."""
    a = cmd.args
    if cmd.app_names:
        return None
    if cmd.tool == "set_volume":
        if a.get("mute"):
            return "Sessize al"
        if "level" in a:
            return f"Sesi %{a['level']} yap"
        return "Sesi aç" if a.get("change", 0) > 0 else "Sesi kıs"
    if cmd.tool == "media_control":
        return {"next": "Sonraki parça", "previous": "Önceki parça", "pause": "Müziği duraklat",
                "play": "Müziği devam ettir"}.get(a.get("action", ""), "Medya kontrolü")
    if cmd.tool == "set_reminder":
        return f"{int(a['in_minutes'])} dk sonra hatırlat: {a['text']}"
    if cmd.tool == "set_alarm":
        return f"Alarm kur: {a['at']}"
    if cmd.tool == "set_timer":
        mins, secs = a.get("minutes", 0), a.get("seconds", 0)
        span = f"{mins} dk" if mins else ""
        span += f" {secs} sn" if secs else ""
        return f"Zamanlayıcı: {span.strip()}" + (f" · {a['label']}" if a.get("label") not in (None, "Zamanlayıcı") else "")
    if cmd.tool == "get_exchange_rate":
        return f"{a['amount']:g} {a['from_currency']} kaç TL?"
    if cmd.tool == "arrange_window":
        where = {"left": "sola", "right": "sağa", "top": "üste", "bottom": "alta", "center": "ortaya",
                 "full": "tam ekrana", "minimize": "simge durumuna"}.get(a.get("position", ""), "")
        return f"Pencereyi {where} al"
    if cmd.tool == "side_by_side":
        return f"Yan yana: {a['left_app']} | {a['right_app']}"
    if cmd.tool == "read_screen_text":
        where = "ekrandaki" if a.get("target") == "screen" else "penceredeki"
        return f"{where.capitalize()} yazıyı {'kopyala' if a.get('to_clipboard') else 'oku'} (cihazda)"
    if cmd.tool == "take_screenshot":
        return "Ekran görüntüsü al" + (" (pencere)" if a.get("target") == "window" else "")
    if cmd.tool == "take_note":
        return f"Not al: {a['text']}"
    if cmd.tool == "focus_mode":
        return f"Odak modu · {a['minutes']} dk + odak müziği"
    return {"show_desktop": "Masaüstünü göster", "list_notes": "Notlarımı göster", "current_time": "Saat / tarih", "lock_screen": "Ekranı kilitle", "get_weather": "Hava durumu",
            "daily_brief": "Günün özeti"}.get(cmd.tool, cmd.tool)
