"""Capability catalog: Jarvis knows what it can do.

Every tool is indexed by its Turkish title, description, example phrase and
category (stemmed, BM25-style, fully local — no API call, ~1 ms). Used to

* answer "bunu yapabilir misin?" / "neler yapabilirsin?" from the real
  registry instead of the model's guess, and
* retrieve a small candidate set of tools for multi-step requests, so the
  prompt stays small as the number of tools (and MCP servers) grows.
"""

from __future__ import annotations

import math
from collections import Counter
from dataclasses import dataclass
from typing import Any

from jarvis.memory.stem import tokens


@dataclass(slots=True)
class Entry:
    name: str
    title: str
    example: str
    category: str
    text: str
    terms: Counter[str]


class Catalog:
    def __init__(self) -> None:
        self.entries: list[Entry] = []
        self.df: Counter[str] = Counter()
        self._sig: tuple[str, ...] = ()

    def build(self, specs: list[Any]) -> None:
        from jarvis.tools.titles import CATEGORIES, TOOLS, title_of

        sig = tuple(sorted(s.name for s in specs))
        if sig == self._sig:
            return
        self._sig = sig
        self.entries, self.df = [], Counter()
        for s in specs:
            meta = TOOLS.get(s.name, {})
            cat = CATEGORIES.get(s.category, {}).get("title", s.category)
            text = " ".join([title_of(s.name), meta.get("say", ""), s.description, cat, s.name.replace("_", " ")])
            terms = Counter(tokens(text))
            # title and example phrase describe the capability best: count them twice
            terms.update(tokens(f"{title_of(s.name)} {meta.get('say', '')}"))
            self.entries.append(Entry(s.name, title_of(s.name), meta.get("say", ""), cat, s.description, terms))
            self.df.update(set(terms))

    def search(self, query: str, k: int = 8) -> list[tuple[Entry, float]]:
        q = tokens(query)
        if not q or not self.entries:
            return []
        n = len(self.entries)
        avg = sum(sum(e.terms.values()) for e in self.entries) / n
        scored = []
        for e in self.entries:
            length = sum(e.terms.values())
            score = 0.0
            for t in q:
                tf = e.terms.get(t, 0)
                if not tf:
                    continue
                idf = math.log(1 + (n - self.df[t] + 0.5) / (self.df[t] + 0.5))
                score += idf * tf * 2.2 / (tf + 1.2 * (0.25 + 0.75 * length / avg))
            if score > 0:
                scored.append((e, score))
        scored.sort(key=lambda x: x[1], reverse=True)
        return scored[:k]


CATALOG = Catalog()
