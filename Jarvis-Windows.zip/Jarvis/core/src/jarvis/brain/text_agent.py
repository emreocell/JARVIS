"""Typed-command agent (when not talking through the Live voice session).

Gemini native function calling over REST, routed through the quota-aware
key pool (``text_worker`` role). Tool calls go through the same
:class:`ToolRuntime` gates as voice; typed messages are published as
``user.text`` so a typed "evet" is valid evidence for confirmations.
"""

from __future__ import annotations

import asyncio
import itertools
import json
import logging
from collections.abc import Callable
from typing import Any

from jarvis.brain.fast import FastPath
from jarvis.brain.router import MORE_TOOLS, IntentRouter, Route, spoken as direct_answer
from jarvis.bus import EventBus
from jarvis.config.schema import Role
from jarvis.providers.gemini import GeminiAdapter
from jarvis.providers.registry import ProviderRegistry
from jarvis.tools.runtime import ToolRuntime

log = logging.getLogger(__name__)

MAX_STEPS = 6
MAX_HISTORY = 24
SPOKEN_NOTE = ("\n\nBu cevap sesli okunacak: kısa ve doğal konuş (1-3 cümle), markdown, liste, emoji, "
               "bağlantı veya kod kullanma.")


def _confident_app(name: str) -> bool:
    from jarvis.skills.apps import confident_app

    return confident_app(name)


class TextAgent:
    def __init__(self, bus: EventBus, providers: ProviderRegistry, tools: ToolRuntime,
                 system_instruction: Callable[[], str],
                 fast_enabled: Callable[[], bool] = lambda: False,
                 router: IntentRouter | None = None) -> None:
        self.bus = bus
        self.providers = providers
        self.tools = tools
        self.system_instruction = system_instruction
        self.contents: list[dict[str, Any]] = []
        self._turns = itertools.count(1)
        self.fast_enabled = fast_enabled
        self.fast = FastPath(tools.execute, _confident_app)
        self.router = router

    def reset(self) -> None:
        self.contents.clear()

    def _recent(self) -> list[tuple[str, str]]:
        out = []
        for c in self.contents[-6:]:
            parts = c.get("parts") or []
            if parts and "text" in parts[0]:
                out.append((c.get("role", ""), parts[0]["text"]))
        return out

    def _declarations(self, route: Route | None = None) -> list[dict[str, Any]]:
        specs = self.tools.enabled()
        if route is not None and route.kind != "full":
            specs = IntentRouter.tools_for(route, specs)
        out = []
        for spec in specs:
            decl: dict[str, Any] = {"name": spec.name, "description": spec.description}
            if spec.parameters.get("properties"):
                decl["parametersJsonSchema"] = spec.parameters
            out.append(decl)
        if route is not None and route.kind != "full":
            out.append(dict(MORE_TOOLS))
        return out

    def _trim(self) -> None:
        if len(self.contents) <= MAX_HISTORY:
            return
        cut = len(self.contents) - MAX_HISTORY
        # restart history at a plain user text turn (never between a call and its response)
        while cut < len(self.contents):
            parts = self.contents[cut].get("parts", [])
            if self.contents[cut].get("role") == "user" and parts and "text" in parts[0]:
                break
            cut += 1
        self.contents = self.contents[cut:]

    async def _generate(self, route: Route | None, spoken: bool) -> Any:
        system = self.system_instruction() + (SPOKEN_NOTE if spoken else "")
        body = {
            "systemInstruction": {"parts": [{"text": system}]},
            "contents": list(self.contents),
            "tools": [{"functionDeclarations": self._declarations(route)}],
            "generationConfig": {"temperature": 0.4},
        }
        return await self.providers.route(
            Role.TEXT_WORKER, lambda adapter, model, secret: adapter.generate(model, secret, body),
            est_tokens=sum(len(str(c)) for c in self.contents) // 4 + 2000, only=GeminiAdapter,
        )

    async def run(self, text: str, publish_turn: bool = True, spoken: bool = False) -> dict[str, Any]:
        """``spoken``: the reply will be read aloud (cascade voice) — keep it
        short and plain. ``publish_turn=False`` when the caller logs the turn."""
        await self.bus.publish("user.text", role="user", text=text, turn=next(self._turns))
        if self.fast_enabled():
            fast = await self.fast.try_run(text)
            if fast is not None:
                # keep the exchange in context so "biraz daha kıs" still makes sense to the LLM
                self.contents += [{"role": "user", "parts": [{"text": text}]},
                                  {"role": "model", "parts": [{"text": fast["text"]}]}]
                self._trim()
                if publish_turn:
                    await self.bus.publish("voice.turn_complete", user=text, assistant=fast["text"])
                return fast
        steps: list[str] = []
        self.contents.append({"role": "user", "parts": [{"text": text}]})
        self._trim()
        # Jev and the LLM start together: if Jev (~0.3 s) finds a ready-made action,
        # the LLM call is dropped; otherwise its answer is already on the way, so
        # routing never makes a command slower.
        first: asyncio.Task[Any] = asyncio.create_task(self._generate(None, spoken))
        route: Route | None = None
        routing: asyncio.Task[Route] | None = None
        if self.router is not None and self.router.enabled() and self.tools.approvals.latest() is None:
            routing = asyncio.create_task(self.router.route(text, self._recent()[:-1],
                                                            available=set(self.tools.tools)))
            done, _ = await asyncio.wait({first, routing}, return_when=asyncio.FIRST_COMPLETED)
            if routing in done:
                route = routing.result()
                await self.bus.publish("router.decision", route=route.label(), ms=route.ms,
                                       confidence=route.confidence)
        if route is not None and route.kind == "direct":
            first.cancel()
            result = await self.tools.execute(route.tool, route.args, source="text")
            steps.append(route.tool)
            out = direct_answer(route.tool, result, route.args)
            if out:   # the tool's own sentence is the answer: no LLM round trip at all
                self.contents.append({"role": "model", "parts": [{"text": out}]})
                self._trim()
                if publish_turn:
                    await self.bus.publish("voice.turn_complete", user=text, assistant=out)
                return {"text": out, "steps": steps, "model": "jev", "route": route.label()}
            self.contents[-1] = {"role": "user", "parts": [{"text": (
                f"{text}\n\n(Sistem notu: bu istek için {route.tool} aracı zaten çalıştırıldı; sonucu aşağıda. "
                f"Aynı aracı tekrar çağırma, sonuca göre cevap ver.)\n"
                f"{json.dumps(result, ensure_ascii=False, default=str)[:4000]}")}]}
            # phrasing only: the small "sohbet" tool set keeps this call fast
            route = Route("area", area="sohbet", confidence=route.confidence, ms=route.ms, tool=route.tool)
            first = asyncio.create_task(self._generate(route, spoken))
        reply = ""
        model_used = ""
        narrow: Route | None = route if route is not None and route.kind == "area" else None
        for step in range(MAX_STEPS):
            if step == 0:
                resp = await first
            else:
                if narrow is None and routing is not None and routing.done() and not routing.cancelled():
                    r = routing.result()
                    # later steps (after a tool result) only need that area's tools…
                    narrow = r if r.kind == "area" and r.confidence >= 0.8 else None
                    if narrow is None and r.kind == "full":
                        # …or, for mixed multi-step requests, the catalog's best candidates + what was used
                        found = IntentRouter.retrieve(text, self.tools.enabled())
                        narrow = Route("set", names=tuple(dict.fromkeys([*found.names, *steps])))
                resp = await self._generate(narrow, spoken)
            model_used = resp.model
            self.contents.append(resp.raw["content"])
            reply = resp.text or reply
            calls = [p["functionCall"] for p in resp.raw["parts"] if "functionCall" in p]
            if not calls:
                break
            responses = []
            for call in calls:
                name, args = call.get("name", ""), call.get("args") or {}
                if name == MORE_TOOLS["name"]:   # the area guess was too narrow: open everything
                    narrow, routing = None, None
                    result = {"output": "Tüm araçlar açıldı; şimdi uygun aracı çağır."}
                else:
                    steps.append(name)
                    result = await self.tools.execute(name, args, call_id=call.get("id", ""), source="text")
                fr: dict[str, Any] = {"name": name, "response": result}
                if call.get("id"):
                    fr["id"] = call["id"]
                responses.append({"functionResponse": fr})
            self.contents.append({"role": "user", "parts": responses})
        else:
            reply = reply or "Bu işi adım sınırı içinde bitiremedim."
        if route is None and routing is not None and routing.done() and not routing.cancelled():
            route = routing.result()
            if route.kind == "direct":   # Jev was slower than the LLM this time
                route = Route("full", ms=route.ms)
        if publish_turn:
            await self.bus.publish("voice.turn_complete", user=text, assistant=reply)
        return {"text": reply, "steps": steps, "model": model_used, "route": route.label() if route else "full"}
