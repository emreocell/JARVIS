"""Jev intent router: decide *where* a command goes before any LLM call.

One Jev request (~0.3 s) answers two typed questions about the utterance:

1. ``direct`` — can a ready-made action answer it completely with no extra
   information ("sonraki şarkı", "pencereleri listele", "hava nasıl")?
   Then the tool runs straight away and the first LLM round trip is skipped.
2. ``area`` — which skill area is it about? The LLM then sees only that
   area's tools (plus an escape hatch), a much smaller and faster prompt.

Low confidence on both → the normal full-tool path. Direct actions are only
read-only / harmless ones, and every call still goes through ToolRuntime's
approval gates.
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from typing import Any

from jarvis.providers.typesafe import choice

log = logging.getLogger(__name__)

DIRECT_MIN = 0.85
AREA_MIN = 0.6

# ready-made actions: option id -> (tool, fixed args, description for Jev)
DIRECT: dict[str, tuple[str, dict[str, Any], str]] = {
    "time": ("current_time", {}, "Saati / bugünün tarihini söylemek"),
    "weather": ("get_weather", {}, "Kullanıcının bulunduğu yerde hava durumu (bugün / yarın / bu hafta)"),
    "news": ("get_news", {}, "Gündem / son haber başlıkları"),
    "brief": ("daily_brief", {}, "Günün özeti, 'günaydın', 'bugün neler var'"),
    "next": ("media_control", {"action": "next"}, "Çalan şarkıyı / videoyu geçmek, sonrakine atlamak"),
    "previous": ("media_control", {"action": "previous"}, "Önceki şarkıya dönmek"),
    "pause": ("media_control", {"action": "pause"}, "Müziği / videoyu durdurmak, duraklatmak"),
    "resume": ("media_control", {"action": "play"}, "Müziği / videoyu devam ettirmek, oynatmak"),
    "playing": ("now_playing", {}, "Şu an çalan şarkının ne olduğunu söylemek"),
    "windows": ("list_windows", {}, "Açık pencereleri listelemek"),
    "apps": ("list_running_apps", {}, "Çalışan uygulamaları listelemek"),
    "desktop": ("show_desktop", {}, "Masaüstünü göstermek, tüm pencereleri küçültmek"),
    "screenshot": ("take_screenshot", {}, "Ekran görüntüsü almak"),
    "reminders": ("list_reminders", {}, "Kurulu hatırlatıcıları / alarmları listelemek"),
    "notes": ("list_notes", {}, "Notlarımı listelemek"),
    "sysinfo": ("system_info", {}, "Pil, işlemci, bellek, disk durumu"),
    "unread": ("gmail_unread", {}, "Okunmamış / yeni mailleri göstermek"),
    "agenda": ("calendar_agenda", {}, "Takvimdeki yaklaşan etkinliklere bakmak"),
    "notifs": ("notifications_summary", {}, "Ben yokken / son zamanlarda gelen bildirimler, kim yazdı, önemli bir şey oldu mu"),
    "today": ("what_did_i_do", {}, "Bugün bilgisayarda ne yaptığımı / hangi projelerle uğraştığımı özetlemek"),
}
# direct results that already read as the answer: tool -> sentence builder
MEDIA_SAID = {"next": "Sonrakine geçtim.", "previous": "Öncekine döndüm.", "pause": "Durdurdum.", "play": "Devam ediyor."}
SELF_SPOKEN: dict[str, Any] = {
    "current_time": lambda r, a: f"Saat {r['time']}." if r.get("time") else None,
    "media_control": lambda r, a: MEDIA_SAID.get(a.get("action", "")) if r.get("output") == "Tamam." else r.get("output"),
    "show_desktop": lambda r, a: r.get("output"),
    "take_screenshot": lambda r, a: r.get("output"),
    "get_weather": lambda r, a: r.get("output"),
    "list_windows": lambda r, a: ("Açık pencereler: " + ", ".join(w for w in r["windows"] if w != "Jarvis") + "."
                                  if r.get("windows") else "Açık pencere yok."),
    "now_playing": lambda r, a: (f"{r['artist']} – {r['title']} {'çalıyor' if r.get('playing') else 'duraklatılmış'}"
                                 f" ({r.get('app', '')})." if r.get("title") else r.get("output")),
    "list_reminders": lambda r, a: ("Kurulu hatırlatıcın yok." if not r.get("items") else
                                    "Hatırlatıcıların: " + "; ".join(f"{i['when']} {i['text']}" for i in r["items"][:6])
                                    + "."),
    "list_notes": lambda r, a: r.get("output") if len(r.get("output") or "") < 200 else None,
}


def spoken(tool: str, result: dict[str, Any], args: dict[str, Any]) -> str | None:
    """The finished answer for a direct action, or None if the LLM should phrase it."""
    if "error" in result or "status" in result or tool not in SELF_SPOKEN:
        return None
    try:
        text = SELF_SPOKEN[tool](result, args)
    except Exception:
        return None
    return text if text and len(text) <= 240 else None

AREAS: dict[str, str] = {
    "sohbet": "Genel sohbet, bilgi sorusu, hesap, çeviri, fikir; bilgisayarda bir şey yapmak gerekmiyor",
    "apps": "Uygulama açmak / kapatmak",
    "files": "Dosya veya klasör bulmak / açmak",
    "system": "Ses, parlaklık, kilit, güç, sistem ayarları, saat",
    "media": "Müzik, Spotify, YouTube, çalan medya",
    "communication": "WhatsApp'tan mesaj göndermek",
    "mail": "Gmail, e-posta, Google Takvim, etkinlik",
    "memory": "Kullanıcı hakkında bir şeyi hatırlamak / unutmak / hatırladıklarını sormak",
    "screen": "Ekranda ne olduğu, ekrana bakmak, ekrandaki yazıyı okumak",
    "routines": "Hatırlatıcı, alarm, zamanlayıcı, rutin, odak modu",
    "ai-tools": "VS Code / Cursor gibi kod editörlerine veya AI araçlarına istem göndermek",
    "browser": "Web sitesi açmak, sayfada tıklamak / okumak / yazmak, web araştırması, ChatGPT'ye sormak, "
               "tarayıcı oyunu",
    "desktop": "Bir Windows uygulamasının içinde tıklamak / yazmak / tuşa basmak",
    "info": "Hava durumu, döviz, haberler, günün özeti, konum",
    "notes": "Not almak, notları listelemek / silmek",
    "windows": "Pencereleri düzenlemek, yan yana koymak, ekran görüntüsü",
    "mcp": "Windows-MCP gibi dış bağlantı araçları",
    "birden_fazla": "Birden fazla alana giren çok adımlı bir iş ya da emin değilim",
}
# always offered, whatever the area
CORE_TOOLS = {"confirm_pending_action", "cancel_pending_action", "remember", "recall", "look_at_screen",
              "what_is_this", "who_is", "what_can_you_do"}
MORE_TOOLS = {
    "name": "need_more_tools",
    "description": "Gereken araç bu listede yoksa bunu çağır; tüm araçlar açılır. Asla 'yapamam' deme, önce bunu dene.",
}


@dataclass(slots=True)
class Route:
    kind: str                                     # "direct" | "area" | "full"
    tool: str = ""
    args: dict[str, Any] = field(default_factory=dict)
    area: str = ""
    confidence: float = 0.0
    ms: int = 0
    names: tuple[str, ...] = ()                   # kind "set": tools picked from the capability catalog

    def label(self) -> str:
        if self.kind == "direct":
            return f"jev:direct:{self.tool}"
        if self.kind == "set":
            return f"catalog:{len(self.names)}"
        if self.kind == "area" and self.tool:
            return f"jev:direct:{self.tool}+llm"
        if self.kind == "area":
            return f"jev:area:{self.area}"
        return "full"


class IntentRouter:
    def __init__(self, core: Any) -> None:
        self.core = core

    def enabled(self) -> bool:
        cfg = getattr(self.core, "config", None)
        return bool(cfg and getattr(cfg.features, "jev_decider", False) and getattr(cfg.features, "jev_router", True))

    def _state(self, text: str, recent: list[tuple[str, str]]) -> str:
        lines = [f"Kullanıcının şu anki isteği: “{text}”"]
        ctx = getattr(self.core, "context", None)
        focus = ctx.current() if ctx else None
        if focus and focus.app != "Jarvis":
            lines.append(f"Öndeki pencere: {focus.app} — {focus.title[:80]}")
        for role, said in recent[-2:]:
            lines.append(f"Önceki {'kullanıcı' if role == 'user' else 'Jarvis'}: {said[:160]}")
        return "\n".join(lines)

    async def route(self, text: str, recent: list[tuple[str, str]] | None = None,
                    available: set[str] | None = None) -> Route:
        direct = {k: v[2] for k, v in DIRECT.items() if available is None or v[0] in available}
        direct["yok"] = "Hiçbiri: ek bilgi gerekiyor, başka bir iş, ya da emin değilim"
        started = time.perf_counter()
        try:
            result = await self.core.providers.decide(self._state(text, recent or []), {
                "direct": choice("Bu istek aşağıdaki hazır eylemlerden biriyle, başka hiçbir bilgi gerekmeden TAM "
                                 "olarak karşılanır mı? Tam uymuyorsa 'yok' seç.", direct),
                "area": choice("Bu istek hangi yetenek alanıyla ilgili?", dict(AREAS)),
            })
        except Exception as exc:
            log.info("router: jev unavailable (%s)", exc)
            return Route("full")
        ms = int((time.perf_counter() - started) * 1000)
        d, a = result["answers"]["direct"], result["answers"]["area"]
        dc, dconf = str(d.get("choice")), float(d.get("confidence") or 0)
        ac, aconf = str(a.get("choice")), float(a.get("confidence") or 0)
        log.info("router %d ms: direct=%s (%.2f) area=%s (%.2f) | %s", ms, dc, dconf, ac, aconf, text[:60])
        if dc in DIRECT and dconf >= DIRECT_MIN:
            tool, args, _ = DIRECT[dc]
            return Route("direct", tool=tool, args=dict(args), area=ac, confidence=dconf, ms=ms)
        if ac in AREAS and ac != "birden_fazla" and aconf >= AREA_MIN:
            return Route("area", area=ac, confidence=aconf, ms=ms)
        return Route("full", confidence=aconf, ms=ms)

    @staticmethod
    def retrieve(text: str, specs: list[Any], k: int = 20) -> Route:
        """Catalog-based candidate tools for a request no area covers (multi-step, mixed)."""
        from jarvis.brain.catalog import CATALOG

        CATALOG.build(specs)
        return Route("set", names=tuple(e.name for e, _ in CATALOG.search(text, k)))

    @staticmethod
    def tools_for(route: Route, specs: list[Any]) -> list[Any]:
        """The tool subset the LLM sees for this route."""
        if route.kind == "set":
            wanted = set(route.names) | CORE_TOOLS
            return [s for s in specs if s.name in wanted]
        if route.kind != "area":
            return specs
        if route.area == "sohbet":
            return [s for s in specs if s.name in CORE_TOOLS]
        area = route.area
        return [s for s in specs if s.category == area or s.name in CORE_TOOLS
                or (area == "mcp" and s.skill.startswith("mcp_"))]
