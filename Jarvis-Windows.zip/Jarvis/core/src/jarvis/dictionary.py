"""Personal dictionary: names and terms Jarvis must never mishear.

"Webioo", "WPanel", project and people names… Each entry has the correct
spelling, what speech recognition tends to make of it ("web yo", "vebio")
and an optional note. Used in four places: Live transcription vocabulary,
cascade STT prompt, the system instruction, and fixing transcripts.
"""

from __future__ import annotations

import re
from typing import Any

from jarvis.brain.fast import fold


def entries(config: Any) -> list[Any]:
    return list(getattr(config.assistant, "dictionary", []) or [])


def terms(config: Any) -> list[str]:
    return [e.term for e in entries(config) if e.term]


def prompt_block(config: Any) -> str:
    lines = []
    for e in entries(config):
        heard = f" (konuşmada '{', '.join(e.sounds_like)}' gibi duyulabilir)" if e.sounds_like else ""
        note = f" — {e.note}" if e.note else ""
        lines.append(f"- {e.term}{heard}{note}")
    return "\n".join(lines)


def fix(text: str, config: Any) -> str:
    """Replace known mishearings with the right term (Turkish-insensitive, whole words)."""
    if not text:
        return text
    out = text
    for e in entries(config):
        for heard in sorted(e.sounds_like or [], key=len, reverse=True):
            h = fold(heard).strip()
            if not h:
                continue
            folded = fold(out)
            if not folded:
                break
            # fold() keeps length, so spans found in the folded text index the original
            for m in reversed(list(re.finditer(rf"(?<![a-z0-9]){re.escape(h)}(?![a-z0-9])", folded))):
                out = out[:m.start()] + e.term + out[m.end():]
    return out
