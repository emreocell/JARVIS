"""Tiny, dependency-free screen perception for games: find blobs that stand
out from the background and describe them in words for a decision model.

Works on a downscaled frame (a few thousand cells) so one pass costs
~10 ms in pure numpy + a Python flood fill.
"""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass

import numpy as np

COLORS = {
    "beyaz": (245, 245, 245), "siyah": (20, 20, 20), "gri": (128, 128, 128), "kırmızı": (220, 40, 40),
    "turuncu": (240, 140, 30), "sarı": (240, 220, 40), "yeşil": (60, 180, 70), "açık mavi": (120, 200, 250),
    "mavi": (40, 90, 220), "mor": (140, 70, 200), "pembe": (240, 120, 180), "kahverengi": (130, 80, 40),
}


@dataclass(slots=True)
class Blob:
    x: float          # centre, 0..1 of the frame
    y: float
    w: int            # size in source pixels
    h: int
    area: int
    fill: float       # area / bbox area (a disc ≈ 0.785)
    color: tuple[int, int, int]

    @property
    def color_name(self) -> str:
        return min(COLORS, key=lambda n: sum((a - b) ** 2 for a, b in zip(COLORS[n], self.color)))

    @property
    def shape(self) -> str:
        ratio = self.w / max(1, self.h)
        if 0.8 < ratio < 1.25 and 0.65 < self.fill < 0.9:
            return "yuvarlak"
        if self.fill > 0.9:
            return "dikdörtgen"
        if ratio > 3:
            return "yatay şerit / yazı"
        return "düzensiz"

    def describe(self) -> str:
        col = "sol" if self.x < 0.34 else "sağ" if self.x > 0.66 else "orta"
        row = "üst" if self.y < 0.34 else "alt" if self.y > 0.66 else "orta"
        where = "tam orta" if col == row == "orta" else f"{row} {col}"
        return (f"{self.color_name} {self.shape} şekil, {self.w}x{self.h} px, {where} "
                f"(x %{round(self.x * 100)}, y %{round(self.y * 100)})")


def background(img: np.ndarray) -> np.ndarray:
    """Most common (quantized) colour = the background."""
    q = (img[::4, ::4] // 32).reshape(-1, 3)
    keys = q[:, 0].astype(np.int32) * 64 + q[:, 1] * 8 + q[:, 2]
    k = np.bincount(keys).argmax()
    mask = keys == k
    return img[::4, ::4].reshape(-1, 3)[mask].mean(axis=0)


def blobs(img: np.ndarray, cell: int = 4, threshold: float = 60.0, min_cells: int = 4,
          max_blobs: int = 12) -> list[Blob]:
    """Connected regions that differ from the background (img: H×W×3 uint8)."""
    h, w = img.shape[:2]
    small = img[: h - h % cell, : w - w % cell].reshape(h // cell, cell, w // cell, cell, 3).mean(axis=(1, 3))
    bg = background(img)
    diff = np.sqrt(((small - bg) ** 2).sum(axis=2)) > threshold
    gh, gw = diff.shape
    seen = np.zeros_like(diff, dtype=bool)
    found: list[Blob] = []
    ys, xs = np.nonzero(diff)
    for y0, x0 in zip(ys.tolist(), xs.tolist()):
        if seen[y0, x0]:
            continue
        queue = deque([(y0, x0)])
        seen[y0, x0] = True
        cells = []
        while queue:
            y, x = queue.popleft()
            cells.append((y, x))
            for ny, nx in ((y + 1, x), (y - 1, x), (y, x + 1), (y, x - 1)):
                if 0 <= ny < gh and 0 <= nx < gw and diff[ny, nx] and not seen[ny, nx]:
                    seen[ny, nx] = True
                    queue.append((ny, nx))
        if len(cells) < min_cells:
            continue
        cy = [c[0] for c in cells]
        cx = [c[1] for c in cells]
        bw, bh = max(cx) - min(cx) + 1, max(cy) - min(cy) + 1
        color = small[cy, cx].mean(axis=0)
        found.append(Blob(x=(sum(cx) / len(cx) + 0.5) / gw, y=(sum(cy) / len(cy) + 0.5) / gh, w=bw * cell,
                          h=bh * cell, area=len(cells) * cell * cell, fill=len(cells) / (bw * bh),
                          color=tuple(int(v) for v in color)))
    found.sort(key=lambda b: b.area, reverse=True)
    # concentric pieces (ring targets) are one object: keep the largest
    merged: list[Blob] = []
    for b in found:
        if not any(abs(b.x - m.x) * w < m.w / 3 and abs(b.y - m.y) * h < m.h / 3 for m in merged):
            merged.append(b)
    return merged[:max_blobs]
