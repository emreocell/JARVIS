"""Browser mini-games as a speed test for fast decisions.

Two decision modes:
- "jev": every move is a Jev choice. Perception is generic vision (blobs on a
  screenshot, described in words), so Jev really decides which thing on
  screen is the target.
- "refleks": Jev decides once what the target looks like, then a local
  reflex repeats it (no network per move).

Every run reports decision latency, so the two can be compared honestly.
"""

from __future__ import annotations

import asyncio
import base64
import io
import logging
import re
import statistics
import time
from dataclasses import dataclass, field
from typing import Any

import numpy as np

from jarvis.games.vision import Blob, blobs

log = logging.getLogger(__name__)

AIM_URL = "https://humanbenchmark.com/tests/aim"
REACTION_URL = "https://humanbenchmark.com/tests/reactiontime"


@dataclass
class Stats:
    decisions: list[int] = field(default_factory=list)   # Jev ms per decision
    moves: list[int] = field(default_factory=list)       # perception→click ms per move
    errors: int = 0
    local: int = 0                                        # moves decided locally because Jev failed

    def summary(self) -> dict[str, Any]:
        out: dict[str, Any] = {"moves": len(self.moves)}
        if self.decisions:
            out["jev_decisions"] = len(self.decisions)
            out["jev_median_ms"] = int(statistics.median(self.decisions))
        if self.moves:
            out["move_median_ms"] = int(statistics.median(self.moves))
        if self.errors:
            out["jev_errors"] = self.errors
        if self.local:
            out["local_fallbacks"] = self.local
        return out


class Frame:
    """Fast frame capture of a page region through the DevTools protocol."""

    def __init__(self, page: Any) -> None:
        self.page = page
        self.cdp: Any = None

    async def grab(self, clip: dict[str, float], scale: float = 0.5) -> np.ndarray:
        from PIL import Image

        if self.cdp is None:
            self.cdp = await self.page.context.new_cdp_session(self.page)
        shot = await self.cdp.send("Page.captureScreenshot", {
            "format": "jpeg", "quality": 55, "clip": {**clip, "scale": scale}, "captureBeyondViewport": False})
        img = Image.open(io.BytesIO(base64.b64decode(shot["data"]))).convert("RGB")
        return np.asarray(img)


async def _decide(core: Any, state: str, question: str, options: dict[str, str], stats: Stats) -> str | None:
    try:
        d = await core.decider._jev(state, question, options)
    except Exception as exc:
        log.warning("jev decision failed: %s", str(exc)[:160])
        stats.errors += 1
        return None
    stats.decisions.append(d.latency_ms)
    return d.choice if d.choice in options else None


# ------------------------------------------------------------------ aim

AREA_JS = """() => {
  const t = document.querySelector('[data-aim-target]');
  let e = t;
  while (e && e.getBoundingClientRect().height < 300) e = e.parentElement;
  const r = (e || document.body).getBoundingClientRect();
  return {x: r.x, y: r.y + window.scrollY, width: r.width, height: Math.min(r.height, innerHeight - r.y)};
}"""

TARGET_JS = """() => {
  const t = document.querySelector('[data-aim-target] > div');
  if (!t) return null;
  const r = t.getBoundingClientRect();
  return {x: r.x + r.width / 2, y: r.y + r.height / 2};
}"""

RESULT_JS = """() => {
  const m = document.body.innerText.match(/Average time per target\\s*(\\d+)\\s*ms/i) ||
            document.body.innerText.match(/(\\d+)\\s*ms/);
  return m && !document.querySelector('[data-aim-target]') ? parseInt(m[1]) : null;
}"""


def _similar(a: Blob, b: Blob) -> bool:
    return abs(a.w - b.w) < max(a.w, b.w) * 0.35 and sum(abs(x - y) for x, y in zip(a.color, b.color)) < 90


async def play_aim(core: Any, page: Any, mode: str = "jev", progress: Any = None) -> dict[str, Any]:
    await page.goto(AIM_URL, wait_until="domcontentloaded")
    await page.wait_for_selector("[data-aim-target]", state="attached", timeout=15_000)
    await asyncio.sleep(0.6)
    area = await page.evaluate(AREA_JS)
    frame = Frame(page)
    stats = Stats()
    learned: Blob | None = None
    scale = 0.5
    last = None
    started = time.perf_counter()
    step = 0
    while time.perf_counter() - started < 90:
        t0 = time.perf_counter()
        img = await frame.grab(area, scale)
        found = [b for b in blobs(img) if b.w >= 12]
        if not found:
            if await page.evaluate(RESULT_JS):
                break
            await asyncio.sleep(0.05)
            continue
        pick: Blob | None = None
        if mode == "refleks" and learned is not None:
            same = [b for b in found if _similar(b, learned)]
            pick = same[0] if same else None
        if pick is None:
            options = {f"b{i}": b.describe() for i, b in enumerate(found[:8])}
            options["yok"] = "Tıklanacak hedef görünmüyor"
            choice = await _decide(core, "Oyun: Aim Trainer (Human Benchmark). Mavi alanda beliren yuvarlak "
                                         "hedeflere olabildiğince hızlı tıklanır; yazılar ve sayaçlar hedef değildir.",
                                   "Şimdi hangisine tıklanmalı?", options, stats)
            if choice == "yok":
                await asyncio.sleep(0.03)
                continue
            if choice is None:   # Jev unreachable this time: local guess keeps the game going
                round_ = [b for b in found if b.shape == "yuvarlak"]
                if not round_:
                    await asyncio.sleep(0.05)
                    continue
                pick = round_[0]
                stats.local += 1
            else:
                pick = found[int(choice[1:])]
            learned = pick
        x = area["x"] + pick.x * area["width"]
        y = area["y"] + pick.y * area["height"]
        if last and abs(last[0] - x) < 3 and abs(last[1] - y) < 3:
            await asyncio.sleep(0.03)   # the old target is still drawn; wait for the next one
            continue
        await page.mouse.click(x, y)
        last = (x, y)
        stats.moves.append(int((time.perf_counter() - t0) * 1000))
        step += 1
        if progress:
            await progress(step, stats)
        await asyncio.sleep(0.02)
        if await page.evaluate(RESULT_JS):
            break
    await asyncio.sleep(0.8)
    score = await page.evaluate(RESULT_JS)
    return {"game": "aim", "mode": mode, "site_avg_ms_per_target": score,
            "seconds": round(time.perf_counter() - started, 1), **stats.summary()}


# ------------------------------------------------------------- reaction

async def play_reaction(core: Any, page: Any, mode: str = "jev", rounds: int = 5,
                        progress: Any = None) -> dict[str, Any]:
    await page.goto(REACTION_URL, wait_until="domcontentloaded")
    await page.wait_for_selector(".view-splash", state="attached", timeout=15_000)
    area = await page.evaluate("""() => { const r = document.querySelector('.view-splash').getBoundingClientRect();
                                      return {x: r.x, y: r.y + scrollY, width: r.width, height: r.height}; }""")
    frame = Frame(page)
    stats = Stats()
    cx, cy = area["x"] + area["width"] / 2, area["y"] + area["height"] / 2
    results: list[int] = []
    await page.mouse.click(cx, cy)   # start
    for n in range(rounds):
        deadline = time.perf_counter() + 8
        seen = ""
        while time.perf_counter() < deadline:
            img = await frame.grab(area, 0.1)
            r, g, b = img.reshape(-1, 3).mean(axis=0)
            green = g > 150 and g > r + 40
            if mode == "jev":
                colour = "yeşil" if green else "kırmızı" if r > g + 40 else "mavi/başka"
                if colour == seen:   # ask Jev only when the screen changes
                    continue
                seen = colour
                t0 = time.perf_counter()
                choice = await _decide(core, f"Oyun: tepki süresi testi. Ekran rengi şu an: {colour}.",
                                       "Şimdi tıklanmalı mı?", {"tikla": "Evet, ekran yeşil: hemen tıkla",
                                                                "bekle": "Hayır, ekran henüz yeşil değil: bekle"},
                                       stats)
                go = choice == "tikla"
            else:
                t0 = time.perf_counter()
                go = green
            if go:
                await page.mouse.click(cx, cy)
                stats.moves.append(int((time.perf_counter() - t0) * 1000))
                break
        await asyncio.sleep(0.6)
        text = await page.evaluate("document.body.innerText")
        m = re.search(r"(\d+)\s*ms", text)
        if m:
            results.append(int(m.group(1)))
        if progress:
            await progress(n + 1, stats)
        if n < rounds - 1:
            await page.mouse.click(cx, cy)   # next round
            await asyncio.sleep(0.3)
    return {"game": "reaction", "mode": mode, "site_ms": results,
            "site_median_ms": int(statistics.median(results)) if results else None, **stats.summary()}
