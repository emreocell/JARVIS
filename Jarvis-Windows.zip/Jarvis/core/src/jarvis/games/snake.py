"""Google Snake (google.com/fbx?fbx=snake_arcade), played from screen frames.

The snake moves a cell every ~130 ms, faster than any network round trip,
so steering is local: parse the board from a frame (~40 ms), plan a safe path
to the apple with BFS + a flood-fill safety check, and press the arrow key.
"""

from __future__ import annotations

import asyncio
import logging
import time
from collections import deque
from typing import Any

import numpy as np

from jarvis.games.play import Frame

log = logging.getLogger(__name__)

URL = "https://www.google.com/fbx?fbx=snake_arcade"
COLS, ROWS = 17, 15
DIRS = {"up": (0, -1), "down": (0, 1), "left": (-1, 0), "right": (1, 0)}
KEYS = {"up": "ArrowUp", "down": "ArrowDown", "left": "ArrowLeft", "right": "ArrowRight"}
OPPOSITE = {"up": "down", "down": "up", "left": "right", "right": "left"}

BOARD_JS = """() => {
  const c = [...document.querySelectorAll('canvas')].sort((a, b) =>
      b.getBoundingClientRect().width * b.getBoundingClientRect().height -
      a.getBoundingClientRect().width * a.getBoundingClientRect().height)[0];
  const r = c.getBoundingClientRect();
  return {x: r.x, y: r.y + scrollY, width: r.width, height: r.height};
}"""


async def start_game(page: Any) -> None:
    """Press the menu's Play button (Turkish or English UI), then nudge right."""
    import re

    for loc in (page.get_by_role("button", name=re.compile(r"^(Oyna|Play)$", re.I)),
                page.get_by_text(re.compile(r"^(Oyna|Play)$"))):
        try:
            await loc.first.click(timeout=2500)
            break
        except Exception:
            continue
    await asyncio.sleep(0.4)
    await page.keyboard.press("ArrowRight")


def parse(img: np.ndarray) -> dict[str, Any]:
    """Board frame (just the grid) → snake cells, head, apple."""
    h, w = img.shape[:2]
    ch, cw = h / ROWS, w / COLS
    snake, apple, head, best_eyes = set(), None, None, 0
    for r in range(ROWS):
        for c in range(COLS):
            y0, y1 = int(r * ch + ch * 0.2), int((r + 1) * ch - ch * 0.2)
            x0, x1 = int(c * cw + cw * 0.2), int((c + 1) * cw - cw * 0.2)
            patch = img[y0:y1, x0:x1].reshape(-1, 3).astype(np.int16)
            red, green, blue = patch[:, 0], patch[:, 1], patch[:, 2]
            n = len(patch)
            if ((red > 170) & (green < 110) & (blue < 90)).sum() > n * 0.25:
                apple = (c, r)
            if ((blue > red + 50) & (blue > green + 20)).sum() > n * 0.35:
                snake.add((c, r))
                eyes = ((red > 215) & (green > 215) & (blue > 215)).sum()
                if eyes > best_eyes:
                    head, best_eyes = (c, r), eyes
    # the eyes are the only white on the board: their centroid pins the head even
    # while it slides between two cells
    white = (img[:, :, 0] > 215) & (img[:, :, 1] > 215) & (img[:, :, 2] > 215)
    ys, xs = np.nonzero(white)
    eye = None
    if len(xs) >= 3:
        eye = (xs.mean() / cw, ys.mean() / ch)
        cell = (min(COLS - 1, int(eye[0])), min(ROWS - 1, int(eye[1])))
        if head is None or cell in snake:
            head = cell
            snake.add(cell)
    return {"snake": snake, "apple": apple, "head": head, "eye": eye}


LATE = 0.3   # cells: closer than this to the next cell centre, a key press lands too late


def next_turn_cell(eye: tuple[float, float], heading: str) -> tuple[tuple[int, int], float]:
    """The next cell centre where a turn can still take effect, and how far away it is.
    Google Snake applies turns at cell centres; the eyes sit ~0.2 cell ahead of the head's centre."""
    dx, dy = DIRS[heading]
    hx, hy = eye[0] - 0.2 * dx, eye[1] - 0.2 * dy
    along, perp = (hx, hy) if dx else (hy, hx)
    sign = dx or dy
    import math

    if sign > 0:
        k = math.floor(along - 0.5) + 1
        dist = k + 0.5 - along
    else:
        k = math.ceil(along - 0.5) - 1
        dist = along - (k + 0.5)
    if dist < LATE:
        k += sign
        dist += 1
    p = min(max(int(perp), 0), (ROWS if dx else COLS) - 1)
    return ((k, p) if dx else (p, k)), dist


def _free(cell: tuple[int, int], body: set[tuple[int, int]]) -> bool:
    c, r = cell
    return 0 <= c < COLS and 0 <= r < ROWS and cell not in body


def _step(cell: tuple[int, int], d: str) -> tuple[int, int]:
    return cell[0] + DIRS[d][0], cell[1] + DIRS[d][1]


def _bfs(start: tuple[int, int], goal: tuple[int, int], body: set[tuple[int, int]]) -> list[str] | None:
    prev: dict[tuple[int, int], tuple[tuple[int, int], str] | None] = {start: None}
    q = deque([start])
    while q:
        cur = q.popleft()
        if cur == goal:
            path = []
            while prev[cur] is not None:
                cur, d = prev[cur]  # type: ignore[misc]
                path.append(d)
            return path[::-1]
        for d in DIRS:
            nxt = _step(cur, d)
            if nxt not in prev and _free(nxt, body):
                prev[nxt] = (cur, d)
                q.append(nxt)
    return None


def _area(start: tuple[int, int], body: set[tuple[int, int]]) -> int:
    seen, q = {start}, deque([start])
    while q:
        cur = q.popleft()
        for d in DIRS:
            nxt = _step(cur, d)
            if nxt not in seen and _free(nxt, body):
                seen.add(nxt)
                q.append(nxt)
    return len(seen)


def choose(head: tuple[int, int], heading: str, body: set[tuple[int, int]],
           apple: tuple[int, int] | None, tail: tuple[int, int] | None = None) -> str:
    """Next direction: shortest path to the apple if the tail stays reachable
    afterwards (the classic "never trap yourself" rule), otherwise chase the
    tail, otherwise the move with the most free space."""
    moves = [d for d in DIRS if d != OPPOSITE.get(heading) and _free(_step(head, d), body)]
    if not moves:
        return heading
    room = {d: _area(_step(head, d), body | {head}) for d in moves}
    open_body = body - {tail} if tail else body

    def tail_ok(frm: tuple[int, int], extra: set[tuple[int, int]]) -> bool:
        return tail is None or _bfs(frm, tail, (open_body | extra) - {frm}) is not None

    if apple is not None:
        path = _bfs(head, apple, body - {head})
        if path and path[0] in moves and room[path[0]] >= min(len(body), 40):
            if len(body) < 8 or tail_ok(apple, {head}):
                return path[0]
    if tail is not None and len(body) >= 8:
        safe = [d for d in moves if tail_ok(_step(head, d), {head})]
        if safe:   # stall by following the tail, taking the roomiest safe move
            return max(safe, key=lambda d: (room[d], d == heading))
    return max(moves, key=lambda d: (room[d], d == heading))


async def play_snake(core: Any, page: Any, mode: str = "refleks", seconds: float = 90,
                     progress: Any = None) -> dict[str, Any]:
    await page.goto(URL, wait_until="domcontentloaded")
    await asyncio.sleep(2.5)
    canvas = await page.evaluate(BOARD_JS)
    # the grid sits inside the canvas with a ~28/650 margin on each side (measured)
    mx, my = canvas["width"] * 28 / 650, canvas["height"] * 28 / 580
    board = {"x": canvas["x"] + mx, "y": canvas["y"] + my,
             "width": canvas["width"] - 2 * mx, "height": canvas["height"] - 2 * my}
    frame = Frame(page)
    await start_game(page)
    heading, last_target, pending, pending_at = "right", None, None, 0.0
    trail: deque[tuple[int, int]] = deque(maxlen=COLS * ROWS)
    prev_eye, still_since, frames, turns = None, time.perf_counter(), 0, 0
    started = time.perf_counter()
    while time.perf_counter() - started < seconds:
        img = await frame.grab(board, 0.5)
        state = parse(img)
        frames += 1
        eye = state["eye"]
        now = time.perf_counter()
        if eye is None:
            if now - still_since > 3:
                break
            continue
        if prev_eye is not None:
            vx, vy = eye[0] - prev_eye[0], eye[1] - prev_eye[1]
            if max(abs(vx), abs(vy)) > 0.05:
                still_since = now
                # observed motion confirms a pending turn / corrects the model
                if max(abs(vx), abs(vy)) > 0.15:
                    seen = ("right" if vx > 0 else "left") if abs(vx) > abs(vy) else ("down" if vy > 0 else "up")
                    if pending is not None and (seen == pending[1] or now - pending_at > 0.3):
                        pending = None
                    if pending is None:
                        heading = seen   # what the snake actually does wins over the model
            elif now - still_since > 1.5:
                break   # the snake stopped: game over
        prev_eye = eye
        if state["head"] is not None and (not trail or trail[-1] != state["head"]):
            trail.append(state["head"])
        if pending is not None:
            cell, want = pending
            dx, dy = DIRS[heading]
            along = (eye[0] - 0.2 * dx) if dx else (eye[1] - 0.2 * dy)
            centre = (cell[0] if dx else cell[1]) + 0.5
            if (along - centre) * (dx or dy) >= -0.1:   # reached the turn cell
                heading, pending = want, None
        target, _ = next_turn_cell(eye, heading)
        if target == last_target or not (0 <= target[0] < COLS and 0 <= target[1] < ROWS):
            continue
        if last_target is not None and pending is None:
            dx, dy = DIRS[heading]
            if (target[0] - last_target[0]) * dx + (target[1] - last_target[1]) * dy < 0:
                continue   # eye jitter while turning: never re-decide a cell we already passed
        last_target = target
        body = state["snake"] - {target}
        n = len(state["snake"])
        tail = trail[-n] if n >= 3 and len(trail) >= n else None
        want = choose(target, heading, body, state["apple"], tail if tail != target else None)
        log.debug("eye=(%.2f,%.2f) heading=%s target=%s want=%s apple=%s len=%d", eye[0], eye[1], heading, target,
                  want, state["apple"], len(state["snake"]))
        if want != heading:
            await page.keyboard.press(KEYS[want])
            pending, pending_at = (target, want), now
            turns += 1
        if progress and frames % 25 == 0:
            await progress(frames, None)
    score = await page.evaluate("""() => { const t = document.body.innerText.match(/\\d+/g); return t ? t.map(Number) : [] }""")
    return {"game": "snake", "mode": "refleks", "seconds": round(time.perf_counter() - started, 1),
            "frames": frames, "fps": round(frames / max(0.1, time.perf_counter() - started), 1),
            "turns": turns, "apples": score[0] if score else None,
            "note": "Yılan her ~130 ms'de bir kare ilerliyor; bu hız ağ gecikmesine izin vermediği için "
                    "yön kararlarını yerel planlayıcı veriyor."}
