"""Activity journal storage: what was in front of the user, and when."""

from __future__ import annotations

import sqlite3
import threading
import time
from dataclasses import dataclass
from pathlib import Path

SCHEMA = """
CREATE TABLE IF NOT EXISTS spans (
    id INTEGER PRIMARY KEY,
    start REAL NOT NULL,
    end REAL NOT NULL,
    app TEXT NOT NULL,
    title TEXT NOT NULL DEFAULT '',
    project TEXT
);
CREATE INDEX IF NOT EXISTS spans_start ON spans(start);
CREATE TABLE IF NOT EXISTS events (
    id INTEGER PRIMARY KEY,
    ts REAL NOT NULL,
    kind TEXT NOT NULL,
    text TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS events_ts ON events(ts);
"""


@dataclass(slots=True)
class Span:
    id: int
    start: float
    end: float
    app: str
    title: str
    project: str | None

    @property
    def seconds(self) -> float:
        return max(0.0, self.end - self.start)


class JournalStore:
    def __init__(self, path: Path) -> None:
        self.path = path
        self._lock = threading.Lock()
        self.db = sqlite3.connect(path, check_same_thread=False)
        self.db.executescript(SCHEMA)
        self.db.commit()

    def open_span(self, start: float, app: str, title: str, project: str | None) -> int:
        with self._lock:
            cur = self.db.execute("INSERT INTO spans(start, end, app, title, project) VALUES (?,?,?,?,?)",
                                  (start, start, app, title, project))
            self.db.commit()
            return int(cur.lastrowid)

    def extend(self, span_id: int, end: float) -> None:
        with self._lock:
            self.db.execute("UPDATE spans SET end = ? WHERE id = ?", (end, span_id))
            self.db.commit()

    def spans(self, since: float, until: float) -> list[Span]:
        with self._lock:
            rows = self.db.execute("SELECT id, start, end, app, title, project FROM spans "
                                   "WHERE end >= ? AND start <= ? ORDER BY start", (since, until)).fetchall()
        return [Span(*r) for r in rows]

    def event(self, kind: str, text: str, ts: float | None = None) -> None:
        with self._lock:
            self.db.execute("INSERT INTO events(ts, kind, text) VALUES (?,?,?)", (ts or time.time(), kind, text[:500]))
            self.db.commit()

    def events(self, since: float, until: float) -> list[tuple[float, str, str]]:
        with self._lock:
            return self.db.execute("SELECT ts, kind, text FROM events WHERE ts BETWEEN ? AND ? ORDER BY ts",
                                   (since, until)).fetchall()

    def prune(self, keep_days: int = 120) -> None:
        cutoff = time.time() - keep_days * 86400
        with self._lock:
            self.db.execute("DELETE FROM spans WHERE end < ?", (cutoff,))
            self.db.execute("DELETE FROM events WHERE ts < ?", (cutoff,))
            self.db.commit()
