"""Turn a day of window spans into a readable work log.

    09:32–10:48  Webioo Growth — VS Code + Chrome + Claude Code
      • ads-landing-profiles.php, hero.tsx
      • git: 2 commits, 3 files changed

Projects come from editor titles; their folders from VS Code/Cursor's
workspace list, so git history and changed files can be attached.
"""

from __future__ import annotations

import json
import os
import re
import subprocess
import urllib.parse
from collections import Counter
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any

from jarvis.journal.store import JournalStore, Span

JOIN_GAP = 15 * 60       # a project block survives this long without its editor in front
SIDE_MAX = 10 * 60       # short detours (browser, chat) belong to the surrounding block
MIN_BLOCK = 3 * 60
NO_WINDOW = 0x08000000
SKIP_DIRS = {".git", "node_modules", ".venv", "venv", "__pycache__", "dist", "build", ".next", "vendor", ".tmp"}
EDITOR_SUFFIX = re.compile(r"\s+[-–—]\s+(Visual Studio Code|Cursor|Antigravity|Zed)$")
BROWSER_SUFFIX = re.compile(r"\s+[-–—]\s+(Opera|Opera GX|Google Chrome|Microsoft Edge|Mozilla Firefox)$", re.I)


def day_bounds(day: str = "bugün") -> tuple[float, float, str]:
    today = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
    d = day.strip().lower()
    if d in ("", "bugün", "today"):
        start = today
    elif d in ("dün", "yesterday"):
        start = today - timedelta(days=1)
    else:
        try:
            start = datetime.fromisoformat(d)
        except ValueError:
            start = today
    return start.timestamp(), (start + timedelta(days=1)).timestamp(), start.strftime("%Y-%m-%d")


# ---------------------------------------------------------- workspaces

def workspace_folders() -> dict[str, Path]:
    """Project (folder) name → path, from the editors' recent workspaces."""
    out: dict[str, Path] = {}
    appdata = Path(os.environ.get("APPDATA", ""))
    for editor in ("Code", "Cursor", "Antigravity"):
        storage = appdata / editor / "User" / "workspaceStorage"
        if not storage.is_dir():
            continue
        for ws in storage.glob("*/workspace.json"):
            try:
                folder = json.loads(ws.read_text(encoding="utf-8")).get("folder", "")
            except (OSError, ValueError):
                continue
            if not folder.startswith("file:///"):
                continue
            path = Path(urllib.parse.unquote(folder[len("file:///"):]))
            if path.is_dir():
                out.setdefault(path.name.lower(), path)
    return out


def _git(path: Path, *args: str) -> str:
    try:
        r = subprocess.run(["git", "-C", str(path), *args], capture_output=True, text=True, encoding="utf-8",
                           errors="replace", timeout=6, creationflags=NO_WINDOW if os.name == "nt" else 0)
        return r.stdout if r.returncode == 0 else ""
    except (OSError, subprocess.TimeoutExpired):
        return ""


def project_changes(path: Path, since: float, until: float) -> dict[str, Any]:
    """Commits and touched files in a time window."""
    fmt = "%Y-%m-%d %H:%M:%S"
    commits = [c for c in _git(path, "log", f"--since={datetime.fromtimestamp(since):{fmt}}",
                               f"--until={datetime.fromtimestamp(until):{fmt}}", "--pretty=%s").splitlines() if c]
    touched: list[tuple[float, str]] = []
    for root, dirs, files in os.walk(path):
        dirs[:] = [d for d in dirs if d not in SKIP_DIRS and not d.startswith(".")]
        for f in files:
            p = Path(root, f)
            try:
                m = p.stat().st_mtime
            except OSError:
                continue
            if since <= m <= until:
                touched.append((m, str(p.relative_to(path)).replace("\\", "/")))
        if len(touched) > 200:
            break
    touched.sort(reverse=True)
    return {"commits": commits[:10], "files": [f for _, f in touched[:12]], "files_total": len(touched)}


# ---------------------------------------------------------------- blocks

def _label(span: Span) -> str:
    title = EDITOR_SUFFIX.sub("", BROWSER_SUFFIX.sub("", span.title)).strip()
    return title[:90]


def _file_of(span: Span) -> str | None:
    if span.project and span.app in ("VS Code", "Cursor", "Antigravity"):
        first = re.split(r"\s+[-–—]\s+", span.title)[0].lstrip("●○* ").strip()
        if re.search(r"\.[a-z0-9]{1,6}$", first, re.I):
            return first
    return None


def build_blocks(spans: list[Span]) -> list[dict[str, Any]]:
    blocks: list[dict[str, Any]] = []
    cur: dict[str, Any] | None = None
    for s in spans:
        if s.seconds < 5:
            continue
        key = s.project
        joinable = cur is not None and s.start - cur["end"] < JOIN_GAP
        if key:
            if joinable and cur["project"] == key:
                pass
            elif joinable and cur["project"] is None and cur["end"] - cur["start"] < SIDE_MAX:
                cur["project"] = key   # the short lead-in belonged to this project
            else:
                cur = _new_block(blocks, s, key)
        elif joinable and cur["project"] and s.seconds < SIDE_MAX:
            pass   # a short detour (browser, chat, terminal) inside the project's block
        elif not (joinable and cur["project"] is None):
            cur = _new_block(blocks, s, None)
        assert cur is not None
        cur["end"] = max(cur["end"], s.end)
        cur["apps"][s.app] += s.seconds
        label = _label(s)
        if label:
            cur["titles"][label] += s.seconds
        f = _file_of(s)
        if f:
            cur["files"][f] += s.seconds
    out = []
    for b in blocks:
        if b["end"] - b["start"] < MIN_BLOCK:
            continue
        out.append({
            "start": datetime.fromtimestamp(b["start"]).strftime("%H:%M"),
            "end": datetime.fromtimestamp(b["end"]).strftime("%H:%M"),
            "minutes": round((b["end"] - b["start"]) / 60),
            "project": b["project"],
            "apps": [a for a, _ in b["apps"].most_common(4)],
            "titles": [t for t, _ in b["titles"].most_common(6)],
            "files": [f for f, _ in b["files"].most_common(8)],
            "_start": b["start"], "_end": b["end"],
        })
    return out


def _new_block(blocks: list[dict[str, Any]], s: Span, project: str | None) -> dict[str, Any]:
    b = {"start": s.start, "end": s.end, "project": project, "apps": Counter(), "titles": Counter(),
         "files": Counter()}
    blocks.append(b)
    return b


def summarize_day(store: JournalStore, day: str = "bugün", with_git: bool = True) -> dict[str, Any]:
    since, until, label = day_bounds(day)
    blocks = build_blocks(store.spans(since, until))
    folders = workspace_folders() if with_git else {}
    for b in blocks:
        path = folders.get((b["project"] or "").lower())
        if path is not None:
            b["path"] = str(path)
            b["git"] = project_changes(path, b["_start"] - 300, b["_end"] + 300)
    events = store.events(since, until)
    for b in blocks:
        b["jarvis"] = [text for ts, _, text in events if b["_start"] - 120 <= ts <= b["_end"] + 120][:6]
        b.pop("_start")
        b.pop("_end")
    total = sum(b["minutes"] for b in blocks)
    projects = Counter()
    for b in blocks:
        if b["project"]:
            projects[b["project"]] += b["minutes"]
    return {"day": label, "active_minutes": total, "projects": dict(projects.most_common()), "blocks": blocks}
