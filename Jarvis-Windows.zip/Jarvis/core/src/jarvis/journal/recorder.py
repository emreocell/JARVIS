"""Records the foreground window into the journal (one cheap read every 30 s).

Away time (no input for 10 min) is not counted; privacy mode and excluded
apps are respected (the tracker already masks their titles).
"""

from __future__ import annotations

import asyncio
import logging
import time
from typing import Any

from jarvis.context.tracker import project_of
from jarvis.tools.titles import title_of

log = logging.getLogger(__name__)

POLL = 30.0
# Jarvis actions worth remembering in the day's story
NOTABLE_TOOLS = {"send_to_ai_tool", "ask_web_ai", "send_whatsapp", "gmail_send", "gmail_draft", "calendar_add_event",
                 "take_note", "set_reminder", "browser_task", "desktop_task", "play_browser_game", "open_app",
                 "replace_selection", "save_to_second_brain"}


class ActivityRecorder:
    def __init__(self, core: Any, store: Any) -> None:
        self.core = core
        self.store = store
        self._span: tuple[int, str, str] | None = None   # (id, app, title)
        self._task: asyncio.Task[None] | None = None
        core.bus.subscribe("tool.finished", self._on_tool)

    def start(self) -> None:
        if self._task is None:
            self._task = asyncio.create_task(self._run(), name="journal")

    def stop(self) -> None:
        if self._task:
            self._task.cancel()
            self._task = None

    def _on_tool(self, event: Any) -> None:
        name = str(event.data.get("tool", ""))
        if name in NOTABLE_TOOLS and event.data.get("ok"):
            text = f"{title_of(name)}: {str(event.data.get('result') or '')[:200]}"
            try:
                self.store.event("jarvis", text)
            except Exception:
                log.debug("journal event failed", exc_info=True)

    async def _run(self) -> None:
        try:
            self.store.prune()
        except Exception:
            pass
        while True:
            try:
                self.tick()
            except Exception:
                log.debug("journal tick failed", exc_info=True)
            await asyncio.sleep(POLL)

    def tick(self) -> None:
        now = time.time()
        cfg = self.core.config
        ctx = self.core.context
        presence = getattr(self.core, "presence", None)
        if cfg.privacy.privacy_mode or ctx is None or (presence is not None and presence.away):
            self._span = None
            return
        focus = ctx.current()
        if focus is None or focus.app in ("Jarvis", "?") or focus.exe.lower() in ("python.exe", "pythonw.exe"):
            if self._span:
                self.store.extend(self._span[0], now)
            return
        title = focus.title if focus.title != "(gizli)" else ""
        if self._span and self._span[1:] == (focus.app, title):
            self.store.extend(self._span[0], now)
            return
        if self._span:
            self.store.extend(self._span[0], now)
        span_id = self.store.open_span(now, focus.app, title, project_of(focus))
        self._span = (span_id, focus.app, title)
