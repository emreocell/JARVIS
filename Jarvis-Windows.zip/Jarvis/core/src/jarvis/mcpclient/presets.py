"""Ready-made MCP servers the user can switch on from Settings → Bağlantılar.

Servers run through ``uvx`` (shipped in Jarvis' own venv), so nothing has to
be installed by hand: the first start downloads the server once.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass(frozen=True, slots=True)
class Preset:
    id: str
    name: str
    description: str
    args: tuple[str, ...]
    env: dict[str, str] = field(default_factory=dict)
    # user-provided settings: key -> (label, env var, secret?)
    fields: tuple[tuple[str, str, str, bool], ...] = ()
    category: str = "mcp"


PRESETS: dict[str, Preset] = {
    "windows": Preset(
        id="windows",
        name="Windows-MCP",
        description="Uygulamaları ekran okuyucu ağacıyla görür ve kullanır: tıklama, yazma, kaydırma, "
                    "kısayollar, pencereler, pano, bildirimler.",
        # PowerShell / Registry / FileSystem / Process stay off: Jarvis has safer tools of its own
        args=("--python", "3.13", "windows-mcp", "serve", "--exclude-tools",
              "PowerShell,Registry,FileSystem,Process"),
        env={"ANONYMIZED_TELEMETRY": "false", "WINDOWS_MCP_SCREENSHOT_SCALE": "0.5"},
        category="desktop",
    ),
    "google": Preset(
        id="google",
        name="Gmail API + Takvim API (gelişmiş)",
        description="İsteğe bağlı: Google'ın resmi API'leriyle daha hızlı ve arka planda çalışır. Kendi Google "
                    "Cloud OAuth istemcini gerektirir (ücretsiz). Çoğu kişi için yukarıdaki giriş yeterli.",
        args=("workspace-mcp", "--single-user", "--tools", "gmail", "calendar", "--tool-tier", "extended"),
        env={"OAUTHLIB_INSECURE_TRANSPORT": "1", "WORKSPACE_MCP_PORT": "8766"},
        fields=(
            ("client_id", "OAuth Client ID", "GOOGLE_OAUTH_CLIENT_ID", False),
            ("client_secret", "OAuth Client Secret", "GOOGLE_OAUTH_CLIENT_SECRET", True),
            ("email", "Gmail adresin", "USER_GOOGLE_EMAIL", False),
        ),
        category="mail",
    ),
}


def available_presets() -> dict[str, Preset]:
    """Windows-MCP only makes sense on Windows."""
    import sys

    return {k: v for k, v in PRESETS.items() if k != "windows" or sys.platform == "win32"}


def server_config(preset: Preset, env: dict[str, str]) -> dict[str, Any]:
    return {"id": preset.id, "name": preset.name, "preset": preset.id, "command": "uvx",
            "args": list(preset.args), "env": {**preset.env, **env}, "enabled": True}
