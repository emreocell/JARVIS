"""In-process async event bus.

Topics are dotted strings (``config.changed``, ``voice.state``). Subscribers
may use a trailing ``*`` wildcard (``voice.*``) or ``*`` for everything.
Handlers may be sync or async; a failing handler never breaks the publisher.
"""

from __future__ import annotations

import asyncio
import inspect
import logging
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from typing import Any

log = logging.getLogger(__name__)

Handler = Callable[["Event"], Awaitable[None] | None]


@dataclass(frozen=True, slots=True)
class Event:
    topic: str
    data: dict[str, Any] = field(default_factory=dict)


def _matches(pattern: str, topic: str) -> bool:
    if pattern == "*" or pattern == topic:
        return True
    return pattern.endswith(".*") and topic.startswith(pattern[:-1])


class EventBus:
    def __init__(self) -> None:
        self._subs: list[tuple[str, Handler]] = []
        self._loop: asyncio.AbstractEventLoop | None = None
        self._tasks: set[asyncio.Task[None]] = set()

    def bind_loop(self, loop: asyncio.AbstractEventLoop) -> None:
        self._loop = loop

    def subscribe(self, pattern: str, handler: Handler) -> Callable[[], None]:
        entry = (pattern, handler)
        self._subs.append(entry)

        def unsubscribe() -> None:
            if entry in self._subs:
                self._subs.remove(entry)

        return unsubscribe

    async def publish(self, topic: str, **data: Any) -> None:
        """Deliver to all matching handlers and wait for async ones."""
        event = Event(topic, data)
        for pattern, handler in list(self._subs):
            if not _matches(pattern, topic):
                continue
            try:
                result = handler(event)
                if inspect.isawaitable(result):
                    await result
            except Exception:
                log.exception("event handler failed for %s", topic)

    def emit(self, topic: str, **data: Any) -> None:
        """Fire-and-forget publish from inside the event loop."""
        task = asyncio.get_running_loop().create_task(self.publish(topic, **data))
        self._tasks.add(task)
        task.add_done_callback(self._tasks.discard)

    def emit_threadsafe(self, topic: str, **data: Any) -> None:
        """Publish from a worker thread (UIA hooks, audio callbacks, ...)."""
        if self._loop is None:
            raise RuntimeError("EventBus.bind_loop() was not called")
        self._loop.call_soon_threadsafe(lambda: self.emit(topic, **data))
