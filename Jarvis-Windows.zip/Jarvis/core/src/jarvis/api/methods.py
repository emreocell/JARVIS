"""RPC methods exposed to the UI."""

from __future__ import annotations

import asyncio
from typing import TYPE_CHECKING, Any

from jarvis.api.server import RpcError
from jarvis.config.schema import AppConfig, Role
from jarvis.providers import NoRouteAvailable

if TYPE_CHECKING:
    from jarvis.core import Core


def register_methods(core: Core) -> None:
    api = core.api

    @api.method("app.snapshot")
    async def _snapshot(params: dict[str, Any]) -> Any:
        return await core.snapshot()

    @api.method("app.show")
    async def _show(params: dict[str, Any]) -> Any:
        """A second launch asks the running instance to come forward."""
        await core.bus.publish("app.show")
        return True

    @api.method("app.shutdown")
    async def _shutdown(params: dict[str, Any]) -> Any:
        core.request_stop()
        return True

    # ------------------------------------------------------------ config

    @api.method("config.get")
    async def _config_get(params: dict[str, Any]) -> Any:
        return {"config": core.config.model_dump(mode="json"),
                "schema": AppConfig.model_json_schema()}

    @api.method("config.patch")
    async def _config_patch(params: dict[str, Any]) -> Any:
        patch = params.get("patch")
        if not isinstance(patch, dict):
            raise RpcError("patch must be an object")
        new = await core.config_store.patch(patch)
        return new.model_dump(mode="json")

    # ----------------------------------------------------------- secrets

    @api.method("secrets.list")
    async def _secrets_list(params: dict[str, Any]) -> Any:
        return core.secrets.describe()

    @api.method("secrets.set")
    async def _secrets_set(params: dict[str, Any]) -> Any:
        """Store a key; optionally attach its ref to a provider's pool."""
        name, value = params.get("name"), params.get("value")
        if not isinstance(name, str) or not isinstance(value, str):
            raise RpcError("name and value are required")
        try:
            ref = core.secrets.set(name, value)
        except ValueError as exc:
            raise RpcError(str(exc)) from exc
        provider_id = params.get("provider")
        if provider_id:
            provider = core.config.provider(provider_id)
            if provider is None:
                raise RpcError(f"unknown provider: {provider_id}")
            if ref not in provider.keys:
                providers = core.config.model_dump(mode="json")["providers"]
                for p in providers:
                    if p["id"] == provider_id:
                        p["keys"].append(ref)
                await core.config_store.patch({"providers": providers})
        else:
            core.providers.load(core.config)
        await core.bus.publish("secrets.changed", secrets=core.secrets.describe())
        return {"ref": ref}

    @api.method("secrets.delete")
    async def _secrets_delete(params: dict[str, Any]) -> Any:
        name = params.get("name")
        if not isinstance(name, str):
            raise RpcError("name is required")
        core.secrets.delete(name)
        ref = f"keyring:{name}"
        providers = core.config.model_dump(mode="json")["providers"]
        if any(ref in p["keys"] for p in providers):
            for p in providers:
                p["keys"] = [k for k in p["keys"] if k != ref]
            await core.config_store.patch({"providers": providers})
        await core.bus.publish("secrets.changed", secrets=core.secrets.describe())
        return True

    @api.method("migrate.legacy_status")
    async def _legacy_status(params: dict[str, Any]) -> Any:
        from jarvis.migrate import find_legacy_config, plan_import

        path = find_legacy_config()
        if path is None:
            return {"found": False}
        keys = plan_import(path)
        return {"found": True, "path": str(path),
                "providers": sorted({p for p, _ in keys}), "count": len(keys)}

    @api.method("migrate.import_legacy_keys")
    async def _import_legacy(params: dict[str, Any]) -> Any:
        """Explicit, user-triggered import of API keys from the old JARVIS."""
        from jarvis.migrate import extra_provider, find_legacy_config, plan_import

        path = find_legacy_config()
        if path is None:
            raise RpcError("Eski Jarvis yapılandırması bulunamadı")
        existing = {core.secrets.get(n) for n in core.secrets.names()}
        providers = core.config.model_dump(mode="json")["providers"]
        by_id = {p["id"]: p for p in providers}
        imported: list[str] = []
        for provider_id, key in plan_import(path):
            if key in existing:
                continue
            if provider_id not in by_id:
                extra = extra_provider(provider_id)
                if extra is None:
                    continue
                by_id[provider_id] = {**extra, "keys": [], "models": [], "headers": {}, "quota_profile": None}
                providers.append(by_id[provider_id])
            n = 1
            names = set(core.secrets.names())
            while f"{provider_id}_{n}" in names:
                n += 1
            ref = core.secrets.set(f"{provider_id}_{n}", key)
            by_id[provider_id]["keys"].append(ref)
            if provider_id == "groq":
                by_id[provider_id]["enabled"] = True
            imported.append(f"{provider_id}_{n}")
            existing.add(key)
        if imported:
            await core.config_store.patch({"providers": providers})
        await core.bus.publish("secrets.changed", secrets=core.secrets.describe())
        return {"imported": imported}

    # --------------------------------------------------------- providers

    @api.method("providers.test")
    async def _providers_test(params: dict[str, Any]) -> Any:
        provider_id = params.get("provider")
        if not isinstance(provider_id, str):
            raise RpcError("provider is required")
        return await core.providers.test_provider(provider_id)

    @api.method("providers.quota")
    async def _providers_quota(params: dict[str, Any]) -> Any:
        return core.providers.quota_snapshot()

    @api.method("providers.stats")
    async def _providers_stats(params: dict[str, Any]) -> Any:
        return core.providers.stats()

    # -------------------------------------------------------------- home

    @api.method("home.summary")
    async def _home_summary(params: dict[str, Any]) -> Any:
        """Everything the home screen needs in one call (all local, no API usage)."""
        import time as _time

        store = core.memory.store
        episodes = store._db.execute(
            "SELECT session, ended, summary FROM episodes ORDER BY ended DESC LIMIT 5").fetchall()
        reminders = [r.as_dict() for r in core.routines.store.pending()[:3]]
        focus = core.context.summary(120) if core.context else {}
        now_playing = None
        try:
            from jarvis.skills.system import now_playing as np_tool

            np_res = await asyncio.wait_for(np_tool.__tool__.handler(), 1.5)  # type: ignore[attr-defined]
            if np_res.get("title"):
                now_playing = {k: np_res.get(k) for k in ("title", "artist", "app", "playing")}
        except Exception:
            pass
        hour = _time.localtime().tm_hour
        greeting = ("İyi geceler" if hour < 5 else "Günaydın" if hour < 12 else "İyi günler" if hour < 18
                    else "İyi akşamlar")
        return {
            "greeting": greeting,
            "user_name": core.config.assistant.user_name,
            "episodes": [{"id": e["session"], "ended": e["ended"], "summary": e["summary"]} for e in episodes],
            "reminders": reminders,
            "projects": focus.get("projects", []) if focus else [],
            "active": focus.get("active") if focus else None,
            "now_playing": now_playing,
            "memory_count": store.count(),
            "recent_facts": [f.content for f in store.list(limit=3)],
        }

    # ----------------------------------------------------------- history

    @api.method("history.sessions")
    async def _history_sessions(params: dict[str, Any]) -> Any:
        rows = core.memory.store.sessions(limit=min(int(params.get("limit", 30)), 200),
                                          offset=int(params.get("offset", 0)),
                                          query=str(params.get("query") or ""))
        return [{**r, "current": r["session"] == core.memory.session} for r in rows]

    @api.method("history.session")
    async def _history_session(params: dict[str, Any]) -> Any:
        session = str(params.get("session") or "")
        if not session:
            raise RpcError("session is required")
        store = core.memory.store
        episode = store._db.execute("SELECT summary FROM episodes WHERE session=?", (session,)).fetchone()
        return {"session": session, "messages": store.session_messages(session),
                "summary": episode["summary"] if episode else None,
                "current": session == core.memory.session}

    @api.method("history.delete")
    async def _history_delete(params: dict[str, Any]) -> Any:
        session = str(params.get("session") or "")
        if not session:
            raise RpcError("session is required")
        if session == core.memory.session:
            core.memory.discard_session()  # never extract facts from a deleted conversation
        deleted = core.memory.store.delete_session(session)
        await core.bus.publish("history.changed", removed=session)
        return {"deleted": deleted}

    # ------------------------------------------------------------ memory

    def _fact_id(params: dict[str, Any]) -> int:
        try:
            return int(params["id"])
        except (KeyError, TypeError, ValueError) as exc:
            raise RpcError("id is required") from exc

    @api.method("memory.list")
    async def _memory_list(params: dict[str, Any]) -> Any:
        query = params.get("query")
        store = core.memory.store
        facts = store.search(query, k=50, strict=False) if query else store.list(params.get("category"))
        return {"facts": [f.as_dict() for f in facts], "stats": core.memory.stats(),
                "last_episode": store.last_episode()}

    @api.method("memory.add")
    async def _memory_add(params: dict[str, Any]) -> Any:
        content = params.get("content")
        if not isinstance(content, str) or not content.strip():
            raise RpcError("content is required")
        fid, created = core.memory.store.add(content, params.get("category", "general"), source="user",
                                             confidence=1.0)
        await core.bus.publish("memory.changed", added=[fid])
        asyncio.create_task(core.memory.embed_missing())
        return {"id": fid, "created": created}

    @api.method("memory.update")
    async def _memory_update(params: dict[str, Any]) -> Any:
        content = params.get("content")
        if not isinstance(content, str) or not content.strip():
            raise RpcError("content is required")
        new_id = core.memory.store.update(_fact_id(params), content)
        await core.bus.publish("memory.changed", added=[new_id])
        asyncio.create_task(core.memory.embed_missing())
        return {"id": new_id}

    @api.method("memory.forget")
    async def _memory_forget(params: dict[str, Any]) -> Any:
        ok = core.memory.store.forget(_fact_id(params))
        await core.bus.publish("memory.changed", removed=[params.get("id")])
        return ok

    @api.method("memory.pin")
    async def _memory_pin(params: dict[str, Any]) -> Any:
        core.memory.store.set_pinned(_fact_id(params), bool(params.get("pinned", True)))
        await core.bus.publish("memory.changed")
        return True

    @api.method("memory.history")
    async def _memory_history(params: dict[str, Any]) -> Any:
        return core.memory.store.history(int(params.get("limit", 50)))

    @api.method("memory.end_session")
    async def _memory_end_session(params: dict[str, Any]) -> Any:
        await core.memory.end_session()
        return True

    # ----------------------------------------------------------- spotify

    @api.method("spotify.status")
    async def _spotify_status(params: dict[str, Any]) -> Any:
        return {"client_id": bool(core.spotify.client_id), "linked": core.spotify.linked,
                "product": core.spotify.product}

    @api.method("spotify.connect")
    async def _spotify_connect(params: dict[str, Any]) -> Any:
        import os

        from jarvis.integrations.spotify import SpotifyError

        async def flow() -> None:
            try:
                product = await core.spotify.authorize(os.startfile)
                await core.bus.publish("spotify.linked", product=product)
            except (SpotifyError, TimeoutError) as exc:
                await core.bus.publish("spotify.linked", error=str(exc) or "zaman aşımı")

        if not core.spotify.client_id:
            raise RpcError("Önce Spotify Client ID gir.")
        asyncio.create_task(flow())
        return {"redirect_uri": "http://127.0.0.1:8765/callback"}

    @api.method("spotify.unlink")
    async def _spotify_unlink(params: dict[str, Any]) -> Any:
        core.spotify.unlink()
        return True

    # ------------------------------------------------- per-app mini commands

    @api.method("context.actions")
    async def _context_actions(params: dict[str, Any]) -> Any:
        """Suggestions for the app that was in front when the command bar opened."""
        import time as _time

        from jarvis.app_actions import actions_for
        from jarvis.skills import this

        snap = this.SNAPSHOT if _time.time() - this.SNAPSHOT.get("at", 0) < 30 else {}
        exe = snap.get("exe", "")
        if not exe or exe.lower() in ("python.exe", "pythonw.exe"):
            focus = core.context.current() if core.context else None
            exe, title = (focus.exe, focus.title) if focus else ("", "")
        else:
            title = snap.get("title", "")
        return actions_for(exe, title)

    # ----------------------------------------------------------- missions

    @api.method("mission.list")
    async def _mission_list(params: dict[str, Any]) -> Any:
        return core.missions.list()

    @api.method("mission.start")
    async def _mission_start(params: dict[str, Any]) -> Any:
        goal = str(params.get("goal") or "").strip()
        if not goal:
            raise RpcError("Hedef boş")
        return (await core.missions.start(goal)).as_dict()

    @api.method("mission.cancel")
    async def _mission_cancel(params: dict[str, Any]) -> Any:
        return await core.missions.cancel(int(params.get("id") or 0))

    # ------------------------------------------------------------ meeting

    @api.method("meeting.start")
    async def _meeting_start(params: dict[str, Any]) -> Any:
        m = await core.meeting.start(str(params.get("title") or ""))
        return {"id": m.id, "title": m.title, "start": m.start}

    @api.method("meeting.stop")
    async def _meeting_stop(params: dict[str, Any]) -> Any:
        return await core.meeting.stop()

    @api.method("meeting.status")
    async def _meeting_status(params: dict[str, Any]) -> Any:
        m = core.meeting.current
        return {"active": m is not None, **({"id": m.id, "title": m.title, "start": m.start, "segments": m.segments,
                                              "last": m.last_text, "sources": m.sources} if m else {}),
                "recent": [{k: v for k, v in x.items() if k != "summary"} | {
                    "decisions": len((x["summary"] or {}).get("decisions", [])),
                    "actions": len((x["summary"] or {}).get("action_items", []))}
                    for x in core.meeting.store.meetings(5)]}

    # ------------------------------------------------------------ journal

    @api.method("journal.day")
    async def _journal_day(params: dict[str, Any]) -> Any:
        from jarvis.journal.day import summarize_day

        return await asyncio.to_thread(summarize_day, core.journal, str(params.get("day") or "bugün"))

    # ------------------------------------------------------ morning brief

    @api.method("brief.run")
    async def _brief_run(params: dict[str, Any]) -> Any:
        from jarvis.proactive.morning import _compact

        data = await core.morning.deliver("manual")
        return _compact(data)

    @api.method("brief.last")
    async def _brief_last(params: dict[str, Any]) -> Any:
        from jarvis.proactive.morning import _compact

        last = core.morning.last
        return {"at": last.get("at"), "data": _compact(last["data"])} if last else None

    # ------------------------------------------------- google (web session)

    @api.method("google.status")
    async def _google_status(params: dict[str, Any]) -> Any:
        from jarvis.skills import google_web

        return await google_web.status(core)

    @api.method("google.sign_in")
    async def _google_sign_in(params: dict[str, Any]) -> Any:
        from types import SimpleNamespace

        from jarvis.skills import google_web

        try:
            return await google_web.google_sign_in.__tool__.handler(SimpleNamespace(core=core))  # type: ignore[attr-defined]
        except Exception as exc:
            raise RpcError(f"Tarayıcı açılamadı: {exc}") from None

    # --------------------------------------------------------------- mcp

    @api.method("mcp.status")
    async def _mcp_status(params: dict[str, Any]) -> Any:
        from jarvis.mcpclient.presets import available_presets

        PRESETS = available_presets()
        configured = {s.id: s for s in core.config.mcp.servers}
        running = {s["id"]: s for s in core.mcp.status()}
        presets = [{"id": p.id, "name": p.name, "description": p.description,
                    "fields": [{"key": k, "label": label, "secret": secret,
                                "set": bool(configured.get(p.id) and configured[p.id].env.get(env))}
                               for k, label, env, secret in p.fields]} for p in PRESETS.values()]
        servers = []
        for cfg in core.config.mcp.servers:
            row = running.get(cfg.id) or {"id": cfg.id, "name": cfg.name, "preset": cfg.preset,
                                          "enabled": cfg.enabled, "state": "off", "error": "",
                                          "tools": [], "tool_count": 0}
            row["email"] = cfg.env.get("USER_GOOGLE_EMAIL", "")
            servers.append(row)
        return {"presets": presets, "servers": servers}

    @api.method("mcp.enable")
    async def _mcp_enable(params: dict[str, Any]) -> Any:
        from jarvis.mcpclient.presets import PRESETS, server_config

        preset = PRESETS.get(str(params.get("preset")))
        if preset is None:
            raise RpcError("Bilinmeyen bağlantı")
        values = params.get("fields") or {}
        existing = next((s for s in core.config.mcp.servers if s.id == preset.id), None)
        env: dict[str, str] = {}
        for key, label, var, secret in preset.fields:
            value = str(values.get(key) or "").strip()
            if not value:
                if existing and existing.env.get(var):
                    env[var] = existing.env[var]
                    continue
                raise RpcError(f"{label} gerekli")
            env[var] = core.secrets.set(f"mcp_{preset.id}_{key}", value) if secret else value
        cfg = server_config(preset, env)
        servers = [s.model_dump() for s in core.config.mcp.servers if s.id != preset.id] + [cfg]
        await core.config_store.patch({"mcp": {"servers": servers}})
        return True

    @api.method("mcp.set_enabled")
    async def _mcp_set_enabled(params: dict[str, Any]) -> Any:
        sid, on = params.get("id"), bool(params.get("enabled"))
        servers = [{**s.model_dump(), "enabled": on} if s.id == sid else s.model_dump()
                   for s in core.config.mcp.servers]
        await core.config_store.patch({"mcp": {"servers": servers}})
        return True

    @api.method("mcp.remove")
    async def _mcp_remove(params: dict[str, Any]) -> Any:
        sid = params.get("id")
        servers = [s.model_dump() for s in core.config.mcp.servers if s.id != sid]
        await core.config_store.patch({"mcp": {"servers": servers}})
        for name in core.secrets.names():
            if name.startswith(f"mcp_{sid}_"):
                core.secrets.delete(name)
        return True

    @api.method("mcp.test")
    async def _mcp_test(params: dict[str, Any]) -> Any:
        """Start the server and make one harmless call. For Google this opens the
        sign-in page in the browser the first time."""
        sid = str(params.get("id"))
        server = core.mcp.servers.get(sid)
        if server is None:
            raise RpcError("Bağlantı açık değil")
        probe = {"windows": ("DisplayInventory", {}),
                 "google": ("search_gmail_messages", {"query": "in:inbox", "page_size": 1})}.get(server.cfg.preset)
        try:
            await server.ensure()
            if probe is None:
                return {"ok": True, "message": f"{len(server.tools)} araç hazır."}
            result = await server.call(*probe)
        except Exception as exc:
            return {"ok": False, "message": f"Başlatılamadı: {exc}"}
        text = str(result.get("error") or result.get("output") or "")
        if "ACTION REQUIRED" in text or "Authentication" in text or "authorization" in text.lower():
            return {"ok": False, "auth": True,
                    "message": "Tarayıcında Google giriş sayfası açıldı. İzin verdikten sonra tekrar dene."}
        if "error" in result:
            return {"ok": False, "message": text[:300]}
        return {"ok": True, "message": f"Bağlantı çalışıyor · {len(server.tools)} araç."}

    @api.method("mcp.refresh")
    async def _mcp_refresh(params: dict[str, Any]) -> Any:
        try:
            return await core.mcp.refresh(str(params.get("id")))
        except KeyError:
            raise RpcError("Bağlantı açık değil") from None
        except Exception as exc:
            raise RpcError(f"Başlatılamadı: {exc}") from None

    # ------------------------------------------------------------ remote

    @api.method("remote.status")
    async def _remote_status(params: dict[str, Any]) -> Any:
        return core.remote.status()

    @api.method("remote.set_token")
    async def _remote_set_token(params: dict[str, Any]) -> Any:
        from jarvis.remote.telegram import TOKEN_SECRET

        token = params.get("token")
        if not isinstance(token, str) or ":" not in token:
            raise RpcError("Geçerli bir bot token'ı gir (BotFather'dan, 123456:ABC… biçiminde)")
        core.secrets.set(TOKEN_SECRET, token)
        await core.remote.stop()
        if not core.config.features.telegram_remote:
            await core.config_store.patch({"features": {"telegram_remote": True}})
        else:
            await core.remote.sync()
        return core.remote.status()

    @api.method("remote.unpair")
    async def _remote_unpair(params: dict[str, Any]) -> Any:
        uid = params.get("user_id")
        ids = [i for i in core.config.remote.telegram_allowed_ids if i != uid]
        await core.config_store.patch({"remote": {"telegram_allowed_ids": ids}})
        return core.remote.status()

    # ---------------------------------------------------------- routines

    @api.method("routines.list")
    async def _routines_list(params: dict[str, Any]) -> Any:
        store = core.routines.store
        return {"reminders": [r.as_dict() for r in store.pending()],
                "rules": [r.as_dict() for r in store.rules()]}

    @api.method("routines.add_reminder")
    async def _routines_add(params: dict[str, Any]) -> Any:
        from jarvis.skills.routines import parse_when

        text = params.get("text")
        if not isinstance(text, str) or not text.strip():
            raise RpcError("text is required")
        try:
            due = parse_when(params.get("at"), params.get("in_minutes"))
        except ValueError as exc:
            raise RpcError(f"Geçersiz zaman: {exc}") from exc
        kind = "alarm" if params.get("kind") == "alarm" else "reminder"
        rem = core.routines.store.add_reminder(text, due, kind, params.get("repeat", "none"))
        core.routines.changed()
        await core.bus.publish("routine.changed")
        return rem.as_dict()

    @api.method("routines.cancel")
    async def _routines_cancel(params: dict[str, Any]) -> Any:
        ok = core.routines.store.cancel(_fact_id(params))
        core.routines.changed()
        await core.bus.publish("routine.changed")
        return ok

    @api.method("routines.save_rule")
    async def _routines_save_rule(params: dict[str, Any]) -> Any:
        from jarvis.routines.store import Rule

        data = params.get("rule")
        if not isinstance(data, dict):
            raise RpcError("rule is required")
        try:
            rule = Rule(**{"id": 0, **data})
        except TypeError as exc:
            raise RpcError(f"geçersiz kural: {exc}") from exc
        if rule.mode not in ("auto", "ask", "notify"):
            raise RpcError("mode auto/ask/notify olmalı")
        saved = core.routines.store.save_rule(rule)
        core.routines.changed()
        await core.bus.publish("routine.changed")
        return saved.as_dict()

    @api.method("routines.delete_rule")
    async def _routines_delete_rule(params: dict[str, Any]) -> Any:
        ok = core.routines.store.delete_rule(_fact_id(params))
        core.routines.changed()
        await core.bus.publish("routine.changed")
        return ok

    @api.method("routines.run_rule")
    async def _routines_run_rule(params: dict[str, Any]) -> Any:
        rid = _fact_id(params)
        rule = next((r for r in core.routines.store.rules() if r.id == rid), None)
        if rule is None:
            raise RpcError("kural bulunamadı")
        return await core.routines.run_rule(rule, "elle çalıştırıldı", force=True)

    # ------------------------------------------------------------- tools

    @api.method("tools.list")
    async def _tools_list(params: dict[str, Any]) -> Any:
        return core.tools.describe()

    @api.method("tools.run")
    async def _tools_run(params: dict[str, Any]) -> Any:
        """Run a tool from the UI (command bar). Same gates as voice."""
        name = params.get("name")
        if not isinstance(name, str):
            raise RpcError("name is required")
        return await core.tools.execute(name, params.get("args") or {}, source="ui")

    # ------------------------------------------------------------- notes

    @api.method("notes.list")
    async def _notes_list(params: dict[str, Any]) -> Any:
        return [n.as_dict() for n in core.notes.list(str(params.get("query") or ""), int(params.get("limit", 300)))]

    @api.method("notes.add")
    async def _notes_add(params: dict[str, Any]) -> Any:
        text = str(params.get("text") or "")
        if not text.strip():
            raise RpcError("text is required")
        note = core.notes.add(text)
        await core.bus.publish("notes.changed")
        return note.as_dict()

    @api.method("notes.update")
    async def _notes_update(params: dict[str, Any]) -> Any:
        note = core.notes.update(_fact_id(params), text=params.get("text"), pinned=params.get("pinned"),
                                 done=params.get("done"))
        await core.bus.publish("notes.changed")
        return note.as_dict() if note else None

    @api.method("notes.delete")
    async def _notes_delete(params: dict[str, Any]) -> Any:
        ok = core.notes.delete(_fact_id(params))
        await core.bus.publish("notes.changed")
        return ok

    # ---------------------------------------------------------- launcher

    @api.method("launcher.search")
    async def _launcher_search(params: dict[str, Any]) -> Any:
        from jarvis import launcher
        from jarvis.brain import fast
        from jarvis.skills.apps import INDEX

        q = str(params.get("q") or "")
        cmd = fast.match(q) if core.config.features.fast_commands else None
        apps = INDEX._apps or []  # never block typing on a Start-menu scan (prewarmed at startup)

        def work() -> list[dict[str, Any]]:
            from jarvis.icons import app_icon

            notes = [(n.id, n.text) for n in core.notes.list(q, 3, include_done=False)] if len(q.strip()) >= 2 else []
            results = launcher.search(q, apps, fast.describe(cmd) if cmd else None, notes=notes)
            for r in results:
                if r["kind"] == "app":
                    r["icon"] = app_icon(r["id"][4:])
            return results
        return await asyncio.to_thread(work)

    @api.method("clipboard.peek")
    async def _clipboard_peek(params: dict[str, Any]) -> Any:
        """Text on the clipboard + Windows' change counter, for the command bar's
        "do something with what you just copied" chip. Secrets are never offered."""
        import ctypes
        import re as _re

        from jarvis.skills.desktop import get_clipboard_text

        seq = int(ctypes.windll.user32.GetClipboardSequenceNumber())
        text = (await asyncio.to_thread(get_clipboard_text) or "").strip()
        looks_secret = bool(text) and " " not in text and len(text) < 200 and (
            _re.search(r"(sk-|ghp_|gho_|github_pat_|AIza|xox[bp]-|eyJ)", text)
            or (_re.search(r"\d", text) and _re.search(r"[A-Za-z]", text) and len(text) >= 20))
        if len(text) < 12 or looks_secret:
            return {"seq": seq, "text": None}
        return {"seq": seq, "text": text[:8000]}

    @api.method("launcher.run")
    async def _launcher_run(params: dict[str, Any]) -> Any:
        from jarvis import launcher

        item = str(params.get("id") or "")
        kind, _, value = item.partition(":")
        if kind in ("app", "file", "page"):
            await asyncio.to_thread(launcher.record_use, item)
        if kind == "app":
            from jarvis.skills.apps import _launch_aumid

            await asyncio.to_thread(_launch_aumid, value)
            return {"done": True}
        if kind == "file":
            await asyncio.to_thread(launcher.open_file, value)
            return {"done": True}
        if kind == "web":
            await asyncio.to_thread(launcher.web_search, value)
            return {"done": True}
        if kind == "page":
            await core.bus.publish("ui.navigate", page=value)
            return {"done": True}
        if kind == "note":
            await core.bus.publish("ui.navigate", page="notes")
            return {"done": True}
        if kind == "calc":
            from jarvis.skills.desktop import set_clipboard_text

            await asyncio.to_thread(set_clipboard_text, value)
            return {"done": False, "text": f"{value} panoya kopyalandı."}
        if kind == "fast":
            result = await core.text_agent.run(value)
            return {"done": False, "text": result["text"], "model": result.get("model")}
        raise RpcError(f"bilinmeyen sonuç: {item}")

    @api.method("media.now_playing")
    async def _media_now_playing(params: dict[str, Any]) -> Any:
        from jarvis.skills.system import now_playing_card

        try:
            return await asyncio.wait_for(now_playing_card(), 2.0)
        except Exception:
            return None

    @api.method("approvals.resolve")
    async def _approvals_resolve(params: dict[str, Any]) -> Any:
        token = params.get("token")
        if not isinstance(token, str):
            raise RpcError("token is required")
        return await core.tools.approve_from_ui(token, bool(params.get("allow")), bool(params.get("remember")))

    @api.method("approvals.pending")
    async def _approvals_pending(params: dict[str, Any]) -> Any:
        return [{"token": a.token, "tool": a.tool, "summary": a.summary}
                for a in core.tools.approvals.pending()]

    # ------------------------------------------------------------- voice

    def _voice():
        if core.voice is None:
            raise RpcError("Sesli asistan kapalı (Ayarlar → Ses veya gizlilik modu)")
        return core.voice

    @api.method("voice.ptt")
    async def _voice_ptt(params: dict[str, Any]) -> Any:
        await _voice().push_to_talk(bool(params.get("pressed")))
        return True

    @api.method("voice.wake")
    async def _voice_wake(params: dict[str, Any]) -> Any:
        await _voice().wake()
        return True

    @api.method("voice.meter")
    async def _voice_meter(params: dict[str, Any]) -> Any:
        """Diagnostics: stream microphone levels (voice.level events) for N seconds."""
        _voice().meter(float(params.get("seconds", 10)))
        return True

    @api.method("voice.preview")
    async def _voice_preview(params: dict[str, Any]) -> Any:
        """Play a short sample of a voice: engine 'edge' (cascade voices) or
        'gemini' (the Live voices: Charon, Kore, …)."""
        from jarvis.voice.audio import Speaker
        from jarvis.voice.cascade import Synthesizer

        engine, voice_name = str(params.get("engine") or "edge"), str(params.get("voice") or "")
        name = core.config.assistant.user_name
        text = f"Merhaba{' ' + name if name else ''}, ben {core.config.assistant.name}. Sesim böyle."
        try:
            if engine == "gemini":
                from jarvis.providers.gemini import GeminiAdapter

                resp = await core.providers.route(
                    Role.TTS, lambda a, m, sec: a.speak(m, sec, text, voice_name or core.config.voice.voice_name),
                    est_tokens=100, only=GeminiAdapter)
                pcm = resp.raw["pcm"]
            else:
                pcm = await Synthesizer(voice_name or core.config.voice.tts_voice).pcm(text)
        except NoRouteAvailable as exc:
            raise RpcError(f"Ses örneği için kota/anahtar yok: {exc}") from exc
        except Exception as exc:
            raise RpcError(f"Ses örneği oluşturulamadı: {exc}") from exc
        speaker = core.voice.speaker if core.voice else Speaker(core.config.voice.output_device)
        speaker.write(pcm)
        return {"seconds": round(len(pcm) / 48000, 1)}

    @api.method("voice.inject")
    async def _voice_inject(params: dict[str, Any]) -> Any:
        """Developer test: speak ``text`` (edge TTS) into the pipeline as if the
        user said it, optionally preceded by the English "Hey Jarvis"."""
        import numpy as np

        from jarvis.voice.cascade import Synthesizer

        voice = _voice()
        text = str(params.get("text") or "")
        clips = []
        if params.get("wake", True):
            clips.append(await Synthesizer("en-US-GuyNeural").pcm("Hey Jarvis."))
            clips.append(bytes(24000))  # 0.5 s pause at 24 kHz
        if text:
            clips.append(await Synthesizer(str(params.get("voice") or "tr-TR-EmelNeural")).pcm(text))
        pcm24 = np.frombuffer(b"".join(clips), dtype=np.int16).astype(np.float32)
        pcm16 = np.interp(np.arange(0, len(pcm24), 1.5), np.arange(len(pcm24)), pcm24).astype(np.int16)
        voice.mic.inject(pcm16)
        return {"seconds": round(len(pcm16) / 16000, 1)}

    @api.method("voice.say")
    async def _voice_say(params: dict[str, Any]) -> Any:
        text = params.get("text")
        if not isinstance(text, str) or not text.strip():
            raise RpcError("text is required")
        await _voice().say(text.strip())
        return True

    @api.method("voice.devices")
    async def _voice_devices(params: dict[str, Any]) -> Any:
        from jarvis.voice.audio import list_devices

        return list_devices()

    @api.method("chat.send")
    async def _chat_send(params: dict[str, Any]) -> Any:
        """Typed command handled by the tool-using text agent."""
        text = params.get("text")
        if not isinstance(text, str) or not text.strip():
            raise RpcError("text is required")
        try:
            result = await core.text_agent.run(text.strip())
        except NoRouteAvailable as exc:
            raise RpcError("Kullanılabilir model yok — Sağlayıcılar sayfasından bir Gemini anahtarı ekle. "
                           f"({exc})") from exc
        await core.bus.publish("providers.quota", quota=core.providers.quota_snapshot())
        return result

    @api.method("chat.reset")
    async def _chat_reset(params: dict[str, Any]) -> Any:
        core.text_agent.reset()
        return True

    @api.method("llm.ask")
    async def _llm_ask(params: dict[str, Any]) -> Any:
        prompt = params.get("prompt")
        if not isinstance(prompt, str) or not prompt.strip():
            raise RpcError("prompt is required")
        role = Role(params.get("role", Role.TEXT_WORKER))
        try:
            resp = await core.providers.ask(prompt, system=params.get("system"), role=role)
        except NoRouteAvailable as exc:
            raise RpcError(str(exc)) from exc
        await core.bus.publish("providers.quota", quota=core.providers.quota_snapshot())
        return {"text": resp.text, "provider": resp.provider, "model": resp.model,
                "key": resp.key_id, "latency_ms": resp.latency_ms}
