"""Local WebSocket API between the core and the UI.

Protocol (JSON text frames):

* client → ``{"type": "auth", "token": "..."}`` must be the first frame,
  within ``AUTH_TIMEOUT`` seconds, or the socket is closed with 1008.
* server → ``{"type": "snapshot", "data": {...}}`` right after auth, so a
  reconnecting UI always starts from current state.
* client → ``{"id": 1, "method": "config.get", "params": {}}``
* server → ``{"id": 1, "result": ...}`` or ``{"id": 1, "error": {"message": ...}}``
* server → ``{"type": "event", "topic": "...", "data": {...}}`` for bus events.

Only loopback is bound, and browser origins other than the app's own are
rejected — otherwise any web page could talk to ``ws://127.0.0.1``.
"""

from __future__ import annotations

import asyncio
import hmac
import json
import logging
import re
from collections.abc import Awaitable, Callable
from http import HTTPStatus
from typing import Any

from pydantic import ValidationError
from websockets.asyncio.server import Server, ServerConnection, serve
from websockets.exceptions import ConnectionClosed
from websockets.http11 import Request, Response

from jarvis.bus import Event, EventBus

log = logging.getLogger(__name__)

AUTH_TIMEOUT = 3.0
# "null" is what WebView2 sends for the native shell's file:// page; the token
# (only obtainable through the shell's Python bridge) is what authorizes.
_ALLOWED_ORIGIN = re.compile(
    r"^(null|file://|tauri://localhost|https?://tauri\.localhost|https?://(localhost|127\.0\.0\.1)(:\d+)?)$"
)

Method = Callable[[dict[str, Any]], Awaitable[Any]]
SnapshotFn = Callable[[], Awaitable[dict[str, Any]]]


class RpcError(Exception):
    """Error whose message is safe to show to the user."""


class ApiServer:
    def __init__(self, bus: EventBus, token: str, snapshot: SnapshotFn,
                 host: str = "127.0.0.1", port: int = 0) -> None:
        self.bus = bus
        self.token = token
        self.snapshot = snapshot
        self.host = host
        self.port = port
        self._methods: dict[str, Method] = {}
        self._clients: set[ServerConnection] = set()
        self._server: Server | None = None
        self._unsubscribe = bus.subscribe("*", self._broadcast)

    # ----------------------------------------------------------- registry

    def method(self, name: str) -> Callable[[Method], Method]:
        def register(fn: Method) -> Method:
            self._methods[name] = fn
            return fn
        return register

    def add_method(self, name: str, fn: Method) -> None:
        self._methods[name] = fn

    # ------------------------------------------------------------ serving

    @staticmethod
    def _check_origin(connection: ServerConnection, request: Request) -> Response | None:
        origin = request.headers.get("Origin")
        if origin is None or _ALLOWED_ORIGIN.match(origin):
            return None
        log.warning("rejected websocket origin %s", origin)
        return connection.respond(HTTPStatus.FORBIDDEN, "origin not allowed\n")

    async def start(self) -> int:
        self._server = await serve(
            self._handle, self.host, self.port,
            process_request=self._check_origin,
            max_size=8 * 1024 * 1024,
        )
        sock = next(iter(self._server.sockets))
        self.port = sock.getsockname()[1]
        log.info("api listening on ws://%s:%d", self.host, self.port)
        return self.port

    async def stop(self) -> None:
        self._unsubscribe()
        if self._server:
            self._server.close()
            await self._server.wait_closed()

    async def _authenticate(self, ws: ServerConnection) -> bool:
        try:
            raw = await asyncio.wait_for(ws.recv(), AUTH_TIMEOUT)
            msg = json.loads(raw)
        except (TimeoutError, json.JSONDecodeError, ConnectionClosed):
            return False
        token = msg.get("token") if isinstance(msg, dict) and msg.get("type") == "auth" else None
        return isinstance(token, str) and hmac.compare_digest(token, self.token)

    async def _handle(self, ws: ServerConnection) -> None:
        if not await self._authenticate(ws):
            await ws.close(1008, "unauthorized")
            return
        self._clients.add(ws)
        try:
            await ws.send(json.dumps({"type": "snapshot", "data": await self.snapshot()},
                                     ensure_ascii=False, default=str))
            async for raw in ws:
                asyncio.create_task(self._dispatch(ws, raw))
        except ConnectionClosed:
            pass
        finally:
            self._clients.discard(ws)

    async def _dispatch(self, ws: ServerConnection, raw: str | bytes) -> None:
        req_id = None
        try:
            msg = json.loads(raw)
            req_id = msg.get("id")
            method = self._methods.get(msg.get("method", ""))
            if method is None:
                raise RpcError(f"unknown method: {msg.get('method')}")
            params = msg.get("params") or {}
            if not isinstance(params, dict):
                raise RpcError("params must be an object")
            reply: dict[str, Any] = {"id": req_id, "result": await method(params)}
        except RpcError as exc:
            reply = {"id": req_id, "error": {"message": str(exc)}}
        except ValidationError as exc:
            reply = {"id": req_id, "error": {"message": "validation failed",
                                             "details": json.loads(exc.json())}}
        except json.JSONDecodeError:
            reply = {"id": None, "error": {"message": "invalid JSON"}}
        except Exception as exc:
            log.exception("rpc method failed")
            reply = {"id": req_id, "error": {"message": f"{type(exc).__name__}: {exc}"}}
        try:
            await ws.send(json.dumps(reply, ensure_ascii=False, default=str))
        except ConnectionClosed:
            pass

    async def _broadcast(self, event: Event) -> None:
        if not self._clients:
            return
        frame = json.dumps({"type": "event", "topic": event.topic, "data": event.data},
                           ensure_ascii=False, default=str)
        for ws in list(self._clients):
            try:
                await ws.send(frame)
            except ConnectionClosed:
                self._clients.discard(ws)
