"""Phone remote over a Telegram bot (long polling: no public IP, no open ports).

Security model:
* the bot token lives in Credential Manager (``keyring:telegram_bot``);
* only user IDs in ``remote.telegram_allowed_ids`` are served — everyone else
  is ignored silently (bots are publicly discoverable);
* pairing: the UI shows a short one-time code; ``/start <code>`` from a new
  account adds it to the allow-list;
* risky actions still go through the normal approval flow (a typed "evet" or
  the inline Evet/Hayır buttons).
"""

from __future__ import annotations

import asyncio
import base64
import contextlib
import logging
import secrets
from typing import TYPE_CHECKING, Any

from jarvis.bus import Event
from jarvis.config.schema import Role
from jarvis.providers.base import ProviderError
from jarvis.providers.gemini import GeminiAdapter

if TYPE_CHECKING:
    from jarvis.core import Core

log = logging.getLogger(__name__)

TOKEN_SECRET = "telegram_bot"


async def transcribe(core: Core, audio: bytes, mime: str) -> str:
    """Speech-to-text through a Gemini text model (audio input)."""
    body = {"contents": [{"role": "user", "parts": [
        {"inline_data": {"mime_type": mime, "data": base64.b64encode(audio).decode()}},
        {"text": "Bu ses kaydını olduğu gibi yazıya dök. Sadece söylenenleri yaz, yorum ekleme."},
    ]}]}
    resp = await core.providers.route(
        Role.TEXT_WORKER, lambda adapter, model, secret: adapter.generate(model, secret, body),
        est_tokens=1500, only=GeminiAdapter)
    return resp.text.strip()


class TelegramRemote:
    def __init__(self, core: Core) -> None:
        self.core = core
        self.pair_code = f"{secrets.randbelow(10**6):06d}"
        self.bot: Any = None
        self._task: asyncio.Task[None] | None = None
        self._dp: Any = None
        self.username: str | None = None
        self.error: str | None = None
        core.bus.subscribe("approval.requested", self._on_approval)
        core.bus.subscribe("routine.fired", self._on_reminder)

    # ------------------------------------------------------------ state

    @property
    def running(self) -> bool:
        return self._task is not None and not self._task.done()

    def _allowed(self) -> list[int]:
        return list(self.core.config.remote.telegram_allowed_ids)

    def status(self) -> dict[str, Any]:
        return {"enabled": self.core.config.features.telegram_remote, "running": self.running,
                "has_token": self.core.secrets.get(TOKEN_SECRET) is not None,
                "username": self.username, "pair_code": self.pair_code,
                "allowed": self._allowed(), "error": self.error}

    # -------------------------------------------------------- lifecycle

    async def sync(self) -> None:
        wanted = self.core.config.features.telegram_remote and not self.core.config.privacy.privacy_mode
        token = self.core.secrets.get(TOKEN_SECRET)
        if wanted and token and not self.running:
            await self.start(token)
        elif (not wanted or not token) and self.running:
            await self.stop()

    async def start(self, token: str) -> None:
        from aiogram import Bot, Dispatcher

        self.error = None
        try:
            self.bot = Bot(token)
            me = await self.bot.get_me()
            self.username = me.username
        except Exception as exc:
            self.error = f"Bot başlatılamadı: {exc}"
            log.warning(self.error)
            await self._close_bot()
            return
        self._dp = Dispatcher()
        self._register(self._dp)
        await self.bot.delete_webhook(drop_pending_updates=True)
        self._task = asyncio.create_task(self._dp.start_polling(self.bot, handle_signals=False,
                                                                close_bot_session=False))
        log.info("telegram remote running as @%s", self.username)

    async def stop(self) -> None:
        if self._dp is not None:
            with contextlib.suppress(Exception):
                await self._dp.stop_polling()
        if self._task:
            self._task.cancel()
            with contextlib.suppress(asyncio.CancelledError, Exception):
                await self._task
        self._task = None
        await self._close_bot()

    async def _close_bot(self) -> None:
        if self.bot is not None:
            with contextlib.suppress(Exception):
                await self.bot.session.close()
        self.bot = None

    # --------------------------------------------------------- handlers

    def _register(self, dp: Any) -> None:
        from aiogram import F
        from aiogram.filters import Command, CommandObject
        from aiogram.types import BufferedInputFile, CallbackQuery, Message

        remote = self

        def allowed(user_id: int | None) -> bool:
            return user_id is not None and user_id in remote._allowed()

        @dp.message(Command("start"))
        async def start(message: Message, command: CommandObject) -> None:
            uid = message.from_user.id if message.from_user else None
            if allowed(uid):
                await message.answer("Jarvis burada. Yaz ya da sesli mesaj gönder. /ekran ekran görüntüsü alır.")
                return
            if command.args and command.args.strip() == remote.pair_code and uid is not None:
                ids = remote._allowed() + [uid]
                await remote.core.config_store.patch({"remote": {"telegram_allowed_ids": ids}})
                remote.pair_code = f"{secrets.randbelow(10**6):06d}"  # one-time
                await remote.core.bus.publish("remote.paired", user_id=uid)
                await message.answer("Eşleşme tamam ✓ Artık Jarvis'e buradan komut verebilirsin.")
            # unknown users get no answer at all

        @dp.message(Command("ekran", "screen"))
        async def screen(message: Message) -> None:
            if not allowed(message.from_user.id if message.from_user else None):
                return
            from jarvis.skills.screen import capture

            jpeg, _ = await asyncio.to_thread(capture, "screen")
            await message.answer_photo(BufferedInputFile(jpeg, "ekran.jpg"))

        @dp.message(F.voice)
        async def voice(message: Message) -> None:
            if not allowed(message.from_user.id if message.from_user else None):
                return
            file = await remote.bot.get_file(message.voice.file_id)
            buf = await remote.bot.download_file(file.file_path)
            try:
                text = await transcribe(remote.core, buf.read(), "audio/ogg")
            except ProviderError as exc:
                await message.answer(f"Sesi yazıya dökemedim: {exc}")
                return
            await remote._run(message, text, echo=True)

        @dp.message(F.text)
        async def text(message: Message) -> None:
            if not allowed(message.from_user.id if message.from_user else None):
                return
            await remote._run(message, message.text or "")

        @dp.callback_query(F.data.startswith("ap:"))
        async def approval(query: CallbackQuery) -> None:
            if not allowed(query.from_user.id):
                return
            _, token, verdict = (query.data or "::").split(":", 2)
            result = await remote.core.tools.approve_from_ui(token, verdict == "1")
            outcome = result.get("output") or result.get("error") or result.get("status") or "tamam"
            await query.answer("Onaylandı" if verdict == "1" else "Reddedildi")
            if query.message:
                await query.message.edit_text(f"{query.message.text}\n\n→ {outcome}")

    async def _run(self, message: Any, text: str, echo: bool = False) -> None:
        await self.bot.send_chat_action(message.chat.id, "typing")
        try:
            result = await self.core.text_agent.run(text)
            reply = result.get("text") or "✓"
        except ProviderError as exc:
            reply = f"Şu an cevap veremiyorum: {exc}"
        await message.answer((f"🎙 “{text}”\n\n" if echo else "") + reply)

    # ------------------------------------------------------- forwarding

    async def _broadcast(self, text: str, markup: Any = None) -> None:
        if not self.running or self.bot is None:
            return
        for uid in self._allowed():
            with contextlib.suppress(Exception):
                await self.bot.send_message(uid, text, reply_markup=markup)

    async def _on_approval(self, event: Event) -> None:
        if not self.core.config.remote.forward_questions or event.data.get("source") == "text":
            return
        from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

        token = event.data.get("token")
        markup = InlineKeyboardMarkup(inline_keyboard=[[
            InlineKeyboardButton(text="Evet", callback_data=f"ap:{token}:1"),
            InlineKeyboardButton(text="Hayır", callback_data=f"ap:{token}:0"),
        ]])
        await self._broadcast(f"Jarvis soruyor: {event.data.get('summary')}", markup)

    async def _on_reminder(self, event: Event) -> None:
        if self.core.config.remote.forward_reminders:
            kind = "⏰ Alarm" if event.data.get("kind") == "alarm" else "🔔 Hatırlatıcı"
            await self._broadcast(f"{kind}: {event.data.get('text')}")
