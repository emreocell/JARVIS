"""macOS building blocks: AppleScript, NSWorkspace, Accessibility (AX), Quartz.

Everything here is imported lazily and only on macOS. The mac skills use
these helpers so each tool stays short.

Permissions macOS asks for the first time: Accessibility (clicking/typing
in other apps, window titles), Screen Recording (screenshots, window
titles of other apps), Automation (AppleScript to Spotify/Music/System
Events), Microphone.
"""

from __future__ import annotations

import os
import plistlib
import re
import subprocess
from pathlib import Path
from typing import Any

APP_DIRS = ("/Applications", "/System/Applications", "/System/Applications/Utilities",
            str(Path.home() / "Applications"))


def osascript(script: str, timeout: float = 10.0) -> str:
    """Run AppleScript and return stdout (raises RuntimeError with the error text)."""
    r = subprocess.run(["osascript", "-e", script], capture_output=True, text=True, timeout=timeout)
    if r.returncode != 0:
        raise RuntimeError(r.stderr.strip() or "AppleScript hatası")
    return r.stdout.strip()


def as_string(text: str) -> str:
    """Quote a Python string for AppleScript."""
    return '"' + text.replace("\\", "\\\\").replace('"', '\\"') + '"'


# ---------------------------------------------------------------- apps

def installed_apps() -> dict[str, str]:
    """App display name → .app path."""
    out: dict[str, str] = {}
    for base in APP_DIRS:
        try:
            for entry in os.scandir(base):
                if entry.name.endswith(".app"):
                    out.setdefault(entry.name[:-4], entry.path)
        except OSError:
            continue
    return out


def resolve_app(name: str) -> str | None:
    """Best matching installed app name for what the user said ('spotify', 'vs code', 'hesap makinesi')."""
    from jarvis.skills.text import norm, similarity

    aliases = {"vs code": "Visual Studio Code", "vscode": "Visual Studio Code", "code": "Visual Studio Code",
               "hesap makinesi": "Calculator", "takvim": "Calendar", "notlar": "Notes", "ayarlar": "System Settings",
               "sistem ayarları": "System Settings", "terminal": "Terminal", "tarayıcı": "Safari",
               "mesajlar": "Messages", "müzik": "Music", "fotoğraflar": "Photos", "finder": "Finder",
               "posta": "Mail", "hatırlatıcılar": "Reminders", "haritalar": "Maps", "kamera": "Photo Booth"}
    apps = installed_apps()
    key = norm(name)
    if key in aliases and aliases[key] in apps:
        return aliases[key]
    best, score = None, 0.0
    for app in apps:
        s = similarity(key, norm(app))
        if norm(app).startswith(key) and len(key) >= 3:
            s = max(s, 0.9)
        if s > score:
            best, score = app, s
    return best if score >= 0.72 else None


def running_apps() -> list[dict[str, Any]]:
    from AppKit import NSApplicationActivationPolicyRegular, NSWorkspace

    out = []
    for app in NSWorkspace.sharedWorkspace().runningApplications():
        if app.activationPolicy() == NSApplicationActivationPolicyRegular:
            out.append({"name": str(app.localizedName()), "pid": int(app.processIdentifier()),
                        "bundle": str(app.bundleIdentifier() or ""), "active": bool(app.isActive())})
    return out


def frontmost() -> tuple[str, int]:
    from AppKit import NSWorkspace

    app = NSWorkspace.sharedWorkspace().frontmostApplication()
    return (str(app.localizedName()), int(app.processIdentifier())) if app else ("", 0)


# ------------------------------------------------------------ windows

def window_list(on_screen: bool = True) -> list[dict[str, Any]]:
    """Visible app windows (titles need Screen Recording permission)."""
    import Quartz

    opts = Quartz.kCGWindowListOptionOnScreenOnly if on_screen else Quartz.kCGWindowListOptionAll
    out = []
    for w in Quartz.CGWindowListCopyWindowInfo(opts | Quartz.kCGWindowListExcludeDesktopElements,
                                               Quartz.kCGNullWindowID) or []:
        if int(w.get("kCGWindowLayer", 0)) != 0:
            continue
        b = w.get("kCGWindowBounds", {})
        out.append({"app": str(w.get("kCGWindowOwnerName", "")), "title": str(w.get("kCGWindowName", "") or ""),
                    "pid": int(w.get("kCGWindowOwnerPID", 0)),
                    "x": int(b.get("X", 0)), "y": int(b.get("Y", 0)),
                    "w": int(b.get("Width", 0)), "h": int(b.get("Height", 0))})
    return out


def idle_seconds() -> float:
    import Quartz

    return float(Quartz.CGEventSourceSecondsSinceLastEventType(
        Quartz.kCGEventSourceStateCombinedSessionState, Quartz.kCGAnyInputEventType))


def screens() -> list[tuple[int, int, int, int]]:
    from AppKit import NSScreen

    return [(int(s.frame().origin.x), int(s.frame().origin.y), int(s.frame().size.width),
             int(s.frame().size.height)) for s in NSScreen.screens()]


# -------------------------------------------------------- accessibility

def ax_trusted(prompt: bool = False) -> bool:
    from ApplicationServices import AXIsProcessTrustedWithOptions, kAXTrustedCheckOptionPrompt

    return bool(AXIsProcessTrustedWithOptions({kAXTrustedCheckOptionPrompt: prompt}))


def ax_attr(element: Any, name: str) -> Any:
    from ApplicationServices import AXUIElementCopyAttributeValue

    err, value = AXUIElementCopyAttributeValue(element, name, None)
    return value if err == 0 else None


def ax_app(pid: int) -> Any:
    from ApplicationServices import AXUIElementCreateApplication

    return AXUIElementCreateApplication(pid)


def ax_focused_window(pid: int) -> Any:
    return ax_attr(ax_app(pid), "AXFocusedWindow")


def ax_frame(element: Any) -> tuple[float, float, float, float] | None:
    from ApplicationServices import AXValueGetValue, kAXValueCGPointType, kAXValueCGSizeType

    pos, size = ax_attr(element, "AXPosition"), ax_attr(element, "AXSize")
    if pos is None or size is None:
        return None
    ok1, p = AXValueGetValue(pos, kAXValueCGPointType, None)
    ok2, s = AXValueGetValue(size, kAXValueCGSizeType, None)
    if not (ok1 and ok2):
        return None
    return float(p.x), float(p.y), float(s.width), float(s.height)


def ax_walk(root: Any, max_depth: int = 25, limit: int = 600):
    """Depth-first walk over AX children: yields (element, depth)."""
    stack = [(root, 0)]
    seen = 0
    while stack and seen < limit:
        el, depth = stack.pop()
        seen += 1
        yield el, depth
        if depth >= max_depth:
            continue
        children = ax_attr(el, "AXChildren") or []
        for child in reversed(list(children)):
            stack.append((child, depth + 1))


def ax_press(element: Any) -> bool:
    from ApplicationServices import AXUIElementPerformAction

    return AXUIElementPerformAction(element, "AXPress") == 0


def ax_set_value(element: Any, text: str) -> bool:
    from ApplicationServices import AXUIElementSetAttributeValue

    return AXUIElementSetAttributeValue(element, "AXValue", text) == 0


def ax_focus(element: Any) -> bool:
    from ApplicationServices import AXUIElementSetAttributeValue

    return AXUIElementSetAttributeValue(element, "AXFocused", True) == 0


def ax_selected_text() -> str:
    """Selected text in the frontmost app (Accessibility)."""
    from ApplicationServices import AXUIElementCreateSystemWide

    focused = ax_attr(AXUIElementCreateSystemWide(), "AXFocusedUIElement")
    if focused is None:
        return ""
    return str(ax_attr(focused, "AXSelectedText") or "").strip()


# ------------------------------------------------------------ keyboard

KEYCODES = {"enter": 36, "return": 36, "tab": 48, "space": 49, "delete": 51, "backspace": 51, "esc": 53,
            "escape": 53, "left": 123, "right": 124, "down": 125, "up": 126, "home": 115, "end": 119,
            "pageup": 116, "pagedown": 121, "f11": 103}
MODS = {"cmd": "command down", "command": "command down", "ctrl": "control down", "control": "control down",
        "alt": "option down", "option": "option down", "shift": "shift down"}


def keystroke_script(keys: str) -> str:
    """'Cmd+Shift+T' → System Events AppleScript (Ctrl on Windows habits maps to Cmd)."""
    parts = [p.strip().lower() for p in keys.split("+") if p.strip()]
    mods = []
    key = ""
    for p in parts:
        if p in ("ctrl", "control") and len(parts) > 1:
            mods.append("command down")   # Windows shortcuts (Ctrl+C) mean Cmd on a Mac
        elif p in MODS:
            mods.append(MODS[p])
        else:
            key = p
    using = f" using {{{', '.join(dict.fromkeys(mods))}}}" if mods else ""
    if key in KEYCODES:
        return f'tell application "System Events" to key code {KEYCODES[key]}{using}'
    if re.fullmatch(r"f([1-9]|1[0-2])", key):
        codes = {1: 122, 2: 120, 3: 99, 4: 118, 5: 96, 6: 97, 7: 98, 8: 100, 9: 101, 10: 109, 11: 103, 12: 111}
        return f'tell application "System Events" to key code {codes[int(key[1:])]}{using}'
    return f'tell application "System Events" to keystroke {as_string(key)}{using}'


def clipboard_get() -> str:
    return subprocess.run(["pbpaste"], capture_output=True, text=True).stdout


def clipboard_set(text: str) -> None:
    subprocess.run(["pbcopy"], input=text, text=True)


def paste_text(text: str) -> None:
    saved = clipboard_get()
    clipboard_set(text)
    osascript('tell application "System Events" to keystroke "v" using {command down}')
    import time

    time.sleep(0.2)
    clipboard_set(saved)


# ------------------------------------------------------------ launch agent

def write_launch_agent(label: str, program: list[str], workdir: str, enabled: bool) -> Path:
    path = Path.home() / "Library" / "LaunchAgents" / f"{label}.plist"
    if not enabled:
        if path.exists():
            subprocess.run(["launchctl", "unload", str(path)], capture_output=True)
            path.unlink()
        return path
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "wb") as f:
        plistlib.dump({"Label": label, "ProgramArguments": program, "WorkingDirectory": workdir,
                       "RunAtLoad": True, "ProcessType": "Interactive"}, f)
    return path
