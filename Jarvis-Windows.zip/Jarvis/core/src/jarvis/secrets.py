"""API key storage in Windows Credential Manager (via ``keyring``).

Config files only hold references like ``keyring:gemini_1``. The set of
known names is tracked in a small index entry because keyring backends
cannot enumerate credentials.
"""

from __future__ import annotations

import json
import re

import keyring
from keyring.errors import PasswordDeleteError

SERVICE = "Jarvis"
_INDEX = "__index__"
_NAME_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.-]{0,63}$")
PREFIX = "keyring:"


def is_ref(value: str) -> bool:
    return value.startswith(PREFIX)


def ref(name: str) -> str:
    return PREFIX + name


def mask(secret: str) -> str:
    if len(secret) <= 8:
        return "•" * len(secret)
    return f"{secret[:4]}…{secret[-4:]}"


class SecretStore:
    def __init__(self, service: str = SERVICE) -> None:
        self.service = service

    def _index(self) -> list[str]:
        raw = keyring.get_password(self.service, _INDEX)
        return json.loads(raw) if raw else []

    def _save_index(self, names: list[str]) -> None:
        keyring.set_password(self.service, _INDEX, json.dumps(sorted(set(names))))

    def names(self) -> list[str]:
        return self._index()

    def set(self, name: str, value: str) -> str:
        if not _NAME_RE.match(name):
            raise ValueError(f"invalid secret name: {name!r}")
        value = value.strip()
        if not value:
            raise ValueError("secret value is empty")
        keyring.set_password(self.service, name, value)
        self._save_index([*self._index(), name])
        return ref(name)

    def get(self, name: str) -> str | None:
        return keyring.get_password(self.service, name)

    def delete(self, name: str) -> None:
        try:
            keyring.delete_password(self.service, name)
        except PasswordDeleteError:
            pass
        self._save_index([n for n in self._index() if n != name])

    def resolve(self, value: str) -> str | None:
        """Turn ``keyring:name`` into the stored secret; pass literals through."""
        if is_ref(value):
            return self.get(value[len(PREFIX):])
        return value or None

    def describe(self) -> list[dict[str, str]]:
        out = []
        for name in self._index():
            secret = self.get(name)
            if secret is not None:
                out.append({"name": name, "ref": ref(name), "masked": mask(secret)})
        return out
