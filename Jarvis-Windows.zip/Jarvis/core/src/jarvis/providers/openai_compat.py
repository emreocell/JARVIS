"""Adapter for any OpenAI-compatible Chat Completions API.

Covers Groq, OpenRouter, Cerebras, DeepSeek, Mistral, GitHub Models,
NVIDIA NIM, Ollama, LM Studio and Gemini's OpenAI endpoint.
"""

from __future__ import annotations

import time
from typing import Any

import httpx

from jarvis.providers.base import ChatRequest, ChatResponse, ProviderError
from jarvis.providers.http import raise_for_status


class OpenAICompatAdapter:
    def __init__(self, provider_id: str, base_url: str, client: httpx.AsyncClient,
                 headers: dict[str, str] | None = None) -> None:
        self.provider_id = provider_id
        self.base_url = base_url.rstrip("/")
        self.client = client
        self.headers = headers or {}

    def _headers(self, api_key: str) -> dict[str, str]:
        h = {"Content-Type": "application/json", **self.headers}
        if api_key:
            h["Authorization"] = f"Bearer {api_key}"
        return h

    async def chat(self, model: str, api_key: str, request: ChatRequest) -> ChatResponse:
        body: dict[str, Any] = {
            "model": model,
            "messages": [{"role": m.role, "content": m.content} for m in request.messages],
        }
        if request.temperature is not None:
            body["temperature"] = request.temperature
        if request.max_tokens is not None:
            body["max_tokens"] = request.max_tokens
        if request.json_schema is not None:
            body["response_format"] = {
                "type": "json_schema",
                "json_schema": {"name": "result", "schema": request.json_schema},
            }
        start = time.perf_counter()
        resp = await self.client.post(
            f"{self.base_url}/chat/completions", json=body, headers=self._headers(api_key)
        )
        raise_for_status(resp, self.provider_id)
        data = resp.json()
        try:
            text = data["choices"][0]["message"]["content"] or ""
        except (KeyError, IndexError, TypeError) as exc:
            raise ProviderError(f"{self.provider_id}: unexpected response shape") from exc
        usage = data.get("usage") or {}
        return ChatResponse(
            text=text,
            provider=self.provider_id,
            model=model,
            input_tokens=int(usage.get("prompt_tokens") or 0),
            output_tokens=int(usage.get("completion_tokens") or 0),
            latency_ms=int((time.perf_counter() - start) * 1000),
            raw=data,
        )

    async def transcribe(self, model: str, api_key: str, wav: bytes, language: str = "tr",
                         vocabulary: list[str] | None = None) -> ChatResponse:
        """Whisper-style ``/audio/transcriptions`` (Groq, OpenAI, …)."""
        headers = {k: v for k, v in self._headers(api_key).items() if k != "Content-Type"}
        data = {"model": model, "language": language.split("-")[0], "response_format": "json",
                "temperature": "0"}
        if vocabulary:
            data["prompt"] = ", ".join(vocabulary)[:400]
        start = time.perf_counter()
        resp = await self.client.post(f"{self.base_url}/audio/transcriptions", headers=headers, data=data,
                                      files={"file": ("speech.wav", wav, "audio/wav")})
        raise_for_status(resp, self.provider_id)
        return ChatResponse(text=str(resp.json().get("text", "")).strip(), provider=self.provider_id,
                            model=model, latency_ms=int((time.perf_counter() - start) * 1000))

    async def list_models(self, api_key: str) -> list[str]:
        resp = await self.client.get(f"{self.base_url}/models", headers=self._headers(api_key))
        raise_for_status(resp, self.provider_id)
        return sorted(m["id"] for m in resp.json().get("data", []) if "id" in m)
