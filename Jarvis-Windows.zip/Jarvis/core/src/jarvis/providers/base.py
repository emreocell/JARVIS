"""Provider-neutral request/response types and errors."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Literal, Protocol


class ProviderError(Exception):
    """Generic, retryable-on-another-route failure."""


class RateLimited(ProviderError):
    def __init__(self, message: str, retry_after: float | None = None, daily: bool = False):
        super().__init__(message)
        self.retry_after = retry_after
        self.daily = daily


class AuthError(ProviderError):
    """Key rejected — do not retry this key."""


class BadRequest(ProviderError):
    """Our request is wrong — retrying elsewhere with the same payload may still help
    (different model), but never retry the same route."""


@dataclass(slots=True)
class Message:
    role: Literal["system", "user", "assistant"]
    content: str


@dataclass(slots=True)
class ChatRequest:
    messages: list[Message]
    temperature: float | None = None
    max_tokens: int | None = None
    json_schema: dict[str, Any] | None = None  # ask for structured JSON output

    def estimate_tokens(self) -> int:
        # ~4 chars per token is good enough for quota pre-checks
        return sum(len(m.content) for m in self.messages) // 4 + (self.max_tokens or 256)


@dataclass(slots=True)
class ChatResponse:
    text: str
    provider: str = ""
    model: str = ""
    key_id: str = ""
    input_tokens: int = 0
    output_tokens: int = 0
    latency_ms: int = 0
    raw: dict[str, Any] = field(default_factory=dict, repr=False)


class ChatAdapter(Protocol):
    async def chat(self, model: str, api_key: str, request: ChatRequest) -> ChatResponse: ...

    async def list_models(self, api_key: str) -> list[str]: ...
