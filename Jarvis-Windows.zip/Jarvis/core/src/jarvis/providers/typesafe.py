"""TypeSafe "System One" (Jev) adapter.

Jev does not generate text; it answers typed questions about a state:
``choice`` (pick one option), ``score`` (ordered levels) and ``noul``
(yes/no probability). Works against TypeSafe directly
(``https://api.typesafe.ai``) or through Vercel AI Gateway's
TypeSafe-compatible endpoint (``https://ai-gateway.vercel.sh/typesafe``).
"""

from __future__ import annotations

import time
from typing import Any

import httpx

from jarvis.providers.base import ProviderError
from jarvis.providers.http import raise_for_status


def choice(instructions: str, options: dict[str, str | None]) -> dict[str, Any]:
    """``options`` maps option name -> description (max 255 options)."""
    return {"type": "choice", "instructions": instructions, "criteria": options}


def score(instructions: str, levels: list[str]) -> dict[str, Any]:
    """``levels`` are ordered descriptions, 2-10 of them."""
    return {"type": "score", "instructions": instructions, "criteria": levels}


def yes_no(instructions: str, true: str | None = None, false: str | None = None) -> dict[str, Any]:
    q: dict[str, Any] = {"type": "noul", "instructions": instructions}
    if true or false:
        q["criteria"] = {"true": true or "yes", "false": false or "no"}
    return q


class TypeSafeAdapter:
    def __init__(self, provider_id: str, base_url: str, client: httpx.AsyncClient) -> None:
        self.provider_id = provider_id
        self.base_url = base_url.rstrip("/")
        self.client = client

    async def decide(self, model: str, api_key: str, state: str,
                     questions: dict[str, dict[str, Any]], timeout: float = 4.0) -> dict[str, Any]:
        """Return the raw ``answers`` mapping keyed by question id, plus latency."""
        start = time.perf_counter()
        resp = await self.client.post(
            f"{self.base_url}/v1/systemone",
            json={"model": model, "state": state, "questions": questions},
            headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
            timeout=timeout,
        )
        raise_for_status(resp, self.provider_id)
        data = resp.json()
        answers = data.get("answers")
        if not isinstance(answers, dict) or set(answers) != set(questions):
            raise ProviderError(f"{self.provider_id}: unexpected response shape")
        return {
            "answers": answers,
            "model": data.get("model", model),
            "usage": data.get("usage") or {},
            "latency_ms": int((time.perf_counter() - start) * 1000),
        }

    async def list_models(self, api_key: str) -> list[str]:
        return []
