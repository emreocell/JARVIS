"""Proactive quota tracking per (key, model).

The router asks :meth:`QuotaTracker.available` *before* calling a provider
instead of waiting for HTTP 429s. Counters are kept in memory and persisted
periodically so daily counts survive restarts.

Gemini resets daily quotas at midnight Pacific time, so the "day" boundary is
configurable per profile.
"""

from __future__ import annotations

import time
from collections import deque
from dataclasses import dataclass, field
from datetime import datetime
from zoneinfo import ZoneInfo


@dataclass(frozen=True, slots=True)
class Limits:
    rpm: int | None = None  # requests per minute; None = unlimited
    tpm: int | None = None  # tokens per minute
    rpd: int | None = None  # requests per day

    @property
    def blocked(self) -> bool:
        """0 means the model is not available on this tier at all."""
        return self.rpm == 0 or self.rpd == 0


@dataclass(slots=True)
class _Usage:
    minute_requests: deque[float] = field(default_factory=deque)
    minute_tokens: deque[tuple[float, int]] = field(default_factory=deque)
    day: str = ""
    day_requests: int = 0
    cooldown_until: float = 0.0


class QuotaTracker:
    def __init__(self, clock=time.time, tz: str = "America/Los_Angeles") -> None:
        self._clock = clock
        self._tz = ZoneInfo(tz)
        self._usage: dict[tuple[str, str], _Usage] = {}

    def _day(self, now: float) -> str:
        return datetime.fromtimestamp(now, self._tz).strftime("%Y-%m-%d")

    def _get(self, key_id: str, model: str, now: float) -> _Usage:
        usage = self._usage.setdefault((key_id, model), _Usage())
        cutoff = now - 60.0
        while usage.minute_requests and usage.minute_requests[0] <= cutoff:
            usage.minute_requests.popleft()
        while usage.minute_tokens and usage.minute_tokens[0][0] <= cutoff:
            usage.minute_tokens.popleft()
        day = self._day(now)
        if usage.day != day:
            usage.day, usage.day_requests = day, 0
        return usage

    def available(self, key_id: str, model: str, limits: Limits, est_tokens: int = 0) -> bool:
        if limits.blocked:
            return False
        now = self._clock()
        u = self._get(key_id, model, now)
        if u.cooldown_until > now:
            return False
        if limits.rpm is not None and len(u.minute_requests) >= limits.rpm:
            return False
        if limits.rpd is not None and u.day_requests >= limits.rpd:
            return False
        if limits.tpm is not None and est_tokens:
            used = sum(t for _, t in u.minute_tokens)
            if used + est_tokens > limits.tpm:
                return False
        return True

    def record(self, key_id: str, model: str, tokens: int = 0) -> None:
        now = self._clock()
        u = self._get(key_id, model, now)
        u.minute_requests.append(now)
        if tokens:
            u.minute_tokens.append((now, tokens))
        u.day_requests += 1

    def add_tokens(self, key_id: str, model: str, tokens: int) -> None:
        """Account tokens reported after the response arrived."""
        if tokens > 0:
            now = self._clock()
            self._get(key_id, model, now).minute_tokens.append((now, tokens))

    def cooldown(self, key_id: str, model: str, seconds: float) -> None:
        now = self._clock()
        u = self._get(key_id, model, now)
        u.cooldown_until = max(u.cooldown_until, now + seconds)

    def exhaust_day(self, key_id: str, model: str, limits: Limits) -> None:
        """Mark the daily quota as used up (server said RPD exceeded)."""
        now = self._clock()
        u = self._get(key_id, model, now)
        if limits.rpd is not None:
            u.day_requests = max(u.day_requests, limits.rpd)
        else:
            u.cooldown_until = max(u.cooldown_until, now + 3600)

    def snapshot(self, key_id: str, model: str, limits: Limits) -> dict[str, int | float | None]:
        now = self._clock()
        u = self._get(key_id, model, now)
        return {
            "rpm_used": len(u.minute_requests),
            "rpm_limit": limits.rpm,
            "rpd_used": u.day_requests,
            "rpd_limit": limits.rpd,
            "tpm_used": sum(t for _, t in u.minute_tokens),
            "tpm_limit": limits.tpm,
            "cooldown_s": max(0.0, round(u.cooldown_until - now, 1)),
        }

    # persistence ---------------------------------------------------------

    def dump(self) -> dict[str, dict[str, int | str]]:
        return {
            f"{k}|{m}": {"day": u.day, "day_requests": u.day_requests}
            for (k, m), u in self._usage.items()
            if u.day_requests
        }

    def restore(self, data: dict[str, dict[str, int | str]]) -> None:
        today = self._day(self._clock())
        for composite, entry in data.items():
            key_id, _, model = composite.partition("|")
            if entry.get("day") == today:
                u = self._usage.setdefault((key_id, model), _Usage())
                u.day = today
                u.day_requests = int(entry.get("day_requests", 0))
