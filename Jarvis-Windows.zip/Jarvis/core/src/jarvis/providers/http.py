"""Shared HTTP error mapping for provider adapters."""

from __future__ import annotations

import json
import re

import httpx

from jarvis.providers.base import AuthError, BadRequest, ProviderError, RateLimited

_RETRY_DELAY = re.compile(r'"retryDelay"\s*:\s*"(\d+(?:\.\d+)?)s"')


def _retry_after(resp: httpx.Response) -> float | None:
    header = resp.headers.get("retry-after")
    if header:
        try:
            return float(header)
        except ValueError:
            pass
    match = _RETRY_DELAY.search(resp.text)
    return float(match.group(1)) if match else None


def _message(resp: httpx.Response) -> str:
    try:
        body = resp.json()
    except json.JSONDecodeError:
        return resp.text[:300]
    err = body.get("error", body) if isinstance(body, dict) else body
    if isinstance(err, dict):
        return str(err.get("message") or err)[:300]
    return str(err)[:300]


def raise_for_status(resp: httpx.Response, provider: str) -> None:
    if resp.is_success:
        return
    msg = f"{provider} HTTP {resp.status_code}: {_message(resp)}"
    code = resp.status_code
    if code == 429:
        daily = "PerDay" in resp.text or "per day" in resp.text.lower()
        raise RateLimited(msg, retry_after=_retry_after(resp), daily=daily)
    if code in (401, 403):
        raise AuthError(msg)
    if code in (400, 404, 422):
        raise BadRequest(msg)
    raise ProviderError(msg)


def default_client(timeout: float = 30.0) -> httpx.AsyncClient:
    return httpx.AsyncClient(timeout=httpx.Timeout(timeout, connect=10.0), http2=False)
