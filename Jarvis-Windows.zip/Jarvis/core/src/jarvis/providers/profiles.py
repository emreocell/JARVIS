"""Known free-tier quota profiles.

``gemini_free_2026`` mirrors the AI Studio rate-limit page as of 2026-09
(per account). Model IDs are the ones AI Studio exposes via ``models.list``;
unknown models fall back to ``DEFAULT`` and the router learns from 429s.
Users can override any entry from the UI.
"""

from __future__ import annotations

from jarvis.providers.quota import Limits

UNLIMITED = Limits()

GEMINI_FREE_2026: dict[str, Limits] = {
    # Live API — unlimited requests, token-per-minute bound
    "gemini-3.8-live": Limits(tpm=65_000),
    "gemini-3.8-live-extended-thinking": Limits(tpm=65_000),
    "gemini-3.1-flash-live-preview": Limits(tpm=65_000),
    "gemini-2.5-flash-native-audio-dialog": Limits(tpm=1_000_000),
    "gemini-3.5-transcribe-live": Limits(tpm=20_000),
    "gemini-3.5-live-translate": Limits(tpm=20_000),
    # text
    "gemini-2.5-flash": Limits(rpm=5, tpm=250_000, rpd=20),
    "gemini-2.5-flash-lite": Limits(rpm=10, tpm=250_000, rpd=20),
    "gemini-3-flash": Limits(rpm=5, tpm=250_000, rpd=20),
    "gemini-3.5-flash": Limits(rpm=5, tpm=250_000, rpd=20),
    "gemini-3.6-flash": Limits(rpm=5, tpm=250_000, rpd=20),
    "gemini-3.7-flash": Limits(rpm=5, tpm=250_000, rpd=20),
    "gemini-3.8-flash": Limits(rpm=5, tpm=250_000, rpd=20),
    "gemini-3.1-flash-lite": Limits(rpm=15, tpm=250_000, rpd=500),
    "gemini-3.5-flash-lite": Limits(rpm=15, tpm=250_000, rpd=500),
    "gemma-4-26b-it": Limits(rpm=30, tpm=16_000, rpd=14_400),
    "gemma-4-31b-it": Limits(rpm=30, tpm=16_000, rpd=14_400),
    "gemini-robotics-er-2-preview": Limits(rpm=5, tpm=250_000, rpd=20),
    "gemini-3.5-transcribe": Limits(rpm=3, tpm=10_000, rpd=25),
    # embeddings
    "gemini-embedding-1": Limits(rpm=100, tpm=30_000, rpd=1_000),
    "gemini-embedding-2": Limits(rpm=100, tpm=30_000, rpd=1_000),
    # not available on free tier
    "gemini-2.5-pro": Limits(rpm=0, rpd=0),
    "gemini-3.1-pro": Limits(rpm=0, rpd=0),
    "computer-use-preview": Limits(rpm=0, rpd=0),
}

PROFILES: dict[str, dict[str, Limits]] = {
    "gemini_free_2026": GEMINI_FREE_2026,
}

# Conservative default for models we know nothing about.
DEFAULT = Limits(rpm=10)


def limits_for(profile: str | None, model: str) -> Limits:
    if not profile:
        return UNLIMITED
    table = PROFILES.get(profile, {})
    if model in table:
        return table[model]
    # tolerate "models/" prefix and version suffixes like "-001"
    bare = model.removeprefix("models/")
    for known, limits in table.items():
        if bare == known or bare.startswith(known + "-"):
            return limits
    return DEFAULT
