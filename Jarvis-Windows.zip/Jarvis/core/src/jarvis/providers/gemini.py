"""Gemini REST adapter (text + structured output + model discovery).

The Live API (voice brain) uses the ``google-genai`` SDK in
:mod:`jarvis.voice`; this adapter handles one-shot background work.
"""

from __future__ import annotations

import base64
import time
from typing import Any

import httpx

from jarvis.providers.base import ChatRequest, ChatResponse, ProviderError
from jarvis.providers.http import raise_for_status

BASE_URL = "https://generativelanguage.googleapis.com/v1beta"


class GeminiAdapter:
    def __init__(self, provider_id: str, client: httpx.AsyncClient, base_url: str | None = None) -> None:
        self.provider_id = provider_id
        self.client = client
        self.base_url = (base_url or BASE_URL).rstrip("/")

    @staticmethod
    def _body(model: str, request: ChatRequest) -> dict[str, Any]:
        system = "\n\n".join(m.content for m in request.messages if m.role == "system")
        contents: list[dict[str, Any]] = []
        for m in request.messages:
            if m.role == "system":
                continue
            role = "model" if m.role == "assistant" else "user"
            contents.append({"role": role, "parts": [{"text": m.content}]})
        body: dict[str, Any] = {"contents": contents}
        if system:
            if model.startswith("gemma"):
                # Gemma rejects systemInstruction; fold it into the first user turn.
                if contents and contents[0]["role"] == "user":
                    contents[0]["parts"].insert(0, {"text": system})
                else:
                    contents.insert(0, {"role": "user", "parts": [{"text": system}]})
            else:
                body["systemInstruction"] = {"parts": [{"text": system}]}
        gen: dict[str, Any] = {}
        if request.temperature is not None:
            gen["temperature"] = request.temperature
        if request.max_tokens is not None:
            gen["maxOutputTokens"] = request.max_tokens
        if request.json_schema is not None:
            gen["responseMimeType"] = "application/json"
            gen["responseJsonSchema"] = request.json_schema
        if gen:
            body["generationConfig"] = gen
        return body

    async def chat(self, model: str, api_key: str, request: ChatRequest) -> ChatResponse:
        model_path = model if model.startswith("models/") else f"models/{model}"
        start = time.perf_counter()
        resp = await self.client.post(
            f"{self.base_url}/{model_path}:generateContent",
            json=self._body(model, request),
            headers={"x-goog-api-key": api_key, "Content-Type": "application/json"},
        )
        raise_for_status(resp, self.provider_id)
        data = resp.json()
        candidates = data.get("candidates") or []
        if not candidates:
            reason = (data.get("promptFeedback") or {}).get("blockReason", "no candidates")
            raise ProviderError(f"{self.provider_id}: {reason}")
        parts = (candidates[0].get("content") or {}).get("parts") or []
        text = "".join(p.get("text", "") for p in parts if not p.get("thought"))
        usage = data.get("usageMetadata") or {}
        return ChatResponse(
            text=text,
            provider=self.provider_id,
            model=model,
            input_tokens=int(usage.get("promptTokenCount") or 0),
            output_tokens=int(usage.get("candidatesTokenCount") or 0),
            latency_ms=int((time.perf_counter() - start) * 1000),
            raw=data,
        )

    async def generate(self, model: str, api_key: str, body: dict[str, Any]) -> ChatResponse:
        """Raw ``generateContent`` (tools, multi-turn contents). The parsed
        candidate is returned in ``raw``; ``text`` holds any text parts."""
        model_path = model if model.startswith("models/") else f"models/{model}"
        start = time.perf_counter()
        resp = await self.client.post(
            f"{self.base_url}/{model_path}:generateContent", json=body,
            headers={"x-goog-api-key": api_key, "Content-Type": "application/json"},
        )
        raise_for_status(resp, self.provider_id)
        data = resp.json()
        candidates = data.get("candidates") or []
        if not candidates:
            reason = (data.get("promptFeedback") or {}).get("blockReason", "no candidates")
            raise ProviderError(f"{self.provider_id}: {reason}")
        parts = (candidates[0].get("content") or {}).get("parts") or []
        usage = data.get("usageMetadata") or {}
        return ChatResponse(
            text="".join(p.get("text", "") for p in parts if not p.get("thought")),
            provider=self.provider_id, model=model,
            input_tokens=int(usage.get("promptTokenCount") or 0),
            output_tokens=int(usage.get("candidatesTokenCount") or 0),
            latency_ms=int((time.perf_counter() - start) * 1000),
            raw={"parts": parts, "content": candidates[0].get("content") or {"role": "model", "parts": parts}},
        )

    async def transcribe(self, model: str, api_key: str, wav: bytes, language: str = "tr",
                         vocabulary: list[str] | None = None) -> ChatResponse:
        """Speech-to-text with a multimodal model (audio in, text out)."""
        hint = f" Özel isimler: {', '.join(vocabulary)}." if vocabulary else ""
        body = {
            "contents": [{"role": "user", "parts": [
                {"inlineData": {"mimeType": "audio/wav", "data": base64.b64encode(wav).decode()}},
                {"text": ("Bu ses kaydında söylenenleri kelimesi kelimesine yazıya dök. Dil çoğunlukla "
                          f"'{language}', araya İngilizce kelimeler girebilir.{hint} Yalnızca söylenen metni yaz; "
                          "açıklama ekleme. Konuşma yoksa boş cevap ver.")},
            ]}],
            "generationConfig": {"temperature": 0},
        }
        resp = await self.generate(model, api_key, body)
        resp.text = resp.text.strip().strip('"')
        return resp

    async def speak(self, model: str, api_key: str, text: str, voice: str = "Charon") -> ChatResponse:
        """Text-to-speech; 24 kHz mono s16le PCM in ``raw['pcm']``."""
        body = {
            "contents": [{"role": "user", "parts": [{"text": text}]}],
            "generationConfig": {"responseModalities": ["AUDIO"], "speechConfig": {
                "voiceConfig": {"prebuiltVoiceConfig": {"voiceName": voice}}}},
        }
        resp = await self.generate(model, api_key, body)
        data = next((p["inlineData"]["data"] for p in resp.raw["parts"] if "inlineData" in p), None)
        if not data:
            raise ProviderError(f"{self.provider_id}: TTS returned no audio")
        resp.raw["pcm"] = base64.b64decode(data)
        return resp

    async def embed(self, model: str, api_key: str, texts: list[str],
                    task_type: str = "RETRIEVAL_DOCUMENT") -> ChatResponse:
        """Batch embeddings; vectors are returned in ``raw['vectors']``."""
        name = model if model.startswith("models/") else f"models/{model}"
        start = time.perf_counter()
        resp = await self.client.post(
            f"{self.base_url}/{name}:batchEmbedContents",
            json={"requests": [{"model": name, "content": {"parts": [{"text": t}]}, "taskType": task_type}
                               for t in texts]},
            headers={"x-goog-api-key": api_key, "Content-Type": "application/json"},
        )
        raise_for_status(resp, self.provider_id)
        vectors = [e.get("values", []) for e in resp.json().get("embeddings", [])]
        if len(vectors) != len(texts):
            raise ProviderError(f"{self.provider_id}: embedding count mismatch")
        return ChatResponse(text="", provider=self.provider_id, model=model,
                            latency_ms=int((time.perf_counter() - start) * 1000), raw={"vectors": vectors})

    async def list_models(self, api_key: str) -> list[str]:
        names: list[str] = []
        page_token = ""
        while True:
            params = {"pageSize": "1000"}
            if page_token:
                params["pageToken"] = page_token
            resp = await self.client.get(
                f"{self.base_url}/models", params=params, headers={"x-goog-api-key": api_key}
            )
            raise_for_status(resp, self.provider_id)
            data = resp.json()
            names += [m["name"].removeprefix("models/") for m in data.get("models", [])]
            page_token = data.get("nextPageToken", "")
            if not page_token:
                return sorted(names)
