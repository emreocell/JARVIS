"""Provider registry and role-based router.

Routing: for a role, walk its ordered targets (provider, model); for each
target walk the provider's key pool starting after the last key used,
skipping keys the :class:`QuotaTracker` says are exhausted. Errors decide
what happens next:

* ``RateLimited``  → cool down that (key, model) and try the next key
* ``AuthError``    → park the key for an hour and try the next key
* ``BadRequest``   → this model/payload won't work; move to the next target
* ``ProviderError``→ short cool-down, next key
"""

from __future__ import annotations

import asyncio
import logging
import re
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from typing import Any

import httpx

from jarvis.config.schema import AppConfig, ProviderConfig, ProviderType, Role
from jarvis.providers.base import (
    AuthError,
    BadRequest,
    ChatRequest,
    ChatResponse,
    Message,
    ProviderError,
    RateLimited,
)
from jarvis.providers.gemini import GeminiAdapter
from jarvis.providers.openai_compat import OpenAICompatAdapter
from jarvis.providers.profiles import limits_for
from jarvis.providers.quota import QuotaTracker
from jarvis.providers.typesafe import TypeSafeAdapter
from jarvis.secrets import SecretStore, is_ref

log = logging.getLogger(__name__)

AUTH_PARK_SECONDS = 3600
ERROR_COOLDOWN_SECONDS = 10
DEFAULT_RATE_COOLDOWN = 30


def _transient(exc: Exception) -> bool:
    return isinstance(exc, ProviderError) and bool(re.search(r"HTTP 50[234]", str(exc)))

class NoRouteAvailable(ProviderError):
    def __init__(self, role: str, attempts: list[str]):
        detail = "; ".join(attempts) if attempts else "no enabled provider/key for this role"
        super().__init__(f"no route available for {role}: {detail}")
        self.attempts = attempts


@dataclass(slots=True)
class _Stats:
    ok: int = 0
    failed: int = 0
    latency_ms: float = 0.0  # exponential moving average

    def success(self, latency: int) -> None:
        self.ok += 1
        self.latency_ms = latency if self.ok == 1 else 0.8 * self.latency_ms + 0.2 * latency

    def failure(self) -> None:
        self.failed += 1


@dataclass(slots=True)
class _Key:
    key_id: str  # the keyring name (safe to log / show)
    secret: str


@dataclass(slots=True)
class _Provider:
    config: ProviderConfig
    adapter: Any
    keys: list[_Key] = field(default_factory=list)
    cursor: int = 0


def _key_id(value: str, index: int) -> str:
    return value.split(":", 1)[1] if is_ref(value) else f"literal-{index}"


class ProviderRegistry:
    def __init__(self, secrets: SecretStore, quota: QuotaTracker | None = None,
                 client: httpx.AsyncClient | None = None) -> None:
        self.secrets = secrets
        self.quota = quota or QuotaTracker()
        self.client = client or httpx.AsyncClient(timeout=httpx.Timeout(30.0, connect=10.0))
        self._providers: dict[str, _Provider] = {}
        self._routes: dict[Role, list[tuple[str, str]]] = {}
        self._stats: dict[str, _Stats] = {}

    # ------------------------------------------------------------ building

    def _adapter(self, cfg: ProviderConfig) -> Any:
        if cfg.type is ProviderType.GEMINI:
            return GeminiAdapter(cfg.id, self.client, cfg.base_url)
        if cfg.type is ProviderType.OPENAI_COMPATIBLE:
            if not cfg.base_url:
                raise ValueError(f"provider {cfg.id}: base_url is required")
            return OpenAICompatAdapter(cfg.id, cfg.base_url, self.client, cfg.headers)
        if cfg.type is ProviderType.TYPESAFE:
            return TypeSafeAdapter(cfg.id, cfg.base_url or "https://api.typesafe.ai", self.client)
        raise ValueError(f"unknown provider type {cfg.type}")

    def load(self, config: AppConfig) -> None:
        providers: dict[str, _Provider] = {}
        for cfg in config.providers:
            if not cfg.enabled:
                continue
            try:
                adapter = self._adapter(cfg)
            except ValueError as exc:
                log.warning("skipping provider: %s", exc)
                continue
            keys = []
            for i, value in enumerate(cfg.keys):
                secret = self.secrets.resolve(value)
                if secret:
                    keys.append(_Key(_key_id(value, i), secret))
            previous = self._providers.get(cfg.id)
            providers[cfg.id] = _Provider(cfg, adapter, keys, previous.cursor if previous else 0)
        self._providers = providers
        self._routes = {role: [(t.provider, t.model) for t in targets]
                        for role, targets in config.routes.items()}

    # ------------------------------------------------------------- routing

    def _candidates(self, provider: _Provider) -> list[_Key]:
        n = len(provider.keys)
        return [provider.keys[(provider.cursor + i) % n] for i in range(n)]

    def _handle_error(self, exc: ProviderError, provider: _Provider, key: _Key, model: str) -> bool:
        """Apply cool-downs. Returns True if the next *target* should be tried
        instead of the next key."""
        limits = limits_for(provider.config.quota_profile, model)
        if isinstance(exc, RateLimited):
            if exc.daily:
                self.quota.exhaust_day(key.key_id, model, limits)
            else:
                self.quota.cooldown(key.key_id, model, exc.retry_after or DEFAULT_RATE_COOLDOWN)
            return False
        if isinstance(exc, AuthError):
            for m in {model, *[t[1] for ts in self._routes.values() for t in ts]}:
                self.quota.cooldown(key.key_id, m, AUTH_PARK_SECONDS)
            return False
        if isinstance(exc, BadRequest):
            return True
        self.quota.cooldown(key.key_id, model, ERROR_COOLDOWN_SECONDS)
        return False

    async def chat(self, role: Role, request: ChatRequest) -> ChatResponse:
        return await self.route(role, lambda adapter, model, secret: adapter.chat(model, secret, request),
                                est_tokens=request.estimate_tokens())

    async def route(self, role: Role, call: Callable[[Any, str, str], Awaitable[ChatResponse]],
                    est_tokens: int = 0, only: type | None = None) -> ChatResponse:
        """Walk the role's targets and key pools, calling ``call(adapter, model, secret)``
        until one succeeds. ``only`` restricts to one adapter type (e.g. Gemini
        for native function calling)."""
        attempts: list[str] = []
        for provider_id, model in self._routes.get(role, []):
            provider = self._providers.get(provider_id)
            if provider is None or not provider.keys or isinstance(provider.adapter, TypeSafeAdapter):
                continue
            if only is not None and not isinstance(provider.adapter, only):
                continue
            limits = limits_for(provider.config.quota_profile, model)
            for key in self._candidates(provider):
                if not self.quota.available(key.key_id, model, limits, est_tokens):
                    attempts.append(f"{provider_id}/{model}/{key.key_id}: quota")
                    continue
                self.quota.record(key.key_id, model)
                stats = self._stats.setdefault(provider_id, _Stats())
                try:
                    resp = await call(provider.adapter, model, key.secret)
                except ProviderError as exc:
                    stats.failure()
                    attempts.append(f"{provider_id}/{model}/{key.key_id}: {type(exc).__name__}")
                    log.info("route failed %s/%s key=%s: %s", provider_id, model, key.key_id, exc)
                    if self._handle_error(exc, provider, key, model):
                        break
                    continue
                except httpx.HTTPError as exc:
                    stats.failure()
                    attempts.append(f"{provider_id}/{model}/{key.key_id}: network")
                    self.quota.cooldown(key.key_id, model, ERROR_COOLDOWN_SECONDS)
                    log.info("network error %s/%s: %s", provider_id, model, exc)
                    continue
                stats.success(resp.latency_ms)
                self.quota.add_tokens(key.key_id, model, resp.input_tokens + resp.output_tokens)
                provider.cursor = (provider.keys.index(key) + 1) % len(provider.keys)
                resp.key_id = key.key_id
                return resp
        raise NoRouteAvailable(role.value, attempts)

    async def ask(self, prompt: str, system: str | None = None,
                  role: Role = Role.TEXT_WORKER, **kwargs: Any) -> ChatResponse:
        messages = [Message("system", system)] if system else []
        messages.append(Message("user", prompt))
        return await self.chat(role, ChatRequest(messages=messages, **kwargs))

    async def decide(self, state: str, questions: dict[str, dict[str, Any]],
                     role: Role = Role.FAST_DECIDER, timeout: float = 4.0) -> dict[str, Any]:
        attempts: list[str] = []
        for provider_id, model in self._routes.get(role, []):
            provider = self._providers.get(provider_id)
            if provider is None or not provider.keys or not isinstance(provider.adapter, TypeSafeAdapter):
                continue
            for key in self._candidates(provider):
                limits = limits_for(provider.config.quota_profile, model)
                if not self.quota.available(key.key_id, model, limits):
                    continue
                self.quota.record(key.key_id, model)
                try:
                    try:
                        result = await provider.adapter.decide(model, key.secret, state, questions, timeout)
                    except ProviderError as exc:
                        # the gateway answers an occasional 502/503: retry once instead of
                        # parking the key (a parked key silently sends every decision to the LLM)
                        if not _transient(exc):
                            raise
                        await asyncio.sleep(0.05)
                        result = await provider.adapter.decide(model, key.secret, state, questions, timeout)
                except (ProviderError, httpx.HTTPError) as exc:
                    attempts.append(f"{provider_id}/{key.key_id}: {type(exc).__name__}")
                    if isinstance(exc, ProviderError):
                        if not _transient(exc):   # a blip is not a reason to park the key
                            self._handle_error(exc, provider, key, model)
                    continue
                self._stats.setdefault(provider_id, _Stats()).success(result["latency_ms"])
                result["provider"] = provider_id
                return result
        raise NoRouteAvailable(role.value, attempts)

    def live_keys(self, provider_id: str, model: str) -> list[tuple[str, str]]:
        """Keys for a streaming session, rotated and minus parked ones.
        Live connections are long-lived, so they bypass per-request counting."""
        provider = self._providers.get(provider_id)
        if provider is None:
            return []
        limits = limits_for(provider.config.quota_profile, model)
        keys = [k for k in self._candidates(provider)
                if self.quota.available(k.key_id, model, limits)] if provider.keys else []
        if provider.keys:
            provider.cursor = (provider.cursor + 1) % len(provider.keys)
        return [(k.key_id, k.secret) for k in keys]

    def park_key(self, key_id: str, model: str, seconds: float) -> None:
        self.quota.cooldown(key_id, model, seconds)

    # ------------------------------------------------------------- UI data

    async def test_provider(self, provider_id: str) -> list[dict[str, Any]]:
        """Check every key of a provider. Uses the models endpoint (free, no
        quota) where available."""
        provider = self._providers.get(provider_id)
        if provider is None:
            return [{"ok": False, "error": "provider disabled or unknown"}]
        if not provider.keys:
            return [{"ok": False, "error": "no API key"}]
        results = []
        for key in provider.keys:
            try:
                if isinstance(provider.adapter, TypeSafeAdapter):
                    from jarvis.providers.typesafe import yes_no

                    model = provider.config.models[0].id if provider.config.models else "jev-latest"
                    r = await provider.adapter.decide(model, key.secret, "ping",
                                                      {"q": yes_no("Is this a ping?")})
                    results.append({"key": key.key_id, "ok": True, "latency_ms": r["latency_ms"]})
                else:
                    models = await provider.adapter.list_models(key.secret)
                    results.append({"key": key.key_id, "ok": True, "models": models})
            except (ProviderError, httpx.HTTPError) as exc:
                results.append({"key": key.key_id, "ok": False, "error": str(exc)})
        return results

    def quota_snapshot(self) -> list[dict[str, Any]]:
        rows = []
        for provider_id, provider in self._providers.items():
            models = {m for ts in self._routes.values() for p, m in ts if p == provider_id}
            for key in provider.keys:
                for model in sorted(models):
                    limits = limits_for(provider.config.quota_profile, model)
                    rows.append({"provider": provider_id, "key": key.key_id, "model": model,
                                 **self.quota.snapshot(key.key_id, model, limits)})
        return rows

    def stats(self) -> dict[str, dict[str, float]]:
        return {pid: {"ok": s.ok, "failed": s.failed, "latency_ms": round(s.latency_ms)}
                for pid, s in self._stats.items()}

    async def aclose(self) -> None:
        await self.client.aclose()
