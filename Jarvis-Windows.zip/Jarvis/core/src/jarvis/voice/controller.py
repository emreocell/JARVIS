"""Voice controller: the turn-taking state machine.

States::

    idle ──wake/ptt──▶ armed ──speech──▶ listening ──silence──▶ thinking
      ▲                  │ (timeout)                              │ audio
      │                  ▼                                        ▼
      └──── follow_up ◀──────── playback finished ◀────────── speaking

* **idle** — only the local wake-word engine runs (worker thread). No cloud
  traffic, no event-loop wakeups.
* **armed** — woke up; the Live session is connecting in parallel and local
  VAD waits for the user to start talking (so we never stream silence).
* **listening** — ``activity_start`` sent; mic frames stream to Live until
  local VAD detects end of speech → ``activity_end``.
* **speaking** — model audio plays. Mic handling depends on the echo profile.
* **follow_up** — a short window where the user can continue without the wake
  word.

The Live session is closed after ``session_idle_seconds`` in idle.
"""

from __future__ import annotations

import asyncio
import contextlib
import logging
import threading
import time
from collections import deque
from collections.abc import Awaitable, Callable
from difflib import SequenceMatcher
from enum import StrEnum

import numpy as np
from google.genai import types

from jarvis.bus import EventBus
from jarvis.config.schema import EchoProfile, VoiceSettings
from jarvis.voice.audio import Microphone, Speaker, output_is_headset, rms_level
from jarvis.voice.detect import Endpointer, OpenWakeWordEngine, PhraseSpec, SileroVad, WakeEngine
from jarvis.voice.live import LiveCallbacks, LiveSession, LiveSettings

log = logging.getLogger(__name__)

ARMED_TIMEOUT = 6.0     # seconds to start talking after the wake word
ECHO_TAIL = 0.35        # room echo after the last played sample
PREROLL_FRAMES = 5      # ~400 ms kept so the first syllable isn't clipped
LEVEL_INTERVAL = 0.1    # UI meter update rate while active


class VoiceState(StrEnum):
    IDLE = "idle"
    ARMED = "armed"
    LISTENING = "listening"
    THINKING = "thinking"
    SPEAKING = "speaking"
    FOLLOW_UP = "follow_up"
    MUTED = "muted"
    ERROR = "error"


ToolHandler = Callable[[list[types.FunctionCall]], Awaitable[list[types.FunctionResponse]]]


def similar(a: str, b: str) -> float:
    a, b = a.lower().strip(), b.lower().strip()
    if not a or not b:
        return 0.0
    if a in b:
        return 1.0
    return SequenceMatcher(None, a, b).ratio()


class VoiceController:
    def __init__(
        self,
        bus: EventBus,
        settings: VoiceSettings,
        live_keys: Callable[[], list[tuple[str, str]]],
        system_instruction: Callable[[], str],
        tools: Callable[[], list[types.Tool]] = lambda: [],
        tool_handler: ToolHandler | None = None,
        *,
        mic: Microphone | None = None,
        speaker: Speaker | None = None,
        wake: WakeEngine | None = None,
        vad: Callable[[np.ndarray], float] | None = None,
        live_factory: Callable[..., LiveSession] = LiveSession,
        cascade_factory: Callable[[LiveCallbacks], object] | None = None,
        vocabulary: Callable[[], list[str]] | None = None,
    ) -> None:
        self._vocabulary = vocabulary or (lambda: [])
        self.meeting_mode = False   # meeting mode: never wake on the wake word (push-to-talk still works)
        self.call_mode = False      # the user is on a call (another app holds the microphone): same
        self.taps: list[Callable[[np.ndarray], None]] = []   # extra listeners on mic frames (sound events)
        self._live_factory = live_factory
        self._cascade_factory = cascade_factory
        self.pipeline = "live"  # which pipeline the current session uses
        self.bus = bus
        self.settings = settings
        self._live_keys = live_keys
        self._system_instruction = system_instruction
        self._tools = tools
        self._tool_handler = tool_handler
        self.mic = mic or Microphone(settings.input_device)
        self.speaker = speaker or Speaker(settings.output_device)
        self._wake = wake
        self._vad = vad
        self.endpointer = Endpointer()
        self.state = VoiceState.IDLE
        self.live: LiveSession | None = None
        self._loop: asyncio.AbstractEventLoop | None = None
        self._worker: threading.Thread | None = None
        self._stop_worker = threading.Event()
        self._preroll: deque[np.ndarray] = deque(maxlen=PREROLL_FRAMES)
        self._timers: dict[str, asyncio.TimerHandle] = {}
        self._watch: asyncio.Task[None] | None = None
        self._ptt = False
        self._last_level_emit = 0.0
        self._output_text = ""
        self._input_text = ""
        self._turn_complete = False
        self._after_tool = False  # a tool ran this turn; its reply comes in a continuation turn
        self._turn_seq = 0
        self._profile = EchoProfile.HALF_DUPLEX
        self.wake_rejected: dict[str, str] = {}
        self.wake_approx: dict[str, str] = {}
        self._wake_pending = False  # set by the audio thread, cleared once the loop armed
        self._meter_until = 0.0  # diagnostics: stream mic levels even in idle until this time
        self._outbox: asyncio.Queue[tuple[str, bytes | str | None]] = asyncio.Queue()
        self._sender_task: asyncio.Future[None] | None = None

    # ------------------------------------------------------------ helpers

    @property
    def echo_profile(self) -> EchoProfile:
        return self._profile

    def _resolve_profile(self) -> EchoProfile:
        p = self.settings.echo_profile
        if p is EchoProfile.AUTO:
            return EchoProfile.FULL_DUPLEX if output_is_headset(self.settings.output_device) else EchoProfile.HALF_DUPLEX
        return p

    def _set_state(self, state: VoiceState, **extra: object) -> None:
        if state is self.state and not extra:
            return
        log.debug("voice %s -> %s", self.state, state)
        self.state = state
        self.bus.emit("voice.state", state=state.value, **extra)
        self.bus.emit("state.changed", voice=_ui_state(state))

    def _timer(self, name: str, delay: float, fn: Callable[[], object]) -> None:
        self._cancel_timer(name)
        assert self._loop is not None
        self._timers[name] = self._loop.call_later(delay, fn)

    def _cancel_timer(self, name: str) -> None:
        handle = self._timers.pop(name, None)
        if handle:
            handle.cancel()

    def _spawn(self, coro: Awaitable[object]) -> None:
        task = asyncio.ensure_future(coro)
        task.add_done_callback(_log_task_error)

    # ---------------------------------------------------------- lifecycle

    async def start(self) -> None:
        self._loop = asyncio.get_running_loop()
        self._profile = self._resolve_profile()
        if self._wake is None:
            self._wake = await asyncio.to_thread(self._build_wake_engine)
        if self._vad is None:
            self._vad = await asyncio.to_thread(SileroVad)
        self._outbox = asyncio.Queue()
        self._sender_task = asyncio.ensure_future(self._sender())
        self.mic.start()
        self._stop_worker.clear()
        self._worker = threading.Thread(target=self._audio_worker, name="voice-audio", daemon=True)
        self._worker.start()
        self._set_state(VoiceState.IDLE)
        log.info("voice started (echo profile %s)", self.echo_profile.value)

    def _build_wake_engine(self) -> WakeEngine:
        """openWakeWord for its pretrained phrases, Vosk for everything else."""
        from jarvis.voice.detect import OWW_PRETRAINED
        from jarvis.voice.vosk_wake import MultiWakeEngine, VoskWakeEngine

        enabled = [w for w in self.settings.wake_words if w.enabled]
        oww = [PhraseSpec(w.phrase, w.sensitivity) for w in enabled
               if w.engine == "openwakeword" and w.phrase in OWW_PRETRAINED]
        custom = [PhraseSpec(w.phrase, w.sensitivity) for w in enabled
                  if not (w.engine == "openwakeword" and w.phrase in OWW_PRETRAINED)]
        engines: list = [OpenWakeWordEngine(oww)] if oww else []
        self.wake_rejected: dict[str, str] = {}
        self.wake_approx: dict[str, str] = {}
        if custom:
            try:
                vosk = VoskWakeEngine(custom)
                self.wake_rejected = vosk.rejected
                self.wake_approx = vosk.approximations
                engines.append(vosk)
            except Exception as exc:
                log.warning("custom wake phrases unavailable: %s", exc)
                self.wake_rejected = {p.phrase: f"Özel ifade motoru başlatılamadı: {exc}" for p in custom}
        self.bus.emit_threadsafe("voice.wake_rejected", phrases=self.wake_rejected, approx=self.wake_approx)
        return MultiWakeEngine(engines)

    async def stop(self) -> None:
        self._stop_worker.set()
        if self._worker:
            await asyncio.to_thread(self._worker.join, 2)
        if self._sender_task:
            self._sender_task.cancel()
            self._sender_task = None
        self.mic.stop()
        self.speaker.stop()
        for name in list(self._timers):
            self._cancel_timer(name)
        if self._watch:
            self._watch.cancel()
        if self.live:
            await self.live.close("stopped")
        self._set_state(VoiceState.MUTED)

    async def apply_settings(self, settings: VoiceSettings) -> None:
        """Hot-reload: restart audio only when devices / wake words changed."""
        old = self.settings
        self.settings = settings
        self._profile = self._resolve_profile()
        restart = (old.input_device != settings.input_device or old.output_device != settings.output_device
                   or old.wake_words != settings.wake_words)
        live_changed = (old.live_model, old.voice_name, old.language, old.mode, old.tts_voice, old.tts_engine) != (
            settings.live_model, settings.voice_name, settings.language, settings.mode, settings.tts_voice,
            settings.tts_engine)
        if live_changed and self.live:
            await self.live.close("settings changed")
            self.live = None
        if restart:
            await self.stop()
            self.mic = Microphone(settings.input_device)
            self.speaker = Speaker(settings.output_device)
            self._wake = None
            await self.start()

    # ------------------------------------------------------- audio worker

    def _audio_worker(self) -> None:
        """Runs in its own thread. In idle it only feeds the wake engine and
        never touches the event loop."""
        assert self._loop is not None and self._wake is not None and self._vad is not None
        loop = self._loop
        while not self._stop_worker.is_set():
            try:
                frame = self.mic.frames.get(timeout=0.5)
            except Exception:
                continue
            for tap in self.taps:
                try:
                    tap(frame)
                except Exception:
                    pass
            state = self.state
            if self._meter_until and time.monotonic() < self._meter_until:
                lvl = rms_level(frame)
                loop.call_soon_threadsafe(self._emit_level, lvl)
            if self._wake_pending:
                # the loop hasn't processed the wake yet; don't drop the words that follow it
                if state in (VoiceState.IDLE, VoiceState.FOLLOW_UP, VoiceState.SPEAKING):
                    state = VoiceState.ARMED
                else:
                    self._wake_pending = False
            profile = self.echo_profile if state is VoiceState.SPEAKING else None
            echo_window = self.speaker.playing(ECHO_TAIL)

            if echo_window and (profile is EchoProfile.HALF_DUPLEX or state is VoiceState.THINKING):
                continue  # mic deaf while we talk (half duplex)

            self._preroll.append(frame)

            if not self.meeting_mode and not self.call_mode and (state in (VoiceState.IDLE, VoiceState.FOLLOW_UP) or (
                state is VoiceState.SPEAKING and profile is not EchoProfile.HALF_DUPLEX
            )):
                phrase = self._wake.process(frame)
                if phrase:
                    self._wake_pending = True
                    loop.call_soon_threadsafe(self._on_wake, phrase)
                    continue

            if state in (VoiceState.ARMED, VoiceState.LISTENING, VoiceState.FOLLOW_UP) or (
                state is VoiceState.SPEAKING and profile is EchoProfile.FULL_DUPLEX
            ):
                prob = self._vad(frame)
                level = rms_level(frame)
                # while our own voice plays, require the user to be clearly louder than the echo
                if state is VoiceState.SPEAKING and level < max(0.12, self.speaker.level * 1.3):
                    prob = 0.0
                loop.call_soon_threadsafe(self._on_frame, frame, prob, level)

    # -------------------------------------------------- loop-side events

    def _emit_level(self, mic_level: float) -> None:
        now = time.monotonic()
        if now - self._last_level_emit >= LEVEL_INTERVAL:
            self._last_level_emit = now
            self.bus.emit("voice.level", mic=round(mic_level, 3), out=round(self.speaker.level, 3))

    def _on_wake(self, phrase: str) -> None:
        self.bus.emit("voice.wake", phrase=phrase)
        if self.state is VoiceState.SPEAKING:
            self._barge_in()
        self._arm()
        self._wake_pending = False

    def _arm(self) -> None:
        self._cancel_timer("close")
        self._cancel_timer("follow_up")
        self.endpointer.reset()
        self._set_state(VoiceState.ARMED)
        self._spawn(self._ensure_live())
        self._timer("armed", ARMED_TIMEOUT, self._armed_timeout)

    def _armed_timeout(self) -> None:
        if self.state is VoiceState.ARMED:
            self._go_idle()

    def _on_frame(self, frame: np.ndarray, prob: float, level: float) -> None:
        self._emit_level(level)
        state = self.state
        if state is VoiceState.LISTENING:
            self._send("audio", frame.tobytes())
            if not self._ptt and self.endpointer.update(prob) == "end":
                self._end_user_turn()
            return
        if state in (VoiceState.ARMED, VoiceState.FOLLOW_UP, VoiceState.SPEAKING):
            if self.endpointer.update(prob) == "start":
                if state is VoiceState.SPEAKING:
                    self._barge_in()
                self._start_user_turn()

    def _callbacks(self) -> LiveCallbacks:
        return LiveCallbacks(self._on_audio, self._on_input_text, self._on_output_text,
                             self._on_turn_complete, self._on_interrupted, self._on_tool_call,
                             self._on_live_closed)

    def _use_cascade(self, reason: str) -> LiveSession | None:
        assert self._cascade_factory is not None
        self.live = self._cascade_factory(self._callbacks())  # type: ignore[assignment]
        self.pipeline = "cascade"
        log.info("voice pipeline: cascade (%s)", reason)
        self.bus.emit("voice.pipeline", pipeline="cascade", reason=reason)
        return self.live

    async def _ensure_live(self) -> LiveSession | None:
        if self.live is None and self.settings.mode == "cascade" and self._cascade_factory:
            self._use_cascade("ayar")
        if self.live is None:
            self.pipeline = "live"
            self.live = self._live_factory(
                self._live_keys,
                LiveSettings(self.settings.live_model, self.settings.voice_name, self.settings.language,
                             self._system_instruction(), self._tools(),
                             vocabulary=[*(w.phrase for w in self.settings.wake_words if w.enabled),
                                         *self._vocabulary()]),
                self._callbacks(),
            )
        if not self.live.connected:
            try:
                await self.live.connect()
            except ConnectionError as exc:
                log.error("%s", exc)
                if self.pipeline == "live" and self.settings.cascade_fallback and self._cascade_factory:
                    live = self._use_cascade("Live bağlanamadı")
                    await live.connect()  # type: ignore[union-attr]
                    self.bus.emit("voice.notice", message="Live'a bağlanılamadı — kademeli hatla devam ediyorum.")
                    return live
                self.bus.emit("voice.error", message=str(exc))
                self._set_state(VoiceState.ERROR, message=str(exc))
                self._timer("recover", 3.0, self._go_idle)
                return None
        return self.live

    # All uplink traffic goes through one ordered outbox drained by a single
    # sender task: audio/activity markers can never be reordered, and frames
    # captured while the session is still connecting are not lost.

    def _send(self, kind: str, payload: bytes | str | None = None) -> None:
        self._outbox.put_nowait((kind, payload))

    async def _sender(self) -> None:
        while True:
            kind, payload = await self._outbox.get()
            live = await self._ensure_live()
            if live is None:
                while not self._outbox.empty():  # connection failed: drop this turn
                    self._outbox.get_nowait()
                continue
            try:
                if kind == "audio":
                    await live.send_audio(payload)  # type: ignore[arg-type]
                elif kind == "start":
                    await live.activity_start()
                elif kind == "end":
                    await live.activity_end()
                elif kind == "text":
                    await live.send_text(payload)  # type: ignore[arg-type]
            except Exception:
                log.exception("live send failed (%s)", kind)

    def _start_user_turn(self) -> None:
        self._cancel_timer("armed")
        self._cancel_timer("follow_up")
        self._set_state(VoiceState.LISTENING)
        self._input_text = ""
        self._turn_seq += 1
        self._send("start")
        for frame in list(self._preroll):
            self._send("audio", frame.tobytes())
        self._preroll.clear()

    def _end_user_turn(self) -> None:
        self._set_state(VoiceState.THINKING)
        self._turn_complete = False
        self._after_tool = False
        self._output_text = ""
        self._send("end")

    def _barge_in(self) -> None:
        log.info("barge-in")
        self.speaker.clear()
        self.bus.emit("voice.barge_in")

    # ------------------------------------------------- live callbacks

    def _on_audio(self, pcm: bytes) -> None:
        if self.state in (VoiceState.LISTENING, VoiceState.ARMED):
            return  # stale audio from an interrupted turn
        self.speaker.write(pcm)
        if self.state is not VoiceState.SPEAKING:
            self._set_state(VoiceState.SPEAKING)
            if self._watch is None or self._watch.done():
                self._watch = asyncio.ensure_future(self._watch_playback())

    async def _watch_playback(self) -> None:
        """Poll playback only while speaking (never in idle)."""
        while self.state is VoiceState.SPEAKING:
            await asyncio.sleep(0.1)
            if self._turn_complete and not self.speaker.playing(ECHO_TAIL):
                self._enter_follow_up()
                return

    def _on_input_text(self, text: str) -> None:
        self._input_text += text
        # echo text filter: if what we "heard" is what we just said, it was our own voice
        if (self.settings.echo_text_filter and self._output_text
                and similar(self._input_text, self._output_text) > 0.75):
            log.info("echo transcript ignored: %r", self._input_text)
            self.bus.emit("voice.echo_ignored", text=self._input_text)
            return
        self.bus.emit("voice.transcript", role="user", text=self._input_text, turn=self._turn_seq)

    def _on_output_text(self, text: str) -> None:
        self._output_text += text
        self.bus.emit("voice.transcript", role="assistant", text=self._output_text)

    def _on_turn_complete(self) -> None:
        if self._after_tool and not self._output_text.strip():
            # Live closes the tool-call turn first; the spoken answer follows in a
            # continuation turn. Wait for it (but never forever: tool-only turns exist).
            self._after_tool = False
            self._timer("tool_followup", 8.0, self._on_turn_complete)
            return
        self._cancel_timer("tool_followup")
        self._after_tool = False
        self._turn_complete = True
        if self.state is VoiceState.THINKING:  # tool-only or empty turn
            self._enter_follow_up()
        self.bus.emit("voice.turn_complete", user=self._input_text, assistant=self._output_text)

    def _on_interrupted(self) -> None:
        self.speaker.clear()

    async def _on_tool_call(self, calls: list[types.FunctionCall]) -> list[types.FunctionResponse]:
        self._after_tool = True
        if self._tool_handler is None:
            return [types.FunctionResponse(id=c.id, name=c.name,
                                           response={"error": "tool runtime not available"}) for c in calls]
        return await self._tool_handler(calls)

    def _on_live_closed(self, reason: str) -> None:
        self.bus.emit("voice.session", connected=False, reason=reason)
        if self.pipeline == "cascade" and self.settings.mode != "cascade":
            self.live = None  # fallback was per-conversation: try Live again next time
        if self.state not in (VoiceState.IDLE, VoiceState.MUTED, VoiceState.ERROR):
            self._go_idle()

    # ------------------------------------------------------- transitions

    def _enter_follow_up(self) -> None:
        if self.settings.follow_up_seconds <= 0:
            self._go_idle()
            return
        self.endpointer.reset()
        self._set_state(VoiceState.FOLLOW_UP)
        self._timer("follow_up", self.settings.follow_up_seconds, self._go_idle)

    def _go_idle(self) -> None:
        self._cancel_timer("armed")
        self._cancel_timer("follow_up")
        self._ptt = False
        self.endpointer.reset()
        self._set_state(VoiceState.IDLE)
        if self.live and self.live.connected:
            self._timer("close", self.settings.session_idle_seconds,
                        lambda: self._spawn(self._close_live()))

    async def _close_live(self) -> None:
        if self.live and self.state is VoiceState.IDLE:
            await self.live.close("idle")

    # ------------------------------------------------------- public API

    async def push_to_talk(self, pressed: bool) -> None:
        if pressed:
            if self.state is VoiceState.SPEAKING:
                self._barge_in()
            self._ptt = True
            self._cancel_timer("close")
            self._preroll.clear()  # don't send whatever was said before the key press
            self._start_user_turn()
        elif self._ptt:
            self._ptt = False
            if self.state is VoiceState.LISTENING:
                self._end_user_turn()

    def meter(self, seconds: float) -> None:
        """Diagnostics: emit mic levels for ``seconds`` even while idle."""
        self._meter_until = time.monotonic() + max(0.0, min(seconds, 60.0))

    async def wake(self) -> None:
        """Programmatic wake (tray click, UI mic button)."""
        self._on_wake("manual")

    async def say(self, text: str, show: bool = True) -> None:
        """Send a typed message through the voice session (answer is spoken).

        ``show=False`` is for system notices (background results, UI approvals):
        they are not shown as user messages and never count as the user's
        answer to a confirmation question."""
        if not show:
            self._cancel_timer("close")
            self._input_text = ""  # the notice is not something the user said
            self._send("text", text)
            return
        self._cancel_timer("close")
        self._cancel_timer("follow_up")
        if self.state is VoiceState.SPEAKING:
            self._barge_in()
        self._set_state(VoiceState.THINKING)
        self._turn_complete = False
        self._output_text = ""
        self._turn_seq += 1
        self.bus.emit("voice.transcript", role="user", text=text, turn=self._turn_seq)
        self._send("text", text)


def _ui_state(state: VoiceState) -> str:
    return {
        VoiceState.ARMED: "listening",
        VoiceState.FOLLOW_UP: "listening",
    }.get(state, state.value)


def _log_task_error(task: asyncio.Future[object]) -> None:
    with contextlib.suppress(asyncio.CancelledError):
        exc = task.exception()
        if exc:
            log.error("voice task failed", exc_info=exc)
