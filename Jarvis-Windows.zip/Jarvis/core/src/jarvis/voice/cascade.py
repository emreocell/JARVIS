"""Cascade voice pipeline: speech → text → agent → speech.

A drop-in replacement for :class:`~jarvis.voice.live.LiveSession` (same
methods and callbacks), used when the user picks the "cascade" mode or when
Live can't connect. The turn-taking state machine in the controller doesn't
know the difference.

* STT: the ``stt`` role (Groq Whisper, then Gemini flash-lite audio input).
* Brain: the text agent — tools, memory and the no-LLM fast commands.
* TTS: Microsoft Edge neural voices (free, unlimited), Gemini TTS as fallback.
  Replies are spoken sentence by sentence so the first words come quickly.
"""

from __future__ import annotations

import asyncio
import contextlib
import io
import logging
import re
import wave
from collections.abc import AsyncIterator, Awaitable, Callable

from jarvis.voice.live import LiveCallbacks

log = logging.getLogger(__name__)

IN_RATE, OUT_RATE = 16_000, 24_000
MIN_SPEECH_SECONDS = 0.35
MAX_TURN_SECONDS = 60

Transcribe = Callable[[bytes], Awaitable[str]]
Respond = Callable[[str], Awaitable[str]]


def pcm_to_wav(pcm: bytes, rate: int = IN_RATE) -> bytes:
    buf = io.BytesIO()
    with wave.open(buf, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(rate)
        w.writeframes(pcm)
    return buf.getvalue()


_MD = re.compile(r"[*_`#>|~]+|\[([^\]]*)\]\([^)]*\)")


def speakable(text: str) -> str:
    """Strip markdown/emoji noise that TTS would read out loud."""
    text = _MD.sub(lambda m: m.group(1) or " ", text)
    text = re.sub(r"^\s*[-•]\s+", "", text, flags=re.M)
    text = "".join(c for c in text if c.isprintable() and not (0x1F000 <= ord(c) <= 0x1FFFF))
    return re.sub(r"\s+", " ", text).strip()


def sentences(text: str, min_len: int = 40, first_min: int = 12) -> list[str]:
    """Split for incremental TTS. The first chunk may be short (quick first
    words); later short pieces are merged forward (fewer requests)."""
    parts = [p.strip() for p in re.split(r"(?<=[.!?…:;])\s+", text) if p.strip()]
    out: list[str] = []
    for p in parts:
        if out and len(out[-1]) < (first_min if len(out) == 1 else min_len):
            out[-1] = f"{out[-1]} {p}"
        else:
            out.append(p)
    return out


class Synthesizer:
    """Edge neural TTS with an optional fallback (e.g. Gemini TTS)."""

    def __init__(self, voice: str, fallback: Callable[[str], Awaitable[bytes]] | None = None,
                 engine: str = "edge") -> None:
        self.voice = voice
        self.fallback = fallback
        self.engine = engine

    async def _edge(self, text: str) -> bytes:
        import edge_tts
        import miniaudio

        mp3 = bytearray()
        async for chunk in edge_tts.Communicate(text, self.voice).stream():
            if chunk["type"] == "audio":
                mp3 += chunk["data"]
        if not mp3:
            raise RuntimeError("edge-tts returned no audio")
        decoded = await asyncio.to_thread(
            miniaudio.decode, bytes(mp3), output_format=miniaudio.SampleFormat.SIGNED16,
            nchannels=1, sample_rate=OUT_RATE)
        return decoded.samples.tobytes()

    async def pcm(self, text: str) -> bytes:
        if self.engine == "gemini" and self.fallback:
            return await self.fallback(text)
        try:
            return await asyncio.wait_for(self._edge(text), timeout=15)
        except Exception as exc:
            if self.fallback is None:
                raise
            log.warning("edge tts failed (%s); using fallback", exc)
            return await self.fallback(text)

    async def stream(self, text: str) -> AsyncIterator[bytes]:
        """Yield PCM per sentence; the next sentence is synthesized while
        the previous one plays."""
        parts = sentences(speakable(text))
        if not parts:
            return
        pending = asyncio.ensure_future(self.pcm(parts[0]))
        for nxt in [*parts[1:], None]:
            audio = await pending
            if nxt is not None:
                pending = asyncio.ensure_future(self.pcm(nxt))
            yield audio


class CascadeSession:
    def __init__(self, transcribe: Transcribe, respond: Respond, synth: Synthesizer,
                 callbacks: LiveCallbacks) -> None:
        self._transcribe = transcribe
        self._respond = respond
        self.synth = synth
        self.cb = callbacks
        self._connected = False
        self._buf = bytearray()
        self._task: asyncio.Task[None] | None = None
        self.key_id = "cascade"

    @property
    def connected(self) -> bool:
        return self._connected

    async def connect(self) -> None:
        self._connected = True  # nothing to dial: every stage is a one-shot request

    async def close(self, reason: str = "idle") -> None:
        was = self._connected
        self._connected = False
        await self._cancel()
        if was:
            self.cb.on_closed(reason)

    async def _cancel(self) -> None:
        task, self._task = self._task, None
        if task and not task.done() and task is not asyncio.current_task():
            task.cancel()
            with contextlib.suppress(asyncio.CancelledError, Exception):
                await task

    # -------------------------------------------------- LiveSession API

    async def activity_start(self) -> None:
        await self._cancel()  # the user started talking again: drop the old answer
        self._buf.clear()

    async def send_audio(self, pcm16k: bytes) -> None:
        if len(self._buf) < MAX_TURN_SECONDS * IN_RATE * 2:
            self._buf += pcm16k

    async def activity_end(self) -> None:
        audio, self._buf = bytes(self._buf), bytearray()
        self._task = asyncio.create_task(self._turn(audio=audio))

    async def send_text(self, text: str) -> None:
        await self._cancel()
        self._task = asyncio.create_task(self._turn(text=text))

    async def send_image(self, jpeg: bytes) -> None:
        pass  # screen frames are a Live feature; tools can still look at the screen

    # ------------------------------------------------------------ turn

    async def _turn(self, audio: bytes | None = None, text: str | None = None) -> None:
        cancelled = False
        try:
            if audio is not None:
                if len(audio) < MIN_SPEECH_SECONDS * IN_RATE * 2:
                    return
                text = (await self._transcribe(pcm_to_wav(audio))).strip()
                if not text:
                    return
                self.cb.on_input_text(text)
            assert text is not None
            reply = (await self._respond(text)).strip() or "Tamam."
            self.cb.on_output_text(reply)
            async for pcm in self.synth.stream(reply):
                self.cb.on_audio(pcm)
        except asyncio.CancelledError:
            cancelled = True  # replaced by a newer turn — it reports its own completion
            raise
        except Exception as exc:
            log.warning("cascade turn failed: %s", exc)
            self.cb.on_output_text(f"Şu an cevap veremiyorum ({type(exc).__name__}).")
        finally:
            if not cancelled:
                self.cb.on_turn_complete()
