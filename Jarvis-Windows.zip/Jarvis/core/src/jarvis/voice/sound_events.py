"""Sound events (experimental): hear the phone ring, the doorbell, an alarm.

Uses YAMNet (Google's AudioSet classifier, 521 classes) through onnxruntime
on the microphone stream Jarvis already has. Runs only when the room is
louder than its noise floor, a ~10 ms inference every half second, so idle
cost stays near zero.

The model is NOT bundled: the user enables the feature in Settings and the
file is downloaded then (source shown there). Reactions:
* phone ringing while Jarvis talks → it stops and waits for the call;
* doorbell / knock → a quiet note ("kapı çalıyor olabilir");
* alarm / smoke alarm / baby crying → a high-priority proactive message.
"""

from __future__ import annotations

import csv
import logging
import threading
import time
from collections import deque
from pathlib import Path
from typing import Any

import numpy as np

from jarvis import paths

log = logging.getLogger(__name__)

MODEL_URL = "https://huggingface.co/andrelgomes/yamnet-onnx/resolve/main/yamnet.onnx"
CLASSMAP_URL = "https://raw.githubusercontent.com/tensorflow/models/master/research/audioset/yamnet/yamnet_class_map.csv"
RATE = 16000
WINDOW = int(0.975 * RATE)
HOP = RATE // 2
EVENTS = {
    "phone": ("Telephone bell ringing", "Ringtone", "Telephone dialing, DTMF"),
    "doorbell": ("Doorbell", "Ding-dong", "Knock"),
    "alarm": ("Alarm", "Smoke detector, smoke alarm", "Fire alarm", "Alarm clock", "Siren", "Buzzer"),
    "baby": ("Baby cry, infant cry",),
}
THRESHOLD = {"phone": 0.35, "doorbell": 0.4, "alarm": 0.45, "baby": 0.5}
COOLDOWN = 60.0


def model_dir() -> Path:
    return paths.data_dir() / "models" / "yamnet"


def available() -> bool:
    d = model_dir()
    return (d / "yamnet.onnx").exists() and (d / "yamnet_class_map.csv").exists()


def download() -> None:
    """Fetch the model + class map (called only after the user enabled the feature)."""
    import httpx

    d = model_dir()
    d.mkdir(parents=True, exist_ok=True)
    for url, name in ((MODEL_URL, "yamnet.onnx"), (CLASSMAP_URL, "yamnet_class_map.csv")):
        with httpx.stream("GET", url, follow_redirects=True, timeout=120) as r:
            r.raise_for_status()
            tmp = d / (name + ".part")
            with open(tmp, "wb") as f:
                for chunk in r.iter_bytes(1 << 16):
                    f.write(chunk)
            tmp.replace(d / name)


class SoundEvents:
    def __init__(self, on_event: Any) -> None:
        self.on_event = on_event          # called (kind, score) from the worker thread
        self._buf: deque[np.ndarray] = deque()
        self._samples = 0
        self._last: dict[str, float] = {}
        self._noise = 0.01
        self._lock = threading.Lock()
        self._session: Any = None
        self._index: dict[str, list[int]] = {}
        self._since = 0

    def load(self) -> bool:
        if not available():
            return False
        import onnxruntime as ort

        d = model_dir()
        self._session = ort.InferenceSession(str(d / "yamnet.onnx"), providers=["CPUExecutionProvider"])
        names = {}
        with open(d / "yamnet_class_map.csv", encoding="utf-8") as f:
            for row in csv.DictReader(f):
                names[row["display_name"]] = int(row["index"])
        self._index = {k: [names[n] for n in v if n in names] for k, v in EVENTS.items()}
        log.info("sound events: YAMNet loaded")
        return True

    def feed(self, frame: np.ndarray) -> None:
        """Mic frames (int16, 16 kHz) from the audio worker thread."""
        if self._session is None:
            return
        x = frame.astype(np.float32) / 32768.0
        level = float(np.sqrt(np.mean(x * x)))
        self._noise = 0.995 * self._noise + 0.005 * level if level < self._noise * 2 else self._noise
        with self._lock:
            self._buf.append(x)
            self._samples += len(x)
            while self._samples - len(self._buf[0]) >= WINDOW:
                self._samples -= len(self._buf.popleft())
            self._since += len(x)
            if self._samples < WINDOW or self._since < HOP:
                return
            self._since = 0
            if level < max(0.02, self._noise * 4):   # quiet room: skip inference
                return
            wave = np.concatenate(self._buf)[-WINDOW:]
        self._classify(wave)

    def _classify(self, wave: np.ndarray) -> None:
        try:
            scores = self._session.run(None, {self._session.get_inputs()[0].name: wave})[0].max(axis=0)
        except Exception:
            log.debug("yamnet failed", exc_info=True)
            return
        now = time.time()
        for kind, idx in self._index.items():
            if not idx:
                continue
            score = float(max(scores[i] for i in idx))
            if score >= THRESHOLD[kind] and now - self._last.get(kind, 0) > COOLDOWN:
                self._last[kind] = now
                self.on_event(kind, score)
