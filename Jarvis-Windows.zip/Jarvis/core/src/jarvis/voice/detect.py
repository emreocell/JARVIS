"""Wake-word detection and voice-activity endpointing.

Both run fully locally on CPU. Engines are pluggable: openWakeWord ships a
pretrained ``hey jarvis`` model; open-vocabulary phrases (Turkish custom
wake words) will plug in through :class:`WakeEngine` (Vosk, planned).
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Protocol

import numpy as np

log = logging.getLogger(__name__)


class WakeEngine(Protocol):
    def process(self, frame: np.ndarray) -> str | None:
        """Feed one 80 ms int16 frame; return the detected phrase or None."""

    def reset(self) -> None: ...


def _oww_models_dir() -> Path:
    import openwakeword

    return Path(openwakeword.__file__).parent / "resources" / "models"


# phrase -> bundled model file stem
OWW_PRETRAINED = {
    "hey jarvis": "hey_jarvis_v0.1",
    "hey mycroft": "hey_mycroft_v0.1",
    "hey marvin": "hey_marvin_v0.1",
    "alexa": "alexa_v0.1",
}


def _load_oww(model_cls, paths: list[str]):
    """openWakeWord renamed its constructor args between 0.4 and 0.6."""
    try:
        return model_cls(wakeword_models=paths, inference_framework="onnx")
    except TypeError:
        return model_cls(wakeword_model_paths=paths)


@dataclass(slots=True)
class PhraseSpec:
    phrase: str
    sensitivity: float  # 0..1, higher = triggers more easily


class OpenWakeWordEngine:
    """openWakeWord with the bundled ONNX models (no downloads)."""

    def __init__(self, phrases: list[PhraseSpec], refractory: float = 1.5) -> None:
        from openwakeword.model import Model

        self._by_model: dict[str, PhraseSpec] = {}
        paths = []
        for spec in phrases:
            stem = OWW_PRETRAINED.get(spec.phrase)
            if stem is None:
                log.warning("openWakeWord has no model for %r (needs a custom engine)", spec.phrase)
                continue
            paths.append(str(_oww_models_dir() / f"{stem}.onnx"))
            self._by_model[stem] = spec
        self.available = bool(paths)
        self._model = _load_oww(Model, paths) if paths else None
        self._refractory = refractory
        self._last = 0.0
        pre = getattr(self._model, "preprocessor", None)
        # blank feature state, restored on reset (Model.reset() only clears predictions)
        self._blank = (pre.melspectrogram_buffer.copy(), pre.feature_buffer.copy()) if pre is not None else None

    def process(self, frame: np.ndarray) -> str | None:
        if self._model is None:
            return None
        scores = self._model.predict(frame)
        now = time.monotonic()
        if now - self._last < self._refractory:
            return None
        for name, score in scores.items():
            spec = self._by_model.get(name)
            # sensitivity 0.5 -> threshold 0.5; 0.8 -> 0.2 (easier)
            if spec and score >= 1.0 - spec.sensitivity:
                self._last = now
                self.reset()
                log.info("wake word %r (score %.2f)", spec.phrase, score)
                return spec.phrase
        return None

    def reset(self) -> None:
        """Forget everything heard so far. openWakeWord keeps ~10 s of audio
        and embeddings in its preprocessor; without clearing them the same
        "hey jarvis" fires again as soon as detection resumes."""
        if self._model is None:
            return
        self._model.reset()
        pre = getattr(self._model, "preprocessor", None)
        if pre is not None and self._blank is not None:
            pre.raw_data_buffer.clear()
            pre.accumulated_samples = 0
            pre.melspectrogram_buffer = self._blank[0].copy()
            pre.feature_buffer = self._blank[1].copy()


class SpeechProbability(Protocol):
    def __call__(self, frame: np.ndarray) -> float: ...


class SileroVad:
    """Silero VAD via the model bundled with openWakeWord."""

    def __init__(self) -> None:
        from openwakeword.vad import VAD

        self._vad = VAD(model_path=str(_oww_models_dir() / "silero_vad.onnx"))

    def __call__(self, frame: np.ndarray) -> float:
        return float(self._vad.predict(frame, frame_size=640))

    def reset(self) -> None:
        self._vad.reset_states()


class Endpointer:
    """Turns per-frame speech probabilities into start / end-of-utterance events.

    ``update`` returns ``"start"`` once speech has been seen for
    ``start_frames`` consecutive frames, ``"end"`` after ``end_silence``
    seconds of silence following speech, otherwise None.
    """

    def __init__(self, threshold: float = 0.5, start_frames: int = 2,
                 end_silence: float = 0.7, frame_seconds: float = 0.08,
                 max_utterance: float = 30.0) -> None:
        self.threshold = threshold
        self.start_frames = start_frames
        self.end_frames = max(1, round(end_silence / frame_seconds))
        self.max_frames = round(max_utterance / frame_seconds)
        self.reset()

    def reset(self) -> None:
        self.in_speech = False
        self._voiced = 0
        self._silent = 0
        self._length = 0

    def update(self, prob: float) -> str | None:
        voiced = prob >= self.threshold
        if not self.in_speech:
            self._voiced = self._voiced + 1 if voiced else 0
            if self._voiced >= self.start_frames:
                self.in_speech, self._silent, self._length = True, 0, self._voiced
                return "start"
            return None
        self._length += 1
        self._silent = 0 if voiced else self._silent + 1
        if self._silent >= self.end_frames or self._length >= self.max_frames:
            self.reset()
            return "end"
        return None
