"""User-defined wake phrases (Turkish or English) with Vosk grammar mode.

Vosk restricts recognition to the given phrases at runtime — no training.
Two safety rules learned from testing:
* the *whole* phrase must be heard ("dostlar" must not fire "uyan dostum");
* words missing from the model vocabulary are silently dropped by Vosk
  ("naber jarvis" would become just "naber"). Unknown words are therefore
  spelled phonetically ("jarvis" -> "carvis") and split into sound-alike
  words the model knows ("car vi is"); only if that fails is the phrase
  rejected and reported to the UI.
"""

from __future__ import annotations

import itertools
import json
import logging
import re
import tempfile
import time
import zipfile
from collections.abc import Callable
from pathlib import Path

import numpy as np

from jarvis import paths
from jarvis.skills.text import norm
from jarvis.voice.detect import PhraseSpec

log = logging.getLogger(__name__)

MODEL_NAME = "vosk-model-small-tr-0.3"
MODEL_URL = f"https://alphacephei.com/vosk/models/{MODEL_NAME}.zip"


def model_dir() -> Path:
    return paths.data_dir() / "models" / MODEL_NAME


def ensure_model() -> Path:
    """Download the 36 MB Turkish model on first use."""
    target = model_dir()
    if (target / "final.mdl").exists():
        return target
    import httpx

    target.parent.mkdir(parents=True, exist_ok=True)
    log.info("downloading %s", MODEL_URL)
    with tempfile.TemporaryDirectory() as tmp:
        archive = Path(tmp) / "model.zip"
        with httpx.stream("GET", MODEL_URL, follow_redirects=True, timeout=120) as r:
            r.raise_for_status()
            with archive.open("wb") as fh:
                for chunk in r.iter_bytes():
                    fh.write(chunk)
        zipfile.ZipFile(archive).extractall(target.parent)
    return target


# ------------------------------------------------------------ phonetics

def grammar_text(phrase: str) -> str:
    """Lowercase (Turkish rules) and drop punctuation but keep diacritics —
    the model's lexicon spells "günaydın", not "gunaydin"."""
    t = phrase.replace("I", "ı").replace("İ", "i").lower()
    t = re.sub(r"[^\w\s]", " ", t)
    return re.sub(r"\s+", " ", t).strip()


_EN_HINT = re.compile(r"[jwxq]|sh|ch|th|ph|ee|oo")
_EN_RULES = [("sh", "ş"), ("ch", "ç"), ("th", "t"), ("ph", "f"), ("ee", "i"), ("oo", "u"),
             ("ck", "k"), ("j", "c"), ("w", "v"), ("x", "ks"), ("q", "k")]
_VOWELS = set("aeıioöuü")
_ALTS = {"i": "ı", "ı": "i", "s": "z", "z": "s", "a": "e", "e": "a", "o": "u", "u": "o"}


def turkish_spelling(word: str) -> str:
    """Rough English -> Turkish phonetic spelling, applied only to words that
    look English (j/w/x/q or English digraphs): "jarvis" -> "carvis"."""
    if not _EN_HINT.search(word):
        return word
    for a, b in _EN_RULES:
        word = word.replace(a, b)
    return word


def _variants(word: str, max_changes: int = 2):
    """The word itself, then spellings with 1..max_changes similar-sound swaps."""
    yield word, 0
    spots = [i for i, c in enumerate(word) if c in _ALTS]
    for n in range(1, max_changes + 1):
        for combo in itertools.combinations(spots, n):
            chars = list(word)
            for i in combo:
                chars[i] = _ALTS[chars[i]]
            yield "".join(chars), n


def _segment(s: str, known: Callable[[str], bool]) -> tuple[float, list[str]] | None:
    """Cheapest split of s into known pieces. Pieces must be 2+ letters with a
    vowel (single letters and abbreviations are pronounced by name: "v" is
    read "ve"); adjacent pieces may share one letter at a small cost."""
    best: dict[int, tuple[float, list[str]]] = {0: (0.0, [])}
    for end in range(2, len(s) + 1):
        for start in range(max(0, end - 12), end - 1):
            piece = s[start:end]
            if not (_VOWELS & set(piece)) or not known(piece):
                continue
            for prev, overlap in ((start, 0.0), (start + 1, 0.6)):
                if prev not in best or (overlap and start == 0):
                    continue
                cost = best[prev][0] + 1.0 + overlap
                if end not in best or cost < best[end][0]:
                    best[end] = (cost, [*best[prev][1], piece])
    return best.get(len(s))


def sounds_like(word: str, known: Callable[[str], bool]) -> list[str] | None:
    """Known words that, said in a row, sound like an out-of-vocabulary word
    ("carvis" -> ["car", "vi", "is"]), or None."""
    best: tuple[float, list[str]] | None = None
    candidates = [(word, 0.0)]
    if (tr := turkish_spelling(word)) != word:
        candidates.append((tr, 0.2))
    for base, extra in candidates:
        for variant, changes in _variants(base):
            found = _segment(variant, known)
            if found is None:
                continue
            cost = found[0] + extra + 0.4 * changes
            if best is None or cost < best[0]:
                best = (cost, found[1])
    return best[1] if best else None


# --------------------------------------------------------------- engine

class VoskWakeEngine:
    def __init__(self, phrases: list[PhraseSpec], refractory: float = 1.5) -> None:
        from vosk import KaldiRecognizer, Model, SetLogLevel

        SetLogLevel(-1)
        self.model = Model(str(ensure_model()))
        self._vocab: dict[str, bool] = {}
        self.rejected: dict[str, str] = {}
        self.approximations: dict[str, str] = {}
        self.phrases: dict[str, PhraseSpec] = {}  # grammar phrase -> spec
        for spec in phrases:
            words, unknown = self.expand(spec.phrase)
            if unknown:
                self.rejected[spec.phrase] = "Türkçe modelde karşılığı bulunamayan kelime: " + ", ".join(unknown)
                continue
            key = " ".join(words)
            if key != grammar_text(spec.phrase) and len(grammar_text(spec.phrase).split()) < 2:
                # measured: a lone sound-alike word fires on "car wheels", "service"...
                self.rejected[spec.phrase] = ("Tek kelimelik yabancı ifadeler yanlış tetiklenir; "
                                              "önüne bir kelime ekleyin (ör. “hey …”, “naber …”).")
                continue
            self.phrases[key] = spec
            if key != grammar_text(spec.phrase):
                self.approximations[spec.phrase] = key
        if self.approximations:
            log.info("wake phrases approximated: %s", self.approximations)
        if self.rejected:
            log.warning("wake phrases rejected: %s", self.rejected)
        self.available = bool(self.phrases)
        self._keys = {norm(k): spec for k, spec in self.phrases.items()}
        self._rec = (KaldiRecognizer(self.model, 16000, json.dumps([*self.phrases, "[unk]"], ensure_ascii=False))
                     if self.available else None)
        self._refractory = refractory
        self._last = 0.0

    def known(self, word: str) -> bool:
        hit = self._vocab.get(word)
        if hit is None:
            hit = self._vocab[word] = self.model.vosk_model_find_word(word) >= 0
        return hit

    def expand(self, phrase: str) -> tuple[list[str], list[str]]:
        """Grammar words for a phrase, plus the words that couldn't be mapped."""
        words: list[str] = []
        unknown: list[str] = []
        for w in grammar_text(phrase).split():
            if self.known(w):
                words.append(w)
            elif (parts := sounds_like(w, self.known)) is not None:
                words.extend(parts)
            else:
                unknown.append(w)
        return words, unknown

    def _match(self, text: str) -> str | None:
        heard = f" {norm(text)} "
        for key, spec in self._keys.items():
            if f" {key} " in heard:
                return spec.phrase
        return None

    def process(self, frame: np.ndarray) -> str | None:
        if self._rec is None:
            return None
        final = self._rec.AcceptWaveform(frame.tobytes())
        text = json.loads(self._rec.Result() if final else self._rec.PartialResult()).get(
            "text" if final else "partial", "")
        if not text:
            return None
        phrase = self._match(text)
        if phrase is None:
            return None
        now = time.monotonic()
        self._rec.Reset()
        if now - self._last < self._refractory:
            return None
        self._last = now
        log.info("custom wake phrase %r", phrase)
        return phrase

    def reset(self) -> None:
        if self._rec is not None:
            self._rec.Reset()


class MultiWakeEngine:
    """Runs several engines on the same audio (openWakeWord + Vosk)."""

    def __init__(self, engines: list) -> None:
        self.engines = [e for e in engines if getattr(e, "available", True)]

    @property
    def available(self) -> bool:
        return bool(self.engines)

    def process(self, frame: np.ndarray) -> str | None:
        for e in self.engines:
            hit = e.process(frame)
            if hit:
                return hit
        return None

    def reset(self) -> None:
        for e in self.engines:
            e.reset()
