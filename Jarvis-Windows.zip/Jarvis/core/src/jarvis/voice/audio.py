"""Microphone capture and speaker playback (sounddevice / PortAudio).

Capture: 16 kHz mono int16 in 80 ms frames (1280 samples) — the frame size
openWakeWord and our VAD expect, and what Gemini Live accepts.
Playback: 24 kHz mono int16 (Gemini Live output format).

PortAudio callbacks run on their own thread. Frames are handed over through
a thread-safe queue; the heavy consumer (wake word) runs in a worker thread
so the asyncio loop stays idle when nothing is happening.
"""

from __future__ import annotations

import logging
import queue
import re
import threading
import time
from collections import deque

import numpy as np
import sounddevice as sd

log = logging.getLogger(__name__)

IN_RATE = 16_000
OUT_RATE = 24_000
FRAME_SAMPLES = 1280  # 80 ms @ 16 kHz
FRAME_SECONDS = FRAME_SAMPLES / IN_RATE

_HEADSET_RE = re.compile(r"headset|headphone|kulakl|earbud|airpods|buds|hands-free|kulaklık", re.I)


def rms_level(frame: np.ndarray) -> float:
    """0..1 loudness for UI meters (roughly perceptual)."""
    if frame.size == 0:
        return 0.0
    rms = float(np.sqrt(np.mean(frame.astype(np.float32) ** 2))) / 32768.0
    return min(1.0, rms * 6.0)


def find_device(name: str | None, kind: str) -> int | None:
    """Resolve a device by (partial) name; ``None`` means system default."""
    if not name:
        return None
    key = "max_input_channels" if kind == "input" else "max_output_channels"
    for idx, dev in enumerate(sd.query_devices()):
        if dev[key] > 0 and name.lower() in dev["name"].lower():
            return idx
    log.warning("%s device %r not found, using default", kind, name)
    return None


def list_devices() -> dict[str, list[str]]:
    devices = sd.query_devices()
    hostapi = sd.default.hostapi if hasattr(sd.default, "hostapi") else None
    def names(key: str) -> list[str]:
        seen: list[str] = []
        for dev in devices:
            if dev[key] > 0 and (hostapi is None or dev["hostapi"] == hostapi) and dev["name"] not in seen:
                seen.append(dev["name"])
        return seen
    return {"inputs": names("max_input_channels"), "outputs": names("max_output_channels")}


def output_is_headset(device: str | None) -> bool:
    try:
        idx = find_device(device, "output")
        info = sd.query_devices(idx if idx is not None else sd.default.device[1])
        return bool(_HEADSET_RE.search(info["name"]))
    except Exception:
        return False


class Microphone:
    """Continuous capture into a bounded queue of int16 frames."""

    def __init__(self, device: str | None = None, max_frames: int = 64) -> None:
        self.device = device
        self.frames: queue.Queue[np.ndarray] = queue.Queue(maxsize=max_frames)
        self._stream: sd.InputStream | None = None
        self.injecting = False

    def inject(self, pcm: np.ndarray) -> threading.Thread:
        """Developer/test hook: play ``pcm`` (16 kHz int16) into the pipeline
        in real time instead of the physical microphone."""
        def feed() -> None:
            self.injecting = True
            try:
                silence = np.zeros(FRAME_SAMPLES * 6, dtype=np.int16)
                data = np.concatenate([silence, pcm.astype(np.int16), silence, silence])
                for i in range(0, len(data) - FRAME_SAMPLES + 1, FRAME_SAMPLES):
                    self.frames.put(data[i:i + FRAME_SAMPLES].copy(), timeout=1)
                    time.sleep(FRAME_SECONDS)
            finally:
                self.injecting = False
        t = threading.Thread(target=feed, name="mic-inject", daemon=True)
        t.start()
        return t

    def _callback(self, indata, frames, time_info, status) -> None:  # PortAudio thread
        if self.injecting:
            return  # a test clip is playing into the pipeline instead
        if status:
            log.debug("mic status: %s", status)
        frame = indata[:, 0].copy()
        try:
            self.frames.put_nowait(frame)
        except queue.Full:
            # consumer stalled — drop the oldest frame rather than blocking PortAudio
            try:
                self.frames.get_nowait()
            except queue.Empty:
                pass
            self.frames.put_nowait(frame)

    def start(self) -> None:
        if self._stream is not None:
            return
        self._stream = sd.InputStream(
            samplerate=IN_RATE, channels=1, dtype="int16", blocksize=FRAME_SAMPLES,
            device=find_device(self.device, "input"), callback=self._callback,
        )
        self._stream.start()
        log.info("microphone started")

    def stop(self) -> None:
        if self._stream is None:
            return
        self._stream.stop()
        self._stream.close()
        self._stream = None
        while not self.frames.empty():
            self.frames.get_nowait()
        log.info("microphone stopped")

    @property
    def running(self) -> bool:
        return self._stream is not None


class Speaker:
    """Streaming playback with instant flush (for barge-in)."""

    def __init__(self, device: str | None = None) -> None:
        self.device = device
        self._buf: deque[np.ndarray] = deque()
        self._cur: np.ndarray | None = None
        self._pos = 0
        self._lock = threading.Lock()
        self._stream: sd.OutputStream | None = None
        self.last_audio_at = 0.0  # monotonic time the last non-silent block played
        self.level = 0.0

    def _callback(self, outdata, frames, time_info, status) -> None:  # PortAudio thread
        out = outdata[:, 0]
        filled = 0
        with self._lock:
            while filled < frames:
                if self._cur is None or self._pos >= len(self._cur):
                    if not self._buf:
                        break
                    self._cur, self._pos = self._buf.popleft(), 0
                take = min(frames - filled, len(self._cur) - self._pos)
                out[filled:filled + take] = self._cur[self._pos:self._pos + take]
                self._pos += take
                filled += take
        out[filled:] = 0
        if filled:
            self.last_audio_at = time.monotonic()
            self.level = rms_level(out[:filled])
        else:
            self.level = 0.0

    def start(self) -> None:
        if self._stream is not None:
            return
        self._stream = sd.OutputStream(
            samplerate=OUT_RATE, channels=1, dtype="int16", blocksize=960,
            device=find_device(self.device, "output"), callback=self._callback,
        )
        self._stream.start()

    def stop(self) -> None:
        self.clear()
        if self._stream is not None:
            self._stream.stop()
            self._stream.close()
            self._stream = None

    def write(self, pcm: bytes) -> None:
        if self._stream is None:
            self.start()
        with self._lock:
            self._buf.append(np.frombuffer(pcm, dtype=np.int16))

    def clear(self) -> None:
        with self._lock:
            self._buf.clear()
            self._cur, self._pos = None, 0

    @property
    def pending(self) -> bool:
        with self._lock:
            return bool(self._buf) or (self._cur is not None and self._pos < len(self._cur))

    def playing(self, tail: float = 0.0) -> bool:
        """True while audio is queued or played within the last ``tail`` seconds
        (room echo lingers after the last sample)."""
        return self.pending or (time.monotonic() - self.last_audio_at) < tail
