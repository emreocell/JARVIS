"""Gemini Live session management.

The session is opened lazily (on wake word / push-to-talk) and closed after
``session_idle_seconds`` of inactivity, so nothing streams to the cloud while
idle. Automatic VAD is disabled: turn boundaries come from our local VAD via
``activity_start`` / ``activity_end``. Session resumption + sliding-window
context compression keep the conversation across reconnects and past the
15-minute limit; a ``go_away`` triggers a transparent reconnect.
"""

from __future__ import annotations

import asyncio
import contextlib
import logging
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from typing import Any

from google import genai
from google.genai import types

log = logging.getLogger(__name__)


@dataclass(slots=True)
class LiveCallbacks:
    on_audio: Callable[[bytes], None]
    on_input_text: Callable[[str], None]
    on_output_text: Callable[[str], None]
    on_turn_complete: Callable[[], None]
    on_interrupted: Callable[[], None]
    on_tool_call: Callable[[list[types.FunctionCall]], Awaitable[list[types.FunctionResponse]]]
    on_closed: Callable[[str], None]


# Names the recognizer tends to mangle in Turkish speech ("Carvis", "Spotifay").
DEFAULT_VOCABULARY = ["Jarvis", "Spotify", "WhatsApp", "YouTube", "ChatGPT", "Claude", "Claude Code",
                      "VS Code", "Zed", "Antigravity", "opencode", "Gemini", "Opera GX", "Discord", "Telegram"]


@dataclass(slots=True)
class LiveSettings:
    model: str
    voice_name: str
    language: str
    system_instruction: str
    tools: list[types.Tool]
    vocabulary: list[str] = field(default_factory=list)


class LiveSession:
    def __init__(self, keys: Callable[[], list[tuple[str, str]]], settings: LiveSettings,
                 callbacks: LiveCallbacks) -> None:
        """``keys`` returns ``[(key_id, secret), ...]`` in preferred order."""
        self._keys = keys
        self.settings = settings
        self.cb = callbacks
        self._session: Any = None
        self._cm: Any = None
        self._receiver: asyncio.Task[None] | None = None
        self._resume_handle: str | None = None
        self._resume_key: str | None = None  # handles only work with the key (project) that issued them
        self._connect_lock = asyncio.Lock()
        self.key_id: str | None = None
        # language hints + vocabulary for input transcription; dropped if the
        # server rejects them (older/other Live models)
        self._rich_transcription = True

    @property
    def connected(self) -> bool:
        return self._session is not None

    def _config(self, handle: str | None = None) -> types.LiveConnectConfig:
        s = self.settings
        return types.LiveConnectConfig(
            response_modalities=[types.Modality.AUDIO],
            system_instruction=s.system_instruction,
            tools=s.tools or None,
            speech_config=types.SpeechConfig(
                voice_config=types.VoiceConfig(
                    prebuilt_voice_config=types.PrebuiltVoiceConfig(voice_name=s.voice_name)
                ),
                language_code=s.language,
            ),
            realtime_input_config=types.RealtimeInputConfig(
                automatic_activity_detection=types.AutomaticActivityDetection(disabled=True),
                activity_handling=types.ActivityHandling.START_OF_ACTIVITY_INTERRUPTS,
            ),
            input_audio_transcription=self._input_transcription(),
            output_audio_transcription=types.AudioTranscriptionConfig(),
            session_resumption=types.SessionResumptionConfig(handle=handle),
            context_window_compression=types.ContextWindowCompressionConfig(
                sliding_window=types.SlidingWindow()
            ),
        )

    def _input_transcription(self) -> types.AudioTranscriptionConfig:
        if not self._rich_transcription:
            return types.AudioTranscriptionConfig()
        s = self.settings
        langs = list(dict.fromkeys([s.language, "en-US"]))  # Turkish speech is full of English names
        vocab = list(dict.fromkeys([*s.vocabulary, *DEFAULT_VOCABULARY]))[:50]
        return types.AudioTranscriptionConfig(language_codes=langs, custom_vocabulary=vocab)

    @staticmethod
    def _config_rejected(exc: Exception) -> bool:
        msg = str(exc).lower()
        return any(k in msg for k in ("language_codes", "custom_vocabulary", "transcription", "unknown name",
                                      "invalid json payload", "1007"))

    async def connect(self) -> None:
        async with self._connect_lock:
            if self._session is not None:
                return
            errors = []
            for key_id, secret in self._keys():
                client = genai.Client(api_key=secret, http_options={"api_version": "v1beta"})
                handle = self._resume_handle if self._resume_key == key_id else None
                session = cm = None
                for _attempt in range(3):
                    cm = client.aio.live.connect(model=self.settings.model, config=self._config(handle))
                    try:
                        session = await asyncio.wait_for(cm.__aenter__(), timeout=10)
                        break
                    except Exception as exc:
                        if handle:
                            # stale/foreign resume handles fail with unrelated-looking
                            # errors (1008 "entity not found", 1011) — retry fresh
                            log.warning("live resume failed with key %s (%s); retrying fresh", key_id, exc)
                            handle = self._resume_handle = self._resume_key = None
                        elif self._rich_transcription and self._config_rejected(exc):
                            log.warning("live: transcription hints rejected (%s); retrying without", exc)
                            self._rich_transcription = False
                        else:  # auth / quota / network — try next key
                            errors.append(f"{key_id}: {type(exc).__name__}: {exc}")
                            log.warning("live connect failed with key %s: %s", key_id, exc)
                            break
                if session is None:
                    continue
                self._cm, self._session, self.key_id = cm, session, key_id
                self._receiver = asyncio.create_task(self._receive_loop())
                log.info("live session connected (model %s, key %s, resumed=%s)",
                         self.settings.model, key_id, bool(handle))
                return
            raise ConnectionError("Live bağlantısı kurulamadı: " + ("; ".join(errors) or "API anahtarı yok"))

    async def close(self, reason: str = "idle") -> None:
        session, cm, receiver = self._session, self._cm, self._receiver
        self._session = self._cm = self._receiver = None
        if receiver and receiver is not asyncio.current_task():
            receiver.cancel()
            with contextlib.suppress(asyncio.CancelledError, Exception):
                await receiver
        if cm is not None:
            with contextlib.suppress(Exception):
                await cm.__aexit__(None, None, None)
        if session is not None:
            log.info("live session closed (%s)", reason)
            self.cb.on_closed(reason)

    # ------------------------------------------------------------ sending

    async def activity_start(self) -> None:
        await self._session.send_realtime_input(activity_start=types.ActivityStart())

    async def activity_end(self) -> None:
        await self._session.send_realtime_input(activity_end=types.ActivityEnd())

    async def send_audio(self, pcm16k: bytes) -> None:
        await self._session.send_realtime_input(
            audio=types.Blob(data=pcm16k, mime_type="audio/pcm;rate=16000")
        )

    async def send_image(self, jpeg: bytes) -> None:
        await self._session.send_realtime_input(video=types.Blob(data=jpeg, mime_type="image/jpeg"))

    async def send_text(self, text: str) -> None:
        await self._session.send_client_content(
            turns=types.Content(role="user", parts=[types.Part(text=text)]), turn_complete=True
        )

    # ---------------------------------------------------------- receiving

    async def _receive_loop(self) -> None:
        reason = "closed"
        try:
            while self._session is not None:
                async for msg in self._session.receive():
                    await self._handle(msg)
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            reason = f"error: {exc}"
            log.warning("live receive loop ended: %s", exc)
        if self._session is not None:
            await self.close(reason)

    async def _handle(self, msg: types.LiveServerMessage) -> None:
        if msg.session_resumption_update and msg.session_resumption_update.new_handle:
            self._resume_handle = msg.session_resumption_update.new_handle
            self._resume_key = self.key_id
        if msg.go_away is not None:
            log.info("live go_away (time left %s) — reconnecting", msg.go_away.time_left)
            asyncio.create_task(self._reconnect())
        sc = msg.server_content
        if sc is not None:
            if sc.interrupted:
                self.cb.on_interrupted()
            if sc.input_transcription and sc.input_transcription.text:
                self.cb.on_input_text(sc.input_transcription.text)
            if sc.output_transcription and sc.output_transcription.text:
                self.cb.on_output_text(sc.output_transcription.text)
            if sc.model_turn:
                for part in sc.model_turn.parts or []:
                    if part.inline_data and part.inline_data.data:
                        self.cb.on_audio(part.inline_data.data)
            if sc.turn_complete:
                self.cb.on_turn_complete()
        if msg.tool_call and msg.tool_call.function_calls:
            responses = await self.cb.on_tool_call(list(msg.tool_call.function_calls))
            if responses and self._session is not None:
                await self._session.send_tool_response(function_responses=responses)

    async def _reconnect(self) -> None:
        old_cm, old_receiver = self._cm, self._receiver
        self._session = self._cm = self._receiver = None
        if old_receiver:
            old_receiver.cancel()
        if old_cm is not None:
            with contextlib.suppress(Exception):
                await old_cm.__aexit__(None, None, None)
        try:
            await self.connect()
        except ConnectionError as exc:
            self.cb.on_closed(str(exc))
