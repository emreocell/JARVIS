"""Notification intelligence: every Windows notification, remembered and
triaged, so "ben yokken önemli bir şey oldu mu?" has an answer.

Windows keeps Action Center notifications in a per-user SQLite database; we
read it read-only every 20 s, copy new entries into Jarvis' own store (the
Action Center forgets dismissed ones) and let Jev sort them into
önemli / normal / önemsiz in one batched request. Jarvis' own toasts are
skipped. Nothing leaves the machine except the short text sent to Jev.
"""

from __future__ import annotations

import asyncio
import logging
import os
import re
import sqlite3
import threading
import time
import xml.etree.ElementTree as ET
from dataclasses import dataclass
from pathlib import Path
from typing import Any

log = logging.getLogger(__name__)

POLL = 20.0
WPN_DB = Path(os.environ.get("LOCALAPPDATA", "")) / "Microsoft" / "Windows" / "Notifications" / "wpndatabase.db"
OWN_HANDLERS = ("WindowsPowerShell\\v1.0\\powershell.exe", "Jarvis.Assistant")
APP_NAMES = {
    "whatsapp": "WhatsApp", "claude": "Claude", "chatgpt": "ChatGPT", "discord": "Discord", "telegram": "Telegram",
    "outlook": "Outlook", "teams": "Teams", "slack": "Slack", "spotify": "Spotify", "msedge": "Edge",
    "chrome": "Chrome", "opera": "Opera", "firefox": "Firefox", "sechealth": "Windows Güvenliği",
    "defender": "Windows Defender", "windowsupdate": "Windows Update", "github": "GitHub", "code": "VS Code",
    "cursor": "Cursor", "steam": "Steam", "instagram": "Instagram", "mail": "Posta", "calendar": "Takvim",
    "screenclip": "Ekran Alıntısı", "xbox": "Xbox", "phone": "Telefon Bağlantısı", "yourphone": "Telefon Bağlantısı",
}
IMPORTANCE = {
    "onemli": "Önemli: bir insandan kişisel mesaj, toplantı/etkinlik hatırlatması, başarısız olan bir iş "
              "(CI/pipeline/derleme), tamamlanan uzun bir görev, güvenlik uyarısı, ödeme/fatura",
    "normal": "Normal: bilgilendirici ama acil değil (grup mesajı, bir uygulamanın durumu)",
    "onemsiz": "Önemsiz: reklam, öneri, sistem bilgisi, indirme bitti, ses/medya, tekrar eden bildirim",
}
SCHEMA = """
CREATE TABLE IF NOT EXISTS notifications (
    id INTEGER PRIMARY KEY,
    wpn_id INTEGER UNIQUE,
    at REAL NOT NULL,
    app TEXT NOT NULL,
    title TEXT NOT NULL DEFAULT '',
    body TEXT NOT NULL DEFAULT '',
    importance TEXT NOT NULL DEFAULT 'normal'
);
CREATE INDEX IF NOT EXISTS notifications_at ON notifications(at);
"""


@dataclass(slots=True)
class Notice:
    wpn_id: int
    at: float
    app: str
    title: str
    body: str
    importance: str = "normal"

    def as_dict(self) -> dict[str, Any]:
        return {"app": self.app, "title": self.title, "body": self.body[:300], "importance": self.importance,
                "time": time.strftime("%H:%M", time.localtime(self.at))}


def app_name(primary_id: str) -> str:
    low = primary_id.lower()
    for key, name in APP_NAMES.items():
        if key in low:
            return name
    tail = re.split(r"[\\!/]", primary_id)[-1] if "!" not in primary_id else primary_id.split("!")[0].split("_")[0]
    tail = tail.removesuffix(".exe").split(".")[-1]
    return tail[:30] or "Uygulama"


def parse_payload(payload: bytes | str) -> tuple[str, str]:
    text = payload.decode("utf-8", "replace") if isinstance(payload, bytes) else payload
    try:
        root = ET.fromstring(text)
    except ET.ParseError:
        return "", ""
    texts = [t.text.strip() for t in root.iter("text") if t.text and t.text.strip()]
    return (texts[0] if texts else ""), " ".join(texts[1:])


def filetime_to_unix(ft: int) -> float:
    return ft / 10_000_000 - 11_644_473_600


def read_wpn(after_id: int) -> list[Notice]:
    if not WPN_DB.exists():
        return []
    con = sqlite3.connect(f"file:{WPN_DB}?mode=ro", uri=True, timeout=2)
    try:
        rows = con.execute(
            "SELECT n.Id, n.ArrivalTime, h.PrimaryId, n.Payload FROM Notification n "
            "JOIN NotificationHandler h ON h.RecordId = n.HandlerId "
            "WHERE n.Type = 'toast' AND n.Id > ? ORDER BY n.Id", (after_id,)).fetchall()
    finally:
        con.close()
    out = []
    for nid, arrival, primary, payload in rows:
        if any(own in (primary or "") for own in OWN_HANDLERS):
            continue
        title, body = parse_payload(payload or b"")
        if not title and not body:
            continue
        out.append(Notice(int(nid), filetime_to_unix(int(arrival or 0)), app_name(primary or ""), title, body))
    return out


def heuristic(n: Notice) -> str:
    text = f"{n.title} {n.body}".lower()
    if re.search(r"fail|başarısız|hata|error|güvenlik|security|tehdit|threat|toplantı|meeting|ödeme|fatura", text):
        return "onemli"
    if n.app in ("WhatsApp", "Telegram", "Discord", "Teams", "Slack", "Outlook", "Posta"):
        return "normal"
    if n.app in ("Claude", "ChatGPT", "VS Code", "Cursor") and re.search(r"tamam|bitti|done|complete|finish", text):
        return "onemli"
    return "onemsiz"


class NotificationStore:
    def __init__(self, path: Path) -> None:
        self._lock = threading.Lock()
        self.db = sqlite3.connect(path, check_same_thread=False)
        self.db.executescript(SCHEMA)
        self.db.commit()

    def last_wpn_id(self) -> int:
        with self._lock:
            row = self.db.execute("SELECT MAX(wpn_id) FROM notifications").fetchone()
        return int(row[0] or 0)

    def add(self, items: list[Notice]) -> None:
        with self._lock:
            self.db.executemany("INSERT OR IGNORE INTO notifications(wpn_id, at, app, title, body, importance) "
                                "VALUES (?,?,?,?,?,?)",
                                [(n.wpn_id, n.at, n.app, n.title, n.body, n.importance) for n in items])
            self.db.commit()

    def since(self, ts: float) -> list[Notice]:
        with self._lock:
            rows = self.db.execute("SELECT wpn_id, at, app, title, body, importance FROM notifications "
                                   "WHERE at >= ? ORDER BY at", (ts,)).fetchall()
        return [Notice(*r) for r in rows]

    def prune(self, days: int = 30) -> None:
        with self._lock:
            self.db.execute("DELETE FROM notifications WHERE at < ?", (time.time() - days * 86400,))
            self.db.commit()


class NotificationWatcher:
    def __init__(self, core: Any, store: NotificationStore) -> None:
        self.core = core
        self.store = store
        self._task: asyncio.Task[None] | None = None

    def start(self) -> None:
        if self._task is None and WPN_DB.exists():
            self._task = asyncio.create_task(self._run(), name="notifications")

    def stop(self) -> None:
        if self._task:
            self._task.cancel()
            self._task = None

    async def _run(self) -> None:
        self.store.prune()
        last = self.store.last_wpn_id()
        first = last == 0
        while True:
            try:
                new = await asyncio.to_thread(read_wpn, last)
                if new:
                    last = max(n.wpn_id for n in new)
                    if first:   # history already in Action Center at first run: keep, don't announce
                        for n in new:
                            n.importance = heuristic(n)
                    else:
                        await self.classify(new)
                    self.store.add(new)
                    if not first:
                        for n in new:
                            await self.core.bus.publish("notification.new", **n.as_dict())
                first = False
            except Exception:
                log.debug("notification poll failed", exc_info=True)
            await asyncio.sleep(POLL)

    async def classify(self, items: list[Notice]) -> None:
        """One Jev request for the whole batch; heuristics if Jev is unavailable."""
        from jarvis.providers.typesafe import choice

        for n in items:
            n.importance = heuristic(n)
        if not getattr(self.core.config.features, "jev_decider", False):
            return
        batch = items[:12]
        user = self.core.config.assistant.user_name or "kullanıcı"
        state = f"Kullanıcı: {user}. Windows bildirimleri:\n" + "\n".join(
            f"[n{i}] {n.app} — {n.title}: {n.body[:160]}" for i, n in enumerate(batch))
        questions = {f"n{i}": choice(f"[n{i}] numaralı bildirim kullanıcı için ne kadar önemli?", IMPORTANCE)
                     for i in range(len(batch))}
        try:
            res = await self.core.providers.decide(state, questions)
        except Exception as exc:
            log.info("notification triage: jev unavailable (%s)", exc)
            return
        for i, n in enumerate(batch):
            ans = res["answers"].get(f"n{i}") or {}
            if ans.get("choice") in IMPORTANCE and float(ans.get("confidence") or 0) >= 0.5:
                n.importance = str(ans["choice"])
