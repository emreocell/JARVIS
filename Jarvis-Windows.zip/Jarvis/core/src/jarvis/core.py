"""The Core object: owns all long-lived services and wires them together."""

from __future__ import annotations

import asyncio
import logging
import os
import secrets as pysecrets
import sys
import time
from typing import Any

from jarvis import __version__, dictionary, paths
from jarvis.api import ApiServer
from jarvis.api.methods import register_methods
from jarvis.brain.decider import Decider
from jarvis.brain.prompt import build_system_instruction
from jarvis.brain.text_agent import TextAgent
from jarvis.context.tracker import ContextTracker
from jarvis.routines.engine import RoutineEngine
from jarvis.hotkeys import HotkeyManager
from jarvis.integrations.spotify import SpotifyClient
from jarvis.remote.telegram import TelegramRemote
from jarvis.routines.store import RoutineStore
from jarvis.memory.service import MemoryService
from jarvis.memory.store import MemoryStore
from jarvis.bus import Event, EventBus
from jarvis.config import ConfigStore
from jarvis.config.schema import Role
from jarvis.fsutil import atomic_write_json, read_json
from jarvis.providers import ProviderRegistry
from jarvis.providers.quota import QuotaTracker
from jarvis.secrets import SecretStore
from jarvis.skills import BUILTIN_SKILLS
from jarvis.tools import ToolRuntime
from jarvis.tools.approval import ApprovalStore
from jarvis.voice.controller import VoiceController

log = logging.getLogger(__name__)

STATE_SAVE_INTERVAL = 300.0


class Core:
    def __init__(self, port: int = 0, secret_store: SecretStore | None = None,
                 enable_voice: bool = True) -> None:
        self.enable_voice = enable_voice
        self.voice: VoiceController | None = None
        self.started_at = time.time()
        self.bus = EventBus()
        self.config_store = ConfigStore(paths.config_path(), self.bus)
        self.secrets = secret_store or SecretStore()
        self.quota = QuotaTracker()
        self.providers = ProviderRegistry(self.secrets, self.quota)
        self.tools = ToolRuntime(self.bus, ApprovalStore(paths.data_dir() / "approvals.json"), core=self)
        self.tools.notify_brain = self.notify_brain
        from jarvis.brain.router import IntentRouter

        self.text_agent = TextAgent(self.bus, self.providers, self.tools, self._system_instruction,
                                    fast_enabled=lambda: self.config.features.fast_commands,
                                    router=IntentRouter(self))
        self.memory = MemoryService(self, MemoryStore(paths.data_dir() / "memory.sqlite3"))
        self.context: ContextTracker | None = None
        self.routines = RoutineEngine(self, RoutineStore(paths.data_dir() / "routines.sqlite3"))
        from jarvis.notes import NoteStore

        self.notes = NoteStore(paths.data_dir() / "notes.sqlite3")
        self.remote = TelegramRemote(self)
        self.spotify = SpotifyClient(self.secrets, None)
        self.decider = Decider(self)
        from jarvis.mcpclient.manager import McpManager

        self.mcp = McpManager(self)
        from jarvis.proactive.morning import MorningBrief
        from jarvis.proactive.presence import Presence

        self.presence = Presence(self.bus)
        from jarvis.journal.recorder import ActivityRecorder
        from jarvis.journal.store import JournalStore

        self.journal = JournalStore(paths.data_dir() / "activity.sqlite3")
        self.recorder = ActivityRecorder(self, self.journal)
        from jarvis.notifications.watcher import NotificationStore, NotificationWatcher

        self.notices = NotificationStore(paths.data_dir() / "notifications.sqlite3")
        self.notice_watcher = NotificationWatcher(self, self.notices)
        self.morning = MorningBrief(self)
        from jarvis.proactive.engine import ProactiveEngine

        self.proactive = ProactiveEngine(self)
        from jarvis.meeting.recorder import MeetingMode, MeetingStore

        self.meeting = MeetingMode(self, MeetingStore(paths.data_dir() / "meetings.sqlite3"))
        from jarvis.people.ingest import PeopleIngest
        from jarvis.people.store import PeopleStore

        self.people = PeopleStore(paths.data_dir() / "people.sqlite3")
        self._people_ingest = PeopleIngest(self, self.people)
        from jarvis.missions.engine import MissionEngine

        self.missions = MissionEngine(self)
        from jarvis.live.translate import LiveTranslator

        self.translator = LiveTranslator(self)
        from jarvis.proactive.calls import CallWatcher

        self.calls = CallWatcher(self)
        self.hotkeys = HotkeyManager(self._on_hotkey_thread)
        self._loop: asyncio.AbstractEventLoop | None = None
        self.token = pysecrets.token_urlsafe(32)
        self.api = ApiServer(self.bus, self.token, self.snapshot, port=port)
        self.state: dict[str, Any] = {"voice": "idle"}
        self._stop = asyncio.Event()
        self._saver: asyncio.Task[None] | None = None

    @property
    def config(self):
        return self.config_store.config

    async def snapshot(self) -> dict[str, Any]:
        return {
            "version": __version__,
            "uptime_s": round(time.time() - self.started_at),
            "state": self.state,
            "config": self.config.model_dump(mode="json"),
            "secrets": self.secrets.describe(),
            "providers": {"stats": self.providers.stats(), "quota": self.providers.quota_snapshot()},
            "decider": self.decider.stats.as_dict(),
            "wake_rejected": self.voice.wake_rejected if self.voice else {},
            "wake_approx": self.voice.wake_approx if self.voice else {},
            "hotkeys_failed": dict(getattr(self.hotkeys, "failed", {}) or {}),
        }

    async def set_state(self, **changes: Any) -> None:
        self.state.update(changes)
        await self.bus.publish("state.changed", **changes)

    # ---------------------------------------------------------- lifecycle

    def _restore_state(self) -> None:
        path = paths.state_path()
        if path.exists():
            try:
                self.quota.restore(read_json(path).get("quota", {}))
            except Exception:
                log.warning("could not restore state.json", exc_info=True)

    def save_state(self) -> None:
        atomic_write_json(paths.state_path(), {"quota": self.quota.dump()})

    async def _periodic_save(self) -> None:
        while True:
            await asyncio.sleep(STATE_SAVE_INTERVAL)
            self.save_state()

    async def _on_config_changed(self, event: Event) -> None:
        sections = set(event.data.get("sections", []))
        if {"providers", "routes"} & sections:
            self.providers.load(self.config)
        if {"voice", "privacy"} & sections:
            await self._sync_voice()
        if {"features", "voice", "privacy"} & sections:
            await self._sync_sound_events()
        if {"features", "privacy"} & sections:
            self._sync_context()
        if {"features", "privacy", "remote"} & sections:
            await self.remote.sync()
        if "integrations" in sections:
            self.spotify.client_id = self.config.integrations.spotify_client_id or None
        if {"voice", "ui"} & sections:
            self._sync_hotkeys()
        if "ui" in sections:
            self._sync_autostart()
        if "features" in sections:
            from jarvis.skills.desktop_control import HUD_ON

            HUD_ON["value"] = bool(self.config.features.hud)
        if "mcp" in sections:
            await self.mcp.sync()

    # -------------------------------------------------------------- voice

    def _voice_wanted(self) -> bool:
        return self.enable_voice and self.config.voice.enabled and not self.config.privacy.privacy_mode

    def _live_keys(self) -> list[tuple[str, str]]:
        return self.providers.live_keys("gemini", self.config.voice.live_model)

    def _system_instruction(self) -> str:
        return build_system_instruction(user_rules=self.config.assistant.user_rules,
                                        user_name=self.config.assistant.user_name,
                                        location=self.config.assistant.location,
                                        dictionary=dictionary.prompt_block(self.config),
                                        memory=self.memory.prompt_block(),
                                        context=self.context.prompt_block() if self.context else "")

    # ------------------------------------------------------- sound events

    async def _sync_sound_events(self) -> None:
        """Attach/detach the YAMNet listener to the voice pipeline's microphone."""
        from jarvis.voice import sound_events as se

        want = bool(self.config.features.sound_events) and self.voice is not None and self.enable_voice
        current = getattr(self, "_sound", None)
        if not want:
            if current is not None and self.voice is not None and current.feed in self.voice.taps:
                self.voice.taps.remove(current.feed)
            self._sound = None
            return
        if current is not None:
            return
        if not se.available():
            try:
                await self.bus.publish("sound_events.state", state="downloading")
                await asyncio.to_thread(se.download)
            except Exception as exc:
                log.warning("sound events model download failed: %s", exc)
                await self.bus.publish("sound_events.state", state="error", error=str(exc))
                return
        loop = asyncio.get_running_loop()

        def on_event(kind: str, score: float) -> None:
            loop.call_soon_threadsafe(lambda: asyncio.ensure_future(self._on_sound_event(kind, score)))

        detector = se.SoundEvents(on_event)
        if not await asyncio.to_thread(detector.load):
            return
        self._sound = detector
        self.voice.taps.append(detector.feed)
        await self.bus.publish("sound_events.state", state="on")

    async def _on_sound_event(self, kind: str, score: float) -> None:
        from jarvis.proactive.engine import Candidate

        log.info("sound event: %s (%.2f)", kind, score)
        await self.bus.publish("sound.event", kind=kind, score=round(score, 2))
        if kind == "phone":
            if self.voice is not None:
                if str(getattr(self.voice.state, "value", "")) == "speaking":
                    self.voice._barge_in()
                self.voice.call_mode = True
                loop = asyncio.get_running_loop()
                loop.call_later(45, lambda: setattr(self.voice, "call_mode", bool(self.calls.in_call))
                                if self.voice is not None else None)
        elif kind == "doorbell":
            self.proactive.add(Candidate("sound", "Kapı çalıyor olabilir (kapı zili ya da vurma sesi duydum).", "normal"))
        elif kind in ("alarm", "baby"):
            what = "bir alarm sesi" if kind == "alarm" else "bebek ağlaması"
            self.proactive.add(Candidate("sound", f"Ortamda {what} duyuyorum.", "high"))

    # ------------------------------------------------------------ hotkeys

    def _sync_hotkeys(self) -> None:
        if not self.enable_voice or sys.platform != "win32":
            return
        cfg = self.config
        self.hotkeys.start({"wake": cfg.voice.push_to_talk_hotkey, "command_bar": cfg.ui.command_bar_hotkey,
                            "selection": cfg.ui.selection_hotkey})
        self.bus.emit("hotkeys.status", failed=dict(self.hotkeys.failed))

    def _on_hotkey_thread(self, name: str) -> None:
        if self._loop is not None:
            self._loop.call_soon_threadsafe(lambda: asyncio.ensure_future(self._on_hotkey(name)))

    async def _on_hotkey(self, name: str) -> None:
        log.info("hotkey %s", name)
        if name == "wake" and self.voice is not None:
            await self.voice.wake()
        elif name == "command_bar":
            # remember the app in front (and its selection) before the bar takes focus: "bunu çevir"
            from jarvis.skills import this, uia

            try:
                this.SNAPSHOT.clear()
                this.SNAPSHOT.update(await asyncio.wait_for(uia.run(this.capture), 1.0))
            except Exception:
                log.debug("this-snapshot failed", exc_info=True)
            await self.bus.publish("hotkey.command_bar")
        elif name == "selection":
            from jarvis.skills import uia
            from jarvis.skills.desktop import get_selected_text

            text = await uia.run(get_selected_text)
            await self.bus.publish("selection.captured", text=text[:8000])
            await self.bus.publish("hotkey.command_bar")

    def _sync_autostart(self) -> None:
        if not self.enable_voice:  # tests / UI-dev runs never touch the registry
            return
        from jarvis import autostart

        try:
            autostart.sync(self.config.ui.start_with_windows)
        except OSError:
            log.warning("could not update autostart entry", exc_info=True)

    def _sync_context(self) -> None:
        wanted = (self.enable_voice and self.config.features.context_tracker
                  and not self.config.privacy.privacy_mode and sys.platform in ("win32", "darwin"))
        if wanted and self.context is None:
            tracker = ContextTracker
            if sys.platform == "darwin":
                from jarvis.context.mac_tracker import MacContextTracker as tracker  # noqa: N813
            self.context = tracker(
                self.config.privacy.excluded_apps,
                on_focus=lambda f: self.bus.emit_threadsafe("context.focus", app=f.app, title=f.title))
            self.context.start()
        elif not wanted and self.context is not None:
            self.context.stop()
            self.context = None
        elif self.context is not None:
            self.context.excluded = [e.lower() for e in self.config.privacy.excluded_apps]

    def _load_skills(self) -> None:
        for module in BUILTIN_SKILLS:
            try:
                self.tools.register_module(module)
            except Exception:
                log.exception("skill %s failed to load", module)
        log.info("tools: %d available, %d unavailable", len(self.tools.tools), len(self.tools.unavailable))

    async def _handle_tool_calls(self, calls: list[Any]) -> list[Any]:
        from google.genai import types

        responses = []
        for call in calls:
            result = await self.tools.execute(call.name, dict(call.args or {}), call_id=call.id or "")
            responses.append(types.FunctionResponse(id=call.id, name=call.name, response=result))
        return responses

    # ------------------------------------------------------ cascade voice

    def _cascade_session(self, callbacks: Any) -> Any:
        from jarvis.voice.cascade import CascadeSession, Synthesizer

        v = self.config.voice
        return CascadeSession(self._transcribe, self._respond_spoken,
                              Synthesizer(v.tts_voice, self._gemini_tts, v.tts_engine), callbacks)

    async def _transcribe(self, wav: bytes) -> str:
        v = self.config.voice
        vocab = [self.config.assistant.name, *(w.phrase for w in v.wake_words if w.enabled),
                 *dictionary.terms(self.config)]
        resp = await self.providers.route(
            Role.STT, lambda adapter, model, secret: adapter.transcribe(model, secret, wav, v.language, vocab),
            est_tokens=len(wav) // 1000 + 200)
        return dictionary.fix(resp.text, self.config)

    async def _respond_spoken(self, text: str) -> str:
        result = await self.text_agent.run(text, publish_turn=False, spoken=True)
        await self.bus.publish("providers.quota", quota=self.providers.quota_snapshot())
        return str(result.get("text") or "")

    async def _gemini_tts(self, text: str) -> bytes:
        from jarvis.providers.gemini import GeminiAdapter

        resp = await self.providers.route(
            Role.TTS, lambda adapter, model, secret: adapter.speak(model, secret, text, self.config.voice.voice_name),
            est_tokens=len(text) // 3 + 100, only=GeminiAdapter)
        return resp.raw["pcm"]

    async def _on_tool_finished(self, event: Event) -> None:
        """Background tasks (browser, web AI, CLI tools) also get a Windows toast,
        so the result isn't missed while the user is in another app."""
        if not event.data.get("background") or not self.enable_voice:
            return
        from jarvis.notify import toast
        from jarvis.tools.titles import title_of

        title = ("✓ " if event.data.get("ok") else "⚠ ") + title_of(str(event.data.get("tool", "")))
        body = str(event.data.get("result") or "")[:240]
        await asyncio.to_thread(toast, title, body, "reminder")

    async def notify_brain(self, text: str) -> None:
        """Tell the voice brain about something that happened outside a tool call
        (background result, UI approval) so it can inform the user."""
        if self.meeting.active:   # meeting mode: never speak on our own
            from jarvis.notify import toast

            await asyncio.to_thread(toast, "Jarvis", text.split("] ", 1)[-1][:200], "default")
            return
        if self.voice is not None:
            await self.voice.say(text, show=False)

    async def _sync_voice(self) -> None:
        """Start, stop or hot-reload the voice controller to match config."""
        if not self._voice_wanted():
            if self.voice:
                await self.voice.stop()
                self.voice = None
            await self.set_state(voice="muted")
            return
        if self.voice is None:
            self.voice = VoiceController(self.bus, self.config.voice, self._live_keys,
                                         self._system_instruction,
                                         tools=self.tools.gemini_tools,
                                         tool_handler=self._handle_tool_calls,
                                         vocabulary=lambda: dictionary.terms(self.config),
                                         cascade_factory=self._cascade_session)
            try:
                await self.voice.start()
            except Exception as exc:
                log.exception("voice failed to start")
                self.voice = None
                await self.set_state(voice="error", voice_error=str(exc))
                await self.bus.publish("voice.error", message=f"Ses başlatılamadı: {exc}")
        else:
            await self.voice.apply_settings(self.config.voice)

    async def start(self) -> None:
        loop = asyncio.get_running_loop()
        self.bus.bind_loop(loop)
        self.config_store.load()
        self._restore_state()
        self.providers.load(self.config)
        self.spotify.client_id = self.config.integrations.spotify_client_id or None
        self._load_skills()
        from jarvis.skills.desktop_control import HUD_ON

        HUD_ON["value"] = bool(self.config.features.hud) and self.enable_voice
        await self.mcp.sync()
        self.bus.subscribe("config.changed", self._on_config_changed)
        self.bus.subscribe("tool.finished", self._on_tool_finished)
        register_methods(self)
        port = await self.api.start()
        atomic_write_json(paths.runtime_path(), {
            "port": port, "token": self.token, "pid": os.getpid(), "version": __version__,
        })
        self._saver = loop.create_task(self._periodic_save())
        self._loop = loop
        self._sync_context()
        self._sync_hotkeys()
        self._sync_autostart()
        await self._sync_voice()
        await self.routines.start()
        if self.enable_voice and sys.platform == "win32":  # warm the app index for the launcher
            from jarvis.skills.apps import INDEX

            def warm() -> None:
                from jarvis.icons import app_icon

                for _, app_id in INDEX.apps():  # icons are cached on disk after the first run
                    app_icon(app_id)
            loop.run_in_executor(None, warm)
        if self.enable_voice:  # tests run headless without network side effects
            await self.remote.sync()
            self.presence.start()
            if sys.platform == "win32":   # notifications under Jarvis' own name and icon
                from jarvis import notify
                from jarvis.desktop.aumid import AUMID, stamp

                if await asyncio.to_thread(stamp):
                    notify.APP_AUMID["value"] = AUMID
            self.recorder.start()
            self.proactive.start()
            self.calls.start()
            await self._sync_sound_events()
            if self.config.features.notification_intel and not self.config.privacy.privacy_mode:
                self.notice_watcher.start()
            from jarvis.skills.this import watch_clipboard

            self._clip_task = loop.create_task(watch_clipboard())
            self._morning_task = loop.create_task(self.morning.on_start())
        log.info("core started (pid %d, port %d)", os.getpid(), port)

    async def stop(self) -> None:
        if self._saver:
            self._saver.cancel()
        await self.mcp.stop()
        self.presence.stop()
        self.recorder.stop()
        self.proactive.stop()
        self.calls.stop()
        self.notice_watcher.stop()
        if self.voice:
            await self.voice.stop()
        if self.context:
            self.context.stop()
        self.hotkeys.stop()
        self.save_state()
        await self.api.stop()
        await self.providers.aclose()
        self.memory.store.close()
        await self.routines.stop()
        self.routines.store.close()
        self.notes.close()
        await self.remote.stop()
        try:
            paths.runtime_path().unlink()
        except FileNotFoundError:
            pass
        log.info("core stopped")

    def request_stop(self) -> None:
        self._stop.set()

    async def run_forever(self) -> None:
        await self.start()
        try:
            await self._stop.wait()
        finally:
            await self.stop()
