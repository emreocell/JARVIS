"""Persistent reminders/alarms and trigger rules (SQLite)."""

from __future__ import annotations

import json
import sqlite3
import threading
import time
from dataclasses import asdict, dataclass, field
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Literal

Repeat = Literal["none", "daily", "weekdays", "weekly"]
Mode = Literal["auto", "ask", "notify"]

SCHEMA = """
CREATE TABLE IF NOT EXISTS reminders (
    id INTEGER PRIMARY KEY,
    kind TEXT NOT NULL,            -- reminder | alarm | timer
    text TEXT NOT NULL,
    due REAL NOT NULL,
    repeat TEXT NOT NULL DEFAULT 'none',
    status TEXT NOT NULL DEFAULT 'pending',   -- pending | done | cancelled
    created REAL NOT NULL,
    fired_at REAL
);
CREATE TABLE IF NOT EXISTS rules (
    id INTEGER PRIMARY KEY,
    data TEXT NOT NULL
);
"""


@dataclass(slots=True)
class Reminder:
    id: int
    kind: str
    text: str
    due: float
    repeat: str
    status: str
    created: float

    def as_dict(self) -> dict[str, Any]:
        d = asdict(self)
        d["due_local"] = datetime.fromtimestamp(self.due).strftime("%d.%m.%Y %H:%M")
        return d


@dataclass(slots=True)
class Rule:
    """``when <trigger> then <action>`` with a behaviour mode.

    trigger: {"type": "app_opened", "app": "VS Code"} | {"type": "time", "at": "09:00", "days": "weekdays"}
             | {"type": "startup"}
    action:  {"type": "tool", "tool": "play_spotify", "args": {...}} | {"type": "say", "text": "..."}
             | {"type": "prompt", "text": "günün özetini çıkar"}
    """

    id: int
    name: str
    trigger: dict[str, Any]
    action: dict[str, Any]
    mode: str = "ask"
    cooldown_minutes: int = 240
    enabled: bool = True
    quiet_hours: list[int] = field(default_factory=lambda: [0, 7])  # [start, end) local hours
    last_fired: float = 0.0

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


def next_occurrence(due: float, repeat: str, now: float | None = None) -> float | None:
    """Next due time strictly after ``now`` for a repeating reminder."""
    if repeat == "none":
        return None
    now = now or time.time()
    t = datetime.fromtimestamp(due)
    while t.timestamp() <= now:
        if repeat == "daily":
            t += timedelta(days=1)
        elif repeat == "weekly":
            t += timedelta(days=7)
        elif repeat == "weekdays":
            t += timedelta(days=1)
            while t.weekday() >= 5:
                t += timedelta(days=1)
        else:
            return None
    return t.timestamp()


class RoutineStore:
    def __init__(self, path: Path) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self._db = sqlite3.connect(path, check_same_thread=False, isolation_level=None)
        self._db.row_factory = sqlite3.Row
        self._db.executescript(SCHEMA)

    def close(self) -> None:
        self._db.close()

    # ----------------------------------------------------------- reminders

    def add_reminder(self, text: str, due: float, kind: str = "reminder", repeat: str = "none") -> Reminder:
        with self._lock:
            cur = self._db.execute(
                "INSERT INTO reminders(kind, text, due, repeat, created) VALUES (?,?,?,?,?)",
                (kind, text.strip(), due, repeat, time.time()))
            return self.get_reminder(int(cur.lastrowid))  # type: ignore[return-value]

    def get_reminder(self, rid: int) -> Reminder | None:
        r = self._db.execute("SELECT * FROM reminders WHERE id=?", (rid,)).fetchone()
        return Reminder(r["id"], r["kind"], r["text"], r["due"], r["repeat"], r["status"], r["created"]) if r else None

    def pending(self) -> list[Reminder]:
        rows = self._db.execute("SELECT * FROM reminders WHERE status='pending' ORDER BY due")
        return [Reminder(r["id"], r["kind"], r["text"], r["due"], r["repeat"], r["status"], r["created"])
                for r in rows]

    def next_due(self) -> Reminder | None:
        items = self.pending()
        return items[0] if items else None

    def mark_fired(self, rem: Reminder) -> Reminder | None:
        """Mark a fired reminder; repeating ones are rescheduled. Returns the rescheduled one."""
        with self._lock:
            nxt = next_occurrence(rem.due, rem.repeat)
            if nxt is None:
                self._db.execute("UPDATE reminders SET status='done', fired_at=? WHERE id=?", (time.time(), rem.id))
                return None
            self._db.execute("UPDATE reminders SET due=?, fired_at=? WHERE id=?", (nxt, time.time(), rem.id))
            return self.get_reminder(rem.id)

    def snooze(self, rid: int, minutes: int) -> Reminder | None:
        with self._lock:
            self._db.execute("UPDATE reminders SET due=?, status='pending' WHERE id=?",
                             (time.time() + minutes * 60, rid))
            return self.get_reminder(rid)

    def cancel(self, rid: int) -> bool:
        with self._lock:
            return self._db.execute("UPDATE reminders SET status='cancelled' WHERE id=? AND status='pending'",
                                    (rid,)).rowcount > 0

    def missed(self, now: float | None = None) -> list[Reminder]:
        now = now or time.time()
        return [r for r in self.pending() if r.due < now]

    # --------------------------------------------------------------- rules

    def rules(self) -> list[Rule]:
        out = []
        for r in self._db.execute("SELECT id, data FROM rules ORDER BY id"):
            data = json.loads(r["data"])
            data["id"] = r["id"]
            out.append(Rule(**data))
        return out

    def save_rule(self, rule: Rule) -> Rule:
        data = rule.as_dict()
        rid = data.pop("id")
        with self._lock:
            if rid:
                self._db.execute("UPDATE rules SET data=? WHERE id=?", (json.dumps(data, ensure_ascii=False), rid))
            else:
                rid = int(self._db.execute("INSERT INTO rules(data) VALUES (?)",
                                           (json.dumps(data, ensure_ascii=False),)).lastrowid)
        rule.id = rid
        return rule

    def delete_rule(self, rid: int) -> bool:
        with self._lock:
            return self._db.execute("DELETE FROM rules WHERE id=?", (rid,)).rowcount > 0
