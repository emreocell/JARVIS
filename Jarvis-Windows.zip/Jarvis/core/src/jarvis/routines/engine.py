"""Scheduler for reminders/alarms and trigger rules.

The scheduler task sleeps until the next due item (or until something
changes) — no polling. App triggers come from the context tracker's
``context.focus`` events.
"""

from __future__ import annotations

import asyncio
import contextlib
import logging
import time
from datetime import datetime, timedelta
from typing import TYPE_CHECKING, Any

from jarvis.bus import Event
from jarvis.notify import toast
from jarvis.routines.store import Reminder, RoutineStore, Rule
from jarvis.skills.text import norm, similarity

if TYPE_CHECKING:
    from jarvis.core import Core

log = logging.getLogger(__name__)

MISSED_GRACE = 90.0  # seconds late before a reminder counts as "missed"
APP_REOPEN_GAP = 30 * 60  # an app counts as "opened" if not seen for this long


def next_rule_time(rule: Rule, now: float | None = None) -> float | None:
    trig = rule.trigger
    if trig.get("type") != "time" or not rule.enabled:
        return None
    try:
        hh, mm = (int(x) for x in str(trig.get("at", "")).split(":"))
    except ValueError:
        return None
    now_dt = datetime.fromtimestamp(now or time.time())
    t = now_dt.replace(hour=hh, minute=mm, second=0, microsecond=0)
    if t <= now_dt:
        t += timedelta(days=1)
    days = trig.get("days", "daily")
    while (days == "weekdays" and t.weekday() >= 5) or (days == "weekends" and t.weekday() < 5):
        t += timedelta(days=1)
    return t.timestamp()


class RoutineEngine:
    def __init__(self, core: Core, store: RoutineStore) -> None:
        self.core = core
        self.store = store
        self._changed = asyncio.Event()
        self._task: asyncio.Task[None] | None = None
        self._app_last_seen: dict[str, float] = {}
        core.bus.subscribe("context.focus", self._on_focus)

    # ------------------------------------------------------------ lifecycle

    async def start(self) -> None:
        for rem in self.store.missed(time.time() - MISSED_GRACE):
            await self._fire(rem, missed=True)
        self._task = asyncio.create_task(self._scheduler())
        for rule in self.store.rules():
            if rule.enabled and rule.trigger.get("type") == "startup":
                asyncio.create_task(self.run_rule(rule, "Jarvis başladı"))

    async def stop(self) -> None:
        if self._task:
            self._task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await self._task

    def changed(self) -> None:
        """Call after adding/cancelling anything so the scheduler re-plans
        (and open UIs refresh their lists)."""
        self._changed.set()
        try:
            asyncio.get_running_loop()
            self.core.bus.emit("routine.changed")
        except RuntimeError:  # not on the event loop (worker thread / tests)
            try:
                self.core.bus.emit_threadsafe("routine.changed")
            except RuntimeError:
                pass

    # ------------------------------------------------------------ scheduler

    def _next(self) -> tuple[float, Reminder | Rule] | None:
        candidates: list[tuple[float, Reminder | Rule]] = []
        rem = self.store.next_due()
        if rem:
            candidates.append((rem.due, rem))
        for rule in self.store.rules():
            t = next_rule_time(rule)
            if t:
                candidates.append((t, rule))
        return min(candidates, key=lambda c: c[0]) if candidates else None

    async def _scheduler(self) -> None:
        while True:
            self._changed.clear()
            nxt = self._next()
            timeout = None if nxt is None else max(0.0, nxt[0] - time.time())
            try:
                await asyncio.wait_for(self._changed.wait(), timeout)
                continue  # something changed: re-plan
            except TimeoutError:
                pass
            if nxt is None:
                continue
            item = nxt[1]
            try:
                if isinstance(item, Reminder):
                    current = self.store.get_reminder(item.id)
                    if current and current.status == "pending" and current.due <= time.time() + 1:
                        await self._fire(current)
                else:
                    await self.run_rule(item, f"saat {item.trigger.get('at')}")
                    await asyncio.sleep(1)  # don't refire within the same minute
            except Exception:
                log.exception("routine fire failed")

    async def _fire(self, rem: Reminder, missed: bool = False) -> None:
        when = datetime.fromtimestamp(rem.due).strftime("%H:%M")
        if rem.kind == "alarm":
            title, sound = f"⏰ Alarm {when}", "alarm"
        elif rem.kind == "timer":
            title, sound = "⏲ Süre doldu", "alarm"
        else:
            title, sound = ("Kaçırılan hatırlatıcı" if missed else "Hatırlatıcı"), "reminder"
        body = rem.text + (f" (saat {when} için kurulmuştu)" if missed else "")
        await asyncio.to_thread(toast, title, body, sound)
        self.store.mark_fired(rem)
        await self.core.bus.publish("routine.fired", id=rem.id, kind=rem.kind, text=rem.text, missed=missed)
        await self.core.bus.publish("routine.changed")
        spoken = {"alarm": "Alarm çalıyor", "timer": "Zamanlayıcı bitti"}.get(rem.kind, "Hatırlatıcı") + f": {rem.text}"
        await self.core.notify_brain(f"[{spoken}{' — kaçırılmıştı' if missed else ''}] Kullanıcıya kısaca hatırlat.")
        self.changed()

    # ---------------------------------------------------------------- rules

    async def _on_focus(self, event: Event) -> None:
        app = str(event.data.get("app", ""))
        if not app:
            return
        now = time.time()
        last = self._app_last_seen.get(app, 0.0)
        self._app_last_seen[app] = now
        if now - last < APP_REOPEN_GAP:
            return
        for rule in self.store.rules():
            trig = rule.trigger
            if rule.enabled and trig.get("type") == "app_opened" and similarity(str(trig.get("app", "")), app) >= 0.85:
                await self.run_rule(rule, f"{app} açıldı")

    def _blocked(self, rule: Rule) -> str | None:
        now = time.time()
        if rule.cooldown_minutes and now - rule.last_fired < rule.cooldown_minutes * 60:
            return "cooldown"
        start, end = (rule.quiet_hours + [0, 0])[:2]
        hour = datetime.now().hour
        if start != end and (start <= hour < end if start < end else hour >= start or hour < end):
            return "quiet hours"
        return None

    def _describe_action(self, rule: Rule) -> str:
        a = rule.action
        if a.get("type") == "say":
            return str(a.get("text", ""))
        if a.get("type") == "prompt":
            return str(a.get("text", ""))
        args = ", ".join(f"{v}" for v in (a.get("args") or {}).values())
        return f"{a.get('tool')}({args})" if a.get("tool") else rule.name

    async def run_rule(self, rule: Rule, reason: str, force: bool = False) -> dict[str, Any]:
        blocked = None if force else self._blocked(rule)
        if blocked:
            log.info("rule %s skipped (%s)", rule.name, blocked)
            return {"skipped": blocked}
        rule.last_fired = time.time()
        self.store.save_rule(rule)
        await self.core.bus.publish("routine.rule", id=rule.id, name=rule.name, mode=rule.mode, reason=reason)
        action = rule.action
        what = self._describe_action(rule)

        if action.get("type") == "say" or rule.mode == "notify":
            await asyncio.to_thread(toast, rule.name, f"{reason}: {what}")
            await self.core.notify_brain(f"[Rutin: {rule.name} — {reason}] Kullanıcıya şunu söyle: {what}")
            return {"status": "notified"}

        tool, args = self._action_tool(action)
        if rule.mode == "ask":
            token = await self.core.tools.ask(tool, args, summary=f"{reason}. {rule.name}: {what}", source="routine")
            await asyncio.to_thread(toast, "Jarvis soruyor", f"{reason}. {rule.name} — yapayım mı?")
            await self.core.notify_brain(
                f"[Rutin: {reason}] Kullanıcıya sor: \"{rule.name} — yapayım mı?\" "
                f"Evet derse confirm_pending_action(token='{token}') çağır, hayır derse cancel_pending_action.")
            return {"status": "asked", "token": token}
        result = await self.core.tools.execute(tool, args, source="routine")
        await asyncio.to_thread(toast, rule.name, str(result.get("output") or result.get("error") or "tamam"))
        return result

    @staticmethod
    def _action_tool(action: dict[str, Any]) -> tuple[str, dict[str, Any]]:
        if action.get("type") == "prompt":
            return "run_routine_prompt", {"text": action.get("text", "")}
        return str(action.get("tool", "")), dict(action.get("args") or {})

    # ------------------------------------------------------------- helpers

    def find_reminders(self, query: str) -> list[Reminder]:
        q = norm(query)
        return [r for r in self.store.pending() if q in norm(r.text)]
