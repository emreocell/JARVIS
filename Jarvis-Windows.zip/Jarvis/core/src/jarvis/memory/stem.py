"""A small, conservative Turkish suffix stripper for search indexing.

SQLite FTS5 has no Turkish stemmer, so "Spotify'da", "Spotify'ı" and
"spotifyda" would not match "spotify". This strips common inflectional
suffixes (case, plural, possessive, a few verb endings) repeatedly while
keeping at least a 3-letter stem. It is intentionally conservative: a missed
suffix only costs recall, an over-eager one merges unrelated words.
"""

from __future__ import annotations

import re

from jarvis.skills.text import norm

# ordered longest-first; applied to diacritic-free lowercase text
_SUFFIXES = sorted({
    # plural + possessive + case combos
    "larimizdan", "lerimizden", "larindan", "lerinden", "larimiz", "lerimiz", "lariniz", "leriniz",
    "larini", "lerini", "larina", "lerine", "larinda", "lerinde", "lari", "leri", "lar", "ler",
    "imizden", "imiz", "iniz", "umuz", "umuzu",
    # possessive (+accusative): kahvemi, kitabımı, arabamız
    "imi", "umu", "mizi", "muzu", "miz", "muz", "mi", "mu",
    # case endings
    "ndan", "nden", "ndaki", "ndeki", "daki", "deki", "taki", "teki",
    "dan", "den", "tan", "ten", "nda", "nde", "da", "de", "ta", "te",
    "nin", "nun", "nın", "in", "un", "yi", "yu", "yla", "yle", "la", "le",
    "na", "ne", "ya", "ye", "ni", "nu", "si", "su",
    # common verb/adjective endings seen in commands and facts
    "iyorum", "iyor", "uyor", "mak", "mek", "masi", "mesi", "dir", "dur", "tir", "tur",
    "sin", "sun", "mis", "mus", "ci", "cu", "li", "lu", "siz", "suz",
    # no single-vowel suffixes: they eat the last letter of names ("Ayşe", "Code", "kahve")
}, key=len, reverse=True)

# bump whenever the rules change: MemoryStore re-indexes existing facts on startup
STEM_VERSION = 3

_TOKEN = re.compile(r"[a-z0-9]+")
MIN_STEM = 3

STOPWORDS = frozenset(
    "ve veya ile de da ki bu su o bir icin gibi ama fakat cok daha en mi mu ne neden nasil "
    "ben sen biz siz onlar benim senin bana sana beni seni evet hayir tamam lutfen tesekkurler "
    "sagol merhaba selam the a an and or of to is are i you it".split()
)


def stem(word: str) -> str:
    w = word
    changed = True
    while changed and len(w) > MIN_STEM:
        changed = False
        for suffix in _SUFFIXES:
            if w.endswith(suffix) and len(w) - len(suffix) >= MIN_STEM:
                w = w[: -len(suffix)]
                changed = True
                break
    return w


def tokens(text: str, keep_stopwords: bool = False) -> list[str]:
    raw = _TOKEN.findall(norm(text.replace("'", " ").replace("’", " ")))
    return [stem(t) for t in raw if keep_stopwords or t not in STOPWORDS]


def search_text(text: str) -> str:
    """What goes into the FTS index: stemmed, diacritic-free tokens."""
    return " ".join(tokens(text, keep_stopwords=True))
