"""Long-term memory: one SQLite file.

* ``facts`` — durable knowledge about the user (content, category, source,
  confidence, pinned, supersedes, usage stats). Updates never overwrite: the
  old row is deactivated and the new row points at it via ``supersedes``.
* ``facts_fts`` — FTS5 index over Turkish-stemmed text.
* ``embeddings`` — optional vectors (brute-force cosine; fine < 50k facts).
* ``messages`` / ``episodes`` — conversation log and per-session summaries.
* ``events`` — append-only history of every memory change.

All methods are synchronous and cheap; call them via ``asyncio.to_thread``
from the event loop when doing many at once.
"""

from __future__ import annotations

import json
import sqlite3
import threading
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np

from jarvis.memory.stem import STEM_VERSION, search_text, tokens
from jarvis.skills.text import norm

SCHEMA = """
CREATE TABLE IF NOT EXISTS facts (
    id INTEGER PRIMARY KEY,
    content TEXT NOT NULL,
    search TEXT NOT NULL,
    category TEXT NOT NULL DEFAULT 'general',
    source TEXT NOT NULL DEFAULT 'user',
    confidence REAL NOT NULL DEFAULT 0.8,
    pinned INTEGER NOT NULL DEFAULT 0,
    active INTEGER NOT NULL DEFAULT 1,
    supersedes INTEGER REFERENCES facts(id),
    created REAL NOT NULL,
    updated REAL NOT NULL,
    last_used REAL,
    use_count INTEGER NOT NULL DEFAULT 0
);
CREATE VIRTUAL TABLE IF NOT EXISTS facts_fts USING fts5(search, content='facts', content_rowid='id');
CREATE TRIGGER IF NOT EXISTS facts_ai AFTER INSERT ON facts BEGIN
    INSERT INTO facts_fts(rowid, search) VALUES (new.id, new.search);
END;
CREATE TRIGGER IF NOT EXISTS facts_ad AFTER DELETE ON facts BEGIN
    INSERT INTO facts_fts(facts_fts, rowid, search) VALUES ('delete', old.id, old.search);
END;
CREATE TRIGGER IF NOT EXISTS facts_au AFTER UPDATE OF search ON facts BEGIN
    INSERT INTO facts_fts(facts_fts, rowid, search) VALUES ('delete', old.id, old.search);
    INSERT INTO facts_fts(rowid, search) VALUES (new.id, new.search);
END;
CREATE TABLE IF NOT EXISTS embeddings (
    fact_id INTEGER PRIMARY KEY REFERENCES facts(id) ON DELETE CASCADE,
    model TEXT NOT NULL,
    vec BLOB NOT NULL
);
CREATE TABLE IF NOT EXISTS messages (
    id INTEGER PRIMARY KEY,
    ts REAL NOT NULL,
    session TEXT NOT NULL,
    role TEXT NOT NULL,
    text TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS messages_session ON messages(session, id);
CREATE TABLE IF NOT EXISTS episodes (
    id INTEGER PRIMARY KEY,
    session TEXT UNIQUE NOT NULL,
    started REAL NOT NULL,
    ended REAL NOT NULL,
    summary TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT);
CREATE TABLE IF NOT EXISTS events (
    id INTEGER PRIMARY KEY,
    ts REAL NOT NULL,
    kind TEXT NOT NULL,
    fact_id INTEGER,
    payload TEXT
);
"""

CATEGORIES = ("identity", "preference", "relationship", "work", "project", "habit", "device", "general")


@dataclass(slots=True)
class Fact:
    id: int
    content: str
    category: str
    source: str
    confidence: float
    pinned: bool
    created: float
    updated: float
    use_count: int
    score: float = 0.0

    def as_dict(self) -> dict[str, Any]:
        return {"id": self.id, "content": self.content, "category": self.category, "source": self.source,
                "confidence": self.confidence, "pinned": self.pinned, "created": self.created,
                "updated": self.updated, "use_count": self.use_count, "score": round(self.score, 3)}


def _row(r: sqlite3.Row, score: float = 0.0) -> Fact:
    return Fact(r["id"], r["content"], r["category"], r["source"], r["confidence"], bool(r["pinned"]),
                r["created"], r["updated"], r["use_count"], score)


class MemoryStore:
    def __init__(self, path: Path) -> None:
        self.path = path
        path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self._db = sqlite3.connect(path, check_same_thread=False, isolation_level=None)
        self._db.row_factory = sqlite3.Row
        self._db.execute("PRAGMA journal_mode=WAL")
        self._db.execute("PRAGMA foreign_keys=ON")
        self._db.executescript(SCHEMA)
        self._reindex_if_needed()

    def _reindex_if_needed(self) -> None:
        row = self._db.execute("SELECT value FROM meta WHERE key='stem_version'").fetchone()
        if row and int(row[0]) == STEM_VERSION:
            return
        with self._lock:
            for fid, content in self._db.execute("SELECT id, content FROM facts").fetchall():
                self._db.execute("UPDATE facts SET search=? WHERE id=?", (search_text(content), fid))
            self._db.execute("INSERT OR REPLACE INTO meta(key, value) VALUES ('stem_version', ?)",
                             (str(STEM_VERSION),))

    def close(self) -> None:
        self._db.close()

    def _event(self, kind: str, fact_id: int | None, **payload: Any) -> None:
        self._db.execute("INSERT INTO events(ts, kind, fact_id, payload) VALUES (?,?,?,?)",
                         (time.time(), kind, fact_id, json.dumps(payload, ensure_ascii=False)))

    # ---------------------------------------------------------------- facts

    def get(self, fact_id: int) -> Fact | None:
        r = self._db.execute("SELECT * FROM facts WHERE id=?", (fact_id,)).fetchone()
        return _row(r) if r else None

    def find_duplicate(self, content: str, threshold: float = 0.88) -> Fact | None:
        from difflib import SequenceMatcher

        target = norm(content)
        for f in self.search(content, k=5, strict=False):
            if SequenceMatcher(None, norm(f.content), target).ratio() >= threshold:
                return f
        return None

    def add(self, content: str, category: str = "general", source: str = "user",
            confidence: float = 0.8, pinned: bool = False) -> tuple[int, bool]:
        """Add a fact; returns (id, created). A near-duplicate refreshes the
        existing fact instead of adding a second copy."""
        content = content.strip()
        if not content:
            raise ValueError("empty fact")
        category = category if category in CATEGORIES else "general"
        with self._lock:
            dup = self.find_duplicate(content)
            now = time.time()
            if dup is not None:
                self._db.execute("UPDATE facts SET updated=?, confidence=MAX(confidence, ?) WHERE id=?",
                                 (now, confidence, dup.id))
                self._event("reinforce", dup.id, source=source)
                return dup.id, False
            cur = self._db.execute(
                "INSERT INTO facts(content, search, category, source, confidence, pinned, created, updated) "
                "VALUES (?,?,?,?,?,?,?,?)",
                (content, search_text(content), category, source, confidence, int(pinned), now, now))
            fid = int(cur.lastrowid)
            self._event("add", fid, content=content, category=category, source=source)
            return fid, True

    def update(self, fact_id: int, content: str, source: str = "user") -> int:
        """Supersede a fact with new content (keeps history)."""
        with self._lock:
            old = self.get(fact_id)
            if old is None:
                raise KeyError(fact_id)
            now = time.time()
            cur = self._db.execute(
                "INSERT INTO facts(content, search, category, source, confidence, pinned, supersedes, created, updated) "
                "VALUES (?,?,?,?,?,?,?,?,?)",
                (content.strip(), search_text(content), old.category, source, max(old.confidence, 0.8),
                 int(old.pinned), fact_id, now, now))
            new_id = int(cur.lastrowid)
            self._db.execute("UPDATE facts SET active=0, updated=? WHERE id=?", (now, fact_id))
            self._db.execute("DELETE FROM embeddings WHERE fact_id=?", (fact_id,))
            self._event("update", new_id, old_id=fact_id, old=old.content, new=content)
            return new_id

    def forget(self, fact_id: int, source: str = "user") -> bool:
        with self._lock:
            f = self.get(fact_id)
            if f is None:
                return False
            self._db.execute("UPDATE facts SET active=0, updated=? WHERE id=?", (time.time(), fact_id))
            self._db.execute("DELETE FROM embeddings WHERE fact_id=?", (fact_id,))
            self._event("forget", fact_id, content=f.content, source=source)
            return True

    def set_pinned(self, fact_id: int, pinned: bool) -> None:
        with self._lock:
            self._db.execute("UPDATE facts SET pinned=? WHERE id=?", (int(pinned), fact_id))
            self._event("pin" if pinned else "unpin", fact_id)

    def mark_used(self, ids: list[int]) -> None:
        if ids:
            with self._lock:
                self._db.executemany("UPDATE facts SET use_count=use_count+1, last_used=? WHERE id=?",
                                     [(time.time(), i) for i in ids])

    def list(self, category: str | None = None, limit: int = 500) -> list[Fact]:
        sql = "SELECT * FROM facts WHERE active=1"
        args: list[Any] = []
        if category:
            sql += " AND category=?"
            args.append(category)
        sql += " ORDER BY pinned DESC, updated DESC LIMIT ?"
        args.append(limit)
        return [_row(r) for r in self._db.execute(sql, args)]

    def count(self) -> int:
        return int(self._db.execute("SELECT COUNT(*) FROM facts WHERE active=1").fetchone()[0])

    # ---------------------------------------------------------- embeddings

    def set_embedding(self, fact_id: int, model: str, vec: list[float]) -> None:
        arr = np.asarray(vec, dtype=np.float32)
        arr /= (np.linalg.norm(arr) or 1.0)
        with self._lock:
            self._db.execute("INSERT OR REPLACE INTO embeddings(fact_id, model, vec) VALUES (?,?,?)",
                             (fact_id, model, arr.tobytes()))

    def missing_embeddings(self, model: str, limit: int = 100) -> list[Fact]:
        rows = self._db.execute(
            "SELECT f.* FROM facts f LEFT JOIN embeddings e ON e.fact_id=f.id AND e.model=? "
            "WHERE f.active=1 AND e.fact_id IS NULL LIMIT ?", (model, limit))
        return [_row(r) for r in rows]

    def _vector_scores(self, query_vec: list[float], model: str) -> dict[int, float]:
        rows = self._db.execute(
            "SELECT e.fact_id, e.vec FROM embeddings e JOIN facts f ON f.id=e.fact_id "
            "WHERE f.active=1 AND e.model=?", (model,)).fetchall()
        if not rows:
            return {}
        q = np.asarray(query_vec, dtype=np.float32)
        q /= (np.linalg.norm(q) or 1.0)
        mat = np.frombuffer(b"".join(r["vec"] for r in rows), dtype=np.float32).reshape(len(rows), -1)
        if mat.shape[1] != q.shape[0]:
            return {}
        sims = mat @ q
        return {int(r["fact_id"]): float(s) for r, s in zip(rows, sims)}

    # --------------------------------------------------------------- search

    def search(self, query: str, k: int = 5, strict: bool = True,
               query_vec: list[float] | None = None, model: str = "") -> list[Fact]:
        """Hybrid search. ``strict`` drops weak matches so small talk ("tamam",
        "teşekkürler") never drags memories into the prompt."""
        q_tokens = tokens(query)
        scores: dict[int, float] = {}
        if q_tokens:
            match = " OR ".join(f'"{t}"*' for t in dict.fromkeys(q_tokens))
            try:
                rows = self._db.execute(
                    "SELECT rowid, bm25(facts_fts) AS rank FROM facts_fts WHERE facts_fts MATCH ? "
                    "ORDER BY rank LIMIT 50", (match,)).fetchall()
            except sqlite3.OperationalError:
                rows = []
            for r in rows:
                # bm25 is negative (better = more negative); squash into 0..1
                scores[int(r["rowid"])] = 1.0 - 1.0 / (1.0 + abs(r["rank"]))
        vec_scores = self._vector_scores(query_vec, model) if query_vec is not None else {}
        for fid, sim in vec_scores.items():
            if sim >= (0.55 if strict else 0.35):
                scores[fid] = max(scores.get(fid, 0.0), 0.0) * 0.5 + sim
        if not scores:
            return []
        placeholders = ",".join("?" * len(scores))
        rows = self._db.execute(f"SELECT * FROM facts WHERE active=1 AND id IN ({placeholders})",
                                list(scores)).fetchall()
        facts = []
        q_set = set(q_tokens)
        for r in rows:
            overlap = len(q_set & set(r["search"].split()))
            if strict and overlap == 0 and vec_scores.get(r["id"], 0.0) < 0.55:
                continue
            score = scores[r["id"]] + 0.15 * overlap + (0.1 if r["pinned"] else 0.0)
            facts.append(_row(r, score))
        facts.sort(key=lambda f: f.score, reverse=True)
        return facts[:k]

    def profile(self, limit: int = 12) -> list[Fact]:
        """Small always-in-prompt core: pinned first, then most used/recent."""
        rows = self._db.execute(
            "SELECT * FROM facts WHERE active=1 ORDER BY pinned DESC, use_count DESC, updated DESC LIMIT ?",
            (limit,))
        return [_row(r) for r in rows]

    # ------------------------------------------------------ conversations

    def log_message(self, session: str, role: str, text: str) -> None:
        if text.strip():
            with self._lock:
                self._db.execute("INSERT INTO messages(ts, session, role, text) VALUES (?,?,?,?)",
                                 (time.time(), session, role, text.strip()))

    def session_messages(self, session: str) -> list[dict[str, Any]]:
        rows = self._db.execute("SELECT ts, role, text FROM messages WHERE session=? ORDER BY id", (session,))
        return [dict(r) for r in rows]

    def recent_messages(self, limit: int = 20) -> list[dict[str, Any]]:
        rows = self._db.execute("SELECT ts, session, role, text FROM messages ORDER BY id DESC LIMIT ?", (limit,))
        return [dict(r) for r in rows][::-1]

    def sessions(self, limit: int = 30, offset: int = 0, query: str = "") -> list[dict[str, Any]]:
        """Conversation list, newest first: time span, turn count, the opening
        user line (as a title fallback) and the episode summary if extracted."""
        where, args = "", []
        if query.strip():
            where = "WHERE m.session IN (SELECT session FROM messages WHERE text LIKE ? ESCAPE '\\')"
            args.append("%" + query.strip().replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%")
        rows = self._db.execute(f"""
            SELECT m.session, MIN(m.ts) AS started, MAX(m.ts) AS ended,
                   SUM(m.role = 'user') AS turns,
                   (SELECT text FROM messages f WHERE f.session = m.session AND f.role = 'user'
                    ORDER BY f.id LIMIT 1) AS opening,
                   e.summary
            FROM messages m LEFT JOIN episodes e ON e.session = m.session
            {where}
            GROUP BY m.session ORDER BY ended DESC, MAX(m.id) DESC LIMIT ? OFFSET ?""", (*args, limit, offset))
        return [dict(r) for r in rows]

    def delete_session(self, session: str) -> int:
        with self._lock:
            n = self._db.execute("DELETE FROM messages WHERE session=?", (session,)).rowcount
            self._db.execute("DELETE FROM episodes WHERE session=?", (session,))
        return n

    def save_episode(self, session: str, started: float, ended: float, summary: str) -> None:
        with self._lock:
            self._db.execute("INSERT OR REPLACE INTO episodes(session, started, ended, summary) VALUES (?,?,?,?)",
                             (session, started, ended, summary))

    def last_episode(self) -> dict[str, Any] | None:
        r = self._db.execute("SELECT * FROM episodes ORDER BY ended DESC LIMIT 1").fetchone()
        return dict(r) if r else None

    def history(self, limit: int = 50) -> list[dict[str, Any]]:
        rows = self._db.execute("SELECT ts, kind, fact_id, payload FROM events ORDER BY id DESC LIMIT ?", (limit,))
        return [{**dict(r), "payload": json.loads(r["payload"] or "{}")} for r in rows]
