"""Browser mini-games: Jarvis plays, and reports how fast it decided."""

from __future__ import annotations

from typing import Annotated, Literal

from jarvis.tools import Risk, ToolContext, tool

HUMAN = {"aim": "insan ortalaması hedef başına ~450 ms", "reaction": "insan ortalaması ~270 ms"}


def _say(res: dict) -> str:
    game = res.get("game")
    if game == "aim":
        avg = res.get("site_avg_ms_per_target")
        text = (f"Aim Trainer bitti: hedef başına ortalama {avg} ms ({HUMAN['aim']})." if avg
                else "Aim Trainer tamamlanamadı.")
    elif game == "reaction":
        text = f"Tepki testi: medyan {res.get('site_median_ms')} ms ({HUMAN['reaction']})."
    else:
        text = f"Yılan: {res.get('apples')} elma, {res.get('seconds')} saniye."
    if res.get("jev_decisions"):
        text += f" Jev {res['jev_decisions']} karar verdi, karar başına ~{res['jev_median_ms']} ms."
    if res.get("local_fallbacks"):
        text += f" Jev {res['local_fallbacks']} kez yanıt veremedi; o hamleler yerel yapıldı."
    return text


@tool(platforms=("win32", "darwin"), risk=Risk.LOW, category="browser", timeout=240, requires=("playwright",), background=True)
async def play_browser_game(ctx: ToolContext,
                            game: Annotated[Literal["aim", "reaction", "snake"],
                                            "aim = Aim Trainer, reaction = tepki süresi testi, snake = Google Yılan"],
                            mode: Annotated[Literal["jev", "refleks"],
                                            "jev = her hamlede Jev karar verir; refleks = Jev hedefi bir kez "
                                            "öğrenir, sonrası yerel ve en hızlısı"] = "refleks") -> dict:
    """Tarayıcıda bir oyunu Jarvis kendisi oynar ve hızını ölçer (Aim Trainer, tepki testi, Google Yılan).
    'yılan oyunu aç ve oyna', 'aim trainer oyna', 'jev ile tepki testini dene' gibi isteklerde kullan.
    Yılanda yön kararları her zaman yerel planlayıcıdadır (oyun ağ gecikmesine izin vermeyecek kadar hızlı)."""
    from jarvis.games import play, snake
    from jarvis.skills.browser import _mode, session

    s = session()
    page = await s.ensure(_mode(ctx))
    await page.bring_to_front()

    async def progress(n: int, stats: object) -> None:
        await ctx.core.bus.publish("game.progress", game=game, step=n)

    if game == "aim":
        res = await play.play_aim(ctx.core, page, mode, progress=progress)
    elif game == "reaction":
        res = await play.play_reaction(ctx.core, page, mode, progress=progress)
    else:
        res = await snake.play_snake(ctx.core, page, progress=progress)
    return {"output": _say(res), "details": res}
