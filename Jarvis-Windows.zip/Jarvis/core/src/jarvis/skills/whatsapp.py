"""WhatsApp Desktop messaging.

Flow (ported from v2, where it was the one reliably working path, and
hardened):

1. open/focus WhatsApp (Store app AUMID or ``whatsapp:`` URI);
2. Ctrl+F, paste the contact name (clipboard — Turkish-safe);
3. read the chat list (UIA ``ListItemControl``) and fuzzy-match the name;
   ambiguous → return candidates so the assistant can ask;
4. open the chat and **verify the header shows that contact** — if not,
   nothing is sent;
5. paste the message and press Enter; restore the user's clipboard.

Phone numbers use the ``whatsapp://send`` URI (opened with ``os.startfile``;
v2's ``cmd start`` dropped everything after ``&``).
"""

from __future__ import annotations

import logging
import os
import re
import time
import urllib.parse
from typing import Annotated, Any

from jarvis.skills import desktop
from jarvis.skills.text import norm, similarity
from jarvis.tools import Risk, tool

log = logging.getLogger(__name__)

WINDOW_NAMES = ("WhatsApp", "WhatsApp Beta", "WhatsApp Business")
MESSAGE_BOX_NAMES = ("bir mesaj yazın", "bir mesaj yaz", "type a message", "mesaj yaz")
_NAME_SUFFIXES = (" grubuna", " grubundan", " grubu", " kişisine", " kisisine", " sohbetine",
                  " sohbetinden", " kişisinden", " kisisinden", " olan kişiye", " olan kisiye", " ile")
_PHONE = re.compile(r"^\+?[\d\s()-]{8,}$")


def clean_contact(name: str) -> str:
    """'Ahmet'e' -> 'Ahmet', 'İş grubuna' -> 'İş'."""
    cleaned = re.sub(r"['’]\w+$", "", name.strip())
    lowered = cleaned.lower()
    for suffix in sorted(_NAME_SUFFIXES, key=len, reverse=True):
        if lowered.endswith(suffix):
            return cleaned[: -len(suffix)].strip()
    return cleaned


def _chat_title(item_name: str) -> str:
    """List items read like 'Ahmet Yılmaz, son mesaj..., 12:30' — keep the name part."""
    return item_name.split(",")[0].strip()


def pick_candidate(query: str, items: list[str]) -> tuple[str | None, list[str]]:
    """Return (chosen item, ambiguous candidates)."""
    scored = sorted(((similarity(query, _chat_title(i)), i) for i in items), reverse=True)
    scored = [s for s in scored if s[0] >= 0.6]
    if not scored:
        return None, []
    best_score, best = scored[0]
    exact = [i for s, i in scored if norm(_chat_title(i)) == norm(query)]
    if len(exact) == 1:
        return exact[0], []
    if len(scored) > 1 and best_score < 0.99 and scored[1][0] >= best_score - 0.05:
        return None, [_chat_title(i) for _, i in scored[:4]]
    return best, []


# ------------------------------------------------------------ UIA plumbing


def _window():
    import uiautomation as auto

    for title in WINDOW_NAMES:
        w = auto.WindowControl(searchDepth=1, Name=title)
        if w.Exists(0.3):
            return w
    return None


def _restore_hidden() -> bool:
    """WhatsApp (WinUI) hides its window when minimized to the tray; bring it back."""
    import ctypes
    from ctypes import wintypes

    import psutil

    user32 = ctypes.windll.user32
    found: list[int] = []

    def cb(hwnd, _):
        pid = wintypes.DWORD()
        user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        buf = ctypes.create_unicode_buffer(64)
        user32.GetWindowTextW(hwnd, buf, 64)
        if buf.value in WINDOW_NAMES:
            try:
                if psutil.Process(pid.value).name().lower().startswith("whatsapp"):
                    found.append(hwnd)
            except psutil.Error:
                pass
        return True

    user32.EnumWindows(ctypes.WINFUNCTYPE(ctypes.c_bool, wintypes.HWND, wintypes.LPARAM)(cb), 0)
    for hwnd in found:
        user32.ShowWindow(hwnd, 9)  # SW_RESTORE
        user32.SetForegroundWindow(hwnd)
    return bool(found)


def _open_whatsapp():
    w = _window()
    if w is not None:
        return w
    if _restore_hidden():
        w = desktop.wait_until(_window, timeout=5)
        if w is not None:
            return w
    from jarvis.skills.apps import INDEX, _launch_aumid

    match = INDEX.find("WhatsApp", 1)
    if match:
        _launch_aumid(match[0][2])
    else:
        os.startfile("whatsapp:")
    return desktop.wait_until(_window, timeout=15)


def _stable_items(window: Any, timeout: float = 3.0) -> list[str]:
    """Search results update asynchronously: wait until two reads agree."""
    time.sleep(0.4)
    previous: list[str] | None = None
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        current = _list_items(window)
        if current and current == previous:
            return current
        previous = current
        time.sleep(0.3)
    return previous or []


def _first_text(ctrl: Any) -> str:
    for child, _ in desktop.walk(ctrl, 8):
        if child.ControlTypeName == "TextControl" and (child.Name or "").strip():
            return child.Name.strip()
    return ""


def _rows(window: Any, limit: int = 12) -> list[tuple[str, Any]]:
    """Chat rows as (title, control). Old Electron builds use list items named
    'Title, preview, 12:30'; the WinUI build uses data-grid items whose first
    text element is the title. Nested duplicates are dropped (first wins)."""
    out: list[tuple[str, Any]] = []
    seen: set[str] = set()
    for ctrl, _ in desktop.walk(window, 30):
        kind = ctrl.ControlTypeName
        if kind == "ListItemControl":
            title = _chat_title(ctrl.Name or "")
        elif kind == "DataItemControl":
            title = _first_text(ctrl)
        else:
            continue
        if title and title not in seen:
            seen.add(title)
            out.append((title, ctrl))
            if len(out) >= limit:
                break
    return out


def _list_items(window: Any, limit: int = 12) -> list[str]:
    return [title for title, _ in _rows(window, limit)]


def _find_list_item(window: Any, name: str):
    return next((ctrl for title, ctrl in _rows(window, 40) if title == name), None)


def _header_shows(window: Any, contact: str) -> bool:
    """Is the open chat's header (top of the right pane) showing ``contact``?"""
    rect = window.BoundingRectangle
    header_bottom = rect.top + 160
    mid_x = rect.left + (rect.right - rect.left) * 0.3
    for ctrl, _ in desktop.walk(window, 22):
        name = (ctrl.Name or "").strip()
        if not name or ctrl.ControlTypeName == "ListItemControl":
            continue
        r = ctrl.BoundingRectangle
        if r.top < header_bottom and r.left > mid_x and similarity(contact, name.split(",")[0]) >= 0.85:
            return True
    return False


def _message_box(window: Any):
    wanted = [norm(n) for n in MESSAGE_BOX_NAMES]
    for ctrl, _ in desktop.walk(window, 30):
        if ctrl.ControlTypeName == "EditControl" and any(n in norm(ctrl.Name or "") for n in wanted):
            return ctrl
    return None


def box_targets_other_chat(box_name: str, title: str) -> bool:
    """WinUI labels the box '<Chat> grup sohbetine bir mesaj yazın' /
    '<Chat> ile sohbete…'. If the label names a chat, it must be ours."""
    label = norm(box_name)
    names_a_chat = any(k in label for k in ("sohbetine", "sohbete", "ile ", "message ", "chat with"))
    return names_a_chat and norm(title) not in label


def _focus_message_box(window: Any) -> None:
    box = _message_box(window)
    if box is not None:
        try:
            box.Click(simulateMove=False)
            return
        except Exception:
            pass
    # new Electron builds don't expose the box: it's always bottom-centre of the chat pane
    import uiautomation as auto

    r = window.BoundingRectangle
    auto.Click((r.left + r.right) // 2 + (r.right - r.left) // 6, r.bottom - 40, waitTime=0.1)


def _send_via_search(contact: str, message: str) -> dict:
    import uiautomation as auto

    with auto.UIAutomationInitializerInThread():
        window = _open_whatsapp()
        if window is None:
            return {"error": "WhatsApp açılamadı."}
        desktop.activate(window)
        with desktop.preserved_clipboard():
            desktop.hotkey("{Ctrl}f")
            time.sleep(0.3)
            desktop.hotkey("{Ctrl}a{Delete}")
            desktop.paste_text(contact)
            items = _stable_items(window)
            chosen, ambiguous = pick_candidate(contact, items)
            if ambiguous:
                desktop.hotkey("{Esc}")
                return {"status": "ambiguous", "candidates": ambiguous,
                        "instruction": "Kullanıcıya hangi kişiyi kastettiğini sor, sonra tam adla tekrar çağır."}
            if chosen is None:
                desktop.hotkey("{Esc}")
                return {"error": f"WhatsApp'ta '{contact}' bulunamadı.", "seen": [_chat_title(i) for i in items[:5]]}
            item = _find_list_item(window, chosen)
            if item is not None:
                item.Click(simulateMove=False)
            else:
                desktop.hotkey("{Enter}")
            title = _chat_title(chosen)
            if not desktop.wait_until(lambda: _header_shows(window, title), timeout=3):
                return {"error": f"'{title}' sohbetinin açıldığını doğrulayamadım; mesaj gönderilmedi."}
            box = _message_box(window)
            if box is not None and box_targets_other_chat(box.Name or "", title):
                return {"error": f"Mesaj kutusu '{title}' sohbetine ait görünmüyor; güvenlik için gönderilmedi."}
            _focus_message_box(window)
            desktop.paste_text(message)
            time.sleep(0.15)
            desktop.hotkey("{Enter}")
            # verify: a sent message leaves the compose box empty
            sent = desktop.wait_until(lambda: not _box_text(window), timeout=3)
    if not sent:
        return {"output": f"{title} sohbetine yazdım ve Enter'a bastım.", "verified": False,
                "observed": "mesaj hâlâ yazma kutusunda duruyor", "verified_by_tool": True,
                "problem": "Mesajın gittiğini doğrulayamadım; kullanıcıya WhatsApp'a bakmasını söyle."}
    return {"output": f"{title} kişisine gönderildi.", "verified": True, "observed": "yazma kutusu boşaldı",
            "verified_by_tool": True}


def _box_text(window: Any) -> str:
    box = _message_box(window)
    if box is None:
        return ""
    try:
        return (box.GetValuePattern().Value or "").strip()
    except Exception:
        try:
            return (box.GetTextPattern().DocumentRange.GetText(-1) or "").strip()
        except Exception:
            return ""


def _send_via_number(phone: str, message: str) -> dict:
    digits = re.sub(r"[^\d+]", "", phone).lstrip("+")
    if digits.startswith("0"):
        digits = "90" + digits[1:]  # Turkish local format
    os.startfile(f"whatsapp://send?phone={digits}&text={urllib.parse.quote(message)}")
    import uiautomation as auto

    with auto.UIAutomationInitializerInThread():
        window = desktop.wait_until(_window, timeout=10)
        if window is None:
            return {"error": "WhatsApp açılamadı."}
        desktop.activate(window)
        time.sleep(1.2)  # the chat opens with the text pre-filled
        desktop.hotkey("{Enter}")
    return {"output": f"{phone} numarasına gönderildi."}


@tool(risk=Risk.SEND, category="communication", timeout=45, requires=("uiautomation",), uia=True)
def send_whatsapp(contact: Annotated[str, "Kişi veya grup adı (kullanıcının söylediği gibi) ya da telefon numarası"],
                  message: Annotated[str, "Gönderilecek mesajın tam metni"]) -> dict:
    """WhatsApp masaüstü uygulamasından bir kişiye veya gruba mesaj gönderir."""
    target = clean_contact(contact)
    if not message.strip():
        return {"error": "Mesaj boş."}
    if _PHONE.match(target):
        return _send_via_number(target, message)
    return _send_via_search(target, message)


send_whatsapp._describe = lambda contact, message: f"WhatsApp'tan {clean_contact(contact)} kişisine “{message}” gönder"  # type: ignore[attr-defined]
send_whatsapp._fingerprint_keys = ("contact",)  # type: ignore[attr-defined]
