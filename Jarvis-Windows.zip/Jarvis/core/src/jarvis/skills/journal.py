"""'Bugün ne yaptım?' and the second brain."""

from __future__ import annotations

import asyncio
import os
import re
from datetime import datetime
from pathlib import Path
from typing import Annotated

from jarvis.tools import Risk, ToolContext, tool


def second_brain_dir(core) -> Path:
    configured = getattr(core.config.assistant, "second_brain_dir", "") or ""
    if configured:
        return Path(os.path.expandvars(os.path.expanduser(configured)))
    home = Path(os.environ.get("USERPROFILE", Path.home()))
    for docs in (home / "OneDrive" / "Belgeler", home / "OneDrive" / "Documents", home / "Documents"):
        if docs.is_dir():
            return docs / "Jarvis Beyin"
    return home / "Documents" / "Jarvis Beyin"


@tool(risk=Risk.READ, category="notes", timeout=40, platforms=())
async def what_did_i_do(ctx: ToolContext,
                        day: Annotated[str, "'bugün', 'dün' veya tarih (2026-09-25)"] = "bugün") -> dict:
    """Kullanıcının bir günde bilgisayarda ne yaptığını zaman bloklarıyla çıkarır: hangi proje, hangi
    uygulamalar, hangi dosyalar, git değişiklikleri, Jarvis'e yaptırılan işler. 'Bugün ne yaptım?',
    'dün hangi projelerle uğraştım', 'bugünkü işlerimi özetle' gibi isteklerde kullan."""
    journal = getattr(ctx.core, "journal", None)
    if journal is None:
        return {"error": "İş günlüğü kapalı (Ayarlar → Özellikler → Bağlam izleyici)."}
    from jarvis.journal.day import summarize_day

    data = await asyncio.to_thread(summarize_day, journal, day)
    if not data["blocks"]:
        return {"output": "Bu gün için kayıtlı bir çalışma yok (günlük, özellik açıldıktan sonra tutulmaya başlar).",
                "day": data["day"]}
    return {**data, "note": "Zaman aralıklarıyla, proje başlıkları ve kısa maddelerle özetle; dosya ve commit "
                            "adlarından ne yapıldığını çıkar. Sesli cevapta en fazla 4-5 cümle."}


@tool(risk=Risk.LOW, category="notes", timeout=20, platforms=())
async def save_to_second_brain(ctx: ToolContext,
                               title: Annotated[str, "Notun başlığı, ör. '26 Eylül iş günlüğü'"],
                               content: Annotated[str, "Markdown içerik (özet, maddeler, kararlar)"],
                               folder: Annotated[str, "Alt klasör: 'Günlük', 'Toplantılar', 'Projeler'…"] = "Günlük") -> dict:
    """İkinci beyne (Obsidian uyumlu Markdown klasörü) not kaydeder; ayrıca Jarvis Notlar'a da ekler.
    'Bugünkü işlerimi ikinci beynime özetle', 'bunu ikinci beynime kaydet' gibi isteklerde kullan."""
    base = second_brain_dir(ctx.core)
    safe_folder = re.sub(r'[<>:"/\\|?*]', "", folder).strip() or "Günlük"
    target_dir = base / safe_folder
    target_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y-%m-%d")
    name = re.sub(r'[<>:"/\\|?*\n]', "", title).strip()[:80] or stamp
    path = target_dir / (name if name.startswith(stamp) else f"{stamp} {name}")
    path = path.with_suffix(".md")
    header = f"# {title}\n\n*{datetime.now():%d.%m.%Y %H:%M} — Jarvis*\n\n"
    mode = "a" if path.exists() else "w"
    with open(path, mode, encoding="utf-8") as f:
        f.write(("\n\n---\n\n" if mode == "a" else header) + content.strip() + "\n")
    notes = getattr(ctx.core, "notes", None)
    if notes is not None:
        try:
            notes.add(f"{title}\n{content[:1500]}", source="jarvis")
        except Exception:
            pass
    return {"output": f"İkinci beynine kaydettim: {safe_folder}/{path.name}", "path": str(path)}
