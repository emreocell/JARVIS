"""Launching and closing applications, opening files and folders.

Apps are resolved from Windows' own Start-menu index (``Get-StartApps``),
which covers classic desktop apps *and* Store apps (AUMIDs like
``SpotifyAB.SpotifyMusic_zpdnekdrzrea0!Spotify``) — the old project could
not open Store apps. Launching goes through ``shell:AppsFolder\\<AppID>``.
"""

from __future__ import annotations

import json
import logging
import os
import subprocess
import time
from pathlib import Path
from typing import Annotated, Literal

import psutil

from jarvis.skills.text import clean_name, norm, similarity
from jarvis.tools import Risk, tool

log = logging.getLogger(__name__)

NO_WINDOW = 0x08000000  # CREATE_NO_WINDOW

# spoken Turkish/English names -> Start-menu names ("|"-separated: Windows localizes them) or a URI
ALIASES: dict[str, str] = {
    "hesap makinesi": "Hesap Makinesi|Calculator", "calculator": "Hesap Makinesi|Calculator",
    "ayarlar": "ms-settings:", "settings": "ms-settings:",
    "gorev yoneticisi": "Görev Yöneticisi|Task Manager", "task manager": "Görev Yöneticisi|Task Manager",
    "dosya gezgini": "explorer:", "file explorer": "explorer:", "explorer": "explorer:",
    "not defteri": "Not Defteri|Notepad", "notepad": "Not Defteri|Notepad",
    "vs code": "Visual Studio Code", "vscode": "Visual Studio Code", "kod editoru": "Visual Studio Code",
    "komut istemi": "Komut İstemi|Command Prompt", "cmd": "Komut İstemi|Command Prompt",
    "tarayici": "__browser__", "browser": "__browser__",
    "camera": "Kamera|Camera", "fotograflar": "Fotoğraflar|Photos", "photos": "Fotoğraflar|Photos",
    "takvim": "Takvim|Calendar", "saat": "Saat|Clock", "clock": "Saat|Clock",
}

# process names for closing apps whose window title differs from the app name
PROCESS_NAMES: dict[str, list[str]] = {
    "spotify": ["Spotify.exe"], "whatsapp": ["WhatsApp.exe", "WhatsApp.Root.exe"],
    "chrome": ["chrome.exe"], "google chrome": ["chrome.exe"], "opera": ["opera.exe"],
    "opera gx": ["opera.exe"], "edge": ["msedge.exe"], "firefox": ["firefox.exe"],
    "visual studio code": ["Code.exe"], "discord": ["Discord.exe"], "steam": ["steam.exe"],
    "notepad": ["notepad.exe"], "telegram": ["Telegram.exe"],
}

KNOWN_FOLDERS = {
    "indirilenler": "Downloads", "downloads": "Downloads", "masaustu": "Desktop", "desktop": "Desktop",
    "belgeler": "Documents", "documents": "Documents", "resimler": "Pictures", "pictures": "Pictures",
    "muzik": "Music", "videolar": "Videos", "videos": "Videos",
}


class AppIndex:
    """Cached Start-menu index. Refreshed lazily (on a miss or when stale)."""

    TTL = 600.0

    def __init__(self) -> None:
        self._apps: list[tuple[str, str]] = []
        self._loaded_at = 0.0

    def refresh(self) -> None:
        out = subprocess.run(
            ["powershell", "-NoProfile", "-NonInteractive", "-Command",
             "[Console]::OutputEncoding=[Text.Encoding]::UTF8; Get-StartApps | ConvertTo-Json -Compress"],
            capture_output=True, text=True, encoding="utf-8", timeout=20, creationflags=NO_WINDOW,
        )
        data = json.loads(out.stdout or "[]")
        if isinstance(data, dict):
            data = [data]
        self._apps = [(d["Name"], d["AppID"]) for d in data if d.get("Name") and d.get("AppID")]
        self._loaded_at = time.monotonic()
        log.info("app index: %d apps", len(self._apps))

    def apps(self) -> list[tuple[str, str]]:
        if not self._apps or time.monotonic() - self._loaded_at > self.TTL:
            self.refresh()
        return self._apps

    def find(self, name: str, limit: int = 5) -> list[tuple[float, str, str]]:
        scored = sorted(((similarity(name, n), n, a) for n, a in self.apps()), reverse=True)
        return [s for s in scored[:limit] if s[0] >= 0.6]


INDEX = AppIndex()


def confident_app(name: str) -> bool:
    """True when ``name`` clearly means one installed app — used by the
    no-LLM fast path, which must never guess ("bunu aç" is not an app)."""
    key = clean_name(name)
    if key in ALIASES or key in PROCESS_NAMES:
        return True
    found = INDEX.find(name, limit=2)
    if not found or found[0][0] < 0.85:
        return False
    return found[0][0] >= 0.95 or len(found) < 2 or found[1][0] < found[0][0] - 0.05


def default_browser_progid() -> str | None:
    try:
        import winreg

        with winreg.OpenKey(winreg.HKEY_CURRENT_USER,
                            r"Software\Microsoft\Windows\Shell\Associations\UrlAssociations\https\UserChoice") as k:
            return winreg.QueryValueEx(k, "ProgId")[0]
    except OSError:
        return None


def _launch_aumid(app_id: str) -> None:
    subprocess.Popen(["explorer.exe", f"shell:AppsFolder\\{app_id}"], creationflags=NO_WINDOW)


def _resolve(name: str) -> tuple[str, str] | list[str] | None:
    """Return (display name, AppID or URI), a list of close candidates, or None."""
    key = clean_name(name)
    alias = ALIASES.get(key)
    if alias == "__browser__":
        return ("Varsayılan tarayıcı", "https://www.google.com")
    if alias and alias.endswith(":"):
        return (name, alias)
    # the spoken name first (Start-menu names are localized: "Hesap Makinesi"), then the alias
    def lookup() -> list[tuple[float, str, str]]:
        found = INDEX.find(name)
        if (not found or found[0][0] < 0.85) and alias:
            for candidate in alias.split("|"):
                found += INDEX.find(candidate)
            found = sorted(set(found), reverse=True)
        return found

    matches = lookup()
    if not matches:
        INDEX.refresh()  # maybe just installed
        matches = lookup()
    if not matches:
        return None
    best = matches[0]
    # ambiguous: two strong, different candidates
    if len(matches) > 1 and best[0] < 0.95 and matches[1][0] > best[0] - 0.05:
        return [m[1] for m in matches[:4]]
    return (best[1], best[2])


@tool(risk=Risk.LOW, category="apps", timeout=30)
def open_app(name: Annotated[str, "Uygulamanın adı, kullanıcının söylediği gibi (ör. 'spotify', 'hesap makinesi')"]) -> dict:
    """Bilgisayardaki bir uygulamayı açar (masaüstü ve Microsoft Store uygulamaları dahil)."""
    resolved = _resolve(name)
    if resolved is None:
        return {"error": f"'{name}' adında bir uygulama bulamadım."}
    if isinstance(resolved, list):
        return {"status": "ambiguous", "candidates": resolved,
                "instruction": "Kullanıcıya hangisini kastettiğini sor."}
    display, target = resolved
    if target in ("explorer:",):
        subprocess.Popen(["explorer.exe"], creationflags=NO_WINDOW)
    elif ":" in target and ("://" in target or target.endswith(":") or target.startswith("ms-")):
        os.startfile(target)  # URI (ms-settings:, https://, steam://)
    else:
        _launch_aumid(target)
    return {"output": f"{display} açılıyor."}


def _window_pids() -> list[tuple[int, str]]:
    """(pid, title) of visible top-level windows."""
    import ctypes
    from ctypes import wintypes

    user32 = ctypes.windll.user32
    out: list[tuple[int, str]] = []

    @ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
    def cb(hwnd, _):
        if user32.IsWindowVisible(hwnd):
            n = user32.GetWindowTextLengthW(hwnd)
            if n:
                buf = ctypes.create_unicode_buffer(n + 1)
                user32.GetWindowTextW(hwnd, buf, n + 1)
                pid = wintypes.DWORD()
                user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
                out.append((pid.value, buf.value))
        return True

    user32.EnumWindows(cb, 0)
    return out


def _processes_for(name: str) -> list[psutil.Process]:
    key = clean_name(name)
    wanted = {p.lower() for p in PROCESS_NAMES.get(key, [])} or {f"{key.replace(' ', '')}.exe"}
    pids: set[int] = set()
    for p in psutil.process_iter(["name"]):
        try:
            if (p.info["name"] or "").lower() in wanted:
                pids.add(p.pid)
        except psutil.Error:
            continue
    if not pids:
        resolved = _resolve(name)
        display, app_id = resolved if isinstance(resolved, tuple) else (name, "")
        if "!" in app_id:
            # Store app: its processes live under WindowsApps\<Name>_<version>_..._<publisher>
            family = app_id.split("!", 1)[0]
            pkg, _, publisher = family.rpartition("_")
            needle, publisher = f"\\windowsapps\\{pkg.lower()}_", publisher.lower()
            for p in psutil.process_iter(["exe"]):
                exe = (p.info["exe"] or "").lower()
                if needle in exe and publisher in exe:
                    pids.add(p.pid)
        if not pids:
            # localized window titles for classic apps
            for pid, title in _window_pids():
                if similarity(display, title) >= 0.85 or similarity(name, title) >= 0.85:
                    pids.add(pid)
    procs = []
    for pid in pids:
        try:
            p = psutil.Process(pid)
            if p.name().lower() not in ("explorer.exe", "applicationframehost.exe"):
                procs.append(p)
        except psutil.Error:
            continue
    return procs


@tool(risk=Risk.WRITE, category="apps")
def close_app(name: Annotated[str, "Kapatılacak uygulamanın adı"]) -> dict:
    """Açık bir uygulamayı kapatır (kaydedilmemiş değişiklikler kaybolabilir)."""
    procs = _processes_for(name)
    if not procs:
        return {"error": f"Açık bir '{name}' bulamadım."}
    for p in procs:
        try:
            p.terminate()
        except psutil.Error:
            pass
    _, alive = psutil.wait_procs(procs, timeout=3)
    for p in alive:
        try:
            p.kill()
        except psutil.Error:
            pass
    return {"output": f"{name} kapatıldı."}


close_app._describe = lambda name: f"{name} uygulamasını kapat"  # type: ignore[attr-defined]
close_app._fingerprint_keys = ("name",)  # type: ignore[attr-defined]


def _known_folder(name: str) -> Path | None:
    sub = KNOWN_FOLDERS.get(norm(name))
    if not sub:
        return None
    home = Path(os.environ.get("USERPROFILE", Path.home()))
    for base in (home / "OneDrive", home):
        for candidate in (base / sub, base / {"Desktop": "Masaüstü", "Documents": "Belgeler",
                                                "Pictures": "Resimler"}.get(sub, sub)):
            if candidate.exists():
                return candidate
    return home / sub


@tool(risk=Risk.LOW, category="files")
def open_path(path: Annotated[str, "Dosya/klasör yolu, web adresi ya da 'indirilenler', 'masaüstü' gibi bir klasör adı"]) -> dict:
    """Bir dosyayı, klasörü veya web adresini varsayılan programıyla açar."""
    target = path.strip().strip('"')
    if target.startswith(("http://", "https://")):
        os.startfile(target)
        return {"output": "Bağlantı açılıyor."}
    folder = _known_folder(target)
    p = folder or Path(os.path.expandvars(os.path.expanduser(target)))
    if not p.exists():
        return {"error": f"'{target}' bulunamadı. Önce find_files ile ara."}
    os.startfile(str(p))
    return {"output": f"{p.name or p} açılıyor.", "path": str(p)}


def _everything(query: str, limit: int) -> list[str] | None:
    for exe in ("es.exe", r"C:\Program Files\Everything\es.exe"):
        try:
            out = subprocess.run([exe, "-n", str(limit), "-sort", "date-modified-descending", query],
                                 capture_output=True, text=True, encoding="utf-8", timeout=5,
                                 creationflags=NO_WINDOW)
            if out.returncode == 0:
                return [line for line in out.stdout.splitlines() if line.strip()]
        except (OSError, subprocess.TimeoutExpired):
            continue
    return None


def _walk_search(query: str, limit: int, kind: str) -> list[str]:
    q = norm(query)
    home = Path(os.environ.get("USERPROFILE", Path.home()))
    roots = [home / d for d in ("Downloads", "Desktop", "Documents", "Pictures", "Videos", "Music")]
    roots += [home / "OneDrive" / d for d in ("Desktop", "Masaüstü", "Documents", "Belgeler")]
    hits: list[tuple[float, str]] = []
    deadline = time.monotonic() + 4
    for root in roots:
        if not root.exists():
            continue
        for dirpath, dirnames, filenames in os.walk(root):
            dirnames[:] = [d for d in dirnames if not d.startswith(".") and d not in ("node_modules", ".venv")]
            names = dirnames if kind == "folder" else filenames if kind == "file" else dirnames + filenames
            for n in names:
                if q in norm(n):
                    full = os.path.join(dirpath, n)
                    try:
                        hits.append((os.path.getmtime(full), full))
                    except OSError:
                        pass
            if time.monotonic() > deadline:
                break
    return [p for _, p in sorted(hits, reverse=True)[:limit]]


@tool(risk=Risk.READ, category="files", timeout=10)
def find_files(query: Annotated[str, "Dosya adında geçen kelime(ler)"],
               kind: Annotated[Literal["any", "file", "folder"], "Ne aranıyor"] = "any",
               limit: int = 8) -> dict:
    """Bilgisayarda dosya veya klasör arar; en son değiştirilenler önce gelir."""
    results = _everything(query, limit)
    source = "everything"
    if results is None:
        results, source = _walk_search(query, limit, kind), "klasör taraması"
    return {"results": results, "source": source,
            "note": "Bulunanlardan birini open_path ile açabilirsin." if results else "Hiçbir şey bulunamadı."}


@tool(risk=Risk.READ, category="apps")
def list_running_apps() -> dict:
    """Şu an açık olan pencereli uygulamaları listeler."""
    import ctypes
    from ctypes import wintypes

    user32 = ctypes.windll.user32
    titles: list[str] = []

    @ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
    def cb(hwnd, _):
        if user32.IsWindowVisible(hwnd) and not user32.GetWindow(hwnd, 4):  # no owner
            n = user32.GetWindowTextLengthW(hwnd)
            if n:
                buf = ctypes.create_unicode_buffer(n + 1)
                user32.GetWindowTextW(hwnd, buf, n + 1)
                if buf.value not in ("Program Manager",):
                    titles.append(buf.value)
        return True

    user32.EnumWindows(cb, 0)
    return {"windows": titles[:30]}
