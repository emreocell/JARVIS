"""Send prompts to AI / coding tools (Claude Code, opencode, VS Code, ChatGPT…)."""

from __future__ import annotations

import asyncio
import logging
import os
import shutil
import time
import urllib.parse
from typing import Annotated

from jarvis.connectors.registry import Connector, find_project_dir, load_connectors
from jarvis.skills.text import norm, similarity
from jarvis.tools import Risk, ToolContext, tool

log = logging.getLogger(__name__)
NO_WINDOW = 0x08000000


def _pick(name: str) -> Connector | None:
    connectors = load_connectors()
    key = norm(name)
    for c in connectors.values():
        if key in (norm(c.id), norm(c.name), *(norm(a) for a in c.aliases)):
            return c
    scored = sorted(((max(similarity(name, c.name), *(similarity(name, a) for a in c.aliases or [c.id])), c)
                     for c in connectors.values()), key=lambda s: s[0], reverse=True)
    return scored[0][1] if scored and scored[0][0] >= 0.75 else None


def _context_prefix(ctx: ToolContext, include: bool) -> str:
    if not include:
        return ""
    tracker = getattr(ctx.core, "context", None)
    focus = tracker.current() if tracker else None
    if not focus or focus.title == "(gizli)":
        return ""
    return f"[Bağlam: kullanıcı şu an {focus.app} kullanıyor — “{focus.title}”]\n\n"


def _active_project(ctx: ToolContext) -> str:
    tracker = getattr(ctx.core, "context", None)
    if tracker is None:
        return ""
    projects = tracker.summary(120).get("projects") or []
    return projects[0] if projects else ""


_CMD_META = str.maketrans({c: " " for c in '"%^&|<>!\r\n'})


def build_argv(c: Connector, prompt: str, cwd: str | None) -> list[str]:
    """Resolve the executable and fill placeholders.

    npm-installed CLIs are ``.cmd`` shims that Windows runs through cmd.exe,
    which would interpret ``& | % ^ " < >`` inside the prompt as commands. For
    those, the prompt is neutralized (metacharacters → spaces)."""
    exe = shutil.which(c.command[0]) or c.command[0]
    shim = exe.lower().endswith((".cmd", ".bat"))
    text = prompt.translate(_CMD_META) if shim else prompt
    return [exe, *(a.replace("{prompt}", text).replace("{project}", cwd or "") for a in c.command[1:])]


async def _run_cli(c: Connector, prompt: str, cwd: str | None) -> dict:
    argv = build_argv(c, prompt, cwd)
    started = time.monotonic()
    proc = await asyncio.create_subprocess_exec(
        *argv, cwd=cwd or None, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.STDOUT,
        creationflags=NO_WINDOW)
    try:
        out, _ = await asyncio.wait_for(proc.communicate(), c.timeout)
    except TimeoutError:
        proc.kill()
        return {"error": f"{c.name} {c.timeout} sn içinde bitmedi."}
    text = out.decode("utf-8", errors="replace").strip()
    tail = text[-3000:]
    return {"output": f"{c.name} bitti ({int(time.monotonic() - started)} sn, çıkış kodu {proc.returncode}).",
            "result": tail}


_CHAT_HINTS = ("chat", "sohbet", "copilot", "agent", "ajan", "ask", "sor", "message", "mesaj", "prompt", "composer",
               "interactive-input")


def _focus_chat_box(auto, win) -> str:
    """Focus an open chat box (SetFocus, else a click on the verified box); returns the focus context."""
    box = _find_chat_input(auto, win)
    if box is None:
        return ""
    for attempt in ("focus", "click"):
        try:
            if attempt == "focus":
                box.SetFocus()
            else:
                box.Click(simulateMove=False)
        except Exception:
            continue
        time.sleep(0.3)
        label = _focus_context(auto)
        if is_chat_input(label):
            return label
    return _focus_context(auto)


def _open_chat(auto, desktop, win, c) -> str:
    """Get keyboard focus into the app's AI chat box without opening a second chat:
    1) an open chat box, 2) the chat shortcut (waiting for the panel to appear),
    3) only if no chat panel exists at all: the 'Toggle Chat' button."""
    label = _focus_chat_box(auto, win)
    if is_chat_input(label):
        return label
    if c.open_chat:
        desktop.hotkey(c.open_chat)
        deadline = time.monotonic() + 3.0
        while time.monotonic() < deadline:
            time.sleep(0.3)
            label = _focus_context(auto)
            if is_chat_input(label):
                return label
            if _find_chat_input(auto, win) is not None:
                label = _focus_chat_box(auto, win)
                if is_chat_input(label):
                    return label
    if _find_chat_input(auto, win) is None:  # no chat panel at all: the toggle opens (never closes) it
        toggle = next((ctrl for ctrl, _ in auto.WalkControl(win, maxDepth=25)
                       if ctrl.ControlTypeName == "ButtonControl"
                       and (ctrl.Name or "").lower() in ("toggle chat", "sohbeti aç/kapat", "chat")), None)
        if toggle is not None:
            try:
                toggle.GetInvokePattern().Invoke()
            except Exception:
                pass
            time.sleep(1.0)
            label = _focus_chat_box(auto, win) or _focus_context(auto)
    return label


def _find_chat_input(auto, win):
    """The editor of an open AI chat panel (VS Code/Cursor: a Monaco editor inside
    a 'chat-input…'/'interactive-input…' container), if one is visible."""
    for ctrl, _ in auto.WalkControl(win, maxDepth=28):
        cls = (ctrl.ClassName or "").lower()
        if ctrl.ControlTypeName == "GroupControl" and ("chat-input-container" in cls or "interactive-input-part" in cls):
            for inner, _d in auto.WalkControl(ctrl, maxDepth=6):
                if inner.ControlTypeName == "EditControl":
                    r = inner.BoundingRectangle
                    if r.right > r.left and r.bottom > r.top:  # actually on screen
                        return inner
    return None


def _focus_context(auto) -> str:
    """Name/help of the focused element plus class names and ids of its
    ancestors — editors share generic labels, their containers don't
    (VS Code: 'chat-input-container', 'workbench.panel.chat')."""
    focused = auto.GetFocusedControl()
    if focused is None:
        return ""
    bits = [focused.Name or "", getattr(focused, "HelpText", "") or ""]
    node = focused
    for _ in range(10):
        node = node.GetParentControl()
        if node is None:
            break
        bits += [node.ClassName or "", node.AutomationId or ""]
    return " ".join(b for b in bits if b)


def is_chat_input(label: str) -> bool:
    """Does the focused element look like an AI chat box (not a code editor)?"""
    import re

    low = label.lower()
    return any(re.search(rf"(?<![a-zçğıöşü]){h}", low) for h in _CHAT_HINTS)


def _run_window(c: Connector, prompt: str) -> dict:
    import uiautomation as auto

    from jarvis.skills import desktop

    with auto.UIAutomationInitializerInThread():
        def find():
            w = auto.WindowControl(searchDepth=1, SubName=c.window)
            return w if w.Exists(0.2) else None

        win = find()
        if win is None and c.app:
            from jarvis.skills.apps import open_app

            opened = open_app.__tool__.handler(c.app)  # type: ignore[attr-defined]
            if "error" in opened:
                return opened
            win = desktop.wait_until(find, timeout=20)
        if win is None:
            return {"error": f"{c.name} penceresi bulunamadı."}
        desktop.activate(win)
        with desktop.preserved_clipboard():
            label = _open_chat(auto, desktop, win, c)
            if not is_chat_input(label):
                # never type a prompt into whatever has focus (e.g. an open source file)
                return {"error": f"{c.name} sohbet kutusunu açamadım (odaktaki: '{label[:60]}'); "
                                 "kodunun içine yazmamak için göndermedim. Sohbet kısayolunu Ayarlar'dan kontrol et."}
            # verified chat box: clear stray input first (Ctrl+Alt = AltGr on Turkish keyboards,
            # so a Ctrl+Alt+I shortcut can also type an "i")
            desktop.hotkey("{Ctrl}a{Delete}")
            desktop.paste_text(prompt)
            time.sleep(0.2)
            if c.submit:
                desktop.hotkey(c.submit)
    return {"output": f"{c.name} sohbetine gönderildi."}


@tool(risk=Risk.LOW, category="ai-tools", platforms=())
async def list_ai_tools() -> dict:
    """Kullanılabilen AI ve kod araçlarını listeler (Claude Code, opencode, VS Code, ChatGPT…)."""
    return {"tools": [c.as_dict() for c in load_connectors().values()]}


@tool(risk=Risk.WRITE, category="ai-tools", timeout=60)
async def send_to_ai_tool(ctx: ToolContext,
                          tool_name: Annotated[str, "Araç: 'claude code', 'opencode', 'vs code', 'chatgpt', 'antigravity'…"],
                          prompt: Annotated[str, "Araca gönderilecek görev/prompt (kullanıcının istediği gibi, net)"],
                          project: Annotated[str | None, "Proje klasörü adı veya yolu; boşsa kullanıcının aktif projesi"] = None,
                          include_context: Annotated[bool, "Ekranda ne olduğunu da prompt'a ekle"] = False) -> dict:
    """Bir AI/kod aracına görev gönderir: 'Claude Code'a şu hatayı düzelttir', 'ChatGPT'ye sor', 'VS Code'da Copilot'a yaz'.
    Komut satırı araçları arka planda çalışır ve bitince haber verilir."""
    c = _pick(tool_name)
    if c is None:
        return {"error": f"'{tool_name}' diye bir araç tanımlı değil.", "known": list(load_connectors())}
    ok, why = c.available()
    if not ok:
        return {"error": f"{c.name} kullanılamıyor: {why}"}
    full_prompt = _context_prefix(ctx, include_context) + prompt
    if c.kind == "url":
        os.startfile(c.url.replace("{prompt}", urllib.parse.quote(full_prompt)))
        return {"output": f"{c.name} tarayıcında açıldı ve soru gönderildi."}
    if c.kind == "window":
        from jarvis.skills import uia

        return await uia.run(_run_window, c, full_prompt)
    # cli: resolve the project folder, then run in the background
    project_name = project or _active_project(ctx)
    cwd = find_project_dir(project_name) if project_name else None
    if c.needs_project and cwd is None:
        return {"error": "Hangi projede çalışacağını bulamadım.", "instruction": "Kullanıcıya proje adını/klasörünü sor."}
    runtime = ctx.core.tools

    async def job() -> None:
        result = await _run_cli(c, full_prompt, str(cwd) if cwd else None)
        await ctx.core.bus.publish("tool.finished", tool=f"{c.id}", ok="error" not in result, background=True,
                                   result=result.get("result") or result.get("error"), ms=0)
        if runtime.notify_brain:
            summary = result.get("error") or f"{result['output']} Son çıktı: {result.get('result', '')[-800:]}"
            await runtime.notify_brain(f"[{c.name} görevi tamamlandı] {summary} Kullanıcıya kısaca özetle.")

    asyncio.create_task(job())
    return {"output": f"{c.name} görevine başladı ({cwd.name if cwd else 'klasörsüz'}). Bitince haber vereceğim."}


send_to_ai_tool._describe = lambda tool_name, prompt, **kw: f"{tool_name} aracına görev gönder: “{prompt[:80]}”"  # type: ignore[attr-defined]
send_to_ai_tool._fingerprint_keys = ("tool_name",)  # type: ignore[attr-defined]
