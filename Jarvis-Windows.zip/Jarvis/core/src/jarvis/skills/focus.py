"""Focus mode: a focus timer plus calm music in one command."""

from __future__ import annotations

from typing import Annotated

from jarvis.tools import Risk, ToolContext, tool


@tool(risk=Risk.LOW, category="routines", platforms=(), timeout=45)
async def focus_mode(ctx: ToolContext,
                     minutes: Annotated[int, "Odak süresi (dakika)"] = 25,
                     music: Annotated[bool, "Odak müziği açılsın mı"] = True,
                     query: Annotated[str, "Müzik araması"] = "lofi hip hop") -> dict:
    """Odak modu: bir odak zamanlayıcısı başlatır ve istenirse Spotify'da sakin müzik açar.
    'Odak modunu başlat', '50 dakika odaklanmam lazım'."""
    from jarvis.skills.routines import set_timer

    minutes = max(1, min(int(minutes), 240))
    await set_timer.__tool__.handler(ctx, minutes=minutes, label="Odak")  # type: ignore[attr-defined]
    parts = [f"{minutes} dakikalık odak başladı; bitince haber vereceğim."]
    if music:
        from jarvis.skills.media import play_spotify

        try:
            result = await play_spotify.__tool__.handler(ctx, query)  # type: ignore[attr-defined]
            parts.append(str(result.get("output") or ""))
        except Exception as exc:  # music is a bonus: the timer already runs
            parts.append(f"Müziği açamadım ({type(exc).__name__}).")
    return {"output": " ".join(p for p in parts if p)}
