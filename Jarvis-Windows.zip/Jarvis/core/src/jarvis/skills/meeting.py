"""Meeting mode tools: start/stop, and questions about past meetings."""

from __future__ import annotations

import re
import time
from typing import Annotated

from jarvis.tools import Risk, ToolContext, tool


def _mode(ctx: ToolContext):
    return getattr(ctx.core, "meeting", None)


@tool(risk=Risk.LOW, category="notes", timeout=20, platforms=())
async def start_meeting_mode(ctx: ToolContext, title: Annotated[str, "Toplantının adı (isteğe bağlı)"] = "") -> dict:
    """Toplantı modunu başlatır: mikrofonu ve bilgisayar sesini dinleyip yazıya döker, sonunda özet, kararlar ve
    aksiyon maddeleri çıkarır. Bu sırada Jarvis kendiliğinden hiç konuşmaz."""
    mode = _mode(ctx)
    if mode is None:
        return {"error": "Toplantı modu kullanılamıyor."}
    m = await mode.start(title)
    return {"output": "Toplantı modu açık; sessizce not alıyorum. Bitince 'toplantı modunu kapat' de.",
            "title": m.title, "note": "Katılımcılara kayıt yapıldığını söylemeyi unutma. Bundan sonra kısa ve sessiz ol."}


@tool(risk=Risk.LOW, category="notes", timeout=240, platforms=())
async def stop_meeting_mode(ctx: ToolContext) -> dict:
    """Toplantı modunu bitirir ve toplantının özetini, kararlarını, aksiyon maddelerini çıkarıp ikinci beyne kaydeder."""
    mode = _mode(ctx)
    if mode is None or not mode.active:
        return {"error": "Toplantı modu açık değil."}
    return await mode.stop()


@tool(risk=Risk.READ, category="notes", timeout=20, platforms=())
async def ask_meeting(ctx: ToolContext,
                      question: Annotated[str, "Soru, ör. 'ödeme sistemiyle ilgili ne karar verdik?'"],
                      which: Annotated[str, "'son' ya da toplantı adından bir parça"] = "son") -> dict:
    """Geçmiş bir toplantı hakkında soruyu cevaplamak için özetini ve ilgili döküm kısımlarını getirir:
    'toplantıda ne kararlaştırdık?', 'benim üzerime kalan işler ne?', 'Ahmet ne dedi?'."""
    mode = _mode(ctx)
    if mode is None:
        return {"error": "Toplantı kaydı yok."}
    meetings = mode.store.meetings(30)
    if not meetings:
        return {"output": "Kayıtlı toplantı yok."}
    chosen = meetings[0]
    if which and which != "son":
        chosen = next((m for m in meetings if which.lower() in m["title"].lower()), chosen)
    segs = mode.store.segments(chosen["id"])
    words = {w for w in re.findall(r"\w{4,}", question.lower())}
    hits = [f"[{time.strftime('%H:%M', time.localtime(t))}] {text}" for t, _, text in segs
            if words and any(w[:5] in text.lower() for w in words)]
    return {"meeting": chosen["title"], "date": time.strftime("%d.%m.%Y %H:%M", time.localtime(chosen["start"])),
            "summary": chosen["summary"], "relevant_transcript": hits[:25] or [t for _, _, t in segs[-10:]],
            "note": "Cevabı özet ve dökümden ver; orada olmayanı uydurma."}


@tool(risk=Risk.READ, category="notes", timeout=15, platforms=())
async def my_action_items(ctx: ToolContext, days: Annotated[int, "Son kaç günün toplantıları"] = 14) -> dict:
    """Toplantılarda kullanıcıya düşen aksiyon maddelerini listeler: 'benim üzerime kalan işler ne?'"""
    mode = _mode(ctx)
    if mode is None:
        return {"error": "Toplantı kaydı yok."}
    since = time.time() - days * 86400
    items = []
    for m in mode.store.meetings(50):
        if m["start"] < since or not m["summary"]:
            continue
        for a in m["summary"].get("action_items", []):
            if a.get("mine"):
                items.append({**a, "meeting": m["title"],
                              "date": time.strftime("%d.%m", time.localtime(m["start"]))})
    return {"items": items} if items else {"output": "Toplantılardan sana kalan bir iş görünmüyor."}
