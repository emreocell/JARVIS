"""macOS: apps, files and the system — same tool names as on Windows."""

from __future__ import annotations

import asyncio
import os
import subprocess
from pathlib import Path
from typing import Annotated, Literal

from jarvis.platform import mac
from jarvis.tools import Risk, tool

MAC = ("darwin",)


@tool(risk=Risk.LOW, category="apps", platforms=MAC)
def open_app(name: Annotated[str, "Uygulamanın adı, kullanıcının söylediği gibi (ör. 'spotify', 'hesap makinesi')"]) -> dict:
    """Bilgisayardaki bir uygulamayı açar."""
    app = mac.resolve_app(name)
    if app is None:
        return {"error": f"'{name}' adında bir uygulama bulamadım."}
    r = subprocess.run(["open", "-a", app], capture_output=True, text=True)
    if r.returncode != 0:
        return {"error": f"{app} açılamadı: {r.stderr.strip()[:120]}"}
    return {"output": f"{app} açılıyor.", "app": app}


@tool(risk=Risk.WRITE, category="apps", platforms=MAC)
def close_app(name: Annotated[str, "Kapatılacak uygulamanın adı"]) -> dict:
    """Açık bir uygulamayı kapatır (kaydedilmemiş değişiklikler için uygulama sorabilir)."""
    app = mac.resolve_app(name) or name
    try:
        mac.osascript(f"tell application {mac.as_string(app)} to quit")
    except RuntimeError as exc:
        return {"error": f"{app} kapatılamadı: {exc}"}
    return {"output": f"{app} kapatıldı."}


close_app._describe = lambda name: f"{name} uygulamasını kapat"  # type: ignore[attr-defined]
close_app._fingerprint_keys = ("name",)  # type: ignore[attr-defined]


@tool(risk=Risk.READ, category="apps", platforms=MAC, requires=("AppKit",))
def list_running_apps() -> dict:
    """Şu an açık olan uygulamaları listeler."""
    return {"apps": [a["name"] for a in mac.running_apps()]}


KNOWN = {"indirilenler": "Downloads", "downloads": "Downloads", "masaüstü": "Desktop", "masaustu": "Desktop",
         "desktop": "Desktop", "belgeler": "Documents", "documents": "Documents", "resimler": "Pictures",
         "müzik": "Music", "filmler": "Movies", "videolar": "Movies"}


@tool(risk=Risk.LOW, category="files", platforms=MAC)
def open_path(path: Annotated[str, "Dosya/klasör yolu, web adresi ya da 'indirilenler', 'masaüstü' gibi bir klasör adı"]) -> dict:
    """Bir dosyayı, klasörü veya web adresini varsayılan programıyla açar."""
    target = path.strip().strip('"')
    known = KNOWN.get(target.lower())
    p = str(Path.home() / known) if known else os.path.expanduser(target)
    if not target.startswith(("http://", "https://")) and not os.path.exists(p):
        return {"error": f"'{target}' bulunamadı. Önce find_files ile ara."}
    subprocess.run(["open", target if target.startswith("http") else p])
    return {"output": "Açılıyor.", "path": p}


@tool(risk=Risk.READ, category="files", platforms=MAC)
def find_files(query: Annotated[str, "Aranan dosya adı ya da içerik"],
               kind: Annotated[Literal["any", "pdf", "image", "document", "folder"], "Tür"] = "any",
               limit: Annotated[int, "En fazla kaç sonuç"] = 10) -> dict:
    """Spotlight ile dosya arar (ad ve içerik)."""
    q = query
    if kind == "pdf":
        q = f'{query} kMDItemContentType == "com.adobe.pdf"'
    r = subprocess.run(["mdfind", "-name", query] if kind == "any" else ["mdfind", q], capture_output=True, text=True,
                       timeout=10)
    items = [ln for ln in r.stdout.splitlines() if ln.strip() and "/Library/" not in ln][:max(1, min(limit, 30))]
    return {"files": items} if items else {"output": "Bulunamadı."}


@tool(risk=Risk.LOW, category="system", platforms=MAC)
def set_volume(level: Annotated[int | None, "Hedef ses seviyesi 0-100"] = None,
               change: Annotated[int | None, "Göreli değişim, ör. +10 veya -20"] = None,
               mute: Annotated[bool | None, "Sessize al (true) / sesi aç (false)"] = None) -> dict:
    """Bilgisayarın ana ses seviyesini ayarlar, artırır/azaltır veya sessize alır."""
    if mute is not None:
        mac.osascript(f"set volume output muted {'true' if mute else 'false'}")
    current = int(mac.osascript("output volume of (get volume settings)") or 0)
    target = level if level is not None else current + (change or 0)
    target = max(0, min(100, target))
    if target != current:
        mac.osascript(f"set volume output volume {target}")
    muted = mac.osascript("output muted of (get volume settings)") == "true"
    return {"output": "Ses kapatıldı." if muted else f"Ses %{target}."}


def _player() -> str | None:
    running = {a["name"] for a in mac.running_apps()}
    for app in ("Spotify", "Music"):
        if app in running:
            return app
    return None


@tool(risk=Risk.LOW, category="system", platforms=MAC, requires=("AppKit",))
def media_control(action: Annotated[Literal["play_pause", "play", "pause", "next", "previous", "stop"], "Yapılacak işlem"]) -> dict:
    """Çalan medyayı kontrol eder (Spotify / Müzik): oynat/duraklat, sonraki, önceki."""
    app = _player()
    if app is None:
        return {"output": "Şu an açık bir müzik uygulaması yok."}
    verb = {"play_pause": "playpause", "play": "play", "pause": "pause", "next": "next track",
            "previous": "previous track", "stop": "pause"}[action]
    mac.osascript(f"tell application {mac.as_string(app)} to {verb}")
    return {"output": "Tamam."}


@tool(risk=Risk.READ, category="system", platforms=MAC, requires=("AppKit",))
def now_playing() -> dict:
    """Şu an ne çaldığını söyler (şarkı adı, sanatçı, uygulama)."""
    app = _player()
    if app is None:
        return {"output": "Şu an çalan bir şey yok."}
    info = mac.osascript(f"tell application {mac.as_string(app)} to (name of current track) & \"|\" & "
                         f"(artist of current track) & \"|\" & (player state as string)")
    title, artist, state = (info.split("|") + ["", "", ""])[:3]
    return {"title": title, "artist": artist, "app": app, "playing": state == "playing"}


@tool(risk=Risk.LOW, category="system", platforms=MAC)
def lock_screen() -> dict:
    """Ekranı kilitler."""
    subprocess.run(["osascript", "-e", 'tell application "System Events" to keystroke "q" using {control down, command down}'])
    return {"output": "Ekran kilitlendi."}


@tool(risk=Risk.DESTRUCTIVE, category="system", platforms=MAC)
def power(action: Annotated[Literal["sleep", "restart", "shutdown", "logout"], "İşlem"]) -> dict:
    """Bilgisayarı uyutur, yeniden başlatır, kapatır ya da oturumu kapatır (her zaman onay ister)."""
    script = {"sleep": 'tell application "System Events" to sleep',
              "restart": 'tell application "System Events" to restart',
              "shutdown": 'tell application "System Events" to shut down',
              "logout": 'tell application "System Events" to log out'}[action]
    mac.osascript(script)
    return {"output": "Tamam."}


@tool(risk=Risk.LOW, category="system", platforms=MAC)
def open_settings(page: Annotated[str, "Ayar sayfası: 'bluetooth', 'wifi', 'ses', 'ekran', 'güncelleme'…"] = "") -> dict:
    """Sistem Ayarları'nı (istenen sayfada) açar."""
    pages = {"bluetooth": "com.apple.BluetoothSettings", "wifi": "com.apple.wifi-settings-extension",
             "ses": "com.apple.Sound-Settings.extension", "ekran": "com.apple.Displays-Settings.extension",
             "güncelleme": "com.apple.Software-Update-Settings.extension",
             "gizlilik": "com.apple.settings.PrivacySecurity.extension"}
    ext = pages.get(page.strip().lower())
    subprocess.run(["open", f"x-apple.systempreferences:{ext}" if ext else "x-apple.systempreferences:"])
    return {"output": "Sistem Ayarları açılıyor."}


@tool(risk=Risk.LOW, category="media", timeout=30, platforms=MAC, requires=("AppKit",))
async def play_spotify(query: Annotated[str, "Şarkı, sanatçı, albüm ya da çalma listesi"]) -> dict:
    """Spotify'da bir şarkı/sanatçı/çalma listesi çalar."""
    import urllib.parse

    subprocess.run(["open", "spotify:search:" + urllib.parse.quote(query)])
    await asyncio.sleep(2.5)
    try:
        # the search view lists the top result first: play it
        mac.osascript('tell application "Spotify" to activate')
        await asyncio.sleep(0.4)
        mac.osascript('tell application "System Events" to key code 36')
        await asyncio.sleep(1.5)
        info = await asyncio.to_thread(now_playing.__tool__.handler)  # type: ignore[attr-defined]
    except RuntimeError as exc:
        return {"error": f"Spotify kontrol edilemedi: {exc}"}
    if info.get("title"):
        return {"output": f"Çalıyor: {info.get('artist')} – {info.get('title')}", "verified_by_tool": True,
                "verified": True, "observed": "Spotify çalıyor"}
    return {"output": f"Spotify'da “{query}” aramasını açtım.", "verified": False,
            "observed": "çalmaya başladığını göremedim"}
