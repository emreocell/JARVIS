"""YouTube and Spotify playback.

Spotify has two tiers:

* **Premium + Web API** (planned: OAuth PKCE; each user registers their own
  developer app because dev-mode apps are limited to 5 users) — exact track
  playback, queue, device transfer.
* **Everyone** — ``spotify:search:`` URI to open results in the desktop app,
  then the top result's play button is pressed through UI Automation; the
  Windows media session (SMTC) is the final fallback.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import re
import urllib.parse
from typing import Annotated, Any, Literal

import httpx

from jarvis.tools import Risk, ToolContext, tool

log = logging.getLogger(__name__)

_INITIAL = re.compile(r"var ytInitialData = (\{.*?\});</script>", re.S)
UA = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)", "Accept-Language": "tr-TR,tr;q=0.9,en;q=0.8"}


def _videos(data: Any, out: list[dict[str, str]], limit: int) -> None:
    """Collect regular video results (skips ads, shorts and mixes)."""
    if len(out) >= limit:
        return
    if isinstance(data, dict):
        v = data.get("videoRenderer")
        if isinstance(v, dict) and v.get("videoId"):
            title = "".join(r.get("text", "") for r in v.get("title", {}).get("runs", []))
            channel = "".join(r.get("text", "") for r in v.get("ownerText", {}).get("runs", []))
            out.append({"id": v["videoId"], "title": title, "channel": channel,
                        "length": v.get("lengthText", {}).get("simpleText", "")})
            return
        for value in data.values():
            _videos(value, out, limit)
    elif isinstance(data, list):
        for value in data:
            _videos(value, out, limit)


async def youtube_search(query: str, limit: int = 5) -> list[dict[str, str]]:
    async with httpx.AsyncClient(timeout=10, headers=UA, follow_redirects=True) as client:
        r = await client.get("https://www.youtube.com/results", params={"search_query": query})
        r.raise_for_status()
    m = _INITIAL.search(r.text)
    results: list[dict[str, str]] = []
    if m:
        _videos(json.loads(m.group(1)), results, limit)
    else:  # layout changed: fall back to the first videoId on the page
        ids = re.findall(r'"videoId":"([\w-]{11})"', r.text)
        results = [{"id": i, "title": "", "channel": "", "length": ""} for i in dict.fromkeys(ids)][:limit]
    return results


@tool(risk=Risk.LOW, category="media", platforms=())
async def play_youtube(query: Annotated[str, "Aranacak video, şarkı veya kanal"]) -> dict:
    """YouTube'da arar ve ilk normal videoyu (reklam/Shorts değil) tarayıcıda oynatır."""
    results = await youtube_search(query, 3)
    if not results:
        return {"error": "YouTube'da sonuç bulamadım."}
    video = results[0]
    os.startfile(f"https://www.youtube.com/watch?v={video['id']}&autoplay=1")
    return {"output": f"Açılıyor: {video['title']} ({video['channel']})".strip(), "video": video}


# ------------------------------------------------------------------ spotify

_PLAY_NAMES = ("Play", "Çal", "Oynat")
PLAYER_BAR = 130  # px at the bottom of the window: the now-playing bar (its own "Play" button)


def _spotify_window(auto: Any):
    """Spotify's main window, found by process — its title is the playing
    track ("Pink Floyd - Time") while music plays, so title matching fails."""
    import ctypes
    from ctypes import wintypes

    import psutil

    user32 = ctypes.windll.user32
    found: list[int] = []

    def cb(hwnd, _):
        if not user32.IsWindowVisible(hwnd):
            return True
        cls = ctypes.create_unicode_buffer(64)
        user32.GetClassNameW(hwnd, cls, 64)
        if cls.value != "Chrome_WidgetWin_1" or user32.GetWindowTextLengthW(hwnd) == 0:
            return True
        pid = wintypes.DWORD()
        user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        try:
            if psutil.Process(pid.value).name().lower() == "spotify.exe":
                found.append(hwnd)
                return False
        except psutil.Error:
            pass
        return True

    user32.EnumWindows(ctypes.WINFUNCTYPE(ctypes.c_bool, wintypes.HWND, wintypes.LPARAM)(cb), 0)
    return auto.ControlFromHandle(found[0]) if found else None


def _search_shows(win: Any, query: str) -> bool:
    """Is the search box showing this query (not a previous search)?"""
    from jarvis.skills.text import norm

    words = norm(query).split()
    for ctrl, _ in _walk(win, 22):
        if ctrl.ControlTypeName in ("ComboBoxControl", "EditControl"):  # the box is a combo box
            try:
                value = norm(ctrl.GetValuePattern().Value.replace("+", " "))
            except Exception:
                continue
            if value and all(w in value for w in words):
                return True
    return False


def _walk(win: Any, depth: int):
    import uiautomation as auto

    return auto.WalkControl(win, maxDepth=depth)


def _top_result_button(win: Any):
    """The big play button of the "top result" card: the highest bare
    'Play'/'Çal' button above the player bar (list rows are 'Çal: <title>')."""
    rect = win.BoundingRectangle
    best = None
    for ctrl, _ in _walk(win, 30):
        if ctrl.ControlTypeName == "ButtonControl" and (ctrl.Name or "").strip() in _PLAY_NAMES:
            b = ctrl.BoundingRectangle
            if b.top < rect.bottom - PLAYER_BAR and (best is None or b.top < best[0]):
                best = (b.top, ctrl)
    return best[1] if best else None


def _press_top_result(query: str, timeout: float = 10.0) -> bool:
    """Wait for this search's results, bring the top result's play button on
    screen and click it. Never clicks anything that isn't visibly on screen."""
    import time

    import uiautomation as auto

    from jarvis.skills import desktop

    deadline = time.monotonic() + timeout
    with auto.UIAutomationInitializerInThread():
        # Chromium throttles occluded windows (their UI tree goes stale): bring
        # Spotify to the front before waiting for the results to render
        win = desktop.wait_until(lambda: _spotify_window(auto), timeout=8)
        if win is not None:
            desktop.activate(win)
        while time.monotonic() < deadline:
            try:
                result = _press_once(auto, desktop, query)
            except Exception as exc:  # the page re-renders while we read it: COM errors are transient
                log.debug("spotify ui read failed: %s", exc)
                result = None
            if result is not None:
                return result
            time.sleep(0.5)
    return False


def _card_matches(auto: Any, btn: Any, query: str) -> bool:
    """Results render after the search box updates: make sure the top-result
    card belongs to *this* query (shares a word with it) before clicking."""
    from jarvis.skills.text import norm

    words = {w for w in norm(query).split() if len(w) > 1}
    node = btn
    for _ in range(4):
        node = node.GetParentControl()
        if node is None:
            return False
        texts = " ".join(c.Name for c, _ in auto.WalkControl(node, maxDepth=6)
                         if c.ControlTypeName in ("TextControl", "HyperlinkControl") and c.Name)
        if texts.strip():
            return bool(words & set(norm(texts).split()))
    return False


def _press_once(auto: Any, desktop: Any, query: str) -> bool | None:
    """One attempt: True clicked, False gave up, None not ready yet."""
    import time

    win = _spotify_window(auto)
    if win is None or not _search_shows(win, query):
        log.debug("spotify: search box not showing %r yet", query)
        return None
    btn = _top_result_button(win)
    if btn is None or not _card_matches(auto, btn, query):
        log.debug("spotify: top result not ready/matching for %r", query)
        return None
    rect, b = win.BoundingRectangle, btn.BoundingRectangle
    if not (rect.top < b.top < rect.bottom - PLAYER_BAR):
        pattern = btn.GetPattern(auto.PatternId.ScrollItemPattern)
        if pattern:
            pattern.ScrollIntoView()
        return None  # re-read positions after scrolling
    desktop.activate(win)
    time.sleep(0.2)
    b = btn.BoundingRectangle
    cx, cy = (b.left + b.right) // 2, (b.top + b.bottom) // 2
    if rect.left < cx < rect.right and rect.top < cy < rect.bottom - PLAYER_BAR:
        btn.Click(simulateMove=False)
        log.info("spotify: clicked top result for %r", query)
        return True
    return False


async def _open_spotify() -> None:
    from jarvis.skills.apps import open_app

    await asyncio.to_thread(open_app.__tool__.handler, "spotify")  # type: ignore[attr-defined]


@tool(risk=Risk.LOW, category="media", timeout=30)
async def play_spotify(ctx: ToolContext,
                       query: Annotated[str, "Şarkı, sanatçı, albüm veya çalma listesi adı"],
                       kind: Annotated[Literal["track", "artist", "album", "playlist"], "Ne çalınacak"] = "track") -> dict:
    """Spotify'da arar ve en iyi sonucu çalar (Premium hesap bağlıysa tam isabetle)."""
    spotify = getattr(ctx.core, "spotify", None)
    if spotify is not None and spotify.linked:
        from jarvis.integrations.spotify import SpotifyError

        try:
            name = await spotify.play(query, kind, ensure_device=_open_spotify)
            return {"output": f"Spotify'da çalıyor: {name}"}
        except SpotifyError as exc:
            log.info("spotify web api unavailable (%s); falling back to the desktop app", exc)
    from jarvis.skills.system import now_playing_card

    before = await _safe_now_playing(now_playing_card)
    os.startfile("spotify:search:" + urllib.parse.quote(query))
    await asyncio.sleep(1.0)
    from jarvis.skills import uia

    pressed = await uia.run(_press_top_result, query)
    if pressed:
        # trust the media session, not the click: report what actually plays
        for _ in range(12):
            await asyncio.sleep(0.5)
            now = await _safe_now_playing(now_playing_card)
            changed = not before or not before["playing"] or (now or {}).get("title") != before["title"]
            if now and now["playing"] and (changed or _mentions(query, f"{now['title']} {now['artist']}")):
                who = f" — {now['artist']}" if now.get("artist") else ""
                return {"output": f"Spotify'da çalıyor: {now['title']}{who}"}
    return {"output": f"Spotify'da '{query}' aramasını açtım ama çalmaya başladığını doğrulayamadım.",
            "note": "Kullanıcıya en üstteki sonuca tıklamasını söyle."}


def _mentions(query: str, text: str) -> bool:
    """Already playing what was asked for ("Pink Floyd Time" vs "Time — Pink Floyd")."""
    from jarvis.skills.text import norm

    words = {w for w in norm(query).split() if len(w) > 2}
    return bool(words) and words <= set(norm(text).split())


async def _safe_now_playing(fn: Any) -> dict | None:
    try:
        return await asyncio.wait_for(fn(), 2.0)
    except Exception:
        return None
