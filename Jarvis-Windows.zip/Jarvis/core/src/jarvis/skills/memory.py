"""Memory tools the assistant can call explicitly."""

from __future__ import annotations

from typing import Annotated, Literal

from jarvis.memory.store import CATEGORIES
from jarvis.tools import Risk, ToolContext, tool

Category = Literal["identity", "preference", "relationship", "work", "project", "habit", "device", "general"]
assert set(Category.__args__) == set(CATEGORIES)  # type: ignore[attr-defined]


@tool(risk=Risk.LOW, category="memory", platforms=())
async def remember(ctx: ToolContext,
                   content: Annotated[str, "Kullanıcı hakkında kalıcı bilgi, tek cümle ('Kullanıcı ...')"],
                   category: Annotated[Category, "Bilgi türü"] = "general") -> dict:
    """Kullanıcı açıkça 'bunu hatırla' dediğinde veya önemli kalıcı bir bilgi paylaştığında hafızaya kaydeder."""
    memory = ctx.core.memory
    fid, created = memory.store.add(content, category, source="assistant", confidence=0.9)
    await memory.embed_missing()
    return {"output": "Kaydettim." if created else "Bunu zaten biliyordum.", "id": fid}


@tool(risk=Risk.READ, category="memory", platforms=())
async def recall(ctx: ToolContext, query: Annotated[str, "Ne hatırlanmak isteniyor"]) -> dict:
    """Kullanıcı hakkında hafızada kayıtlı bilgileri arar (kişiler, tercihler, projeler, geçmiş konuşmalar)."""
    facts = await ctx.core.memory.recall(query)
    if not facts:
        return {"output": "Hafızamda bununla ilgili bir şey yok."}
    return {"facts": [{"id": f.id, "content": f.content} for f in facts]}


@tool(risk=Risk.LOW, category="memory", platforms=())
async def forget(ctx: ToolContext, query: Annotated[str, "Unutulacak bilgiyi tarif eden kelimeler"]) -> dict:
    """Kullanıcı 'bunu unut' dediğinde ilgili bilgiyi hafızadan siler."""
    facts = await ctx.core.memory.recall(query, k=3)
    if not facts:
        return {"output": "Bununla ilgili kayıtlı bir bilgi bulamadım."}
    target = facts[0]
    ctx.core.memory.store.forget(target.id, source="assistant")
    await ctx.core.bus.publish("memory.changed", removed=[target.id])
    return {"output": f"Unuttum: {target.content}"}


@tool(risk=Risk.LOW, category="memory", platforms=())
async def add_to_dictionary(ctx: ToolContext,
                            term: Annotated[str, "Doğru yazılış, ör. 'Webioo'"],
                            sounds_like: Annotated[list[str], "Konuşmada nasıl yanlış duyulabildiği, ör. ['web yo']"] = [],  # noqa: B006
                            note: Annotated[str, "Kısa açıklama, ör. 'Emre'nin şirketi'"] = "") -> dict:
    """Kişisel sözlüğe bir isim/terim ekler; Jarvis onu artık hep doğru duyar ve yazar. 'Webioo'yu öğren, web yo
    diye anlıyorsun', 'WPanel benim projem, bunu hatırla' gibi isteklerde kullan."""
    term = term.strip()
    if not term:
        return {"error": "Terim boş."}
    entries = [e.model_dump() for e in ctx.core.config.assistant.dictionary if e.term.lower() != term.lower()]
    old = next((e for e in ctx.core.config.assistant.dictionary if e.term.lower() == term.lower()), None)
    heard = list(dict.fromkeys([*(old.sounds_like if old else []), *[s.strip() for s in sounds_like if s.strip()]]))
    entries.append({"term": term, "sounds_like": heard, "note": note or (old.note if old else "")})
    await ctx.core.config_store.patch({"assistant": {"dictionary": entries}})
    return {"output": f"“{term}” sözlüğe eklendi" + (f"; '{', '.join(heard)}' duyarsam {term} anlayacağım." if heard
                                                        else ".")}


@tool(risk=Risk.READ, category="memory", platforms=())
async def what_can_you_do(ctx: ToolContext,
                          query: Annotated[str, "Kullanıcının sorduğu iş, ör. 'faturayı bul ve hatırlat'; boşsa genel"] = "") -> dict:
    """Jarvis'in gerçekten sahip olduğu yetenekleri (araç kataloğu) arar. 'Bunu yapabilir misin?', 'neler
    yapabilirsin?', 'mail gönderebilir misin?' sorularında tahmin etmek yerine bunu çağır."""
    from jarvis.brain.catalog import CATALOG
    from jarvis.tools.titles import CATEGORIES

    specs = ctx.core.tools.enabled()
    CATALOG.build(specs)
    if not query.strip():
        counts: dict[str, int] = {}
        for s in specs:
            title = CATEGORIES.get(s.category, {}).get("title", s.category)
            counts[title] = counts.get(title, 0) + 1
        return {"areas": counts, "total_tools": len(specs),
                "note": "Alanları kısaca, örneklerle anlat; hepsini sayma."}
    hits = CATALOG.search(query, 8)
    if not hits:
        return {"output": "Bununla ilgili bir yeteneğim yok.", "note": "Dürüstçe söyle; istersen yakın bir alternatif öner."}
    return {"matches": [{"tool": e.name, "title": e.title, "example": e.example, "area": e.category,
                         "what": e.text.splitlines()[0][:160]} for e, _ in hits],
            "note": "Eşleşmeler isteği karşılıyorsa 'evet' de ve hangi adımlarla yapacağını kısaca söyle; birden "
                    "fazla araç gerekiyorsa (ör. mail ara + hatırlatıcı kur) sırayla kullanabileceğini belirt."}
