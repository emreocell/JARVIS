"""Reminders, alarms and "when X, do Y" routines."""

from __future__ import annotations

import re
import time
from datetime import datetime, timedelta
from typing import Annotated, Any, Literal

from jarvis.routines.store import Rule
from jarvis.tools import Risk, ToolContext, tool

Repeat = Literal["none", "daily", "weekdays", "weekly"]


def parse_when(at: str | None, in_minutes: float | None, now: datetime | None = None) -> float:
    """``at``: 'HH:MM' (today, or tomorrow if already past) or ISO 'YYYY-MM-DDTHH:MM'.
    ``in_minutes``: relative. Raises ValueError when neither parses."""
    now = now or datetime.now()
    if in_minutes is not None:
        if in_minutes <= 0:
            raise ValueError("in_minutes must be positive")
        return (now + timedelta(minutes=in_minutes)).timestamp()
    if not at:
        raise ValueError("either 'at' or 'in_minutes' is required")
    at = at.strip()
    m = re.fullmatch(r"(\d{1,2})[:.](\d{2})", at)
    if m:
        t = now.replace(hour=int(m.group(1)), minute=int(m.group(2)), second=0, microsecond=0)
        if t <= now:
            t += timedelta(days=1)
        return t.timestamp()
    t = datetime.fromisoformat(at)
    if t.tzinfo is not None:
        t = t.astimezone().replace(tzinfo=None)
    if t <= now:
        raise ValueError("that time is in the past")
    return t.timestamp()


def _when_text(ts: float) -> str:
    t = datetime.fromtimestamp(ts)
    today = datetime.now().date()
    day = "bugün" if t.date() == today else "yarın" if t.date() == today + timedelta(days=1) else t.strftime("%d.%m")
    return f"{day} {t:%H:%M}"


@tool(risk=Risk.LOW, category="routines", platforms=())
async def set_reminder(ctx: ToolContext,
                       text: Annotated[str, "Neyi hatırlatacağım (kullanıcının söylediği gibi)"],
                       at: Annotated[str | None, "Saat 'HH:MM' veya tarih-saat 'YYYY-MM-DDTHH:MM' (yerel)"] = None,
                       in_minutes: Annotated[float | None, "Kaç dakika sonra (at yerine)"] = None,
                       repeat: Annotated[Repeat, "Tekrar"] = "none") -> dict:
    """Hatırlatıcı kurar: 'yarın 9'da doktoru aramamı hatırlat', '20 dakika sonra ocağı hatırlat'."""
    try:
        due = parse_when(at, in_minutes)
    except ValueError as exc:
        return {"error": f"Zamanı anlayamadım: {exc}"}
    rem = ctx.core.routines.store.add_reminder(text, due, "reminder", repeat)
    ctx.core.routines.changed()
    return {"output": f"Tamam, {_when_text(due)} hatırlatacağım.", "id": rem.id}


def _span_text(seconds: float) -> str:
    seconds = int(round(seconds))
    m, s = divmod(seconds, 60)
    h, m = divmod(m, 60)
    parts = [f"{h} saat" if h else "", f"{m} dakika" if m else "", f"{s} saniye" if s and not h else ""]
    return " ".join(p for p in parts if p) or "0 saniye"


def _lik(word: str) -> str:
    """Turkish -lık/-lik/-luk/-lük by vowel harmony: dakikalık, saniyelik, saatlik."""
    if word.lower().endswith("saat"):  # loanword exception: saatlik
        return "lik"
    last = next((c for c in reversed(word.lower()) if c in "aıoueiöü"), "e")
    return {"a": "lık", "ı": "lık", "o": "luk", "u": "luk", "e": "lik", "i": "lik", "ö": "lük", "ü": "lük"}[last]


@tool(risk=Risk.LOW, category="routines", platforms=())
async def set_timer(ctx: ToolContext,
                    minutes: Annotated[float, "Kaç dakika"] = 0,
                    seconds: Annotated[int, "Ek saniye"] = 0,
                    label: Annotated[str, "Ne için (ör. 'Çay', 'Makarna')"] = "Zamanlayıcı") -> dict:
    """Geri sayım zamanlayıcısı kurar ve süre dolunca haber verir: '5 dakikalık zamanlayıcı kur', 'çay için 7 dakika'."""
    total = minutes * 60 + seconds
    if not 1 <= total <= 24 * 3600:
        return {"error": "Zamanlayıcı 1 saniye ile 24 saat arasında olmalı."}
    rem = ctx.core.routines.store.add_reminder(label.strip() or "Zamanlayıcı", time.time() + total, "timer")
    ctx.core.routines.changed()
    span = _span_text(total)
    return {"output": f"{span}{_lik(span)} zamanlayıcı başladı" + (f" ({label})." if label != "Zamanlayıcı" else "."),
            "id": rem.id}


@tool(risk=Risk.LOW, category="routines", platforms=())
async def set_alarm(ctx: ToolContext,
                    at: Annotated[str, "Alarm saati 'HH:MM' veya 'YYYY-MM-DDTHH:MM'"],
                    label: Annotated[str, "Alarm etiketi"] = "Alarm",
                    repeat: Annotated[Repeat, "Tekrar"] = "none") -> dict:
    """Alarm kurar (sesli bildirim + Jarvis söyler). 'Yarın 7'de beni uyandır', 'hafta içi her gün 7:30 alarm'."""
    try:
        due = parse_when(at, None)
    except ValueError as exc:
        return {"error": f"Saati anlayamadım: {exc}"}
    rem = ctx.core.routines.store.add_reminder(label, due, "alarm", repeat)
    ctx.core.routines.changed()
    suffix = {"daily": ", her gün", "weekdays": ", hafta içi her gün", "weekly": ", her hafta"}.get(repeat, "")
    return {"output": f"Alarm {_when_text(due)}{suffix} için kuruldu.", "id": rem.id}


@tool(risk=Risk.READ, category="routines", platforms=())
async def list_reminders(ctx: ToolContext) -> dict:
    """Bekleyen hatırlatıcıları ve alarmları listeler."""
    items = ctx.core.routines.store.pending()
    return {"items": [{"id": r.id, "kind": r.kind, "text": r.text, "when": _when_text(r.due), "repeat": r.repeat}
                      for r in items[:20]]}


@tool(risk=Risk.LOW, category="routines", platforms=())
async def cancel_reminder(ctx: ToolContext,
                          reminder_id: Annotated[int | None, "list_reminders'daki id"] = None,
                          query: Annotated[str | None, "id bilinmiyorsa metinden arama"] = None) -> dict:
    """Bir hatırlatıcıyı veya alarmı iptal eder."""
    engine = ctx.core.routines
    ids = [reminder_id] if reminder_id else [r.id for r in engine.find_reminders(query or "")] if query else []
    if not ids:
        return {"error": "Hangi hatırlatıcı olduğunu bulamadım; önce list_reminders ile bak."}
    if len(ids) > 1:
        return {"status": "ambiguous", "ids": ids, "instruction": "Kullanıcıya hangisi olduğunu sor."}
    ok = engine.store.cancel(ids[0])
    engine.changed()
    return {"output": "İptal edildi." if ok else "O hatırlatıcı zaten yok."}


@tool(risk=Risk.LOW, category="routines", platforms=())
async def snooze_reminder(ctx: ToolContext, minutes: Annotated[int, "Kaç dakika ertelensin"] = 10,
                          reminder_id: Annotated[int | None, "Boşsa son çalan"] = None) -> dict:
    """Son çalan hatırlatıcıyı/alarmı erteler."""
    store = ctx.core.routines.store
    rid = reminder_id
    if rid is None:
        row = store._db.execute("SELECT id FROM reminders WHERE fired_at IS NOT NULL ORDER BY fired_at DESC LIMIT 1").fetchone()
        rid = row[0] if row else None
    if rid is None:
        return {"error": "Ertelenecek bir hatırlatıcı yok."}
    store.snooze(rid, minutes)
    ctx.core.routines.changed()
    return {"output": f"{minutes} dakika erteledim."}


@tool(risk=Risk.WRITE, category="routines", platforms=())
async def create_routine(ctx: ToolContext,
                         name: Annotated[str, "Rutinin kısa adı, ör. 'Kodlarken müzik'"],
                         trigger: Annotated[Literal["app_opened", "time", "startup"], "Ne zaman tetiklenecek"],
                         mode: Annotated[Literal["auto", "ask", "notify"],
                                         "auto: direkt yap, ask: önce kullanıcıya sor, notify: sadece bildir"] = "ask",
                         app: Annotated[str | None, "trigger=app_opened ise uygulama adı"] = None,
                         at: Annotated[str | None, "trigger=time ise 'HH:MM'"] = None,
                         days: Annotated[Literal["daily", "weekdays", "weekends"], "trigger=time için günler"] = "daily",
                         action_tool: Annotated[str | None, "Çalıştırılacak araç adı, ör. play_spotify"] = None,
                         action_args: Annotated[dict[str, Any] | None, "Aracın argümanları"] = None,
                         say: Annotated[str | None, "Araç yerine sadece söylenecek/bildirilecek metin"] = None,
                         prompt: Annotated[str | None, "Araç yerine Jarvis'e verilecek görev, ör. 'günün özetini çıkar'"] = None) -> dict:
    """'VS Code açılınca çalışma müziği açayım mı diye sor', 'her sabah 9'da gündemi özetle' gibi rutinler oluşturur."""
    trig: dict[str, Any] = {"type": trigger}
    if trigger == "app_opened":
        if not app:
            return {"error": "Hangi uygulama açılınca?"}
        trig["app"] = app
    elif trigger == "time":
        if not at or not re.fullmatch(r"\d{1,2}:\d{2}", at):
            return {"error": "Saat 'HH:MM' biçiminde olmalı."}
        trig.update(at=at, days=days)
    if action_tool:
        if action_tool not in ctx.core.tools.tools:
            return {"error": f"'{action_tool}' diye bir araç yok."}
        action = {"type": "tool", "tool": action_tool, "args": action_args or {}}
    elif prompt:
        action = {"type": "prompt", "text": prompt}
    elif say:
        action = {"type": "say", "text": say}
    else:
        return {"error": "Rutin ne yapacak? action_tool, prompt veya say gerekli."}
    rule = ctx.core.routines.store.save_rule(Rule(0, name, trig, action, mode))
    ctx.core.routines.changed()
    return {"output": f"'{name}' rutini oluşturuldu.", "id": rule.id}


create_routine._describe = lambda name, trigger, mode="ask", **kw: f"'{name}' rutinini oluştur ({trigger}, {mode})"  # type: ignore[attr-defined]


@tool(risk=Risk.READ, category="routines", platforms=(), hidden=True, timeout=120)
async def run_routine_prompt(ctx: ToolContext, text: str) -> dict:
    """Bir rutinin görev metnini Jarvis'e verir (iç araç)."""
    core = ctx.core
    if core.voice is not None:
        await core.voice.say(f"[Rutin görevi] {text}", show=False)
        return {"output": "Göreve başlandı."}
    result = await core.text_agent.run(text)
    return {"output": result.get("text", "")}
