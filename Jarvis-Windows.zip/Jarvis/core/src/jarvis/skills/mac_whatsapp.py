"""macOS: WhatsApp messages — same tool name as on Windows.

Phone numbers go through the whatsapp:// URL (pre-filled chat). Names use
the app's chat search; before sending, the open chat's header must show the
contact (Accessibility), otherwise nothing is sent.
"""

from __future__ import annotations

import re
import subprocess
import time
import urllib.parse
from typing import Annotated

from jarvis.platform import mac
from jarvis.tools import Risk, tool

PHONE = re.compile(r"^\+?[\d\s()-]{7,}$")


def _header_shows(name: str) -> bool:
    for app in mac.running_apps():
        if app["name"] == "WhatsApp":
            win = mac.ax_focused_window(app["pid"])
            if win is None:
                return False
            for el, depth in mac.ax_walk(win, max_depth=14, limit=400):
                if str(mac.ax_attr(el, "AXRole") or "") in ("AXStaticText", "AXHeading"):
                    value = str(mac.ax_attr(el, "AXValue") or mac.ax_attr(el, "AXTitle") or "")
                    if value.strip().lower() == name.strip().lower():
                        return True
    return False


@tool(risk=Risk.SEND, category="communication", timeout=45, platforms=("darwin",), requires=("ApplicationServices",))
def send_whatsapp(contact: Annotated[str, "Kişi veya grup adı ya da telefon numarası"],
                  message: Annotated[str, "Gönderilecek mesajın tam metni"]) -> dict:
    """WhatsApp masaüstü uygulamasından bir kişiye veya gruba mesaj gönderir."""
    if not message.strip():
        return {"error": "Mesaj boş."}
    if PHONE.match(contact.strip()):
        digits = re.sub(r"[^\d+]", "", contact).lstrip("+")
        if digits.startswith("0"):
            digits = "90" + digits[1:]
        subprocess.run(["open", f"whatsapp://send?phone={digits}&text={urllib.parse.quote(message)}"])
        time.sleep(2.0)
        mac.osascript(mac.keystroke_script("enter"))
        return {"output": f"{contact} numarasına gönderildi.", "verified": None}
    subprocess.run(["open", "-a", "WhatsApp"])
    time.sleep(1.2)
    mac.osascript(mac.keystroke_script("cmd+f"))
    time.sleep(0.3)
    mac.paste_text(contact)
    time.sleep(1.0)
    mac.osascript(mac.keystroke_script("down"))
    mac.osascript(mac.keystroke_script("enter"))
    time.sleep(0.8)
    if not _header_shows(contact):
        mac.osascript(mac.keystroke_script("esc"))
        return {"error": f"'{contact}' sohbetinin açıldığını doğrulayamadım; güvenlik için mesaj gönderilmedi."}
    mac.paste_text(message)
    time.sleep(0.2)
    mac.osascript(mac.keystroke_script("enter"))
    return {"output": f"{contact} kişisine gönderildi.", "verified": None,
            "observed": "sohbet başlığı doğrulandı; gönderim kutusu kontrol edilemedi"}


send_whatsapp._describe = lambda contact, message: f"WhatsApp'tan {contact} kişisine “{message}” gönder"  # type: ignore[attr-defined]
send_whatsapp._fingerprint_keys = ("contact",)  # type: ignore[attr-defined]
