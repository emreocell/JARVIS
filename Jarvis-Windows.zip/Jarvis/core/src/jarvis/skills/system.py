"""System controls: volume, media, brightness, power, system info."""

from __future__ import annotations

import ctypes
import subprocess
from datetime import datetime
from typing import Annotated, Literal

import psutil

from jarvis.tools import Risk, tool

NO_WINDOW = 0x08000000
KEYEVENTF_KEYUP = 0x0002
VK = {"play_pause": 0xB3, "next": 0xB0, "previous": 0xB1, "stop": 0xB2,
      "volume_mute": 0xAD}


def _press(vk: int) -> None:
    user32 = ctypes.windll.user32
    user32.keybd_event(vk, 0, 0, 0)
    user32.keybd_event(vk, 0, KEYEVENTF_KEYUP, 0)


# -------------------------------------------------------------------- audio


def _endpoint():
    from pycaw.pycaw import AudioUtilities

    return AudioUtilities.GetSpeakers().EndpointVolume


def _master_volume() -> int | None:
    try:
        return round(_endpoint().GetMasterVolumeLevelScalar() * 100)
    except Exception:
        return None


@tool(risk=Risk.LOW, category="system", requires=("pycaw",))
def set_volume(level: Annotated[int | None, "Hedef ses seviyesi 0-100"] = None,
               change: Annotated[int | None, "Göreli değişim, ör. +10 veya -20"] = None,
               mute: Annotated[bool | None, "Sessize al (true) / sesi aç (false)"] = None) -> dict:
    """Bilgisayarın ana ses seviyesini ayarlar, artırır/azaltır veya sessize alır."""
    ep = _endpoint()
    if mute is not None:
        ep.SetMute(int(mute), None)
    current = round(ep.GetMasterVolumeLevelScalar() * 100)
    target = current
    if level is not None:
        target = level
    elif change is not None:
        target = current + change
    target = max(0, min(100, target))
    if target != current:
        ep.SetMasterVolumeLevelScalar(target / 100, None)
        if target > 0 and mute is None:
            ep.SetMute(0, None)
    muted = bool(ep.GetMute())
    return {"output": "Ses kapatıldı." if muted else f"Ses %{target}."}


@tool(risk=Risk.LOW, category="system", requires=("pycaw",))
def set_app_volume(app: Annotated[str, "Uygulama adı, ör. 'spotify', 'chrome'"],
                   level: Annotated[int, "0-100"]) -> dict:
    """Tek bir uygulamanın sesini ayarlar (ör. sadece Spotify'ın sesini kıs)."""
    from pycaw.pycaw import AudioUtilities

    from jarvis.skills.text import clean_name

    key = clean_name(app).replace(" ", "")
    hit = []
    for s in AudioUtilities.GetAllSessions():
        if s.Process and key in s.Process.name().lower().replace(" ", ""):
            s.SimpleAudioVolume.SetMasterVolume(max(0, min(100, level)) / 100, None)
            hit.append(s.Process.name())
    if not hit:
        return {"error": f"Şu an ses çalan bir '{app}' yok."}
    return {"output": f"{app} sesi %{level}."}


# -------------------------------------------------------------------- media


async def _media_session():
    from winrt.windows.media.control import GlobalSystemMediaTransportControlsSessionManager as M

    manager = await M.request_async()
    return manager.get_current_session()


@tool(risk=Risk.LOW, category="media")
async def media_control(action: Annotated[Literal["play_pause", "play", "pause", "next", "previous", "stop"],
                                          "Yapılacak işlem"]) -> dict:
    """Çalan medyayı kontrol eder (Spotify, YouTube, tarayıcı, her oynatıcı): oynat/duraklat, sonraki, önceki."""
    try:
        s = await _media_session()
    except Exception:
        s = None
    if s is not None:
        method = {"play_pause": s.try_toggle_play_pause_async, "play": s.try_play_async,
                  "pause": s.try_pause_async, "next": s.try_skip_next_async,
                  "previous": s.try_skip_previous_async, "stop": s.try_stop_async}[action]
        if await method():
            return {"output": "Tamam."}
    _press(VK["play_pause" if action in ("play", "pause") else action])
    return {"output": "Tamam."}


@tool(risk=Risk.READ, category="media")
async def now_playing() -> dict:
    """Şu an ne çaldığını söyler (şarkı adı, sanatçı, uygulama)."""
    s = await _media_session()
    if s is None:
        return {"output": "Şu an çalan bir şey yok."}
    props = await s.try_get_media_properties_async()
    status = s.get_playback_info().playback_status
    app = s.source_app_user_model_id.split("!")[-1].split(".")[0]
    return {"title": props.title, "artist": props.artist, "app": app,
            "playing": int(status) == 4}  # 4 = Playing


async def now_playing_info() -> dict | None:
    """now_playing as data (None when nothing plays) — for verifiers."""
    try:
        r = await now_playing.__tool__.handler()  # type: ignore[attr-defined]
    except Exception:
        return None
    return r if r.get("title") else None


_art_cache: dict[str, str | None] = {}


async def now_playing_card() -> dict | None:
    """For the UI mini-player: now_playing + album art as a data URL (cached
    per track; never sent to the LLM)."""
    s = await _media_session()
    if s is None:
        return None
    props = await s.try_get_media_properties_async()
    if not props.title:
        return None
    info = s.get_playback_info()
    key = f"{props.title}|{props.artist}"
    if key not in _art_cache:
        _art_cache.clear()  # keep only the current track
        _art_cache[key] = await _read_thumbnail(props.thumbnail)
    app = s.source_app_user_model_id.split("!")[-1].split(".")[0]
    return {"title": props.title, "artist": props.artist, "album": props.album_title, "app": app,
            "playing": int(info.playback_status) == 4, "art": _art_cache[key]}


async def _read_thumbnail(ref) -> str | None:
    if ref is None:
        return None
    try:
        import base64

        from winrt.windows.storage.streams import Buffer, DataReader, InputStreamOptions

        stream = await ref.open_read_async()
        size = min(int(stream.size), 2_000_000)
        buf = Buffer(size)
        await stream.read_async(buf, size, InputStreamOptions.READ_AHEAD)
        data = bytearray(buf.length)
        DataReader.from_buffer(buf).read_bytes(data)
        mime = stream.content_type or "image/png"
        return f"data:{mime};base64,{base64.b64encode(bytes(data)).decode()}"
    except Exception:
        return None


# --------------------------------------------------------------- display


@tool(risk=Risk.LOW, category="system", requires=("screen_brightness_control",))
def set_brightness(level: Annotated[int | None, "0-100"] = None,
                   change: Annotated[int | None, "Göreli değişim, ör. +10"] = None) -> dict:
    """Ekran parlaklığını ayarlar (laptop ekranı ve destekleyen harici monitörler)."""
    import screen_brightness_control as sbc

    try:
        current = sbc.get_brightness()[0]
    except Exception as exc:
        return {"error": f"Parlaklık okunamadı: {exc}"}
    target = level if level is not None else current + (change or 0)
    target = max(0, min(100, target))
    sbc.set_brightness(target)
    return {"output": f"Parlaklık %{target}."}


# ----------------------------------------------------------------- power


@tool(risk=Risk.LOW, category="system")
def lock_screen() -> dict:
    """Bilgisayarı kilitler."""
    ctypes.windll.user32.LockWorkStation()
    return {"output": "Kilitlendi."}


@tool(risk=Risk.DESTRUCTIVE, category="system")
def power(action: Annotated[Literal["sleep", "shutdown", "restart", "cancel"], "Güç işlemi"],
          delay_minutes: Annotated[int, "Kaç dakika sonra (0 = hemen)"] = 0) -> dict:
    """Bilgisayarı uyutur, kapatır veya yeniden başlatır; zamanlanmış kapatmayı iptal eder."""
    if action == "cancel":
        subprocess.run(["shutdown", "/a"], creationflags=NO_WINDOW)
        return {"output": "Zamanlanmış kapatma iptal edildi."}
    if action == "sleep":
        ctypes.windll.powrprof.SetSuspendState(0, 1, 0)
        return {"output": "Uyku moduna geçiliyor."}
    flag = "/s" if action == "shutdown" else "/r"
    subprocess.run(["shutdown", flag, "/t", str(max(0, delay_minutes) * 60)], creationflags=NO_WINDOW)
    when = f"{delay_minutes} dakika sonra" if delay_minutes else "hemen"
    return {"output": f"Bilgisayar {when} {'kapanacak' if action == 'shutdown' else 'yeniden başlayacak'}."}


power._describe = lambda action, delay_minutes=0: {  # type: ignore[attr-defined]
    "sleep": "Bilgisayarı uyut", "shutdown": f"Bilgisayarı {delay_minutes or 'hemen'} dk sonra kapat",
    "restart": "Bilgisayarı yeniden başlat", "cancel": "Kapatmayı iptal et"}[action]


# ------------------------------------------------------------------ info


@tool(risk=Risk.READ, category="system", platforms=())
def system_info() -> dict:
    """İşlemci, bellek, disk ve pil durumunu ve en çok bellek kullanan uygulamaları verir."""
    mem = psutil.virtual_memory()
    disk = psutil.disk_usage("C:\\" if psutil.WINDOWS else "/")
    battery = psutil.sensors_battery()
    top: dict[str, float] = {}
    for p in psutil.process_iter(["name", "memory_info"]):
        try:
            top[p.info["name"]] = top.get(p.info["name"], 0) + p.info["memory_info"].rss / 2**20
        except (psutil.Error, AttributeError, TypeError):
            continue
    heavy = sorted(top.items(), key=lambda kv: kv[1], reverse=True)[:5]
    return {
        "cpu_percent": psutil.cpu_percent(interval=0.3),
        "ram": f"%{mem.percent:.0f} ({mem.used / 2**30:.1f}/{mem.total / 2**30:.1f} GB)",
        "disk_c": f"%{disk.percent:.0f} dolu, {disk.free / 2**30:.0f} GB boş",
        "battery": None if battery is None else f"%{battery.percent:.0f}{' şarjda' if battery.power_plugged else ''}",
        "top_memory": [f"{n}: {mb:.0f} MB" for n, mb in heavy],
    }


@tool(risk=Risk.READ, category="system", platforms=())
def current_time() -> dict:
    """Şu anki tarih, saat ve günü verir."""
    now = datetime.now()
    days = ["Pazartesi", "Salı", "Çarşamba", "Perşembe", "Cuma", "Cumartesi", "Pazar"]
    return {"date": now.strftime("%d.%m.%Y"), "time": now.strftime("%H:%M"), "weekday": days[now.weekday()]}


@tool(risk=Risk.LOW, category="system")
def open_settings(page: Annotated[str, "Ayar sayfası: 'bluetooth', 'wifi', 'ses', 'ekran', 'güncelleme', 'uygulamalar' vb."] = "") -> dict:
    """Windows Ayarlar'da belirli bir sayfayı açar."""
    import os

    from jarvis.skills.text import norm

    pages = {"bluetooth": "bluetooth", "wifi": "network-wifi", "ag": "network", "ses": "sound",
             "ekran": "display", "guncelleme": "windowsupdate", "uygulamalar": "appsfeatures",
             "bildirimler": "notifications", "guc": "powersleep", "pil": "batterysaver",
             "arka plan": "personalization-background", "tema": "themes", "fare": "mousetouchpad",
             "klavye": "typing", "dil": "regionlanguage", "depolama": "storagesense",
             "gizlilik": "privacy", "odak": "quiethours"}
    uri = "ms-settings:" + pages.get(norm(page), "")
    os.startfile(uri)
    return {"output": "Ayarlar açılıyor."}
