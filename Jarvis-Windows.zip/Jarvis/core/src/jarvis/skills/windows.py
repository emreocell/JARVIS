"""Window management and screenshots: snap to halves, centre, maximise,
side-by-side, show desktop, screen capture.

Windows are found by process first (like closing apps: Store apps included),
then by title. Snapping compensates for Windows 10/11's invisible resize
borders (DWM extended frame) so windows sit flush against each other.
"""

from __future__ import annotations

import ctypes
import os
import time
from ctypes import wintypes
from datetime import datetime
from pathlib import Path
from typing import Annotated, Literal

from jarvis.skills.text import similarity
from jarvis.tools import Risk, tool

user32 = ctypes.windll.user32 if hasattr(ctypes, "windll") else None
SW_RESTORE, SW_MINIMIZE, SW_MAXIMIZE = 9, 6, 3
Position = Literal["left", "right", "top", "bottom", "full", "center", "minimize", "restore"]
POSITION_TR = {"left": "sol yarıya", "right": "sağ yarıya", "top": "üst yarıya", "bottom": "alt yarıya",
               "full": "tam ekrana", "center": "ortaya", "minimize": "simge durumuna", "restore": "eski boyutuna"}


class MONITORINFO(ctypes.Structure):
    _fields_ = [("cbSize", wintypes.DWORD), ("rcMonitor", wintypes.RECT), ("rcWork", wintypes.RECT),
                ("dwFlags", wintypes.DWORD)]


def _title(hwnd: int) -> str:
    buf = ctypes.create_unicode_buffer(512)
    user32.GetWindowTextW(hwnd, buf, 512)
    return buf.value


def _cloaked(hwnd: int) -> bool:
    val = ctypes.c_int(0)
    ctypes.windll.dwmapi.DwmGetWindowAttribute(wintypes.HWND(hwnd), 14, ctypes.byref(val), ctypes.sizeof(val))
    return bool(val.value)


def top_windows() -> list[tuple[int, int, str]]:
    """(hwnd, pid, title) of real, visible app windows in z-order."""
    out: list[tuple[int, int, str]] = []

    def cb(hwnd, _):
        if not user32.IsWindowVisible(hwnd) or user32.GetWindow(hwnd, 4):  # GW_OWNER: skip owned popups
            return True
        ex = user32.GetWindowLongW(hwnd, -20)
        if ex & 0x80 and not ex & 0x40000:  # WS_EX_TOOLWINDOW without WS_EX_APPWINDOW
            return True
        title = _title(hwnd)
        if not title or title in ("Program Manager",) or _cloaked(hwnd):
            return True
        pid = wintypes.DWORD()
        user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        out.append((hwnd, pid.value, title))
        return True

    user32.EnumWindows(ctypes.WINFUNCTYPE(ctypes.c_bool, wintypes.HWND, wintypes.LPARAM)(cb), 0)
    return out


def find_window(name: str) -> tuple[int, str] | None:
    """Best window for an app name ('vs code', 'spotify', 'chrome')."""
    from jarvis.skills.apps import _processes_for

    if name == "__foreground__":  # "bu pencere": the window in front (never Jarvis itself)
        wins = [w for w in top_windows() if w[2] not in ("Jarvis", "Jarvis Komut", "Jarvis Orb")]
        return (wins[0][0], wins[0][2]) if wins else None
    wins = top_windows()
    try:
        pids = {p.pid for p in _processes_for(name)}
    except Exception:
        pids = set()
    for hwnd, pid, title in wins:  # z-order: the most recently used first
        if pid in pids:
            return hwnd, title
    scored = sorted(((similarity(name, t), hwnd, t) for hwnd, _, t in wins), reverse=True)
    if scored and scored[0][0] >= 0.6:
        return scored[0][1], scored[0][2]
    low = name.lower()
    return next(((h, t) for h, _, t in wins if low in t.lower()), None)


def _work_area(hwnd: int) -> wintypes.RECT:
    mon = user32.MonitorFromWindow(wintypes.HWND(hwnd), 2)  # MONITOR_DEFAULTTONEAREST
    info = MONITORINFO(cbSize=ctypes.sizeof(MONITORINFO))
    user32.GetMonitorInfoW(mon, ctypes.byref(info))
    return info.rcWork


def _frame_margins(hwnd: int) -> tuple[int, int, int, int]:
    """Invisible border widths (left, top, right, bottom)."""
    win, ext = wintypes.RECT(), wintypes.RECT()
    user32.GetWindowRect(wintypes.HWND(hwnd), ctypes.byref(win))
    if ctypes.windll.dwmapi.DwmGetWindowAttribute(wintypes.HWND(hwnd), 9, ctypes.byref(ext), ctypes.sizeof(ext)):
        return 0, 0, 0, 0
    return ext.left - win.left, ext.top - win.top, win.right - ext.right, win.bottom - ext.bottom


def place(hwnd: int, position: str) -> None:
    if position == "minimize":
        user32.ShowWindow(hwnd, SW_MINIMIZE)
        return
    if position == "full":
        user32.ShowWindow(hwnd, SW_MAXIMIZE)
        user32.SetForegroundWindow(hwnd)
        return
    user32.ShowWindow(hwnd, SW_RESTORE)
    if position == "restore":
        user32.SetForegroundWindow(hwnd)
        return
    wa = _work_area(hwnd)
    x, y, w, h = wa.left, wa.top, wa.right - wa.left, wa.bottom - wa.top
    rect = {
        "left": (x, y, w // 2, h), "right": (x + w // 2, y, w - w // 2, h),
        "top": (x, y, w, h // 2), "bottom": (x, y + h // 2, w, h - h // 2),
        "center": (x + w // 6, y + h // 8, w * 2 // 3, h * 3 // 4),
    }[position]
    ml, mt, mr, mb = _frame_margins(hwnd)
    rx, ry, rw, rh = rect
    user32.SetWindowPos(hwnd, None, rx - ml, ry - mt, rw + ml + mr, rh + mt + mb, 0x0004 | 0x0040)  # NOZORDER|SHOWWINDOW
    user32.SetForegroundWindow(hwnd)


@tool(risk=Risk.LOW, category="windows")
def arrange_window(app: Annotated[str, "Uygulama/pencere adı, ör. 'vs code', 'chrome'"],
                   position: Annotated[Position, "Nereye: left, right, top, bottom, full, center, minimize, restore"]) -> dict:
    """Bir pencereyi ekranın sol/sağ yarısına, ortaya, tam ekrana alır ya da küçültür: 'VS Code'u sola al'."""
    found = find_window(app)
    if found is None:
        return {"error": f"Açık bir '{app}' penceresi bulamadım."}
    place(found[0], position)
    label = "Pencere" if app == "__foreground__" else app
    return {"output": f"{label} {POSITION_TR[position]} alındı."}


@tool(risk=Risk.LOW, category="windows")
def side_by_side(left_app: Annotated[str, "Sola gelecek uygulama"],
                 right_app: Annotated[str, "Sağa gelecek uygulama"]) -> dict:
    """İki pencereyi yan yana dizer: 'VS Code ile Chrome'u yan yana koy'."""
    left, right = find_window(left_app), find_window(right_app)
    missing = [n for n, w in ((left_app, left), (right_app, right)) if w is None]
    if missing:
        return {"error": f"Açık pencere bulamadım: {', '.join(missing)}."}
    place(left[0], "left")  # type: ignore[index]
    place(right[0], "right")  # type: ignore[index]
    return {"output": f"{left_app} solda, {right_app} sağda."}


@tool(risk=Risk.LOW, category="windows")
def show_desktop() -> dict:
    """Tüm pencereleri küçültüp masaüstünü gösterir (tekrar çağrılınca geri getirir)."""
    import comtypes.client

    comtypes.client.CreateObject("Shell.Application").ToggleDesktop()
    return {"output": "Tamam."}


@tool(risk=Risk.READ, category="windows")
def list_windows() -> dict:
    """Açık pencereleri listeler."""
    return {"windows": [t for _, _, t in top_windows()][:30]}


@tool(risk=Risk.LOW, category="windows")
def take_screenshot(target: Annotated[Literal["screen", "window"], "Tüm ekran mı, öndeki pencere mi"] = "screen") -> dict:
    """Ekran görüntüsü alır: Resimler\\Ekran Görüntüleri klasörüne kaydeder ve panoya kopyalar."""
    from PIL import ImageGrab

    if target == "window":
        hwnd = user32.GetForegroundWindow()
        ext = wintypes.RECT()
        ctypes.windll.dwmapi.DwmGetWindowAttribute(wintypes.HWND(hwnd), 9, ctypes.byref(ext), ctypes.sizeof(ext))
        img = ImageGrab.grab(bbox=(ext.left, ext.top, ext.right, ext.bottom), all_screens=True)
    else:
        img = ImageGrab.grab(all_screens=True)
    folder = _pictures() / "Ekran Görüntüleri"
    folder.mkdir(parents=True, exist_ok=True)
    path = folder / f"Jarvis {datetime.now():%Y-%m-%d %H.%M.%S}.png"
    img.save(path)
    copied = _copy_image(img)
    return {"output": "Ekran görüntüsü kaydedildi" + (" ve panoya kopyalandı." if copied else "."), "path": str(path)}


def _pictures() -> Path:
    home = Path(os.environ.get("USERPROFILE", Path.home()))
    for base in (home / "OneDrive" / "Resimler", home / "OneDrive" / "Pictures", home / "Pictures"):
        if base.exists():
            return base
    return home / "Pictures"


def _copy_image(img) -> bool:
    """Put a PIL image on the clipboard as a DIB (pastes into chats, docs, Paint)."""
    import io

    buf = io.BytesIO()
    img.convert("RGB").save(buf, "BMP")
    data = buf.getvalue()[14:]  # strip BITMAPFILEHEADER
    kernel32 = ctypes.windll.kernel32
    kernel32.GlobalAlloc.restype = ctypes.c_void_p
    kernel32.GlobalLock.restype = ctypes.c_void_p
    for _ in range(10):
        if user32.OpenClipboard(None):
            break
        time.sleep(0.05)
    else:
        return False
    try:
        user32.EmptyClipboard()
        handle = kernel32.GlobalAlloc(0x0002, len(data))  # GMEM_MOVEABLE
        ptr = kernel32.GlobalLock(ctypes.c_void_p(handle))
        ctypes.memmove(ptr, data, len(data))
        kernel32.GlobalUnlock(ctypes.c_void_p(handle))
        user32.SetClipboardData.argtypes = [wintypes.UINT, ctypes.c_void_p]
        return bool(user32.SetClipboardData(8, ctypes.c_void_p(handle)))  # CF_DIB
    finally:
        user32.CloseClipboard()


# ------------------------------------------------------------------- OCR

async def ocr_image(img) -> str:
    """Offline text recognition with Windows' built-in OCR (user's languages)."""
    from winrt.windows.graphics.imaging import BitmapPixelFormat, SoftwareBitmap
    from winrt.windows.media.ocr import OcrEngine
    from winrt.windows.storage.streams import DataWriter

    engine = OcrEngine.try_create_from_user_profile_languages()
    if engine is None:
        raise RuntimeError("Windows OCR bu dil için yüklü değil")
    limit = int(OcrEngine.max_image_dimension)
    # small UI text reads much better upscaled (up to 2x, within the engine's limit)
    scale = min(2.0, limit / max(img.size))
    if scale > 1.15 or scale < 1.0:
        from PIL import Image as _Image

        img = img.resize((int(img.width * scale), int(img.height * scale)), _Image.LANCZOS)
    rgba = img.convert("RGBA")
    b, g, r, a = rgba.split()
    from PIL import Image

    bgra = Image.merge("RGBA", (b, g, r, a)).tobytes()
    writer = DataWriter()
    writer.write_bytes(bgra)
    bitmap = SoftwareBitmap.create_copy_from_buffer(writer.detach_buffer(), BitmapPixelFormat.BGRA8,
                                                     rgba.width, rgba.height)
    result = await engine.recognize_async(bitmap)
    return "\n".join(line.text for line in result.lines)


def _grab(target: str):
    from PIL import ImageGrab

    if target == "window":
        found = find_window("__foreground__")
        if found:
            ext = wintypes.RECT()
            ctypes.windll.dwmapi.DwmGetWindowAttribute(wintypes.HWND(found[0]), 9, ctypes.byref(ext), ctypes.sizeof(ext))
            return ImageGrab.grab(bbox=(ext.left, ext.top, ext.right, ext.bottom), all_screens=True), found[1]
    return ImageGrab.grab(all_screens=True), "ekran"


@tool(risk=Risk.READ, category="screen")
async def read_screen_text(target: Annotated[Literal["window", "screen"], "Öndeki pencere mi, tüm ekran mı"] = "window",
                           to_clipboard: Annotated[bool, "Metni panoya da kopyala"] = False) -> dict:
    """Ekrandaki/penceredeki yazıyı cihazda (çevrimdışı, Windows OCR) okur; istenirse panoya kopyalar.
    'Bu penceredeki metni kopyala', 'ekrandaki yazıyı oku', 'şu hatayı oku'. Görüntü hiçbir yere gönderilmez."""
    import asyncio

    img, source = await asyncio.to_thread(_grab, target)
    text = (await ocr_image(img)).strip()
    if not text:
        return {"output": "Okunacak bir yazı bulamadım."}
    if to_clipboard:
        from jarvis.skills.desktop import set_clipboard_text

        await asyncio.to_thread(set_clipboard_text, text)
    head = f"{source} içindeki yazı" + (" panoya kopyalandı" if to_clipboard else "")
    return {"output": f"{head}:\n{text[:1500]}", "text": text[:8000], "source": source}
