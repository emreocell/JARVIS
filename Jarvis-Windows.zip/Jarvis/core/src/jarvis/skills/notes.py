"""Notes tools: 'not al: …', 'notlarımı oku', 'şu notu sil'."""

from __future__ import annotations

from typing import Annotated

from jarvis.tools import Risk, ToolContext, tool


def _store(ctx: ToolContext):
    return ctx.core.notes


@tool(risk=Risk.LOW, category="notes", platforms=())
async def take_note(ctx: ToolContext, text: Annotated[str, "Not metni (kullanıcının söylediği gibi)"]) -> dict:
    """Hızlı not alır: 'not al: yarın faturayı öde', 'şunu not et …'. Notlar sayfasında görünür."""
    if not text.strip():
        return {"error": "Not boş."}
    note = _store(ctx).add(text)
    await ctx.core.bus.publish("notes.changed")
    return {"output": "Not aldım.", "id": note.id}


@tool(risk=Risk.READ, category="notes", platforms=())
async def list_notes(ctx: ToolContext,
                     query: Annotated[str, "Aranacak kelime(ler); boşsa son notlar"] = "",
                     limit: Annotated[int, "Kaç not"] = 8) -> dict:
    """Notları okur veya arar: 'notlarımı oku', 'fatura ile ilgili notum var mıydı?'."""
    notes = _store(ctx).list(query, max(1, min(limit, 30)), include_done=False)
    if not notes:
        return {"output": "Eşleşen not yok." if query else "Hiç notun yok."}
    return {"output": "\n".join(f"{i}. {n.text}" for i, n in enumerate(notes, 1)),
            "notes": [{"id": n.id, "text": n.text} for n in notes]}


@tool(risk=Risk.WRITE, category="notes", platforms=())
async def delete_note(ctx: ToolContext, note_id: Annotated[int, "list_notes çıktısındaki not id'si"]) -> dict:
    """Bir notu siler."""
    ok = _store(ctx).delete(int(note_id))
    await ctx.core.bus.publish("notes.changed")
    return {"output": "Not silindi."} if ok else {"error": "Not bulunamadı."}


delete_note._describe = lambda note_id: f"{note_id} numaralı notu sil"  # type: ignore[attr-defined]


@tool(risk=Risk.LOW, category="notes", platforms=())
async def complete_note(ctx: ToolContext, note_id: Annotated[int, "Notun id'si"]) -> dict:
    """Notu/yapılacak işi tamamlandı olarak işaretler: 'faturayı ödedim, notu kapat'."""
    note = _store(ctx).update(int(note_id), done=True)
    await ctx.core.bus.publish("notes.changed")
    return {"output": "Tamamlandı olarak işaretledim."} if note else {"error": "Not bulunamadı."}
