"""Verifiers for computer-control tools (see jarvis.tools.verify).

Each one looks at the real world after the action — a window appeared, the
volume really changed, the page reacted — and recovers once when it can.
"""

from __future__ import annotations

import asyncio
import re
import sys
from typing import Any

from jarvis.tools.verify import Verdict, Verifier, poll, verifies

SUCCESS_WORDS = re.compile(r"teşekkür|başar|gönderildi|kaydedildi|tamamlandı|alındı|thank|success|submitted|"
                           r"received|saved|confirmed", re.I)
ERROR_WORDS = re.compile(r"hata|geçersiz|zorunlu|gerekli alan|başarısız|lütfen .* girin|error|invalid|required|"
                         r"failed|try again", re.I)


# ---------------------------------------------------------------- apps

def _app_windows(name: str) -> tuple[set[int], set[int]]:
    """(pids of the app's processes, pids that own a visible window)."""
    from jarvis.skills.apps import _processes_for, _window_pids

    app = {p.pid for p in _processes_for(name)}
    windowed = {pid for pid, _ in _window_pids()}
    return app, windowed


def _foreground_pid() -> int:
    import ctypes
    from ctypes import wintypes

    pid = wintypes.DWORD()
    ctypes.windll.user32.GetWindowThreadProcessId(ctypes.windll.user32.GetForegroundWindow(), ctypes.byref(pid))
    return pid.value


@verifies("open_app")
class OpenAppCheck(Verifier):
    async def before(self, ctx: Any, args: dict[str, Any]) -> Any:
        from jarvis.skills.apps import _window_pids

        app, windowed = await asyncio.to_thread(_app_windows, args.get("name", ""))
        titles = {t for _, t in await asyncio.to_thread(_window_pids)}
        return {"running": bool(app & windowed), "titles": titles}

    async def check(self, ctx: Any, args: dict[str, Any], result: dict[str, Any], pre: Any) -> Verdict:
        if sys.platform != "win32":
            return Verdict(None)
        name = args.get("name", "")

        def seen() -> str | None:
            from jarvis.skills.apps import _window_pids
            from jarvis.skills.text import similarity

            app, windowed = _app_windows(name)
            if app & windowed:
                return "penceresi açık"
            # apps we can't map to a process (Settings, Store apps): a new window with a similar title
            display = str(result.get("output", "")).removesuffix(" açılıyor.") or name
            for _, title in _window_pids():
                if title not in (pre or {}).get("titles", set()) and (
                        similarity(display, title) >= 0.6 or display.lower() in title.lower()):
                    return f"“{title[:40]}” penceresi açıldı"
            return None

        found = await poll(lambda: asyncio.to_thread(seen), timeout=9, interval=0.4)
        if found:
            already = (pre or {}).get("running")
            return Verdict(True, "zaten açıktı" if already else found)
        return Verdict(False, f"{name} penceresi 9 saniye içinde görünmedi")

    async def recover(self, ctx: Any, args: dict[str, Any], result: dict[str, Any], pre: Any) -> dict[str, Any] | None:
        """Second route: Start menu search, like a person would."""
        from jarvis.skills import desktop

        name = args.get("name", "")
        await asyncio.to_thread(desktop.hotkey, "{Win}")
        await asyncio.sleep(0.8)
        await asyncio.to_thread(desktop.type_unicode, name)
        await asyncio.sleep(1.2)
        await asyncio.to_thread(desktop.hotkey, "{Enter}")
        return {"recovery": "Başlat menüsünden tekrar denedim"}


@verifies("close_app")
class CloseAppCheck(Verifier):
    async def check(self, ctx: Any, args: dict[str, Any], result: dict[str, Any], pre: Any) -> Verdict:
        from jarvis.skills.apps import _processes_for

        gone = await poll(lambda: asyncio.to_thread(lambda: not _processes_for(args.get("name", ""))), 5)
        return Verdict(True, "işlemleri kapandı") if gone else Verdict(False, "uygulama hâlâ çalışıyor")


@verifies("focus_window")
class FocusCheck(Verifier):
    async def check(self, ctx: Any, args: dict[str, Any], result: dict[str, Any], pre: Any) -> Verdict:
        if sys.platform != "win32":
            return Verdict(None)
        from jarvis.skills.windows import _title
        from jarvis.skills.text import similarity

        import ctypes

        def front() -> str:
            return _title(ctypes.windll.user32.GetForegroundWindow())

        name = args.get("name", "")
        ok = await poll(lambda: similarity(name, front()) >= 0.5 or name.lower() in front().lower(), 2)
        return Verdict(bool(ok), f"önde: {front()[:50]}")


# -------------------------------------------------------------- system

@verifies("set_volume")
class VolumeCheck(Verifier):
    async def check(self, ctx: Any, args: dict[str, Any], result: dict[str, Any], pre: Any) -> Verdict:
        m = re.search(r"%(\d+)", str(result.get("output", "")))
        if not m or sys.platform != "win32":
            return Verdict(None)
        from jarvis.skills.system import _master_volume

        now = await asyncio.to_thread(_master_volume)
        if now is None:
            return Verdict(None)
        ok = abs(now - int(m.group(1))) <= 2
        return Verdict(ok, f"ses şu an %{now}")


@verifies("media_control")
class MediaCheck(Verifier):
    async def before(self, ctx: Any, args: dict[str, Any]) -> Any:
        from jarvis.skills.system import now_playing_info

        return await now_playing_info()

    async def check(self, ctx: Any, args: dict[str, Any], result: dict[str, Any], pre: Any) -> Verdict:
        from jarvis.skills.system import now_playing_info

        action = args.get("action", "")
        if not pre:
            return Verdict(None)

        async def changed() -> dict[str, Any] | None:
            now = await now_playing_info()
            if not now:
                return None
            if action in ("next", "previous") and now.get("title") != pre.get("title"):
                return now
            if action == "pause" and not now.get("playing"):
                return now
            if action == "play" and now.get("playing"):
                return now
            if action == "play_pause" and now.get("playing") != pre.get("playing"):
                return now
            return None

        now = await poll(changed, 3, 0.3)
        if now:
            return Verdict(True, f"{now.get('artist', '')} – {now.get('title', '')}".strip(" –"))
        return Verdict(False, "çalan medyada bir değişiklik olmadı")


# ------------------------------------------------------------- windows

@verifies("arrange_window", "side_by_side")
class ArrangeCheck(Verifier):
    async def check(self, ctx: Any, args: dict[str, Any], result: dict[str, Any], pre: Any) -> Verdict:
        if sys.platform != "win32":
            return Verdict(None)
        from jarvis.skills.windows import find_window

        names = [args[k] for k in ("app", "left_app", "right_app") if args.get(k)]
        missing = [n for n in names if await asyncio.to_thread(find_window, n) is None]
        return Verdict(not missing, "pencere bulunamadı: " + ", ".join(missing) if missing else "yerleştirildi")


# ------------------------------------------------------------- browser

async def _page_state(ctx: Any) -> dict[str, Any] | None:
    from jarvis.skills.browser import session

    s = session()
    if not s.connected:
        return None
    page = await s.ensure()
    try:
        info = await asyncio.wait_for(page.evaluate(
            "() => ({url: location.href, title: document.title, n: document.body ? document.body.innerText.length : 0,"
            " text: document.body ? document.body.innerText.slice(-4000) : ''})"), 2)
    except Exception:
        return None
    info["tabs"] = len(page.context.pages)
    return info


@verifies("browser_click", "browser_do", "browser_click_confirmed")
class BrowserClickCheck(Verifier):
    async def before(self, ctx: Any, args: dict[str, Any]) -> Any:
        return await _page_state(ctx)

    async def check(self, ctx: Any, args: dict[str, Any], result: dict[str, Any], pre: Any) -> Verdict:
        if not pre:
            return Verdict(None)

        async def reaction() -> str | None:
            now = await _page_state(ctx)
            if not now:
                return None
            if now["tabs"] > pre["tabs"]:
                return "yeni sekme açıldı"
            if now["url"] != pre["url"]:
                return f"sayfa değişti: {now['title'][:60]}"
            if abs(now["n"] - pre["n"]) > 20 or now["title"] != pre["title"]:
                new_text = now["text"][-1500:]
                if ERROR_WORDS.search(new_text) and not ERROR_WORDS.search(pre["text"][-1500:]):
                    return "HATA: sayfada bir hata/uyarı mesajı belirdi"
                if SUCCESS_WORDS.search(new_text) and not SUCCESS_WORDS.search(pre["text"][-1500:]):
                    return "sayfada başarı mesajı göründü"
                return "sayfa içeriği güncellendi"
            return None

        seen = await poll(reaction, 3, 0.35)
        if seen and seen.startswith("HATA"):
            return Verdict(False, seen.removeprefix("HATA: "))
        if seen:
            return Verdict(True, seen)
        label = str(result.get("element") or result.get("output") or "")
        if re.search(r"gönder|kaydet|onayla|submit|send|save|ödeme|satın", label, re.I):
            return Verdict(False, "butona bastım ama sayfada bir değişiklik ya da başarı mesajı görünmedi")
        return Verdict(None, "sayfada görünür bir değişiklik olmadı")


@verifies("browser_type_into", "browser_type")
class BrowserTypeCheck(Verifier):
    async def check(self, ctx: Any, args: dict[str, Any], result: dict[str, Any], pre: Any) -> Verdict:
        if args.get("submit"):
            return Verdict(None)   # the field is gone/cleared after submitting; the next read shows the result
        from jarvis.skills.browser import session

        text = str(args.get("text", ""))[:30]
        if not text:
            return Verdict(None)
        page = await session().ensure()
        try:
            value = await page.evaluate("() => { const e = document.activeElement; return e ? (e.value ?? "
                                        "e.innerText ?? '') : '' }")
        except Exception:
            return Verdict(None)
        ok = text in (value or "")
        return Verdict(ok, "alana yazıldı" if ok else "yazdığım metin alanda görünmüyor")


# ------------------------------------------------------------- desktop

@verifies("desktop_do", "click_element", "click_element_confirmed")
class DesktopClickCheck(Verifier):
    async def before(self, ctx: Any, args: dict[str, Any]) -> Any:
        return await asyncio.to_thread(_desktop_state)

    async def check(self, ctx: Any, args: dict[str, Any], result: dict[str, Any], pre: Any) -> Verdict:
        if not pre:
            return Verdict(None)
        now = await poll(lambda: asyncio.to_thread(lambda: (s := _desktop_state()) != pre and s), 2, 0.3)
        if now:
            return Verdict(True, "pencerede değişiklik oldu")
        return Verdict(None, "görünür bir değişiklik olmadı")


def _desktop_state() -> tuple[Any, ...] | None:
    if sys.platform != "win32":
        return None
    import ctypes

    from jarvis.skills.apps import _window_pids
    from jarvis.skills.windows import _title

    return (_title(ctypes.windll.user32.GetForegroundWindow()), tuple(sorted(t for _, t in _window_pids())))
