"""The one thread all UI Automation work runs on.

``uiautomation`` keeps a process-wide automation client bound to the COM
apartment of the thread that first used it. Calling it from arbitrary
worker threads works once and then returns stale trees or COM errors, so
every UIA-using skill goes through this single long-lived thread.
"""

from __future__ import annotations

import asyncio
from collections.abc import Callable
from concurrent.futures import ThreadPoolExecutor
from typing import Any, TypeVar

T = TypeVar("T")


def _init_com() -> None:
    import comtypes

    comtypes.CoInitializeEx()


executor = ThreadPoolExecutor(max_workers=1, thread_name_prefix="uia", initializer=_init_com)


async def run(fn: Callable[..., T], *args: Any) -> T:
    """Run ``fn(*args)`` on the UIA thread."""
    return await asyncio.get_running_loop().run_in_executor(executor, fn, *args)
