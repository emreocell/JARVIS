"""Turkish-aware text helpers for fuzzy matching names and commands."""

from __future__ import annotations

import re
import unicodedata

_TR = str.maketrans({"ı": "i", "İ": "i", "ğ": "g", "Ğ": "g", "ü": "u", "Ü": "u", "ş": "s", "Ş": "s",
                     "ö": "o", "Ö": "o", "ç": "c", "Ç": "c", "â": "a", "î": "i", "û": "u"})

# case suffixes people naturally add when speaking: "Spotify'ı aç", "Ahmet'e yaz", "WhatsApp'tan"
_SUFFIX = re.compile(
    r"['’]?(y?[ıiuü]|y?[ae]|[dt][ae]n|[dt][ae]|n[ıiuü]n|[ıiuü]n|l[ae]r[ıi]?|y?l[ae]|ki)$", re.I
)


def norm(text: str) -> str:
    """Lowercase, strip Turkish diacritics and punctuation, collapse spaces."""
    t = text.translate(_TR).lower()
    t = unicodedata.normalize("NFKD", t)
    t = "".join(c for c in t if not unicodedata.combining(c))
    t = re.sub(r"[^\w\s.+#-]", " ", t)
    return re.sub(r"\s+", " ", t).strip()


def strip_suffix(word: str) -> str:
    """Remove a trailing apostrophe suffix: "spotify'ı" -> "spotify"."""
    if "'" in word or "’" in word:
        return re.split(r"['’]", word, maxsplit=1)[0]
    return word


def clean_name(text: str) -> str:
    return norm(" ".join(strip_suffix(w) for w in text.split()))


def similarity(a: str, b: str) -> float:
    """0..1 match score between a spoken name and a candidate."""
    a, b = clean_name(a), norm(b)
    if not a or not b:
        return 0.0
    if a == b:
        return 1.0
    a_words, b_words = a.split(), b.split()
    if a_words == b_words[: len(a_words)]:
        return 0.92  # "opera" -> "Opera GX tarayıcı"
    if set(a_words) <= set(b_words):
        return 0.86
    if b.startswith(a) or a.startswith(b):
        return 0.5 + 0.35 * min(len(a), len(b)) / max(len(a), len(b))
    from difflib import SequenceMatcher

    return SequenceMatcher(None, a, b).ratio() * 0.9
