"""Built-in skills. Each module exposes ``@tool`` functions."""

BUILTIN_SKILLS = (
    "jarvis.skills.apps",
    "jarvis.skills.system",
    "jarvis.skills.media",
    "jarvis.skills.whatsapp",
    "jarvis.skills.memory",
    "jarvis.skills.screen",
    "jarvis.skills.routines",
    "jarvis.skills.connectors",
    "jarvis.skills.browser",
    "jarvis.skills.desktop_control",
    "jarvis.skills.info",
    "jarvis.skills.notes",
    "jarvis.skills.focus",
    "jarvis.skills.windows",
    "jarvis.skills.games",
    "jarvis.skills.google_web",
    "jarvis.skills.checks",
    "jarvis.skills.this",
    "jarvis.skills.journal",
    "jarvis.skills.notifications",
    "jarvis.skills.meeting",
    "jarvis.skills.people",
    "jarvis.skills.missions",
    "jarvis.skills.translate",
)

import sys as _sys

if _sys.platform == "darwin":   # same tool names, macOS implementations (registered last: they win)
    BUILTIN_SKILLS += ("jarvis.skills.mac_apps", "jarvis.skills.mac_desktop", "jarvis.skills.mac_whatsapp")
