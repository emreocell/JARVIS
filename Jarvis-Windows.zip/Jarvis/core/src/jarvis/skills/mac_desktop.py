"""macOS: windows, screen text and in-app control through Accessibility (AX) —
same tool names as the Windows UIA versions, so prompts and the Jev router
work unchanged."""

from __future__ import annotations

import asyncio
import subprocess
import tempfile
import time
from pathlib import Path
from typing import Annotated, Any, Literal

from jarvis.platform import mac
from jarvis.tools import Risk, ToolContext, tool

MAC = ("darwin",)
ROLE_KIND = {"AXButton": "Button", "AXTextField": "Edit", "AXTextArea": "Edit", "AXSearchField": "Edit",
             "AXLink": "Hyperlink", "AXMenuItem": "MenuItem", "AXTab": "TabItem", "AXRadioButton": "RadioButton",
             "AXCheckBox": "CheckBox", "AXPopUpButton": "ComboBox", "AXComboBox": "ComboBox", "AXRow": "ListItem",
             "AXCell": "ListItem", "AXMenuButton": "Button", "AXDisclosureTriangle": "Button"}
_elements: dict[int, Any] = {}
_meta: dict[int, dict[str, Any]] = {}


def _target_pid(window: str | None) -> tuple[int, str]:
    if window:
        want = mac.resolve_app(window) or window
        for app in mac.running_apps():
            if app["name"].lower() == want.lower() or want.lower() in app["name"].lower():
                subprocess.run(["open", "-a", app["name"]])
                time.sleep(0.4)
                return app["pid"], app["name"]
        return 0, window
    name, pid = mac.frontmost()
    return pid, name


def snapshot(window: str | None = None) -> dict[str, Any]:
    from jarvis.skills.desktop_control import position

    pid, app = _target_pid(window)
    if not pid:
        return {"error": f"'{window}' açık değil."}
    if not mac.ax_trusted(prompt=True):
        return {"error": "Erişilebilirlik izni gerekiyor: Sistem Ayarları → Gizlilik ve Güvenlik → Erişilebilirlik → Jarvis."}
    win = mac.ax_focused_window(pid)
    if win is None:
        return {"error": f"{app} penceresi bulunamadı."}
    frame = mac.ax_frame(win) or (0, 0, 1, 1)
    _elements.clear()
    _meta.clear()
    n = 0
    for el, _ in mac.ax_walk(win):
        role = str(mac.ax_attr(el, "AXRole") or "")
        kind = ROLE_KIND.get(role)
        if not kind:
            continue
        name = str(mac.ax_attr(el, "AXTitle") or mac.ax_attr(el, "AXDescription") or
                   mac.ax_attr(el, "AXPlaceholderValue") or mac.ax_attr(el, "AXHelp") or "").strip()[:80]
        value = str(mac.ax_attr(el, "AXValue") or "")[:60] if kind == "Edit" else ""
        if not name and kind != "Edit":
            continue
        f = mac.ax_frame(el)
        if f is None or f[2] <= 2 or f[3] <= 2:
            continue
        n += 1
        _elements[n] = el
        cx = (f[0] + f[2] / 2 - frame[0]) / max(1.0, frame[2])
        cy = (f[1] + f[3] / 2 - frame[1]) / max(1.0, frame[3])
        _meta[n] = {"id": n, "type": kind, "name": name or ("metin alanı" if kind == "Edit" else ""), "value": value,
                    "pos": position(cx, cy), "frame": f}
        if n >= 180:
            break
    return {"window": f"{app} — {mac.ax_attr(win, 'AXTitle') or ''}", "items": list(_meta.values())}


def _act(element_id: int, action: str, text: str = "") -> dict[str, Any]:
    el = _elements.get(element_id)
    if el is None:
        return {"error": "Bu numara son okumada yok; önce read_window çağır."}
    if action == "click":
        ok = mac.ax_press(el)
        if not ok:
            f = _meta[element_id].get("frame")
            if f:   # AXPress unsupported: a real click in the middle
                import Quartz

                x, y = f[0] + f[2] / 2, f[1] + f[3] / 2
                for t in (Quartz.kCGEventLeftMouseDown, Quartz.kCGEventLeftMouseUp):
                    ev = Quartz.CGEventCreateMouseEvent(None, t, (x, y), Quartz.kCGMouseButtonLeft)
                    Quartz.CGEventPost(Quartz.kCGHIDEventTap, ev)
        return {"output": "Tamam."}
    mac.ax_focus(el)
    if not mac.ax_set_value(el, text):
        mac.paste_text(text)
    time.sleep(0.15)
    verified = text.strip()[:40] in str(mac.ax_attr(el, "AXValue") or "")
    return {"output": "Tamam.", "verified": verified}


def _format(snap: dict[str, Any]) -> str:
    from jarvis.skills.desktop_control import format_snapshot

    return format_snapshot(snap)


@tool(risk=Risk.READ, category="desktop", timeout=20, platforms=MAC, requires=("ApplicationServices",))
async def read_window(window: Annotated[str | None, "Pencere/uygulama adı; boşsa öndeki pencere"] = None) -> dict:
    """Bir uygulama penceresindeki tıklanabilir/yazılabilir elemanları numaralı olarak listeler."""
    snap = await asyncio.to_thread(snapshot, window)
    return snap if "error" in snap else {"window": _format(snap)}


@tool(risk=Risk.LOW, category="desktop", timeout=20, platforms=MAC, requires=("ApplicationServices",))
async def click_element(element_id: Annotated[int, "read_window çıktısındaki numara"]) -> dict:
    """Pencerede numaralı bir elemana tıklar."""
    return await asyncio.to_thread(_act, element_id, "click")


@tool(risk=Risk.LOW, category="desktop", timeout=20, platforms=MAC, requires=("ApplicationServices",))
async def type_into(element_id: Annotated[int, "Yazı alanının numarası"], text: Annotated[str, "Yazılacak metin"]) -> dict:
    """Pencerede numaralı bir metin alanına yazar."""
    return await asyncio.to_thread(_act, element_id, "type", text)


@tool(risk=Risk.LOW, category="desktop", timeout=10, platforms=MAC)
async def press_keys(keys: Annotated[str, "Tuşlar: 'Enter', 'Cmd+S', 'Cmd+Shift+T'…"]) -> dict:
    """Öndeki uygulamaya klavye kısayolu/tuş gönderir."""
    if {"cmd", "q"} <= {p.strip().lower() for p in keys.split("+")}:
        return {"error": "Cmd+Q yerine close_app kullan (onay ister)."}
    await asyncio.to_thread(mac.osascript, mac.keystroke_script(keys))
    return {"output": f"{keys} gönderildi."}


@tool(risk=Risk.LOW, category="desktop", timeout=10, platforms=MAC)
async def focus_window(name: Annotated[str, "Pencere/uygulama adı"]) -> dict:
    """Açık bir uygulamayı öne getirir."""
    app = mac.resolve_app(name) or name
    await asyncio.to_thread(mac.osascript, f"tell application {mac.as_string(app)} to activate")
    return {"output": f"{app} öne getirildi."}


async def _pick(ctx: ToolContext, window: str | None, instruction: str, roles: tuple[str, ...] | None = None):
    from jarvis.browser import fast
    from jarvis.skills.desktop_control import as_candidates

    snap = await asyncio.to_thread(snapshot, window)
    if "error" in snap:
        return None, snap
    pick = await fast.pick_element(ctx.core, as_candidates(snap), instruction, roles=roles)
    if pick.item is None:
        return None, {"error": "Tarife uyan bir öğe bulamadım."}
    return pick, snap


@tool(risk=Risk.LOW, category="desktop", timeout=25, platforms=MAC, requires=("ApplicationServices",))
async def desktop_do(ctx: ToolContext,
                     instruction: Annotated[str, "Tek tıklama, kullanıcının sözleriyle: 'sağ üstteki ayarlar butonuna tıkla'"],
                     window: Annotated[str | None, "Uygulama adı; boşsa öndeki"] = None) -> dict:
    """Bir uygulamada tarif edilen TEK öğeye hızla tıklar (öğeyi Jev ile ~0.3 sn'de bulur)."""
    from jarvis.skills.browser import RISKY_LABEL

    pick, info = await _pick(ctx, window, instruction)
    if pick is None:
        return info
    label = pick.item.get("label", "")
    if RISKY_LABEL.search(label):
        return {"status": "needs_confirmation", "instruction": f"Kullanıcıya sor: “{label}” butonuna basayım mı?"}
    r = await asyncio.to_thread(_act, pick.item["id"], "click")
    return r if "error" in r else {"output": f"“{label}” öğesine tıkladım.", "decided_by": pick.source}


@tool(risk=Risk.LOW, category="desktop", timeout=25, platforms=MAC, requires=("ApplicationServices",))
async def desktop_type(ctx: ToolContext,
                       field: Annotated[str, "Hangi alan: 'arama kutusu', 'mesaj alanı'"],
                       text: Annotated[str, "Yazılacak metin"],
                       window: Annotated[str | None, "Uygulama adı; boşsa öndeki"] = None,
                       submit: Annotated[bool, "Yazdıktan sonra Enter'a bas"] = False) -> dict:
    """Bir uygulamada tarif edilen metin alanına yazar (alanı Jev ile hızlı bulur)."""
    from jarvis.skills.desktop_control import TEXT_ROLES

    pick, info = await _pick(ctx, window, field, roles=TEXT_ROLES)
    if pick is None:
        return info
    r = await asyncio.to_thread(_act, pick.item["id"], "type", text)
    if "error" in r:
        return r
    if r.get("verified") is False:
        return {"error": "Yazdım ama alanda göremedim."}
    if submit:
        await asyncio.to_thread(mac.osascript, mac.keystroke_script("enter"))
    return {"output": "Yazdım" + (" ve Enter'a bastım." if submit else "."), "decided_by": pick.source}


# ------------------------------------------------------------- windows

@tool(risk=Risk.READ, category="windows", platforms=MAC, requires=("Quartz",))
def list_windows() -> dict:
    """Açık pencereleri listeler."""
    return {"windows": [f"{w['app']} — {w['title']}".strip(" —") for w in mac.window_list()]}


@tool(risk=Risk.LOW, category="windows", platforms=MAC, requires=("AppKit",))
def arrange_window(app: Annotated[str, "Uygulama/pencere adı"],
                   position: Annotated[Literal["left", "right", "top", "bottom", "maximize", "center"], "Konum"]) -> dict:
    """Bir uygulamanın penceresini ekranın soluna/sağına alır, büyütür veya ortalar."""
    name = mac.resolve_app(app) or app
    _, _, sw, sh = mac.screens()[0]
    top = 25   # menu bar
    boxes = {"left": (0, top, sw // 2, sh), "right": (sw // 2, top, sw, sh), "maximize": (0, top, sw, sh),
             "top": (0, top, sw, sh // 2), "bottom": (0, sh // 2, sw, sh),
             "center": (sw // 6, sh // 8, sw * 5 // 6, sh * 7 // 8)}
    x1, y1, x2, y2 = boxes[position]
    try:
        mac.osascript(f'tell application "System Events" to tell process {mac.as_string(name)} to '
                      f"set position of window 1 to {{{x1}, {y1}}}")
        mac.osascript(f'tell application "System Events" to tell process {mac.as_string(name)} to '
                      f"set size of window 1 to {{{x2 - x1}, {y2 - y1}}}")
    except RuntimeError as exc:
        return {"error": f"{name} penceresi taşınamadı: {exc}"}
    return {"output": f"{name} yerleştirildi."}


@tool(risk=Risk.LOW, category="windows", platforms=MAC, requires=("AppKit",))
def side_by_side(left_app: Annotated[str, "Sola gelecek uygulama"], right_app: Annotated[str, "Sağa gelecek uygulama"]) -> dict:
    """İki uygulamayı yan yana yerleştirir."""
    a = arrange_window.__tool__.handler(left_app, "left")  # type: ignore[attr-defined]
    b = arrange_window.__tool__.handler(right_app, "right")  # type: ignore[attr-defined]
    return a if "error" in a else b


@tool(risk=Risk.LOW, category="windows", platforms=MAC)
def show_desktop() -> dict:
    """Masaüstünü gösterir."""
    mac.osascript(mac.keystroke_script("f11"))
    return {"output": "Masaüstü gösteriliyor."}


def _capture(target: str) -> Path:
    path = Path(tempfile.gettempdir()) / f"jarvis-shot-{int(time.time())}.png"
    args = ["screencapture", "-x"]
    if target == "window":
        _, pid = mac.frontmost()
        wins = [w for w in mac.window_list() if w["pid"] == pid]
        if wins:
            w = wins[0]
            args += ["-R", f"{w['x']},{w['y']},{w['w']},{w['h']}"]
    subprocess.run([*args, str(path)], check=False)
    return path


@tool(risk=Risk.LOW, category="windows", platforms=MAC)
def take_screenshot(target: Annotated[Literal["screen", "window"], "Tüm ekran mı, öndeki pencere mi"] = "screen") -> dict:
    """Ekran görüntüsü alır, Resimler klasörüne kaydeder ve panoya kopyalar."""
    tmp = _capture(target)
    dest = Path.home() / "Pictures" / f"Jarvis {time.strftime('%Y-%m-%d %H.%M.%S')}.png"
    dest.parent.mkdir(exist_ok=True)
    tmp.replace(dest)
    subprocess.run(["osascript", "-e", f'set the clipboard to (read (POSIX file "{dest}") as «class PNGf»)'])
    return {"output": f"Ekran görüntüsü kaydedildi: {dest.name}", "path": str(dest)}


def ocr(path: Path) -> str:
    """Text in an image with Apple's Vision framework (on device)."""
    import Vision
    from Foundation import NSURL

    handler = Vision.VNImageRequestHandler.alloc().initWithURL_options_(NSURL.fileURLWithPath_(str(path)), None)
    request = Vision.VNRecognizeTextRequest.alloc().init()
    request.setRecognitionLanguages_(["tr-TR", "en-US"])
    request.setUsesLanguageCorrection_(True)
    handler.performRequests_error_([request], None)
    lines = [obs.topCandidates_(1)[0].string() for obs in (request.results() or [])]
    return "\n".join(str(x) for x in lines)


@tool(risk=Risk.READ, category="screen", timeout=30, platforms=MAC, requires=("Vision",))
async def read_screen_text(target: Annotated[Literal["window", "screen"], "Öndeki pencere mi, tüm ekran mı"] = "window",
                           to_clipboard: Annotated[bool, "Metni panoya da kopyala"] = False) -> dict:
    """Ekrandaki/penceredeki yazıyı cihazda (Apple Vision) okur; istenirse panoya kopyalar."""
    path = await asyncio.to_thread(_capture, target)
    try:
        text = await asyncio.to_thread(ocr, path)
    finally:
        path.unlink(missing_ok=True)
    if to_clipboard:
        mac.clipboard_set(text)
    return {"output": text[:1500] or "Yazı bulunamadı.", "text": text[:8000]}


# --------------------------------------------------------------- "bu"

@tool(risk=Risk.READ, category="screen", timeout=15, platforms=MAC, requires=("ApplicationServices",))
def what_is_this(hint: Annotated[str, "Kullanıcının cümlesi"] = "") -> dict:
    """Kullanıcının "bu / bunu" dediği şeyi bulur: seçili metin, az önce kopyalanan metin ya da aktif pencere."""
    found = []
    sel = mac.ax_selected_text()
    if sel:
        found.append({"kind": "seçili metin", "text": sel[:8000]})
    clip = mac.clipboard_get().strip()
    if clip and clip != sel:
        found.append({"kind": "panodaki metin", "text": clip[:8000]})
    app, _ = mac.frontmost()
    return {"best": found[0] if found else None, "others": found[1:], "window": {"app": app},
            "note": "Kullanıcının 'bu' dediği büyük olasılıkla 'best'; görsel bir şeyse look_at_screen kullan."}


@tool(risk=Risk.LOW, category="screen", timeout=15, platforms=MAC)
def replace_selection(text: Annotated[str, "Seçili metnin yerine yazılacak yeni metin"]) -> dict:
    """Kullanıcının seçili metnini yeni metinle değiştirir (Cmd+Z ile geri alınır)."""
    mac.paste_text(text)
    return {"output": "Seçili metni değiştirdim (Cmd+Z ile geri alınır)."}
