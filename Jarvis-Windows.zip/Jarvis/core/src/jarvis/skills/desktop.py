"""Low-level desktop helpers shared by app skills: windows, keys, clipboard.

Text is entered through the clipboard (paste) or Unicode SendInput, never
``pyautogui.write`` — which silently drops Turkish characters (ı, ş, ğ …).
"""

from __future__ import annotations

import ctypes
import time
from collections.abc import Callable
from contextlib import contextmanager
from ctypes import wintypes
from typing import Any, TypeVar

T = TypeVar("T")

user32 = ctypes.windll.user32 if hasattr(ctypes, "windll") else None
CF_UNICODETEXT = 13


# ---------------------------------------------------------------- clipboard


def _open_clipboard(retries: int = 10) -> bool:
    for _ in range(retries):
        if user32.OpenClipboard(None):
            return True
        time.sleep(0.02)
    return False


def get_clipboard_text() -> str | None:
    kernel32 = ctypes.windll.kernel32
    kernel32.GlobalLock.restype = ctypes.c_void_p
    user32.GetClipboardData.restype = ctypes.c_void_p
    if not _open_clipboard():
        return None
    try:
        handle = user32.GetClipboardData(CF_UNICODETEXT)
        if not handle:
            return None
        ptr = kernel32.GlobalLock(ctypes.c_void_p(handle))
        try:
            return ctypes.wstring_at(ptr) if ptr else None
        finally:
            kernel32.GlobalUnlock(ctypes.c_void_p(handle))
    finally:
        user32.CloseClipboard()


def set_clipboard_text(text: str) -> None:
    kernel32 = ctypes.windll.kernel32
    kernel32.GlobalAlloc.restype = ctypes.c_void_p
    kernel32.GlobalLock.restype = ctypes.c_void_p
    user32.SetClipboardData.argtypes = [wintypes.UINT, ctypes.c_void_p]
    data = text.encode("utf-16-le") + b"\x00\x00"
    handle = kernel32.GlobalAlloc(0x0042, len(data))  # GMEM_MOVEABLE | GMEM_ZEROINIT
    ptr = kernel32.GlobalLock(ctypes.c_void_p(handle))
    ctypes.memmove(ptr, data, len(data))
    kernel32.GlobalUnlock(ctypes.c_void_p(handle))
    if not _open_clipboard():
        raise OSError("clipboard busy")
    try:
        user32.EmptyClipboard()
        user32.SetClipboardData(CF_UNICODETEXT, handle)
    finally:
        user32.CloseClipboard()


@contextmanager
def preserved_clipboard():
    """Restore the user's clipboard text after we used it for pasting."""
    saved = get_clipboard_text()
    try:
        yield
    finally:
        time.sleep(0.15)  # let the target app read the paste first
        if saved is not None:
            try:
                set_clipboard_text(saved)
            except OSError:
                pass
        _clipboard_is_ours()


def _clipboard_is_ours() -> None:
    from jarvis.skills import this

    this.CLIPBOARD["seq"] = int(user32.GetClipboardSequenceNumber())


# --------------------------------------------------------------------- keys


def hotkey(keys: str) -> None:
    """uiautomation SendKeys syntax, e.g. '{Ctrl}f', '{Enter}', '{Ctrl}a{Delete}'."""
    import uiautomation as auto

    auto.SendKeys(keys, interval=0.02, waitTime=0.05)


def paste_text(text: str) -> None:
    set_clipboard_text(text)
    time.sleep(0.05)
    hotkey("{Ctrl}v")


def type_unicode(text: str) -> None:
    """Type any text (Turkish included) with KEYEVENTF_UNICODE SendInput."""

    class KEYBDINPUT(ctypes.Structure):
        _fields_ = [("wVk", wintypes.WORD), ("wScan", wintypes.WORD), ("dwFlags", wintypes.DWORD),
                    ("time", wintypes.DWORD), ("dwExtraInfo", ctypes.POINTER(ctypes.c_ulong))]

    class INPUT(ctypes.Structure):
        class _U(ctypes.Union):
            _fields_ = [("ki", KEYBDINPUT), ("pad", ctypes.c_byte * 32)]
        _anonymous_ = ("u",)
        _fields_ = [("type", wintypes.DWORD), ("u", _U)]

    units = text.encode("utf-16-le")
    codes = [int.from_bytes(units[i:i + 2], "little") for i in range(0, len(units), 2)]
    inputs = []
    for code in codes:
        for flags in (0x0004, 0x0004 | 0x0002):  # KEYEVENTF_UNICODE (| KEYUP)
            inp = INPUT(type=1)
            inp.ki = KEYBDINPUT(0, code, flags, 0, None)
            inputs.append(inp)
    arr = (INPUT * len(inputs))(*inputs)
    user32.SendInput(len(inputs), arr, ctypes.sizeof(INPUT))


def get_selected_text() -> str:
    """Text selected in the foreground app: UIA TextPattern first, then a
    Ctrl+C round-trip that restores the user's clipboard afterwards."""
    try:
        import uiautomation as auto

        with auto.UIAutomationInitializerInThread():
            focused = auto.GetFocusedControl()
            if focused is not None:
                pattern = focused.GetPattern(auto.PatternId.TextPattern)
                if pattern:
                    ranges = pattern.GetSelection()
                    text = "".join(r.GetText(-1) for r in ranges or []).strip()
                    if text:
                        return text
    except Exception:
        pass
    before_seq = user32.GetClipboardSequenceNumber()
    saved = get_clipboard_text()
    try:
        # release the hotkey's modifiers first, otherwise Ctrl+C becomes Ctrl+Alt+C
        for vk in (0x11, 0x12, 0x10, 0x5B):  # ctrl, alt, shift, win
            user32.keybd_event(vk, 0, 0x0002, 0)
        hotkey("{Ctrl}c")
        changed = wait_until(lambda: user32.GetClipboardSequenceNumber() != before_seq, timeout=0.8, interval=0.03)
        return (get_clipboard_text() or "").strip() if changed else ""
    finally:
        time.sleep(0.05)
        if saved is not None:
            try:
                set_clipboard_text(saved)
            except OSError:
                pass
        _clipboard_is_ours()


# ------------------------------------------------------------------ waiting


def wait_until(fn: Callable[[], T], timeout: float = 5.0, interval: float = 0.15) -> T | None:
    """Poll ``fn`` until it returns something truthy (instead of fixed sleeps)."""
    deadline = time.monotonic() + timeout
    while True:
        try:
            value = fn()
        except Exception:
            value = None
        if value:
            return value
        if time.monotonic() >= deadline:
            return None
        time.sleep(interval)


def activate(window: Any) -> None:
    """Bring a uiautomation window to the foreground reliably."""
    try:
        if window.IsMinimize():
            window.ShowWindow(9)  # SW_RESTORE
    except Exception:
        pass
    for fn in (window.SetActive, window.SetFocus):
        try:
            fn()
        except Exception:
            pass
    time.sleep(0.15)


def walk(root: Any, max_depth: int = 20):
    import uiautomation as auto

    for ctrl, depth in auto.WalkControl(root, maxDepth=max_depth):
        yield ctrl, depth
