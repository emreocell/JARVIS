"""Autonomous missions: start, list, cancel."""

from __future__ import annotations

from typing import Annotated

from jarvis.tools import Risk, ToolContext, tool


@tool(risk=Risk.LOW, category="routines", timeout=15, platforms=())
async def start_mission(ctx: ToolContext,
                        goal: Annotated[str, "Kullanıcının hedefi, olduğu gibi ve eksiksiz"]) -> dict:
    """Birden çok adım ve farklı araçlar gerektiren bir işi arka planda otonom görev olarak başlatır
    (araştır + not al + hatırlatıcı kur gibi). Tek araçla biten işler için KULLANMA. Görev Görevler
    sayfasında adım adım görünür; bitince haber verilir, riskli adımlarda onay istenir."""
    engine = getattr(ctx.core, "missions", None)
    if engine is None:
        return {"error": "Görev motoru yok."}
    m = await engine.start(goal)
    return {"output": "Görevi başlattım; plan çıkarıp adım adım ilerliyorum, bitince haber vereceğim.",
            "mission_id": m.id}


@tool(risk=Risk.READ, category="routines", platforms=())
async def list_missions(ctx: ToolContext) -> dict:
    """Otonom görevlerin durumunu listeler: 'görev ne durumda?', 'araştırma bitti mi?'."""
    engine = getattr(ctx.core, "missions", None)
    items = engine.list() if engine else []
    if not items:
        return {"output": "Aktif ya da yakın zamanda bitmiş bir görev yok."}
    return {"missions": [{"id": m["id"], "title": m["title"], "status": m["status"],
                          "done": sum(1 for s in m["steps"] if s["status"] == "done"), "steps": len(m["steps"]),
                          "report": m["report"]} for m in items[:5]]}


@tool(risk=Risk.LOW, category="routines", platforms=())
async def cancel_mission(ctx: ToolContext, mission_id: Annotated[int, "Görev numarası; 0 = en son görev"] = 0) -> dict:
    """Çalışan bir otonom görevi iptal eder."""
    engine = getattr(ctx.core, "missions", None)
    if engine is None or not engine.missions:
        return {"error": "Görev yok."}
    mid = mission_id or max(engine.missions)
    return {"output": "Görevi durdurdum."} if await engine.cancel(mid) else {"error": "Bu görev zaten bitmiş."}
