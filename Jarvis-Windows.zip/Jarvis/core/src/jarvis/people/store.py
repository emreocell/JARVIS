"""Person memory: who is who, and what happened with them.

Built from what already flows through Jarvis — messages and mails it sent,
notifications from people, meetings and their action items, remembered
facts — never by reading the user's chat history. Answers "Ahmet kimdi?",
"en son ne konuşmuştuk?", "ona ne göndermiştim?".
"""

from __future__ import annotations

import json
import sqlite3
import threading
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from jarvis.brain.fast import fold

SCHEMA = """
CREATE TABLE IF NOT EXISTS people (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    key TEXT NOT NULL UNIQUE,
    aliases TEXT NOT NULL DEFAULT '[]',
    relation TEXT NOT NULL DEFAULT '',
    notes TEXT NOT NULL DEFAULT '',
    first_seen REAL NOT NULL,
    last_seen REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS interactions (
    id INTEGER PRIMARY KEY,
    person_id INTEGER NOT NULL,
    ts REAL NOT NULL,
    channel TEXT NOT NULL,
    direction TEXT NOT NULL,
    summary TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS interactions_person ON interactions(person_id, ts);
"""
GROUP_HINTS = ("grup", "group", "ekip", "team", "aile", "sınıf", "kanal")


def person_key(name: str) -> str:
    return " ".join(fold(name).split())


@dataclass(slots=True)
class Person:
    id: int
    name: str
    aliases: list[str]
    relation: str
    notes: str
    first_seen: float
    last_seen: float


class PeopleStore:
    def __init__(self, path: Path) -> None:
        self._lock = threading.Lock()
        self.db = sqlite3.connect(path, check_same_thread=False)
        self.db.executescript(SCHEMA)
        self.db.commit()

    def _row(self, r: tuple) -> Person:
        return Person(r[0], r[1], json.loads(r[2]), r[3], r[4], r[5], r[6])

    def upsert(self, name: str, relation: str = "", notes: str = "", ts: float | None = None) -> Person:
        name = name.strip()
        key = person_key(name)
        now = ts or time.time()
        with self._lock:
            row = self.db.execute("SELECT id, name, aliases, relation, notes, first_seen, last_seen FROM people "
                                  "WHERE key = ?", (key,)).fetchone()
            if row is None:
                cur = self.db.execute("INSERT INTO people(name, key, relation, notes, first_seen, last_seen) "
                                      "VALUES (?,?,?,?,?,?)", (name, key, relation, notes, now, now))
                self.db.commit()
                return Person(int(cur.lastrowid), name, [], relation, notes, now, now)
            p = self._row(row)
            relation = relation or p.relation
            if notes and notes not in p.notes:
                notes = (p.notes + "\n" + notes).strip()
            else:
                notes = p.notes
            self.db.execute("UPDATE people SET relation = ?, notes = ?, last_seen = MAX(last_seen, ?) WHERE id = ?",
                            (relation, notes, now, p.id))
            self.db.commit()
            return Person(p.id, p.name, p.aliases, relation, notes, p.first_seen, max(p.last_seen, now))

    def log(self, name: str, channel: str, direction: str, summary: str, ts: float | None = None) -> None:
        if not name.strip() or any(h in name.lower() for h in GROUP_HINTS) and channel == "whatsapp_group":
            return
        p = self.upsert(name, ts=ts)
        with self._lock:
            self.db.execute("INSERT INTO interactions(person_id, ts, channel, direction, summary) VALUES (?,?,?,?,?)",
                            (p.id, ts or time.time(), channel, direction, summary[:400]))
            self.db.commit()

    def find(self, name: str) -> Person | None:
        from jarvis.skills.text import similarity

        key = person_key(name)
        with self._lock:
            rows = self.db.execute("SELECT id, name, aliases, relation, notes, first_seen, last_seen FROM people").fetchall()
        best, score = None, 0.0
        for r in rows:
            p = self._row(r)
            candidates = [p.name, *p.aliases]
            s = max(similarity(key, person_key(c)) for c in candidates)
            first = person_key(p.name).split()[0] if p.name.strip() else ""
            if key == first:
                s = max(s, 0.9)   # "Ahmet" → "Ahmet Yılmaz"
            if s > score:
                best, score = p, s
        return best if score >= 0.75 else None

    def interactions(self, person_id: int, limit: int = 12) -> list[dict[str, Any]]:
        with self._lock:
            rows = self.db.execute("SELECT ts, channel, direction, summary FROM interactions WHERE person_id = ? "
                                   "ORDER BY ts DESC LIMIT ?", (person_id, limit)).fetchall()
        return [{"time": time.strftime("%d.%m.%Y %H:%M", time.localtime(r[0])), "channel": r[1],
                 "direction": "gelen" if r[2] == "in" else "giden" if r[2] == "out" else r[2], "summary": r[3]}
                for r in rows]

    def recent(self, limit: int = 20) -> list[Person]:
        with self._lock:
            rows = self.db.execute("SELECT id, name, aliases, relation, notes, first_seen, last_seen FROM people "
                                   "ORDER BY last_seen DESC LIMIT ?", (limit,)).fetchall()
        return [self._row(r) for r in rows]
