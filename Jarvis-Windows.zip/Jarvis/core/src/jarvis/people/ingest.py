"""Feeds the person memory from events Jarvis already sees."""

from __future__ import annotations

import logging
from typing import Any

log = logging.getLogger(__name__)

PEOPLE_APPS = {"WhatsApp": "whatsapp", "Telegram": "telegram", "Teams": "teams", "Discord": "discord",
               "Outlook": "mail", "Posta": "mail", "Instagram": "instagram"}


class PeopleIngest:
    def __init__(self, core: Any, store: Any) -> None:
        self.core = core
        self.store = store
        core.bus.subscribe("notification.new", self._on_notification)
        core.tools.after_hooks.append(self._after_tool)

    def _safe(self, fn, *args: Any) -> None:
        try:
            fn(*args)
        except Exception:
            log.debug("people ingest failed", exc_info=True)

    def _on_notification(self, event: Any) -> None:
        d = event.data
        channel = PEOPLE_APPS.get(str(d.get("app")))
        title = str(d.get("title") or "").strip()
        if channel and title and len(title) <= 60:
            self._safe(self.store.log, title, channel, "in", str(d.get("body") or "")[:200])

    def _after_tool(self, name: str, args: dict[str, Any], result: dict[str, Any]) -> None:
        if "error" in result or result.get("status"):
            return
        if name == "send_whatsapp" and result.get("verified") is not False:
            self._safe(self.store.log, str(args.get("contact", "")), "whatsapp", "out", str(args.get("message", "")))
        elif name in ("gmail_send", "gmail_draft"):
            for to in str(args.get("to", "")).split(","):
                if to.strip():
                    verb = "mail gönderildi" if name == "gmail_send" else "mail taslağı"
                    self._safe(self.store.log, to.strip(), "mail", "out",
                               f"{verb}: {args.get('subject', '')} — {str(args.get('body', ''))[:160]}")
        elif name == "stop_meeting_mode":
            s = result.get("summary") or {}
            title = result.get("title") or "toplantı"
            for person in s.get("participants") or []:
                mine = [a.get("task") for a in s.get("action_items", []) if (a.get("owner") or "") == person]
                note = f"'{title}' toplantısı" + (f"; üzerine kalan: {', '.join(mine)}" if mine else "")
                self._safe(self.store.log, person, "toplantı", "birlikte", note)
