"""Start-menu / desktop shortcuts: open Jarvis without typing commands.

``python -m jarvis.shortcuts`` creates both (pythonw — no console window).
"""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path

from jarvis import paths


def icon_path() -> Path:
    from jarvis.desktop.icon import make_icon

    path = paths.data_dir() / "jarvis.ico"
    make_icon(256).save(path, sizes=[(16, 16), (32, 32), (48, 48), (64, 64), (128, 128), (256, 256)])
    return path


def create_mac_app(desktop: bool = True) -> list[str]:
    """~/Applications/Jarvis.app (Launchpad, Spotlight, Dock) + a Desktop alias."""
    import os
    import plistlib
    import stat

    from jarvis.desktop.icon import make_icon

    core = Path(__file__).resolve().parents[2]
    app = Path.home() / "Applications" / "Jarvis.app"
    macos, res = app / "Contents" / "MacOS", app / "Contents" / "Resources"
    macos.mkdir(parents=True, exist_ok=True)
    res.mkdir(parents=True, exist_ok=True)
    launcher = macos / "jarvis"
    launcher.write_text(f'#!/bin/bash\ncd "{core}"\nexec "{sys.executable}" -m jarvis "$@"\n', encoding="utf-8")
    launcher.chmod(launcher.stat().st_mode | stat.S_IEXEC | stat.S_IXGRP | stat.S_IXOTH)
    make_icon(512).save(res / "jarvis.icns")
    with open(app / "Contents" / "Info.plist", "wb") as f:
        plistlib.dump({"CFBundleName": "Jarvis", "CFBundleDisplayName": "Jarvis", "CFBundleExecutable": "jarvis",
                       "CFBundleIdentifier": "com.jarvis.assistant", "CFBundleIconFile": "jarvis.icns",
                       "CFBundlePackageType": "APPL", "CFBundleShortVersionString": "0.1",
                       "NSMicrophoneUsageDescription": "Jarvis seni duyabilmek için mikrofonu kullanır.",
                       "NSAppleEventsUsageDescription": "Jarvis uygulamaları kontrol etmek için Apple Events kullanır.",
                       "LSMinimumSystemVersion": "12.0"}, f)
    made = [str(app)]
    if desktop:
        link = Path.home() / "Desktop" / "Jarvis"
        if not link.exists():
            os.symlink(app, link)
        made.append(str(link))
    return made


def create(desktop: bool = True, start_menu: bool = True) -> list[str]:
    if sys.platform == "darwin":
        return create_mac_app(desktop)
    exe = Path(sys.executable)
    target = exe.with_name("pythonw.exe") if exe.with_name("pythonw.exe").exists() else exe
    workdir = Path(__file__).resolve().parents[2]  # core/
    icon = icon_path()
    folders = []
    if start_menu:
        folders.append("[Environment]::GetFolderPath('Programs')")
    if desktop:
        folders.append("[Environment]::GetFolderPath('Desktop')")
    script = "[Console]::OutputEncoding = [Text.Encoding]::UTF8; $s = New-Object -ComObject WScript.Shell; $out = @()\n"
    for folder in folders:
        script += (
            f"$p = Join-Path ({folder}) 'Jarvis.lnk'; $l = $s.CreateShortcut($p);"
            f" $l.TargetPath = '{target}'; $l.Arguments = '-m jarvis'; $l.WorkingDirectory = '{workdir}';"
            f" $l.IconLocation = '{icon}'; $l.Description = 'Jarvis sesli asistan'; $l.Save(); $out += $p\n"
        )
    script += "$out -join \"`n\""
    out = subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-Command", script],
                         capture_output=True, text=True, encoding="utf-8", timeout=30, check=True)
    made = [line for line in out.stdout.splitlines() if line.strip()]
    try:   # Jarvis' own name/icon on notifications
        from jarvis.desktop.aumid import stamp

        stamp()
    except Exception:
        pass
    return made


if __name__ == "__main__":
    for p in create():
        print("oluşturuldu:", p)
