""""Windows ile başlat": a per-user Run entry that starts Jarvis in the tray.

Only ever touches our own value (``Jarvis`` under HKCU\\...\\Run) and only
deletes it when it points at Jarvis.
"""

from __future__ import annotations

import logging
import sys
from pathlib import Path

log = logging.getLogger(__name__)

RUN_KEY = r"Software\Microsoft\Windows\CurrentVersion\Run"
VALUE = "Jarvis"


def command() -> str:
    """pythonw (no console window) from the same environment, tray mode."""
    exe = Path(sys.executable)
    windowless = exe.with_name("pythonw.exe")
    return f'"{windowless if windowless.exists() else exe}" -m jarvis --tray'


def _winreg():
    import winreg

    return winreg


def current() -> str | None:
    reg = _winreg()
    try:
        with reg.OpenKey(reg.HKEY_CURRENT_USER, RUN_KEY) as key:
            return str(reg.QueryValueEx(key, VALUE)[0])
    except OSError:
        return None


def sync(enabled: bool) -> bool:
    """Make the Run entry match ``enabled``; returns True if anything changed."""
    if sys.platform == "darwin":
        from jarvis.platform.mac import write_launch_agent

        core_dir = str(Path(__file__).resolve().parents[2])
        write_launch_agent("com.jarvis.assistant", [sys.executable, "-m", "jarvis", "--tray"], core_dir, enabled)
        return True
    if sys.platform != "win32":
        return False
    reg = _winreg()
    now = current()
    want = command()
    if enabled and now != want:
        with reg.OpenKey(reg.HKEY_CURRENT_USER, RUN_KEY, 0, reg.KEY_SET_VALUE) as key:
            reg.SetValueEx(key, VALUE, 0, reg.REG_SZ, want)
        log.info("autostart enabled: %s", want)
        return True
    if not enabled and now is not None and "-m jarvis" in now:
        with reg.OpenKey(reg.HKEY_CURRENT_USER, RUN_KEY, 0, reg.KEY_SET_VALUE) as key:
            reg.DeleteValue(key, VALUE)
        log.info("autostart disabled")
        return True
    return False
