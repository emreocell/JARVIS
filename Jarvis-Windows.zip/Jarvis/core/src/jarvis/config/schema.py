"""Typed configuration schema.

The UI renders its settings screens from ``AppConfig.model_json_schema()``,
so every user-facing field carries a Turkish ``title`` and ``description``.
Adding a feature toggle = adding a field here.

Secrets are never stored in this file: API keys are referenced as
``keyring:<name>`` and resolved through :mod:`jarvis.secrets`.
"""

from __future__ import annotations

from enum import StrEnum
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field

CONFIG_VERSION = 2


class _Model(BaseModel):
    model_config = ConfigDict(extra="ignore", validate_assignment=True)


# --------------------------------------------------------------------- voice


class EchoProfile(StrEnum):
    FULL_DUPLEX = "full_duplex"
    HALF_DUPLEX = "half_duplex"
    KEY_ONLY = "key_only"
    AUTO = "auto"


class WakeWord(_Model):
    phrase: str = Field(title="İfade", description="Söylenecek uyandırma ifadesi.")
    engine: Literal["openwakeword", "vosk", "porcupine"] = Field(
        default="openwakeword", title="Motor"
    )
    sensitivity: float = Field(default=0.5, ge=0.05, le=0.95, title="Hassasiyet")
    enabled: bool = Field(default=True, title="Açık")


class VoiceSettings(_Model):
    enabled: bool = Field(
        default=True, title="Sesli asistan",
        description="Kapalıyken mikrofon hiç açılmaz; sadece yazarak kullanılır.",
    )
    mode: Literal["live", "cascade"] = Field(
        default="live",
        title="Ses hattı",
        description=("Live: Gemini Live ile tek bağlantı (en doğal). Kademeli: konuşman yazıya çevrilir, "
                     "cevap metin modelinden gelir ve seslendirilir — Live kotası/bağlantısı gerekmez."),
    )
    cascade_fallback: bool = Field(
        default=True, title="Live çalışmazsa kademeliye geç",
        description="Live bağlanamazsa o konuşma otomatik olarak kademeli hatla yapılır.",
    )
    tts_engine: Literal["edge", "gemini"] = Field(
        default="edge", title="Kademeli ses motoru",
        description="Edge: ücretsiz Microsoft sinirsel sesleri (sınırsız). Gemini: TTS modeli (kotalı).",
    )
    tts_voice: str = Field(default="tr-TR-AhmetNeural", title="Kademeli ses",
                           description="Edge sesi, ör. tr-TR-AhmetNeural veya tr-TR-EmelNeural.")
    echo_profile: EchoProfile = Field(
        default=EchoProfile.AUTO,
        title="Yankı / araya girme",
        description=(
            "Tam çift yönlü: konuşurken sözünü kesebilirsin (kulaklık önerilir). "
            "Yarı çift yönlü: Jarvis konuşurken mikrofon kapanır. "
            "Sadece tuşla: sesle kesme kapalı. Otomatik: çıkış cihazına göre seçer."
        ),
    )
    echo_text_filter: bool = Field(
        default=True,
        title="Yankı metin filtresi",
        description="Duyulan metin Jarvis'in az önce söylediğine benziyorsa yok sayılır.",
    )
    wake_words: list[WakeWord] = Field(
        default_factory=lambda: [WakeWord(phrase="hey jarvis")],
        title="Uyandırma ifadeleri",
    )
    follow_up_seconds: float = Field(
        default=8.0, ge=0, le=60, title="Takip penceresi (sn)",
        description="Cevaptan sonra uyandırma ifadesi olmadan dinlemeye devam etme süresi.",
    )
    session_idle_seconds: float = Field(
        default=30.0, ge=5, le=600, title="Oturum kapanma süresi (sn)",
        description="Bu kadar sessizlikten sonra Live bağlantısı kapatılır.",
    )
    push_to_talk_hotkey: str = Field(default="ctrl+alt+space", title="Bas-konuş kısayolu")
    language: str = Field(default="tr-TR", title="Dil")
    live_model: str = Field(default="gemini-3.8-live", title="Live modeli")
    voice_name: str = Field(default="Charon", title="Ses")
    input_device: str | None = Field(default=None, title="Mikrofon")
    output_device: str | None = Field(default=None, title="Hoparlör")


# ----------------------------------------------------------------- providers


class ProviderType(StrEnum):
    OPENAI_COMPATIBLE = "openai_compatible"
    GEMINI = "gemini"
    TYPESAFE = "typesafe"


class ModelSpec(_Model):
    id: str
    caps: list[str] = Field(default_factory=lambda: ["text"])


class ProviderConfig(_Model):
    id: str = Field(title="Kimlik", pattern=r"^[a-z0-9][a-z0-9_-]{0,39}$")
    type: ProviderType = Field(title="Tür")
    label: str = Field(default="", title="Görünen ad")
    base_url: str | None = Field(default=None, title="Adres")
    keys: list[str] = Field(
        default_factory=list,
        title="API anahtarları",
        description="keyring:<ad> referansları. Birden fazla anahtar havuz olarak kullanılır.",
    )
    models: list[ModelSpec] = Field(default_factory=list, title="Modeller")
    quota_profile: str | None = Field(
        default=None, title="Kota profili",
        description="Bilinen ücretsiz katman limitleri (ör. gemini_free_2026).",
    )
    headers: dict[str, str] = Field(default_factory=dict, title="Ek başlıklar")
    enabled: bool = Field(default=True, title="Açık")


class Role(StrEnum):
    VOICE_BRAIN = "voice_brain"
    FAST_DECIDER = "fast_decider"
    TEXT_WORKER = "text_worker"
    VISION_GROUND = "vision_ground"
    EMBEDDING = "embedding"
    STT = "stt"
    TTS = "tts"


class RouteTarget(_Model):
    provider: str
    model: str


def _default_routes() -> dict[Role, list[RouteTarget]]:
    return {
        Role.VOICE_BRAIN: [RouteTarget(provider="gemini", model="gemini-3.8-live")],
        Role.TEXT_WORKER: [
            RouteTarget(provider="gemini", model="gemini-3.5-flash-lite"),
            RouteTarget(provider="gemini", model="gemini-3.1-flash-lite"),
            RouteTarget(provider="gemini", model="gemma-4-31b-it"),
        ],
        Role.FAST_DECIDER: [RouteTarget(provider="jev", model="typesafe-ai/jev")],
        Role.EMBEDDING: [RouteTarget(provider="gemini", model="gemini-embedding-2")],
        Role.VISION_GROUND: [RouteTarget(provider="gemini", model="gemini-robotics-er-2-preview")],
        Role.STT: [RouteTarget(provider="groq", model="whisper-large-v3-turbo"),
                   RouteTarget(provider="gemini", model="gemini-3.5-flash-lite"),
                   RouteTarget(provider="gemini", model="gemini-3.1-flash-lite")],
        Role.TTS: [RouteTarget(provider="gemini", model="gemini-3.8-flash-lite-tts")],
    }


def _default_providers() -> list[ProviderConfig]:
    return [
        ProviderConfig(
            id="gemini", type=ProviderType.GEMINI, label="Google Gemini",
            quota_profile="gemini_free_2026",
        ),
        ProviderConfig(
            id="groq", type=ProviderType.OPENAI_COMPATIBLE, label="Groq",
            base_url="https://api.groq.com/openai/v1",
            models=[ModelSpec(id="llama-3.3-70b-versatile", caps=["text", "tools"]),
                    ModelSpec(id="whisper-large-v3-turbo", caps=["stt"])],
            enabled=False,
        ),
        ProviderConfig(
            id="jev", type=ProviderType.TYPESAFE, label="Jev (Vercel AI Gateway)",
            base_url="https://ai-gateway.vercel.sh/typesafe",
            models=[ModelSpec(id="typesafe-ai/jev", caps=["decide"])],
            enabled=False,
        ),
    ]


# ------------------------------------------------------------------ features


class BrowserAccess(StrEnum):
    FULL = "full"
    JARVIS_PROFILE = "jarvis_profile"
    OPEN_ONLY = "open_only"


class Features(_Model):
    fast_commands: bool = Field(default=True, title="Hızlı komutlar",
                                description="Basit komutlar LLM'e gitmeden anında çalışır.")
    jev_decider: bool = Field(default=True, title="Jev karar katmanı")
    jev_router: bool = Field(default=True, title="Jev niyet yönlendirici",
                             description="Yazılı ve kademeli sesli komutlarda işi önce Jev yönlendirir: basit işler "
                                         "modele hiç gitmeden yapılır, diğerlerinde model daha az araçla hızlı çalışır.")
    jev_shadow_mode: bool = Field(
        default=True, title="Jev gölge modu",
        description="Jev çalışır ama kararı kullanılmaz; sadece LLM ile karşılaştırılır.",
    )
    morning_brief: bool = Field(default=True, title="Sabah özeti",
                                description="Sabah bilgisayarın başına ilk geldiğinde Jarvis günaydın der; hava, "
                                            "takvim, okunmamış mailler ve hatırlatıcıları kısaca anlatır.")
    proactive: bool = Field(default=True, title="Proaktif Jarvis",
                            description="Önemli bir şey olduğunda (önemli mesaj, sen yokken gelenler, pil) sen "
                                        "sormadan kısaca söyler. Oyun, görüşme ve toplantı modunda susar.")
    break_reminders: bool = Field(default=False, title="Mola hatırlatıcı",
                                  description="İki saat ara vermeden çalışınca kısa bir mola önerir.")
    hud: bool = Field(default=True, title="Ekran üstü işaretler (HUD)",
                      description="Jarvis tıkladığı ya da gösterdiği yeri ekranın üstünde kısa bir halka ve "
                                  "çerçeveyle işaretler.")
    sound_events: bool = Field(default=False, title="Ses olaylarını tanı (deneysel)",
                               description="Telefon zili, kapı zili, alarm gibi sesleri fark eder; telefon çalınca "
                                           "Jarvis susar. Açınca ~15 MB'lık YAMNet modeli (Google AudioSet, Apache-2.0; "
                                           "Hugging Face andrelgomes/yamnet-onnx) indirilir.")
    notification_intel: bool = Field(default=True, title="Bildirim zekası",
                                     description="Windows bildirimlerini hatırlar ve Jev ile önemli / önemsiz diye "
                                                 "ayırır: 'ben yokken ne oldu?'")
    context_tracker: bool = Field(default=True, title="Bağlam izleyici",
                                  description="Hangi uygulama/projede çalıştığını yerelde kaydeder.")
    memory_auto_extract: bool = Field(default=True, title="Otomatik hafıza")
    clipboard_history: bool = Field(default=True, title="Pano geçmişi")
    selection_actions: bool = Field(default=True, title="Seçili metin eylemleri")
    telegram_remote: bool = Field(default=False, title="Telegram ile uzaktan kontrol")
    browser_access: BrowserAccess = Field(default=BrowserAccess.JARVIS_PROFILE, title="Tarayıcı erişimi")
    sound_effects: bool = Field(default=True, title="Ses efektleri")


class PrivacySettings(_Model):
    privacy_mode: bool = Field(
        default=False, title="Gizlilik modu",
        description="Mikrofon, bağlam izleyici, loglar ve hafıza yazımı durur.",
    )
    excluded_apps: list[str] = Field(
        default_factory=lambda: ["KeePass", "1Password", "Bitwarden"],
        title="Hariç tutulan uygulamalar",
    )


class UISettings(_Model):
    theme: Literal["dark", "light", "system"] = Field(default="light", title="Tema")
    accent: str = Field(default="#7c5cff", title="Vurgu rengi")
    locale: Literal["tr", "en"] = Field(default="tr", title="Arayüz dili")
    command_bar_hotkey: str = Field(default="alt+space", title="Komut çubuğu kısayolu")
    selection_hotkey: str = Field(default="ctrl+alt+j", title="Seçili metin kısayolu",
                                  description="Herhangi bir uygulamada seçtiğin metni Jarvis'e getirir.")
    start_with_windows: bool = Field(default=False, title="Windows ile başlat")
    quiet_hours: tuple[int, int] = Field(default=(23, 8), title="Sessiz saatler",
                                         description="Bu saatler arasında Jarvis kendiliğinden konuşmaz (yalnızca acil).")


class RemoteSettings(_Model):
    telegram_allowed_ids: list[int] = Field(default_factory=list, title="İzinli Telegram hesapları")
    forward_questions: bool = Field(
        default=True, title="Soruları telefona gönder",
        description="'Önce sor' rutinleri ve onay istekleri Telegram'a Evet/Hayır butonlarıyla da gelir.",
    )
    forward_reminders: bool = Field(default=True, title="Hatırlatıcıları telefona gönder")


class IntegrationsSettings(_Model):
    spotify_client_id: str = Field(
        default="", title="Spotify Client ID",
        description="developer.spotify.com'da oluşturduğun uygulamanın Client ID'si (Premium özellikler için).",
    )


class McpServerConfig(_Model):
    id: str = Field(title="Kimlik", pattern=r"^[a-z0-9][a-z0-9_]{0,19}$")
    name: str = Field(default="", title="Ad")
    preset: str = Field(default="", title="Hazır ayar")
    command: str = Field(title="Komut", description="'uvx' Jarvis'in kendi uvx'ini kullanır.")
    args: list[str] = Field(default_factory=list, title="Argümanlar")
    env: dict[str, str] = Field(default_factory=dict, title="Ortam değişkenleri",
                                description="Gizli değerler 'keyring:ad' biçiminde saklanır.")
    enabled: bool = Field(default=True, title="Açık")
    disabled_tools: list[str] = Field(default_factory=list, title="Kapalı araçlar")


class McpSettings(_Model):
    servers: list[McpServerConfig] = Field(default_factory=list, title="Sunucular")


class DictEntry(_Model):
    term: str = Field(title="Doğru yazılış")
    sounds_like: list[str] = Field(default_factory=list, title="Nasıl duyulabilir")
    note: str = Field(default="", title="Not")


class AssistantSettings(_Model):
    name: str = Field(default="Jarvis", title="Asistanın adı")
    user_name: str = Field(default="", title="Senin adın", description="Jarvis sana bu adla hitap eder.")
    location: str = Field(default="", title="Konum",
                          description="Hava durumu için şehir/ilçe. Boş bırakırsan yaklaşık konum otomatik bulunur.")
    user_rules: str = Field(
        default="", title="Kurallarım",
        description="Jarvis'in her zaman uyacağı kişisel kurallar (ör. 'bana kısaca cevap ver').",
    )
    dictionary: list[DictEntry] = Field(default_factory=list, title="Kişisel sözlük",
                                        description="Jarvis'in asla yanlış anlamaması gereken isimler ve terimler.")
    second_brain_dir: str = Field(default="", title="İkinci beyin klasörü",
                                  description="Jarvis'in günlükleri ve notları Markdown olarak kaydettiği klasör "
                                              "(Obsidian kasası olabilir). Boşsa Belgeler/Jarvis Beyin.")


def migrate(raw: dict) -> dict:
    """Upgrade an older config.json in place (dict level, before validation)."""
    version = int(raw.get("version") or 1)
    if version < 2:
        routes = raw.setdefault("routes", {})
        # v1 default pointed STT at a Live-only model, unusable over REST
        if routes.get("stt") == [{"provider": "gemini", "model": "gemini-3.5-transcribe-live"}]:
            routes.pop("stt")
        for p in raw.get("providers", []):
            if p.get("id") == "groq" and not any(m.get("id", "").startswith("whisper") for m in p.get("models", [])):
                p.setdefault("models", []).append({"id": "whisper-large-v3-turbo", "caps": ["stt"]})
    # roles added in later versions get their defaults
    routes = raw.setdefault("routes", {})
    for role, targets in _default_routes().items():
        routes.setdefault(role.value, [t.model_dump() for t in targets])
    raw["version"] = CONFIG_VERSION
    return raw


class AppConfig(_Model):
    version: int = CONFIG_VERSION
    assistant: AssistantSettings = Field(default_factory=AssistantSettings, title="Asistan")
    voice: VoiceSettings = Field(default_factory=VoiceSettings, title="Ses")
    providers: list[ProviderConfig] = Field(default_factory=_default_providers, title="Sağlayıcılar")
    routes: dict[Role, list[RouteTarget]] = Field(default_factory=_default_routes, title="Roller")
    features: Features = Field(default_factory=Features, title="Özellikler")
    privacy: PrivacySettings = Field(default_factory=PrivacySettings, title="Gizlilik")
    remote: RemoteSettings = Field(default_factory=RemoteSettings, title="Uzaktan kontrol")
    integrations: IntegrationsSettings = Field(default_factory=IntegrationsSettings, title="Entegrasyonlar")
    mcp: McpSettings = Field(default_factory=McpSettings, title="MCP bağlantıları")
    ui: UISettings = Field(default_factory=UISettings, title="Arayüz")

    def provider(self, provider_id: str) -> ProviderConfig | None:
        return next((p for p in self.providers if p.id == provider_id), None)
