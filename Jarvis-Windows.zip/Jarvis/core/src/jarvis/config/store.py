"""Load, validate, patch and persist :class:`AppConfig`."""

from __future__ import annotations

import asyncio
import copy
import json
import logging
import time
from pathlib import Path
from typing import Any

from pydantic import ValidationError

from jarvis.bus import EventBus
from jarvis.config.schema import CONFIG_VERSION, AppConfig, migrate
from jarvis.fsutil import atomic_write_json, read_json

log = logging.getLogger(__name__)


def deep_merge(base: dict[str, Any], patch: dict[str, Any]) -> dict[str, Any]:
    """Recursively merge ``patch`` into a copy of ``base``.

    Dicts merge; everything else (lists included) is replaced wholesale, so a
    patch can remove list items.
    """
    out = copy.deepcopy(base)
    for key, value in patch.items():
        if isinstance(value, dict) and isinstance(out.get(key), dict):
            out[key] = deep_merge(out[key], value)
        else:
            out[key] = copy.deepcopy(value)
    return out


class ConfigStore:
    def __init__(self, path: Path, bus: EventBus | None = None) -> None:
        self.path = path
        self.bus = bus
        self._config = AppConfig()
        self._lock = asyncio.Lock()

    @property
    def config(self) -> AppConfig:
        return self._config

    def load(self) -> AppConfig:
        if not self.path.exists():
            self._config = AppConfig()
            self._write()
            return self._config
        try:
            raw = read_json(self.path)
            upgraded = int(raw.get("version") or 1) < CONFIG_VERSION
            self._config = AppConfig.model_validate(migrate(raw))
            if upgraded:
                log.info("config migrated to v%d", CONFIG_VERSION)
                self._write()
        except (json.JSONDecodeError, ValidationError, UnicodeDecodeError) as exc:
            backup = self.path.with_suffix(f".invalid-{time.strftime('%Y%m%d-%H%M%S')}.json")
            self.path.replace(backup)
            log.error("config invalid (%s); backed up to %s and reset to defaults", exc, backup)
            self._config = AppConfig()
            self._write()
        return self._config

    def _write(self) -> None:
        atomic_write_json(self.path, self._config.model_dump(mode="json"))

    async def patch(self, patch: dict[str, Any]) -> AppConfig:
        """Apply a partial update. Raises ``ValidationError`` and keeps the
        old config if the result is invalid."""
        async with self._lock:
            merged = deep_merge(self._config.model_dump(mode="json"), patch)
            new = AppConfig.model_validate(merged)
            old = self._config
            self._config = new
            self._write()
        if self.bus:
            await self.bus.publish(
                "config.changed",
                patch=patch,
                sections=sorted(k for k in patch if getattr(old, k, None) != getattr(new, k, None)),
            )
        return new

    async def replace(self, config: AppConfig) -> AppConfig:
        return await self.patch(config.model_dump(mode="json"))
