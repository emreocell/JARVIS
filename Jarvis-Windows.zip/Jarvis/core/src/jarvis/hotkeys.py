"""System-wide hotkeys via RegisterHotKey (no low-level keyboard hook).

Runs a tiny message loop on its own thread; each hotkey publishes a bus event
(``hotkey.<name>``) on the core's loop.
"""

from __future__ import annotations

import ctypes
import logging
import threading
from collections.abc import Callable
from ctypes import wintypes

log = logging.getLogger(__name__)

MOD = {"alt": 0x0001, "ctrl": 0x0002, "control": 0x0002, "shift": 0x0004, "win": 0x0008}
MOD_NOREPEAT = 0x4000
WM_HOTKEY, WM_QUIT = 0x0312, 0x0012
VK_NAMED = {"space": 0x20, "enter": 0x0D, "tab": 0x09, "esc": 0x1B, "escape": 0x1B,
            **{f"f{i}": 0x6F + i for i in range(1, 13)}}


def parse(combo: str) -> tuple[int, int]:
    """'ctrl+alt+space' -> (modifiers, virtual key)."""
    mods, vk = MOD_NOREPEAT, 0
    for part in (p.strip().lower() for p in combo.split("+") if p.strip()):
        if part in MOD:
            mods |= MOD[part]
        elif part in VK_NAMED:
            vk = VK_NAMED[part]
        elif len(part) == 1:
            vk = ord(part.upper())
        else:
            raise ValueError(f"unknown key: {part}")
    if not vk:
        raise ValueError(f"no key in {combo!r}")
    return mods, vk


class HotkeyManager:
    def __init__(self, on_hotkey: Callable[[str], None]) -> None:
        self.on_hotkey = on_hotkey
        self._bindings: dict[str, str] = {}
        self._thread: threading.Thread | None = None
        self._thread_id = 0
        self.failed: dict[str, str] = {}
        self._ready = threading.Event()

    def start(self, bindings: dict[str, str]) -> None:
        """``bindings``: name -> combo (e.g. {'wake': 'ctrl+alt+space'})."""
        import sys

        if sys.platform == "darwin":
            self._start_mac(bindings)
            return
        self.stop()
        self._bindings = dict(bindings)
        self._ready.clear()
        self._thread = threading.Thread(target=self._run, name="hotkeys", daemon=True)
        self._thread.start()
        self._ready.wait(2)

    def _run(self) -> None:
        user32 = ctypes.windll.user32
        self._thread_id = ctypes.windll.kernel32.GetCurrentThreadId()
        ids: dict[int, str] = {}
        self.failed = {}
        for i, (name, combo) in enumerate(self._bindings.items(), start=1):
            try:
                mods, vk = parse(combo)
            except ValueError as exc:
                self.failed[name] = str(exc)
                continue
            if user32.RegisterHotKey(None, i, mods, vk):
                ids[i] = name
            else:
                self.failed[name] = f"{combo} başka bir uygulama tarafından kullanılıyor"
        if self.failed:
            log.warning("hotkeys not registered: %s", self.failed)
        self._ready.set()
        msg = wintypes.MSG()
        while user32.GetMessageW(ctypes.byref(msg), None, 0, 0) > 0:
            if msg.message == WM_HOTKEY and msg.wParam in ids:
                try:
                    self.on_hotkey(ids[msg.wParam])
                except Exception:
                    log.exception("hotkey handler failed")
        for i in ids:
            user32.UnregisterHotKey(None, i)

    def _start_mac(self, bindings: dict[str, str]) -> None:
        """macOS: pynput global hotkeys (needs Input Monitoring / Accessibility permission).
        Windows habits map over: win → cmd."""
        from pynput import keyboard

        self.stop()
        mapping = {}
        self.failed = {}
        for name, combo in bindings.items():
            parts = []
            for p in (x.strip().lower() for x in combo.split("+") if x.strip()):
                p = {"win": "cmd", "control": "ctrl", "option": "alt", "escape": "esc"}.get(p, p)
                parts.append(f"<{p}>" if len(p) > 1 else p)
            mapping["+".join(parts)] = (lambda n=name: self.on_hotkey(n))
        try:
            self._mac = keyboard.GlobalHotKeys(mapping)
            self._mac.start()
        except Exception as exc:
            self.failed = {n: f"kısayol kaydedilemedi: {exc}" for n in bindings}

    def stop(self) -> None:
        mac = getattr(self, "_mac", None)
        if mac is not None:
            mac.stop()
            self._mac = None
        if self._thread and self._thread_id:
            ctypes.windll.user32.PostThreadMessageW(self._thread_id, WM_QUIT, 0, 0)
            self._thread.join(2)
        self._thread = None
