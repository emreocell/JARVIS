"""AI / coding tool connectors, defined as data (YAML) so users can add their own.

Kinds:
* ``cli``    — run a command line with ``{prompt}`` (and ``{project}``) filled in,
               in the project folder, in the background; the output is announced
               when it finishes (Claude Code, opencode, Codex, Gemini CLI).
* ``window`` — bring an app to the front, open its chat with a hotkey, paste the
               prompt and send (VS Code, Antigravity, Zed, Cursor, ChatGPT app).
* ``url``    — open a web app with the prompt in the URL, in the user's own
               browser session (ChatGPT, Claude, Perplexity).

Built-ins live here; ``%LOCALAPPDATA%\\Jarvis\\connectors.yaml`` overrides or
extends them (same keys).
"""

from __future__ import annotations

import logging
import os
import shutil
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Literal

import yaml

from jarvis import paths

log = logging.getLogger(__name__)

Kind = Literal["cli", "window", "url"]


@dataclass(slots=True)
class Connector:
    id: str
    name: str
    kind: Kind
    aliases: list[str] = field(default_factory=list)
    # cli
    command: list[str] = field(default_factory=list)     # argv; "{prompt}" / "{project}" are substituted
    needs_project: bool = False
    timeout: int = 900
    # window
    app: str = ""                    # name for open_app when not running
    window: str = ""                 # substring of the window title
    open_chat: str = ""              # uiautomation SendKeys syntax, e.g. "{Ctrl}{Alt}i"
    submit: str = "{Enter}"
    # url
    url: str = ""                    # "{prompt}" is URL-encoded
    note: str = ""

    def available(self) -> tuple[bool, str]:
        if self.kind == "cli":
            exe = self.command[0] if self.command else ""
            return (shutil.which(exe) is not None, f"'{exe}' PATH'te bulunamadı" if exe else "komut yok")
        if self.kind == "window" and self.app and sys.platform == "win32":
            try:
                from jarvis.skills.apps import confident_app

                if not confident_app(self.app):
                    return False, f"{self.app} bu bilgisayarda yüklü görünmüyor"
            except Exception:
                pass  # index unavailable: let the send attempt report the problem
        return True, ""

    def as_dict(self) -> dict[str, Any]:
        ok, why = self.available()
        return {"id": self.id, "name": self.name, "kind": self.kind, "aliases": self.aliases,
                "available": ok, "reason": why, "note": self.note}


BUILTIN: list[dict[str, Any]] = [
    {"id": "claude-code", "name": "Claude Code", "kind": "cli", "aliases": ["claude", "claude code"],
     "command": ["claude", "-p", "{prompt}"], "needs_project": True},
    {"id": "opencode", "name": "opencode", "kind": "cli", "aliases": ["open code", "opencode"],
     "command": ["opencode", "run", "{prompt}"], "needs_project": True},
    {"id": "codex", "name": "Codex CLI", "kind": "cli", "aliases": ["codex"],
     "command": ["codex", "exec", "{prompt}"], "needs_project": True},
    {"id": "gemini-cli", "name": "Gemini CLI", "kind": "cli", "aliases": ["gemini cli"],
     "command": ["gemini", "-p", "{prompt}"], "needs_project": True},
    {"id": "vscode", "name": "VS Code (Copilot Chat)", "kind": "window", "aliases": ["vs code", "vscode", "copilot"],
     "app": "Visual Studio Code", "window": "Visual Studio Code", "open_chat": "{Ctrl}{Alt}i"},
    {"id": "cursor", "name": "Cursor", "kind": "window", "aliases": ["cursor"],
     "app": "Cursor", "window": "Cursor", "open_chat": "{Ctrl}l"},
    {"id": "antigravity", "name": "Antigravity", "kind": "window", "aliases": ["antigravity"],
     "app": "Antigravity", "window": "Antigravity", "open_chat": "{Ctrl}l",
     "note": "Sohbet kısayolu farklıysa connectors.yaml'da open_chat'i değiştir."},
    {"id": "zed", "name": "Zed", "kind": "window", "aliases": ["zed"],
     "app": "Zed", "window": "Zed", "open_chat": "{Ctrl}?",
     "note": "Zed'in agent paneli kısayolunu kendi ayarına göre güncelle."},
    {"id": "chatgpt", "name": "ChatGPT (web)", "kind": "url", "aliases": ["chatgpt", "chat gpt", "gpt"],
     "url": "https://chatgpt.com/?q={prompt}"},
    {"id": "claude-web", "name": "Claude (web)", "kind": "url", "aliases": ["claude.ai", "claude web"],
     "url": "https://claude.ai/new?q={prompt}"},
    {"id": "perplexity", "name": "Perplexity", "kind": "url", "aliases": ["perplexity"],
     "url": "https://www.perplexity.ai/search?q={prompt}"},
]


def user_file() -> Path:
    return paths.data_dir() / "connectors.yaml"


def load_connectors() -> dict[str, Connector]:
    items: dict[str, dict[str, Any]] = {c["id"]: dict(c) for c in BUILTIN}
    f = user_file()
    if f.exists():
        try:
            data = yaml.safe_load(f.read_text(encoding="utf-8-sig")) or {}
            for entry in data.get("connectors", []):
                if isinstance(entry, dict) and entry.get("id"):
                    items[entry["id"]] = {**items.get(entry["id"], {}), **entry}
        except yaml.YAMLError as exc:
            log.error("connectors.yaml invalid: %s", exc)
    out: dict[str, Connector] = {}
    for cid, entry in items.items():
        try:
            out[cid] = Connector(**{k: v for k, v in entry.items() if k in Connector.__dataclass_fields__})
        except TypeError as exc:
            log.warning("connector %s skipped: %s", cid, exc)
    return out


def write_example() -> Path:
    """Create a commented connectors.yaml the user can edit."""
    f = user_file()
    if not f.exists():
        f.write_text(
            "# Jarvis bağlayıcıları — yerleşikleri değiştir ya da yenilerini ekle.\n"
            "# kind: cli | window | url ; {prompt} ve {project} yer tutucudur.\n"
            "connectors:\n"
            "  # - id: aider\n"
            "  #   name: Aider\n"
            "  #   kind: cli\n"
            "  #   aliases: [aider]\n"
            "  #   command: [aider, --message, \"{prompt}\"]\n"
            "  #   needs_project: true\n"
            "  # - id: antigravity\n"
            "  #   open_chat: \"{Ctrl}{Shift}l\"\n",
            encoding="utf-8")
    return f


def find_project_dir(name: str) -> Path | None:
    """Locate a project folder by name in the usual places (git repos first)."""
    if not name:
        return None
    direct = Path(os.path.expandvars(os.path.expanduser(name)))
    if direct.is_dir():
        return direct
    home = Path(os.environ.get("USERPROFILE", Path.home()))
    roots = [Path("C:/dev"), home / "dev", home / "projects", home / "source" / "repos", home / "Desktop",
             home / "Documents", home / "OneDrive" / "Masaüstü", home / "OneDrive" / "Desktop",
             home / "OneDrive" / "Belgeler"]
    target = name.lower()
    best: Path | None = None
    for root in roots:
        if not root.is_dir():
            continue
        for depth_dir in [root, *[p for p in root.iterdir() if p.is_dir()]][:200]:
            candidates = [depth_dir] if depth_dir.name.lower() == target else []
            if depth_dir is not root:
                try:
                    candidates += [p for p in depth_dir.iterdir() if p.is_dir() and p.name.lower() == target]
                except OSError:
                    continue
            for c in candidates:
                if (c / ".git").exists():
                    return c
                best = best or c
    return best
