@echo off
rem Jarvis'i konsol penceresi olmadan baslatir.
start "" /d "%~dp0core" "%~dp0core\.venv\Scripts\pythonw.exe" -m jarvis
