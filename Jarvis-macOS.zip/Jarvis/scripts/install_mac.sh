#!/bin/bash
# Jarvis kurulumu (macOS): eksik olanları kurar, Jarvis'i hazırlar, uygulamayı ve kısayolu oluşturur.
# Çalıştırma: Kur.command'a çift tıkla  ya da:  bash scripts/install_mac.sh [--no-launch] [--autostart yes|no]
set -euo pipefail

NO_LAUNCH=0
AUTOSTART=ask
while [[ $# -gt 0 ]]; do
  case "$1" in
    --no-launch) NO_LAUNCH=1 ;;
    --autostart) AUTOSTART="${2:-ask}"; shift ;;
  esac
  shift
done

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
CORE="$ROOT/core"
APP="$ROOT/app"
step() { printf "\n\033[36m==> %s\033[0m\n" "$1"; }
ok()   { printf "    \033[32m✓ %s\033[0m\n" "$1"; }
warn() { printf "    \033[33m! %s\033[0m\n" "$1"; }
have() { command -v "$1" >/dev/null 2>&1; }

printf "\033[35mJarvis kurulumu (macOS)\033[0m\nKlasör: %s\n" "$ROOT"

step "Sistem"
VER="$(sw_vers -productVersion)"
MAJOR="${VER%%.*}"
if [[ "$MAJOR" -lt 12 ]]; then echo "Jarvis macOS 12 veya üstünü gerektirir (bu Mac: $VER)."; exit 1; fi
ok "macOS $VER ($(uname -m))"

step "Python 3.12"
PY=""
for c in python3.12 python3.13 python3; do
  if have "$c" && "$c" -c 'import sys; sys.exit(0 if (3,12) <= sys.version_info[:2] < (3,14) else 1)' 2>/dev/null; then
    PY="$(command -v "$c")"; break
  fi
done
if [[ -z "$PY" ]]; then
  if have brew; then
    echo "    Python 3.12 kuruluyor (Homebrew)…"
    brew install python@3.12
    PY="$(brew --prefix)/bin/python3.12"
  else
    echo "Python 3.12 gerekli. https://www.python.org/downloads/macos/ adresinden kurup bu betiği tekrar çalıştır"
    echo "(ya da Homebrew kur: https://brew.sh)."
    exit 1
  fi
fi
ok "$PY"

step "Python paketleri (uv)"
if ! "$PY" -m uv --version >/dev/null 2>&1; then
  if have brew; then brew install uv; UV="uv"; else "$PY" -m pip install --user --quiet uv; UV="$PY -m uv"; fi
else
  UV="$PY -m uv"
fi
(cd "$CORE" && $UV sync --python "$PY")
ok "Bağımlılıklar hazır"
VENV_PY="$CORE/.venv/bin/python"

step "Arayüz"
if [[ -f "$APP/dist/index.html" ]]; then
  ok "Hazır (app/dist)"
else
  if ! have npm; then
    if have brew; then brew install node; else echo "Node.js gerekli: https://nodejs.org"; exit 1; fi
  fi
  (cd "$APP" && npm ci --no-audit --no-fund && npx vite build)
  ok "Derlendi"
fi

step "Uygulama ve kısayol"
(cd "$CORE" && "$VENV_PY" -m jarvis.shortcuts)
ok "~/Applications/Jarvis.app ve masaüstüne kısayol eklendi"

if [[ "$AUTOSTART" == "ask" ]]; then
  read -r -p $'\nJarvis Mac açılınca otomatik başlasın mı? (E/h) ' ans || ans=""
  [[ -z "$ans" || "$ans" =~ ^[eEyY] ]] && AUTOSTART=yes || AUTOSTART=no
fi
if [[ "$AUTOSTART" == "yes" ]]; then
  (cd "$CORE" && "$VENV_PY" - <<'PYEOF'
import json, os
from jarvis import autostart, paths
autostart.sync(True)
p = paths.config_path()
c = json.load(open(p, encoding="utf-8-sig")) if os.path.exists(p) else {}
c.setdefault("ui", {})["start_with_windows"] = True
json.dump(c, open(p, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
PYEOF
  )
  ok "Otomatik başlatma açık"
fi

step "İzinler"
cat <<'TXT'
    İlk kullanımda macOS şu izinleri soracak (Sistem Ayarları → Gizlilik ve Güvenlik):
      • Mikrofon              — seni duyabilmesi için
      • Erişilebilirlik       — uygulamalarda tıklama/yazma, pencere başlıkları
      • Ekran Kaydı           — ekrana bakma ve ekran görüntüsü
      • Otomasyon             — Spotify, Müzik ve System Events kontrolü
      • Giriş İzleme          — kısayol tuşları (Option+Space)
TXT
open "x-apple.systempreferences:com.apple.settings.PrivacySecurity.extension" >/dev/null 2>&1 || true

printf "\n\033[35mKurulum tamam.\033[0m\n"
if [[ "$NO_LAUNCH" -eq 0 ]]; then
  echo "Jarvis açılıyor…"
  open "$HOME/Applications/Jarvis.app"
fi
echo "İlk açılışta Modeller sayfasından bir Gemini API anahtarı eklemen yeterli."
