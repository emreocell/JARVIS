#!/bin/bash
# Jarvis kurulumu: çift tıkla (ilk seferde: sağ tık → Aç).
cd "$(dirname "$0")"
bash scripts/install_mac.sh
read -r -p "Kapatmak için Enter..." _
