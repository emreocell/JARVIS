#!/bin/bash
# Jarvis'i başlat.
cd "$(dirname "$0")/core"
nohup ./.venv/bin/python -m jarvis >/dev/null 2>&1 &
